var recordData = [
    {
        "length": 2550,
        "seq_id": "NZ_NHSD01000001",
        "regions": []
    },
    {
        "length": 2567,
        "seq_id": "NZ_NHSD01000002",
        "regions": []
    },
    {
        "length": 2513,
        "seq_id": "NZ_NHSD01000003",
        "regions": []
    },
    {
        "length": 2611,
        "seq_id": "NZ_NHSD01000004",
        "regions": []
    },
    {
        "length": 3019,
        "seq_id": "NZ_NHSD01000005",
        "regions": []
    },
    {
        "length": 2583,
        "seq_id": "NZ_NHSD01000006",
        "regions": []
    },
    {
        "length": 2589,
        "seq_id": "NZ_NHSD01000007",
        "regions": []
    },
    {
        "length": 2627,
        "seq_id": "NZ_NHSD01000008",
        "regions": []
    },
    {
        "length": 2688,
        "seq_id": "NZ_NHSD01000009",
        "regions": []
    },
    {
        "length": 2752,
        "seq_id": "NZ_NHSD01000010",
        "regions": []
    },
    {
        "length": 2763,
        "seq_id": "NZ_NHSD01000011",
        "regions": []
    },
    {
        "length": 2937,
        "seq_id": "NZ_NHSD01000012",
        "regions": []
    },
    {
        "length": 3200,
        "seq_id": "NZ_NHSD01000013",
        "regions": []
    },
    {
        "length": 2577,
        "seq_id": "NZ_NHSD01000014",
        "regions": []
    },
    {
        "length": 2599,
        "seq_id": "NZ_NHSD01000015",
        "regions": []
    },
    {
        "length": 2594,
        "seq_id": "NZ_NHSD01000016",
        "regions": []
    },
    {
        "length": 2610,
        "seq_id": "NZ_NHSD01000017",
        "regions": []
    },
    {
        "length": 2612,
        "seq_id": "NZ_NHSD01000018",
        "regions": []
    },
    {
        "length": 2657,
        "seq_id": "NZ_NHSD01000019",
        "regions": []
    },
    {
        "length": 2653,
        "seq_id": "NZ_NHSD01000020",
        "regions": []
    },
    {
        "length": 2693,
        "seq_id": "NZ_NHSD01000021",
        "regions": []
    },
    {
        "length": 2758,
        "seq_id": "NZ_NHSD01000022",
        "regions": []
    },
    {
        "length": 2780,
        "seq_id": "NZ_NHSD01000023",
        "regions": []
    },
    {
        "length": 2817,
        "seq_id": "NZ_NHSD01000024",
        "regions": []
    },
    {
        "length": 2820,
        "seq_id": "NZ_NHSD01000025",
        "regions": []
    },
    {
        "length": 2861,
        "seq_id": "NZ_NHSD01000026",
        "regions": []
    },
    {
        "length": 2873,
        "seq_id": "NZ_NHSD01000027",
        "regions": []
    },
    {
        "length": 2885,
        "seq_id": "NZ_NHSD01000028",
        "regions": []
    },
    {
        "length": 2888,
        "seq_id": "NZ_NHSD01000029",
        "regions": []
    },
    {
        "length": 2974,
        "seq_id": "NZ_NHSD01000030",
        "regions": []
    },
    {
        "length": 3041,
        "seq_id": "NZ_NHSD01000031",
        "regions": []
    },
    {
        "length": 3999,
        "seq_id": "NZ_NHSD01000032",
        "regions": []
    },
    {
        "length": 3103,
        "seq_id": "NZ_NHSD01000033",
        "regions": []
    },
    {
        "length": 3047,
        "seq_id": "NZ_NHSD01000034",
        "regions": []
    },
    {
        "length": 3124,
        "seq_id": "NZ_NHSD01000035",
        "regions": []
    },
    {
        "length": 3076,
        "seq_id": "NZ_NHSD01000036",
        "regions": []
    },
    {
        "length": 3094,
        "seq_id": "NZ_NHSD01000037",
        "regions": []
    },
    {
        "length": 3214,
        "seq_id": "NZ_NHSD01000038",
        "regions": []
    },
    {
        "length": 3230,
        "seq_id": "NZ_NHSD01000039",
        "regions": []
    },
    {
        "length": 3350,
        "seq_id": "NZ_NHSD01000040",
        "regions": []
    },
    {
        "length": 3357,
        "seq_id": "NZ_NHSD01000041",
        "regions": []
    },
    {
        "length": 3292,
        "seq_id": "NZ_NHSD01000042",
        "regions": []
    },
    {
        "length": 3339,
        "seq_id": "NZ_NHSD01000043",
        "regions": []
    },
    {
        "length": 3395,
        "seq_id": "NZ_NHSD01000044",
        "regions": []
    },
    {
        "length": 3404,
        "seq_id": "NZ_NHSD01000045",
        "regions": []
    },
    {
        "length": 3619,
        "seq_id": "NZ_NHSD01000046",
        "regions": []
    },
    {
        "length": 3517,
        "seq_id": "NZ_NHSD01000047",
        "regions": []
    },
    {
        "length": 3467,
        "seq_id": "NZ_NHSD01000048",
        "regions": []
    },
    {
        "length": 3550,
        "seq_id": "NZ_NHSD01000049",
        "regions": []
    },
    {
        "length": 3464,
        "seq_id": "NZ_NHSD01000050",
        "regions": []
    },
    {
        "length": 3526,
        "seq_id": "NZ_NHSD01000051",
        "regions": []
    },
    {
        "length": 3570,
        "seq_id": "NZ_NHSD01000052",
        "regions": []
    },
    {
        "length": 3599,
        "seq_id": "NZ_NHSD01000053",
        "regions": []
    },
    {
        "length": 3625,
        "seq_id": "NZ_NHSD01000054",
        "regions": []
    },
    {
        "length": 3690,
        "seq_id": "NZ_NHSD01000055",
        "regions": []
    },
    {
        "length": 3855,
        "seq_id": "NZ_NHSD01000056",
        "regions": []
    },
    {
        "length": 3806,
        "seq_id": "NZ_NHSD01000057",
        "regions": []
    },
    {
        "length": 3732,
        "seq_id": "NZ_NHSD01000058",
        "regions": []
    },
    {
        "length": 3877,
        "seq_id": "NZ_NHSD01000059",
        "regions": []
    },
    {
        "length": 3897,
        "seq_id": "NZ_NHSD01000060",
        "regions": []
    },
    {
        "length": 3917,
        "seq_id": "NZ_NHSD01000061",
        "regions": []
    },
    {
        "length": 3985,
        "seq_id": "NZ_NHSD01000062",
        "regions": []
    },
    {
        "length": 3929,
        "seq_id": "NZ_NHSD01000063",
        "regions": []
    },
    {
        "length": 4866,
        "seq_id": "NZ_NHSD01000064",
        "regions": []
    },
    {
        "length": 4243,
        "seq_id": "NZ_NHSD01000065",
        "regions": []
    },
    {
        "length": 4043,
        "seq_id": "NZ_NHSD01000066",
        "regions": []
    },
    {
        "length": 4157,
        "seq_id": "NZ_NHSD01000067",
        "regions": []
    },
    {
        "length": 4095,
        "seq_id": "NZ_NHSD01000068",
        "regions": []
    },
    {
        "length": 4065,
        "seq_id": "NZ_NHSD01000069",
        "regions": []
    },
    {
        "length": 4354,
        "seq_id": "NZ_NHSD01000070",
        "regions": []
    },
    {
        "length": 4477,
        "seq_id": "NZ_NHSD01000071",
        "regions": []
    },
    {
        "length": 4442,
        "seq_id": "NZ_NHSD01000072",
        "regions": []
    },
    {
        "length": 4505,
        "seq_id": "NZ_NHSD01000073",
        "regions": []
    },
    {
        "length": 4357,
        "seq_id": "NZ_NHSD01000074",
        "regions": []
    },
    {
        "length": 4470,
        "seq_id": "NZ_NHSD01000075",
        "regions": []
    },
    {
        "length": 4602,
        "seq_id": "NZ_NHSD01000076",
        "regions": []
    },
    {
        "length": 4608,
        "seq_id": "NZ_NHSD01000077",
        "regions": []
    },
    {
        "length": 4669,
        "seq_id": "NZ_NHSD01000078",
        "regions": []
    },
    {
        "length": 4718,
        "seq_id": "NZ_NHSD01000079",
        "regions": []
    },
    {
        "length": 4726,
        "seq_id": "NZ_NHSD01000080",
        "regions": []
    },
    {
        "length": 4740,
        "seq_id": "NZ_NHSD01000081",
        "regions": []
    },
    {
        "length": 4806,
        "seq_id": "NZ_NHSD01000082",
        "regions": []
    },
    {
        "length": 4806,
        "seq_id": "NZ_NHSD01000083",
        "regions": []
    },
    {
        "length": 4815,
        "seq_id": "NZ_NHSD01000084",
        "regions": []
    },
    {
        "length": 5158,
        "seq_id": "NZ_NHSD01000085",
        "regions": []
    },
    {
        "length": 5096,
        "seq_id": "NZ_NHSD01000086",
        "regions": []
    },
    {
        "length": 5023,
        "seq_id": "NZ_NHSD01000087",
        "regions": []
    },
    {
        "length": 5160,
        "seq_id": "NZ_NHSD01000088",
        "regions": []
    },
    {
        "length": 5148,
        "seq_id": "NZ_NHSD01000089",
        "regions": []
    },
    {
        "length": 5697,
        "seq_id": "NZ_NHSD01000090",
        "regions": []
    },
    {
        "length": 5288,
        "seq_id": "NZ_NHSD01000091",
        "regions": []
    },
    {
        "length": 5368,
        "seq_id": "NZ_NHSD01000092",
        "regions": []
    },
    {
        "length": 5368,
        "seq_id": "NZ_NHSD01000093",
        "regions": []
    },
    {
        "length": 5526,
        "seq_id": "NZ_NHSD01000094",
        "regions": []
    },
    {
        "length": 5549,
        "seq_id": "NZ_NHSD01000095",
        "regions": []
    },
    {
        "length": 5599,
        "seq_id": "NZ_NHSD01000096",
        "regions": []
    },
    {
        "length": 5227,
        "seq_id": "NZ_NHSD01000097",
        "regions": []
    },
    {
        "length": 5763,
        "seq_id": "NZ_NHSD01000098",
        "regions": []
    },
    {
        "length": 6019,
        "seq_id": "NZ_NHSD01000099",
        "regions": []
    },
    {
        "length": 5850,
        "seq_id": "NZ_NHSD01000100",
        "regions": []
    },
    {
        "length": 12198,
        "seq_id": "NZ_NHSD01000101",
        "regions": []
    },
    {
        "length": 12443,
        "seq_id": "NZ_NHSD01000102",
        "regions": []
    },
    {
        "length": 12493,
        "seq_id": "NZ_NHSD01000103",
        "regions": []
    },
    {
        "length": 12686,
        "seq_id": "NZ_NHSD01000104",
        "regions": []
    },
    {
        "length": 12510,
        "seq_id": "NZ_NHSD01000105",
        "regions": []
    },
    {
        "length": 12531,
        "seq_id": "NZ_NHSD01000106",
        "regions": []
    },
    {
        "length": 12716,
        "seq_id": "NZ_NHSD01000107",
        "regions": []
    },
    {
        "length": 13045,
        "seq_id": "NZ_NHSD01000108",
        "regions": []
    },
    {
        "length": 12724,
        "seq_id": "NZ_NHSD01000109",
        "regions": []
    },
    {
        "length": 13030,
        "seq_id": "NZ_NHSD01000110",
        "regions": []
    },
    {
        "length": 13082,
        "seq_id": "NZ_NHSD01000111",
        "regions": []
    },
    {
        "length": 13298,
        "seq_id": "NZ_NHSD01000112",
        "regions": []
    },
    {
        "length": 13163,
        "seq_id": "NZ_NHSD01000113",
        "regions": []
    },
    {
        "length": 13245,
        "seq_id": "NZ_NHSD01000114",
        "regions": []
    },
    {
        "length": 13309,
        "seq_id": "NZ_NHSD01000115",
        "regions": []
    },
    {
        "length": 13658,
        "seq_id": "NZ_NHSD01000116",
        "regions": []
    },
    {
        "length": 13482,
        "seq_id": "NZ_NHSD01000117",
        "regions": []
    },
    {
        "length": 13548,
        "seq_id": "NZ_NHSD01000118",
        "regions": []
    },
    {
        "length": 13820,
        "seq_id": "NZ_NHSD01000119",
        "regions": []
    },
    {
        "length": 14066,
        "seq_id": "NZ_NHSD01000120",
        "regions": []
    },
    {
        "length": 13860,
        "seq_id": "NZ_NHSD01000121",
        "regions": []
    },
    {
        "length": 13936,
        "seq_id": "NZ_NHSD01000122",
        "regions": []
    },
    {
        "length": 14025,
        "seq_id": "NZ_NHSD01000123",
        "regions": []
    },
    {
        "length": 14249,
        "seq_id": "NZ_NHSD01000124",
        "regions": []
    },
    {
        "length": 14247,
        "seq_id": "NZ_NHSD01000125",
        "regions": []
    },
    {
        "length": 14263,
        "seq_id": "NZ_NHSD01000126",
        "regions": []
    },
    {
        "length": 14603,
        "seq_id": "NZ_NHSD01000127",
        "regions": []
    },
    {
        "length": 16289,
        "seq_id": "NZ_NHSD01000128",
        "regions": []
    },
    {
        "length": 14787,
        "seq_id": "NZ_NHSD01000129",
        "regions": []
    },
    {
        "length": 14805,
        "seq_id": "NZ_NHSD01000130",
        "regions": []
    },
    {
        "length": 14820,
        "seq_id": "NZ_NHSD01000131",
        "regions": []
    },
    {
        "length": 15182,
        "seq_id": "NZ_NHSD01000132",
        "regions": []
    },
    {
        "length": 15672,
        "seq_id": "NZ_NHSD01000133",
        "regions": []
    },
    {
        "length": 16058,
        "seq_id": "NZ_NHSD01000134",
        "regions": []
    },
    {
        "length": 16597,
        "seq_id": "NZ_NHSD01000135",
        "regions": []
    },
    {
        "length": 16955,
        "seq_id": "NZ_NHSD01000136",
        "regions": []
    },
    {
        "length": 9722,
        "seq_id": "NZ_NHSD01000137",
        "regions": []
    },
    {
        "length": 9449,
        "seq_id": "NZ_NHSD01000138",
        "regions": []
    },
    {
        "length": 9345,
        "seq_id": "NZ_NHSD01000139",
        "regions": []
    },
    {
        "length": 9638,
        "seq_id": "NZ_NHSD01000140",
        "regions": []
    },
    {
        "length": 9184,
        "seq_id": "NZ_NHSD01000141",
        "regions": []
    },
    {
        "length": 9148,
        "seq_id": "NZ_NHSD01000142",
        "regions": []
    },
    {
        "length": 8901,
        "seq_id": "NZ_NHSD01000143",
        "regions": []
    },
    {
        "length": 9325,
        "seq_id": "NZ_NHSD01000144",
        "regions": []
    },
    {
        "length": 8649,
        "seq_id": "NZ_NHSD01000145",
        "regions": []
    },
    {
        "length": 8634,
        "seq_id": "NZ_NHSD01000146",
        "regions": []
    },
    {
        "length": 2649,
        "seq_id": "NZ_NHSD01000147",
        "regions": []
    },
    {
        "length": 8633,
        "seq_id": "NZ_NHSD01000148",
        "regions": []
    },
    {
        "length": 8382,
        "seq_id": "NZ_NHSD01000149",
        "regions": []
    },
    {
        "length": 8373,
        "seq_id": "NZ_NHSD01000150",
        "regions": []
    },
    {
        "length": 8364,
        "seq_id": "NZ_NHSD01000151",
        "regions": []
    },
    {
        "length": 8277,
        "seq_id": "NZ_NHSD01000152",
        "regions": []
    },
    {
        "length": 10593,
        "seq_id": "NZ_NHSD01000153",
        "regions": []
    },
    {
        "length": 8184,
        "seq_id": "NZ_NHSD01000154",
        "regions": []
    },
    {
        "length": 7899,
        "seq_id": "NZ_NHSD01000155",
        "regions": []
    },
    {
        "length": 7839,
        "seq_id": "NZ_NHSD01000156",
        "regions": []
    },
    {
        "length": 7832,
        "seq_id": "NZ_NHSD01000157",
        "regions": []
    },
    {
        "length": 7819,
        "seq_id": "NZ_NHSD01000158",
        "regions": []
    },
    {
        "length": 7809,
        "seq_id": "NZ_NHSD01000159",
        "regions": []
    },
    {
        "length": 7745,
        "seq_id": "NZ_NHSD01000160",
        "regions": []
    },
    {
        "length": 7745,
        "seq_id": "NZ_NHSD01000161",
        "regions": []
    },
    {
        "length": 7687,
        "seq_id": "NZ_NHSD01000162",
        "regions": []
    },
    {
        "length": 7553,
        "seq_id": "NZ_NHSD01000163",
        "regions": []
    },
    {
        "length": 7409,
        "seq_id": "NZ_NHSD01000164",
        "regions": []
    },
    {
        "length": 7356,
        "seq_id": "NZ_NHSD01000165",
        "regions": []
    },
    {
        "length": 7337,
        "seq_id": "NZ_NHSD01000166",
        "regions": []
    },
    {
        "length": 7293,
        "seq_id": "NZ_NHSD01000167",
        "regions": []
    },
    {
        "length": 7272,
        "seq_id": "NZ_NHSD01000168",
        "regions": []
    },
    {
        "length": 7098,
        "seq_id": "NZ_NHSD01000169",
        "regions": []
    },
    {
        "length": 7086,
        "seq_id": "NZ_NHSD01000170",
        "regions": []
    },
    {
        "length": 6926,
        "seq_id": "NZ_NHSD01000171",
        "regions": []
    },
    {
        "length": 6919,
        "seq_id": "NZ_NHSD01000172",
        "regions": []
    },
    {
        "length": 6863,
        "seq_id": "NZ_NHSD01000173",
        "regions": []
    },
    {
        "length": 7159,
        "seq_id": "NZ_NHSD01000174",
        "regions": []
    },
    {
        "length": 3668,
        "seq_id": "NZ_NHSD01000175",
        "regions": []
    },
    {
        "length": 9670,
        "seq_id": "NZ_NHSD01000176",
        "regions": []
    },
    {
        "length": 7095,
        "seq_id": "NZ_NHSD01000177",
        "regions": []
    },
    {
        "length": 11375,
        "seq_id": "NZ_NHSD01000178",
        "regions": []
    },
    {
        "length": 3160,
        "seq_id": "NZ_NHSD01000179",
        "regions": []
    },
    {
        "length": 8483,
        "seq_id": "NZ_NHSD01000180",
        "regions": []
    },
    {
        "length": 2654,
        "seq_id": "NZ_NHSD01000181",
        "regions": []
    },
    {
        "length": 8682,
        "seq_id": "NZ_NHSD01000182",
        "regions": []
    },
    {
        "length": 2881,
        "seq_id": "NZ_NHSD01000183",
        "regions": []
    },
    {
        "length": 10205,
        "seq_id": "NZ_NHSD01000184",
        "regions": []
    },
    {
        "length": 4762,
        "seq_id": "NZ_NHSD01000185",
        "regions": []
    },
    {
        "length": 19821,
        "seq_id": "NZ_NHSD01000186",
        "regions": []
    },
    {
        "length": 6760,
        "seq_id": "NZ_NHSD01000187",
        "regions": []
    },
    {
        "length": 6134,
        "seq_id": "NZ_NHSD01000188",
        "regions": []
    },
    {
        "length": 31422,
        "seq_id": "NZ_NHSD01000189",
        "regions": []
    },
    {
        "length": 3026,
        "seq_id": "NZ_NHSD01000190",
        "regions": []
    },
    {
        "length": 10812,
        "seq_id": "NZ_NHSD01000191",
        "regions": []
    },
    {
        "length": 7076,
        "seq_id": "NZ_NHSD01000192",
        "regions": []
    },
    {
        "length": 3581,
        "seq_id": "NZ_NHSD01000193",
        "regions": []
    },
    {
        "length": 8465,
        "seq_id": "NZ_NHSD01000194",
        "regions": []
    },
    {
        "length": 4652,
        "seq_id": "NZ_NHSD01000195",
        "regions": []
    },
    {
        "length": 19294,
        "seq_id": "NZ_NHSD01000196",
        "regions": []
    },
    {
        "length": 6845,
        "seq_id": "NZ_NHSD01000197",
        "regions": []
    },
    {
        "length": 23336,
        "seq_id": "NZ_NHSD01000198",
        "regions": []
    },
    {
        "length": 5275,
        "seq_id": "NZ_NHSD01000199",
        "regions": []
    },
    {
        "length": 7274,
        "seq_id": "NZ_NHSD01000200",
        "regions": []
    },
    {
        "length": 3778,
        "seq_id": "NZ_NHSD01000201",
        "regions": []
    },
    {
        "length": 8461,
        "seq_id": "NZ_NHSD01000202",
        "regions": []
    },
    {
        "length": 17762,
        "seq_id": "NZ_NHSD01000203",
        "regions": []
    },
    {
        "length": 6731,
        "seq_id": "NZ_NHSD01000204",
        "regions": []
    },
    {
        "length": 7247,
        "seq_id": "NZ_NHSD01000205",
        "regions": []
    },
    {
        "length": 16623,
        "seq_id": "NZ_NHSD01000206",
        "regions": []
    },
    {
        "length": 2568,
        "seq_id": "NZ_NHSD01000207",
        "regions": []
    },
    {
        "length": 7041,
        "seq_id": "NZ_NHSD01000208",
        "regions": []
    },
    {
        "length": 3576,
        "seq_id": "NZ_NHSD01000209",
        "regions": []
    },
    {
        "length": 7802,
        "seq_id": "NZ_NHSD01000210",
        "regions": []
    },
    {
        "length": 4030,
        "seq_id": "NZ_NHSD01000211",
        "regions": []
    },
    {
        "length": 7619,
        "seq_id": "NZ_NHSD01000212",
        "regions": []
    },
    {
        "length": 3920,
        "seq_id": "NZ_NHSD01000213",
        "regions": []
    },
    {
        "length": 3149,
        "seq_id": "NZ_NHSD01000214",
        "regions": []
    },
    {
        "length": 11364,
        "seq_id": "NZ_NHSD01000215",
        "regions": []
    },
    {
        "length": 8495,
        "seq_id": "NZ_NHSD01000216",
        "regions": []
    },
    {
        "length": 4712,
        "seq_id": "NZ_NHSD01000217",
        "regions": []
    },
    {
        "length": 19419,
        "seq_id": "NZ_NHSD01000218",
        "regions": [
            {
                "start": 1,
                "end": 9387,
                "idx": 1,
                "orfs": [
                    {
                        "start": 435,
                        "end": 1055,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_01436",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01436</span></strong><br>\n \n  Cytidylate kinase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01436</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">cmk</span><br>\n \n Location: 435 - 1,055,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAEGARFTVALDGPAASGKGTLGRALAQACGFAHLDTGLLYRAVGARAAAGEDPVAAARSLVPEDLSRADLRSAAAGQAASRVAALEEVRAALLAFQRDFARRPGGAVLDGRDIGTVVCPGAEVKLFVTASDAVRSRRRWLELRAHQPDLTQVEVLEDLRARDARDRERAAAPLRPAPDAMLLDTSDLTIEAAIARALSAVEAARR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=11055\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAEGARFTVALDGPAASGKGTLGRALAQACGFAHLDTGLLYRAVGARAAAGEDPVAAARSLVPEDLSRADLRSAAAGQAASRVAALEEVRAALLAFQRDFARRPGGAVLDGRDIGTVVCPGAEVKLFVTASDAVRSRRRWLELRAHQPDLTQVEVLEDLRARDARDRERAAAPLRPAPDAMLLDTSDLTIEAAIARALSAVEAARR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCTGAGGGCGCGCGGTTCACGGTCGCGCTGGATGGGCCGGCGGCGTCGGGCAAGGGCACGCTGGGGCGCGCGCTGGCGCAGGCGTGCGGGTTTGCGCATCTCGATACGGGGCTTCTGTATCGTGCCGTGGGTGCGCGGGCGGCGGCGGGCGAGGACCCGGTGGCCGCAGCGCGCAGCCTCGTGCCCGAGGATCTGTCGCGCGCCGATCTGCGCAGCGCCGCCGCAGGGCAGGCCGCCAGCCGCGTGGCGGCACTGGAAGAGGTGCGCGCGGCGCTGCTGGCATTCCAGCGGGATTTCGCGCGCAGACCCGGCGGAGCGGTGCTGGACGGGCGCGACATCGGCACCGTGGTCTGCCCGGGCGCAGAGGTGAAGCTGTTCGTCACCGCATCGGATGCGGTGCGGTCGCGGCGGCGTTGGCTGGAGCTGCGCGCGCACCAGCCCGACCTGACGCAGGTGGAGGTTCTCGAAGACCTGCGTGCCCGCGATGCCCGCGACCGCGAACGGGCAGCCGCGCCGCTGCGACCGGCGCCGGACGCGATGCTTCTGGACACCTCGGACCTGACGATCGAGGCGGCGATCGCACGGGCGCTCTCGGCGGTCGAGGCCGCCCGCCGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1048,
                        "end": 2397,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_01437",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01437</span></strong><br>\n \n  3-phosphoshikimate 1-carboxyvinyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01437</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">aroA</span><br>\n \n Location: 1,048 - 2,397,\n (total: 1350 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTATSAPMPLTARAGGALRGTTDVPGDKSISHRALILGALAVGETRITGLLEGQDVLDTAAAMRAFGAEVIRHGPGSWSVHGVGVGGFGEPSGVIDCGNSGTGVRLIMGAMATTPITATFTGDASLCRRPMGRVTDPLALFGAQAVGRAGGRLPMTLVGAADPVPVRYVLPVPSAQVKSAVLLAGLNAPGETAVIEAEPTRDHTERMLAGFGAVIRHEDTPEGRAVILTGQPELIAQPVAVPRDPSSAAFPVVAALMVPGSDVRVPGVSRNPTRDGLYCTLLEMGADLLFEAERAEGGEPVADLRARFTGTLRGVEVPPERAASMIDEFPILAALAATAEGATVMRGVRELRVKESDRIAAMATGLAACGVAVEETEDTLTVHGCGPDGVPGGTTVATHLDHRIAMSFLCLGLVARAPVTVDDAGPIATSFPDFIPLMTALGADLATHG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=12397\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTATSAPMPLTARAGGALRGTTDVPGDKSISHRALILGALAVGETRITGLLEGQDVLDTAAAMRAFGAEVIRHGPGSWSVHGVGVGGFGEPSGVIDCGNSGTGVRLIMGAMATTPITATFTGDASLCRRPMGRVTDPLALFGAQAVGRAGGRLPMTLVGAADPVPVRYVLPVPSAQVKSAVLLAGLNAPGETAVIEAEPTRDHTERMLAGFGAVIRHEDTPEGRAVILTGQPELIAQPVAVPRDPSSAAFPVVAALMVPGSDVRVPGVSRNPTRDGLYCTLLEMGADLLFEAERAEGGEPVADLRARFTGTLRGVEVPPERAASMIDEFPILAALAATAEGATVMRGVRELRVKESDRIAAMATGLAACGVAVEETEDTLTVHGCGPDGVPGGTTVATHLDHRIAMSFLCLGLVARAPVTVDDAGPIATSFPDFIPLMTALGADLATHG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCGCCACTTCCGCGCCCATGCCCCTGACCGCCCGTGCCGGCGGGGCGCTGCGGGGCACCACCGACGTGCCCGGCGACAAGTCCATCAGCCACCGCGCTCTGATCCTGGGTGCGCTGGCGGTGGGCGAGACGCGCATCACCGGGCTGCTGGAAGGGCAGGATGTCCTCGACACCGCCGCCGCGATGCGCGCCTTCGGGGCCGAGGTGATCCGCCACGGACCCGGCAGCTGGTCGGTGCATGGCGTGGGCGTGGGCGGGTTCGGCGAACCGTCGGGTGTGATCGACTGCGGCAACTCGGGCACCGGGGTGCGGCTGATCATGGGCGCGATGGCGACCACGCCGATCACCGCCACCTTCACCGGCGATGCCAGCCTGTGCCGCCGCCCCATGGGCCGCGTGACCGATCCGCTGGCGCTGTTTGGTGCACAGGCGGTGGGGCGCGCGGGCGGACGGCTGCCGATGACGCTGGTGGGCGCGGCCGATCCGGTGCCGGTGCGCTATGTGCTGCCGGTGCCCTCGGCGCAGGTGAAATCGGCGGTGCTGCTGGCCGGGCTGAACGCGCCGGGCGAGACCGCGGTGATCGAGGCCGAGCCGACCCGCGACCACACCGAACGCATGCTCGCGGGCTTCGGCGCCGTCATCCGCCACGAGGACACGCCCGAGGGCCGCGCGGTGATCCTGACGGGCCAGCCGGAGTTGATCGCGCAGCCGGTGGCGGTGCCGCGCGATCCGTCCTCGGCCGCGTTTCCGGTGGTGGCGGCGCTGATGGTGCCGGGATCGGATGTGCGGGTGCCGGGCGTCAGCCGCAACCCCACGCGCGACGGCCTTTATTGCACGCTGCTGGAGATGGGCGCCGATCTGCTGTTCGAGGCCGAGCGCGCGGAGGGCGGCGAGCCGGTGGCCGACCTGCGCGCCCGCTTCACGGGAACCTTGCGCGGGGTGGAGGTGCCGCCCGAGCGCGCCGCCAGCATGATCGACGAGTTCCCGATCCTCGCAGCCCTTGCCGCCACCGCCGAGGGCGCCACCGTCATGCGCGGCGTGCGCGAGTTGCGCGTCAAGGAAAGCGACCGCATCGCCGCGATGGCCACCGGGCTGGCCGCCTGCGGCGTCGCGGTGGAGGAGACGGAGGACACGCTGACGGTGCATGGCTGCGGCCCGGACGGCGTGCCGGGGGGCACGACGGTGGCCACGCACCTCGACCACCGCATCGCCATGAGCTTCCTGTGCCTTGGCCTCGTGGCCCGCGCGCCCGTCACGGTGGACGATGCCGGCCCCATCGCCACGTCGTTTCCCGACTTCATTCCGCTGATGACGGCCCTTGGCGCCGATCTGGCCACCCATGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2489,
                        "end": 3880,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_01438",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01438</span></strong><br>\n \n  Aspartate kinase Ask_Ect<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01438</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ask</span><br>\n \n Location: 2,489 - 3,880,\n (total: 1392 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSRSRELLETLWVGGREDVYGRIFVVSAYGGITNLLLEHKKSGEQGVYARFASDDGGSGWHQALNDTAAEMMRVHGEILEHDGDRGRADAFVRDRIEGARACMIDLQRLGSYGHFRIDGQLMTLRELLAGLGEAHSAFVSTLLLQRHGVNARFVDLSGWRDEAHPDLAERLRAALDGIDFSEELPIVTGYAHCAEGLMREYDRGYSEVVFAHIAAQTAASEAIIHKEFHLSSADPKVVGLDKVRKIGRTSYDVADQLSNLGMEAIHPNAARILRRAEVALRVKHAFEPDDPGTLIGPEGGQAGRVEMVTGLPLQALEVYEPDMVGVKGYDAGILDALTRHKLWIVSKSSNANSITHWVSGSLKALRRVERELAQRWSNAEITIRPVAMVSAIGSDLTGLGAVRRGLEALDAAGIEVLAVQQGLRRVEVQFLVPREAQDAAVAALHARLIEETGAASVQPIAAE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=13880\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSRSRELLETLWVGGREDVYGRIFVVSAYGGITNLLLEHKKSGEQGVYARFASDDGGSGWHQALNDTAAEMMRVHGEILEHDGDRGRADAFVRDRIEGARACMIDLQRLGSYGHFRIDGQLMTLRELLAGLGEAHSAFVSTLLLQRHGVNARFVDLSGWRDEAHPDLAERLRAALDGIDFSEELPIVTGYAHCAEGLMREYDRGYSEVVFAHIAAQTAASEAIIHKEFHLSSADPKVVGLDKVRKIGRTSYDVADQLSNLGMEAIHPNAARILRRAEVALRVKHAFEPDDPGTLIGPEGGQAGRVEMVTGLPLQALEVYEPDMVGVKGYDAGILDALTRHKLWIVSKSSNANSITHWVSGSLKALRRVERELAQRWSNAEITIRPVAMVSAIGSDLTGLGAVRRGLEALDAAGIEVLAVQQGLRRVEVQFLVPREAQDAAVAALHARLIEETGAASVQPIAAE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCCGGAGCCGCGAGTTGCTCGAGACCCTGTGGGTCGGAGGCCGCGAGGATGTGTATGGCCGCATCTTTGTCGTCTCGGCCTATGGCGGGATCACCAACCTGCTGCTGGAGCACAAGAAAAGCGGCGAGCAGGGGGTCTATGCCCGGTTTGCCTCGGATGACGGCGGCAGCGGCTGGCACCAGGCGCTGAACGACACCGCAGCCGAGATGATGCGCGTGCACGGAGAGATCCTGGAGCATGACGGCGACAGGGGCCGGGCGGATGCGTTCGTGCGCGACCGCATCGAGGGTGCGCGGGCCTGCATGATCGACCTTCAGCGGCTGGGCTCCTACGGGCACTTCCGCATCGACGGGCAACTGATGACGCTGCGCGAGTTGCTGGCGGGGCTGGGCGAGGCGCATTCGGCCTTTGTCAGCACGCTGCTGTTGCAGCGCCACGGGGTGAACGCGCGCTTTGTGGATCTGTCGGGTTGGCGCGACGAGGCGCATCCCGATCTGGCCGAGCGGCTGCGCGCCGCGCTCGACGGGATCGACTTCTCCGAGGAGCTGCCGATCGTCACCGGCTATGCGCATTGTGCCGAAGGGCTGATGCGCGAATACGATCGTGGCTATTCCGAGGTGGTGTTCGCCCACATCGCGGCGCAGACCGCGGCCTCCGAGGCGATCATCCACAAGGAGTTCCATCTGTCCTCGGCTGATCCCAAGGTCGTGGGGCTGGACAAGGTGCGCAAGATCGGGCGCACCAGCTATGACGTGGCCGACCAGCTGTCGAACCTCGGGATGGAGGCGATCCACCCCAACGCAGCCCGCATCCTGCGCCGCGCCGAGGTCGCGCTGCGGGTCAAGCACGCGTTTGAACCCGACGATCCCGGCACCCTGATCGGTCCCGAGGGCGGGCAGGCGGGGCGCGTGGAGATGGTCACCGGCCTGCCGTTGCAGGCGCTGGAGGTCTATGAGCCCGACATGGTCGGGGTGAAGGGCTATGACGCCGGGATCCTGGACGCGCTGACGCGCCACAAGCTGTGGATCGTGTCGAAGTCCTCCAACGCGAACTCCATCACCCACTGGGTCAGCGGCTCGCTCAAGGCCCTGCGCCGGGTGGAGCGGGAGCTGGCGCAGCGCTGGTCCAACGCCGAGATCACCATTCGTCCCGTGGCGATGGTGTCGGCCATCGGCAGCGACCTGACCGGCCTTGGTGCGGTGCGTCGGGGGCTGGAGGCGCTGGACGCCGCCGGGATCGAGGTGCTTGCGGTGCAGCAGGGCCTGCGCCGGGTGGAGGTGCAGTTCCTCGTTCCGCGCGAGGCGCAGGACGCAGCGGTCGCCGCCCTGCATGCCCGCCTGATCGAGGAGACGGGCGCGGCCAGCGTCCAGCCCATCGCCGCCGAGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 4004,
                        "end": 4387,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_01439",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01439</span></strong><br>\n \n  L-ectoine synthase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01439</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectC</span><br>\n \n Location: 4,004 - 4,387,\n (total: 384 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ectoine: ectoine_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIVRDFHEANKTDRKVANERWESVRLLLADDGMGFSFHITTIEGGSEHTFHYKNHFESVYCISGKGSIEDLATGTVHQIRPGVMYALDKHDKHTLRCEDTMVLACCFNPPVTGTEVHRADGSYAAAD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=14387\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIVRDFHEANKTDRKVANERWESVRLLLADDGMGFSFHITTIEGGSEHTFHYKNHFESVYCISGKGSIEDLATGTVHQIRPGVMYALDKHDKHTLRCEDTMVLACCFNPPVTGTEVHRADGSYAAAD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCGTTCGCGATTTCCACGAAGCCAACAAGACCGACCGCAAGGTCGCCAACGAGCGTTGGGAGTCGGTGCGCCTGCTGCTGGCCGATGACGGGATGGGGTTTTCGTTCCACATCACCACCATCGAAGGCGGCTCCGAGCACACCTTTCACTACAAGAACCATTTCGAGAGCGTGTATTGCATCTCGGGTAAGGGCTCGATCGAGGATCTCGCCACCGGCACCGTCCACCAGATCCGGCCCGGCGTGATGTACGCGCTCGACAAGCACGACAAGCACACCTTGCGCTGCGAGGACACGATGGTTCTGGCGTGCTGCTTCAACCCGCCCGTGACGGGCACCGAGGTGCACCGGGCCGACGGCTCCTACGCCGCCGCGGACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 4391,
                        "end": 5689,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_01440",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01440</span></strong><br>\n \n  Diaminobutyrate--2-oxoglutarate transaminase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01440</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectB</span><br>\n \n Location: 4,391 - 5,689,\n (total: 1299 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_3<br>\n \n  biosynthetic-additional (smcogs) SMCOG1013:aminotransferase class-III (Score: 353.4; E-value: 2.6e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTDHTQTDTGPMAVYARRESQVRSYCRSFPVEFTKGRNATLTDRAGREYIDFLAGCSSLNYGHNDPDMKAALIDHITGDGIAHGLDMHTDAKTAFLETFERVILRPRGMEHKVMMTGPTGTNAVEAAMKLARKVTGRDTIVAFTNGFHGMTMGALAATGNAGKRAGGGMALHGVVRMPYEGAMDGVDSLAMIEAMLDNPSSGFDAPAAFLIEPVQGEGGLNAASADFLRGLKRLAEKHGALLIADDIQSGIGRTGPFFSFEGMDVMPDLIPLAKSLSGMGLPFAALLVRPDLDVWKPAEHNGTFRGNQHAFVTARVALEKFWTDDTFQKQTEAKAEFLERRLSDIAALIPGARLKGRGMMRGVDVGSGETAGAICAACFEHGLVIETSGAHDEVVKVLAPLTIPEAQLAQGLDIIEAAVRSRIAGTTPIAAE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=15689\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTDHTQTDTGPMAVYARRESQVRSYCRSFPVEFTKGRNATLTDRAGREYIDFLAGCSSLNYGHNDPDMKAALIDHITGDGIAHGLDMHTDAKTAFLETFERVILRPRGMEHKVMMTGPTGTNAVEAAMKLARKVTGRDTIVAFTNGFHGMTMGALAATGNAGKRAGGGMALHGVVRMPYEGAMDGVDSLAMIEAMLDNPSSGFDAPAAFLIEPVQGEGGLNAASADFLRGLKRLAEKHGALLIADDIQSGIGRTGPFFSFEGMDVMPDLIPLAKSLSGMGLPFAALLVRPDLDVWKPAEHNGTFRGNQHAFVTARVALEKFWTDDTFQKQTEAKAEFLERRLSDIAALIPGARLKGRGMMRGVDVGSGETAGAICAACFEHGLVIETSGAHDEVVKVLAPLTIPEAQLAQGLDIIEAAVRSRIAGTTPIAAE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCGATCATACCCAGACCGACACCGGCCCCATGGCCGTCTATGCCCGCCGCGAAAGCCAGGTGCGCAGCTACTGCCGCAGCTTTCCGGTGGAGTTCACCAAGGGCCGCAACGCCACGCTGACCGACCGCGCGGGGCGGGAGTACATCGACTTCCTCGCCGGGTGCTCGTCGCTGAACTATGGCCACAACGACCCGGACATGAAGGCGGCGCTGATCGACCACATCACCGGCGACGGCATCGCCCACGGCCTGGACATGCACACCGACGCCAAGACCGCGTTCCTGGAGACGTTCGAGCGCGTGATCCTGCGCCCGCGCGGCATGGAGCACAAGGTGATGATGACCGGCCCCACCGGCACCAACGCCGTCGAGGCCGCGATGAAGCTGGCGCGCAAGGTCACCGGGCGCGACACCATCGTCGCCTTCACCAACGGCTTTCACGGCATGACGATGGGCGCGCTGGCGGCCACCGGCAACGCCGGCAAGCGCGCGGGCGGCGGCATGGCGCTGCATGGCGTCGTGCGGATGCCCTATGAGGGGGCGATGGACGGCGTCGACAGCCTCGCGATGATCGAGGCGATGCTGGACAACCCCTCCAGCGGGTTCGACGCGCCGGCCGCGTTCCTGATCGAGCCGGTGCAGGGTGAGGGCGGGCTGAACGCCGCCTCGGCCGACTTCCTGCGCGGGCTGAAGCGGCTGGCCGAGAAGCACGGCGCGCTGCTCATTGCCGACGATATCCAGTCGGGCATCGGGCGCACGGGGCCGTTCTTCAGCTTCGAGGGGATGGACGTGATGCCCGACCTGATCCCGCTGGCGAAGTCGCTGTCGGGGATGGGCCTGCCGTTCGCCGCACTTCTGGTGCGCCCGGACCTGGACGTGTGGAAGCCGGCCGAACACAACGGCACCTTCCGCGGCAACCAGCATGCCTTCGTCACCGCCCGCGTGGCGCTGGAGAAGTTCTGGACCGACGACACCTTCCAGAAGCAGACCGAAGCCAAGGCCGAGTTCCTGGAGCGCCGGCTGTCGGACATCGCCGCCCTGATCCCCGGCGCCCGGCTGAAGGGCCGCGGCATGATGCGTGGCGTCGACGTCGGTTCGGGCGAGACGGCGGGCGCGATCTGCGCGGCCTGTTTCGAGCACGGTCTGGTCATCGAGACCTCGGGCGCCCATGATGAGGTCGTCAAGGTCCTCGCGCCCCTGACAATTCCCGAGGCGCAGTTGGCGCAGGGCCTCGACATCATCGAAGCGGCGGTGCGCAGCCGGATCGCCGGCACCACCCCCATTGCAGCGGAGTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 5735,
                        "end": 6277,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_01441",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01441</span></strong><br>\n \n  L-2,4-diaminobutyric acid acetyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01441</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectA</span><br>\n \n Location: 5,735 - 6,277,\n (total: 543 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MARTNRKIIETPKGAVRLRSPVKTDGTAVQELIARCAPLDQNSLYMNLIQCDHFADTCVLAERGDDVLGWISAHVPPGREDTIFVWQVAVDARARGMGLGRHMLTALLERPLCRRVINLETTITRDNEGSWALFRSLARRLDGDLSHAPHFEREAHFGGAHDTEHLVTIALDAEAVRRAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=16277\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MARTNRKIIETPKGAVRLRSPVKTDGTAVQELIARCAPLDQNSLYMNLIQCDHFADTCVLAERGDDVLGWISAHVPPGREDTIFVWQVAVDARARGMGLGRHMLTALLERPLCRRVINLETTITRDNEGSWALFRSLARRLDGDLSHAPHFEREAHFGGAHDTEHLVTIALDAEAVRRAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCCCGGACAAATCGCAAGATCATCGAAACACCCAAGGGTGCGGTGCGCCTGCGCAGCCCCGTCAAGACTGACGGCACGGCCGTCCAGGAGCTGATCGCGCGCTGCGCGCCACTGGACCAGAATTCCCTCTACATGAACCTGATCCAGTGCGACCACTTCGCCGACACCTGTGTGCTGGCCGAGCGTGGCGACGATGTGCTGGGCTGGATCTCGGCGCATGTGCCGCCGGGGCGCGAGGACACGATCTTCGTGTGGCAGGTGGCTGTTGACGCCCGCGCACGCGGCATGGGGCTGGGACGCCACATGCTGACGGCGCTGCTGGAGCGCCCGCTGTGCCGCCGCGTCATCAACCTGGAGACCACGATCACCCGCGACAACGAGGGGTCCTGGGCACTGTTCCGCAGCCTTGCCCGGCGTCTGGACGGCGATCTGTCCCACGCGCCCCATTTTGAACGCGAGGCGCATTTCGGCGGCGCGCATGACACCGAGCATCTGGTGACCATCGCGCTCGACGCCGAAGCGGTGCGCCGGGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 6556,
                        "end": 7044,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_01442",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01442</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01442</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,556 - 7,044,\n (total: 489 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1135:MarR family transcriptional regulator (Score: 88.6; E-value: 4.5e-27)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTERVDATLIALRRVLRAIEGNARAIARASGLTHAQMLVLHALADRGQELPSDIARRLGVAQATVTTQIDRLEARGLVRRERRQTDRRTVWVILTDSGRQLLADTPDPLYGRFADRFARLADWEQGMLMTSAERLAKLFDAEAVEPLPAGEDTARKPAPPVA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=17044\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTERVDATLIALRRVLRAIEGNARAIARASGLTHAQMLVLHALADRGQELPSDIARRLGVAQATVTTQIDRLEARGLVRRERRQTDRRTVWVILTDSGRQLLADTPDPLYGRFADRFARLADWEQGMLMTSAERLAKLFDAEAVEPLPAGEDTARKPAPPVA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGAACGGGTGGATGCGACGCTGATCGCACTCAGGCGCGTGCTGCGCGCGATCGAGGGCAACGCCCGCGCGATCGCGCGGGCCTCGGGGTTGACGCACGCACAGATGCTGGTGCTGCACGCGCTGGCCGACCGCGGGCAGGAACTGCCCAGCGACATCGCCCGCCGTCTGGGCGTGGCCCAGGCCACCGTCACCACCCAGATCGATCGGCTGGAGGCGCGCGGCCTTGTGCGCCGCGAGCGTCGGCAGACCGACCGCCGCACCGTCTGGGTGATCCTGACCGACAGCGGGCGCCAGCTTCTGGCCGACACCCCCGACCCGCTCTATGGCCGCTTCGCCGACCGGTTCGCGCGGCTTGCGGATTGGGAACAGGGCATGCTGATGACCAGCGCCGAGCGTCTGGCCAAGCTGTTTGACGCCGAGGCCGTCGAGCCCCTGCCCGCGGGCGAGGACACCGCGCGCAAACCCGCGCCCCCCGTCGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 7260,
                        "end": 8933,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_01443",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01443</span></strong><br>\n \n  Cytochrome c oxidase subunit 1-beta<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01443</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ctaDII</span><br>\n \n Location: 7,260 - 8,933,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MADAVTQGGGHGDTRGFFTRWFMSTNHKDIGILYLFTSGIVGFIAVAFTVYMRMELMEPGVQYMCLEGARMTAAAAGECTPNGHLWNVLITAHGVLMMFFVVIPALFGGFGNYFMPLHIGAPDMAFPRLNNLSYWLYVAGASLAVASLFSPGGAGQTGAGVGWVLYPPLSTTETGYAMDLAIFAVHVAGASSILGAINIITTFLNMRAPGMTLHKVPLFAWSVFITAWMILLALPVLAGAITMLLTDRNFGTTFFDPSGGGDPVLYQHILWFFGHPEVYIIIIPGFGIISHVIATFSRKPIFGYLPMVYAMVAIGVLGFVVWAHHMYTVGMSLTQQSYFMLATMVIAVPTGIKIFSWIATMWGGSVEFKTPMLWAFGFLFLFTVGGVTGVVLSQAAVDRYYHDTYYVVAHFHYVMSLGAVFALFAGIYYWIGKMSGRQYPEWAGKTHFWAMFIGSNLTFFPQHFLGRQGMPRRYIDYPEAFALWNWVSSIGAFISFASFVFFIGVIYYTLRHGARVTENNYWNEHADTLEWTLPSPPPEHTFETLPKREDWDRSPAH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=18933\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MADAVTQGGGHGDTRGFFTRWFMSTNHKDIGILYLFTSGIVGFIAVAFTVYMRMELMEPGVQYMCLEGARMTAAAAGECTPNGHLWNVLITAHGVLMMFFVVIPALFGGFGNYFMPLHIGAPDMAFPRLNNLSYWLYVAGASLAVASLFSPGGAGQTGAGVGWVLYPPLSTTETGYAMDLAIFAVHVAGASSILGAINIITTFLNMRAPGMTLHKVPLFAWSVFITAWMILLALPVLAGAITMLLTDRNFGTTFFDPSGGGDPVLYQHILWFFGHPEVYIIIIPGFGIISHVIATFSRKPIFGYLPMVYAMVAIGVLGFVVWAHHMYTVGMSLTQQSYFMLATMVIAVPTGIKIFSWIATMWGGSVEFKTPMLWAFGFLFLFTVGGVTGVVLSQAAVDRYYHDTYYVVAHFHYVMSLGAVFALFAGIYYWIGKMSGRQYPEWAGKTHFWAMFIGSNLTFFPQHFLGRQGMPRRYIDYPEAFALWNWVSSIGAFISFASFVFFIGVIYYTLRHGARVTENNYWNEHADTLEWTLPSPPPEHTFETLPKREDWDRSPAH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCCGACGCAGTCACCCAGGGCGGAGGGCACGGGGACACCCGCGGGTTCTTCACCCGCTGGTTCATGTCCACCAACCACAAGGACATCGGGATCCTGTATCTGTTCACCTCCGGCATCGTCGGATTCATCGCGGTGGCCTTCACGGTCTACATGCGCATGGAACTGATGGAGCCCGGCGTTCAGTACATGTGCCTGGAGGGCGCGCGCATGACCGCGGCCGCCGCGGGCGAGTGCACCCCCAACGGCCACCTGTGGAACGTGCTGATCACCGCCCACGGCGTGCTGATGATGTTCTTCGTCGTGATTCCGGCGCTGTTCGGGGGCTTTGGCAACTACTTCATGCCGCTGCACATCGGCGCGCCGGACATGGCGTTCCCGCGGCTCAACAACCTGTCGTACTGGCTTTATGTGGCCGGGGCGTCGCTGGCGGTGGCGTCGCTGTTCTCGCCCGGCGGCGCGGGGCAGACCGGCGCGGGGGTGGGCTGGGTGCTCTATCCGCCGCTGTCGACGACCGAGACCGGCTATGCGATGGACCTCGCGATCTTTGCGGTGCATGTCGCGGGCGCCTCGTCGATCCTGGGTGCGATCAACATCATCACCACCTTCCTGAACATGCGAGCGCCGGGCATGACGCTGCACAAGGTGCCGCTGTTCGCCTGGTCGGTGTTCATCACCGCGTGGATGATCCTGCTGGCGCTGCCGGTTCTTGCGGGCGCCATCACCATGCTGCTGACCGACCGGAACTTCGGCACCACCTTCTTCGATCCCTCGGGCGGCGGCGACCCGGTGCTGTACCAGCACATCCTGTGGTTCTTCGGCCATCCGGAGGTCTACATCATCATCATCCCCGGCTTCGGCATCATCAGCCATGTCATCGCCACGTTCTCGCGCAAGCCGATCTTCGGCTACCTGCCGATGGTCTATGCGATGGTGGCCATCGGGGTGCTGGGCTTCGTGGTGTGGGCGCACCACATGTACACCGTGGGCATGTCGCTGACGCAGCAGAGCTACTTCATGCTGGCGACGATGGTGATCGCGGTGCCGACGGGCATCAAGATCTTCAGCTGGATCGCCACGATGTGGGGCGGCTCGGTGGAGTTCAAGACGCCCATGCTGTGGGCCTTCGGGTTCCTGTTCCTGTTCACCGTGGGCGGCGTGACGGGCGTGGTGCTCAGCCAGGCCGCCGTCGACCGCTACTATCACGACACCTACTATGTGGTCGCGCACTTCCACTATGTGATGTCCTTGGGCGCCGTGTTCGCGCTGTTTGCCGGGATCTACTACTGGATCGGCAAGATGTCGGGGCGGCAGTACCCCGAATGGGCCGGCAAGACGCACTTCTGGGCGATGTTCATCGGCTCCAACCTGACCTTCTTTCCGCAGCACTTCCTCGGCCGTCAGGGGATGCCGCGCCGCTACATCGACTACCCCGAGGCGTTCGCGCTGTGGAACTGGGTAAGCTCGATCGGCGCCTTCATCTCGTTCGCCTCGTTCGTGTTCTTCATCGGGGTGATCTACTACACCCTGCGCCACGGCGCGCGCGTGACCGAGAACAACTACTGGAACGAGCACGCCGACACGCTGGAGTGGACCCTGCCCTCGCCGCCGCCCGAACATACGTTCGAGACGCTGCCGAAGCGCGAGGACTGGGACCGCTCGCCCGCCCACTGA\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 4003,
                        "end": 4387,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 0,
                        "neighbouring_end": 9387,
                        "product": "ectoine",
                        "height": 2,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [],
                "type": "ectoine",
                "products": [
                    "ectoine"
                ],
                "anchor": "r218c1"
            }
        ]
    },
    {
        "length": 6693,
        "seq_id": "NZ_NHSD01000219",
        "regions": []
    },
    {
        "length": 6705,
        "seq_id": "NZ_NHSD01000220",
        "regions": []
    },
    {
        "length": 3453,
        "seq_id": "NZ_NHSD01000221",
        "regions": []
    },
    {
        "length": 11862,
        "seq_id": "NZ_NHSD01000222",
        "regions": []
    },
    {
        "length": 6656,
        "seq_id": "NZ_NHSD01000223",
        "regions": []
    },
    {
        "length": 10261,
        "seq_id": "NZ_NHSD01000224",
        "regions": []
    },
    {
        "length": 2849,
        "seq_id": "NZ_NHSD01000225",
        "regions": []
    },
    {
        "length": 9960,
        "seq_id": "NZ_NHSD01000226",
        "regions": []
    },
    {
        "length": 33203,
        "seq_id": "NZ_NHSD01000227",
        "regions": []
    },
    {
        "length": 2995,
        "seq_id": "NZ_NHSD01000228",
        "regions": []
    },
    {
        "length": 10626,
        "seq_id": "NZ_NHSD01000229",
        "regions": []
    },
    {
        "length": 7906,
        "seq_id": "NZ_NHSD01000230",
        "regions": []
    },
    {
        "length": 3255,
        "seq_id": "NZ_NHSD01000231",
        "regions": []
    },
    {
        "length": 11912,
        "seq_id": "NZ_NHSD01000232",
        "regions": []
    },
    {
        "length": 3114,
        "seq_id": "NZ_NHSD01000233",
        "regions": []
    },
    {
        "length": 12186,
        "seq_id": "NZ_NHSD01000234",
        "regions": []
    },
    {
        "length": 6044,
        "seq_id": "NZ_NHSD01000235",
        "regions": []
    },
    {
        "length": 6869,
        "seq_id": "NZ_NHSD01000236",
        "regions": []
    },
    {
        "length": 3563,
        "seq_id": "NZ_NHSD01000237",
        "regions": [
            {
                "start": 1,
                "end": 3563,
                "idx": 1,
                "orfs": [
                    {
                        "start": 6,
                        "end": 1016,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_01604",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01604</span></strong><br>\n \n  Phytoene desaturase (neurosporene-forming)<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01604</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtI_1</span><br>\n \n Location: 6 - 1,016,\n (total: 1011 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 315.4; E-value: 1.3e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRLRGDRSVYQTVSRYVKDERLRVMLSFHPLLIGGNPFHASSVYCLISYLERHWGIHFAMGGTGRLASGLAKLVEGQGNQIRYHAQVEEIEVADGRATGVRLTTGERIPAEIVVSNADSAYTYRRMLPPQVRKRWTDRKLDRARYSMSLFVWYFGTKRQYSETAHHTILLGPRYKELIEDIFERKILADDFSLYLHRPTATDPSLAPDGCDSFYVLSPVPHMDAGIDWSQQAQAYRARIADFLERTELPGLRENIVSEHMITPQDFQDRLLSERGAAFGLEPRLTQSAWFRPHNKSEDVEGLYLVGAGTHPGAGLPGVLSSARVLDQVVPDASEFA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRLRGDRSVYQTVSRYVKDERLRVMLSFHPLLIGGNPFHASSVYCLISYLERHWGIHFAMGGTGRLASGLAKLVEGQGNQIRYHAQVEEIEVADGRATGVRLTTGERIPAEIVVSNADSAYTYRRMLPPQVRKRWTDRKLDRARYSMSLFVWYFGTKRQYSETAHHTILLGPRYKELIEDIFERKILADDFSLYLHRPTATDPSLAPDGCDSFYVLSPVPHMDAGIDWSQQAQAYRARIADFLERTELPGLRENIVSEHMITPQDFQDRLLSERGAAFGLEPRLTQSAWFRPHNKSEDVEGLYLVGAGTHPGAGLPGVLSSARVLDQVVPDASEFA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGCCTGCGCGGCGACCGCAGCGTCTATCAGACGGTCAGCCGCTACGTGAAGGACGAGCGGCTGCGGGTCATGCTGTCGTTCCATCCGCTCTTGATCGGCGGCAACCCCTTCCATGCCAGTTCGGTCTATTGCCTGATCTCCTATCTGGAACGGCACTGGGGTATCCATTTCGCGATGGGCGGCACCGGCCGGCTGGCCAGCGGTCTCGCGAAGCTGGTGGAGGGGCAGGGCAACCAGATCCGCTATCACGCGCAGGTCGAGGAGATCGAGGTTGCGGACGGCCGGGCGACCGGTGTGCGCCTTACGACCGGCGAGCGCATTCCCGCCGAGATCGTCGTCTCCAACGCCGACAGCGCCTACACCTACCGCCGGATGCTGCCGCCGCAGGTCCGCAAGCGCTGGACCGACCGCAAGCTGGACCGCGCGCGCTACTCGATGAGTCTGTTCGTCTGGTACTTCGGCACCAAGCGACAGTACTCGGAGACGGCGCACCATACGATCCTGCTTGGCCCGCGCTACAAGGAGCTGATCGAGGACATCTTCGAGCGCAAAATCCTGGCCGACGACTTCTCGCTGTATCTGCACCGGCCGACCGCGACCGATCCGTCGCTGGCGCCGGACGGCTGCGATAGCTTCTACGTGTTGTCGCCGGTGCCGCACATGGATGCCGGGATCGACTGGTCGCAGCAGGCGCAGGCGTATCGCGCGCGGATCGCGGATTTCCTGGAGCGCACCGAGTTGCCGGGCCTGCGCGAGAACATCGTGTCCGAACACATGATCACGCCGCAGGATTTTCAGGACCGCCTGCTGTCCGAGCGCGGCGCGGCCTTCGGGCTGGAGCCGCGACTGACACAGAGCGCCTGGTTCCGCCCCCACAACAAGAGCGAGGACGTCGAGGGTCTATACCTCGTTGGTGCCGGTACCCATCCCGGTGCCGGTTTGCCCGGAGTCCTCTCGTCCGCTCGCGTGCTCGACCAGGTGGTGCCCGATGCCAGTGAATTCGCCTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 997,
                        "end": 2061,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_01605",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01605</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01605</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 997 - 2,061,\n (total: 1065 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPVNSPRDATLRAADAAAATAAIRTGSRSFHAASLVLPRRVREPARGLYAFCREADDAVDTRPDRTRALAELRQRLQWIYDGRPGNNAADRAFADVVAAYAIPQTLPEALLEGFAWDAEERRYRTIQDLRAYGARVAGAVGAMVAMLMGARQAEVVSRATDLGVAMQLTNIARDVGEDARQGRVYLPIDWLEAEGIDADAWLADPRFGPGVARTVERLLAHAEELYQRAEAGIPALPASCRPGITAASRLYRAIGHQVARQGHDSLSRRAVVPAMRKVGLMVDALKGPMPVAHYSDYPCLPETRFLVQAVHEALPALHGFKPDAADASAPVEEGAAAFVIDLFMRLEQRDQARG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPVNSPRDATLRAADAAAATAAIRTGSRSFHAASLVLPRRVREPARGLYAFCREADDAVDTRPDRTRALAELRQRLQWIYDGRPGNNAADRAFADVVAAYAIPQTLPEALLEGFAWDAEERRYRTIQDLRAYGARVAGAVGAMVAMLMGARQAEVVSRATDLGVAMQLTNIARDVGEDARQGRVYLPIDWLEAEGIDADAWLADPRFGPGVARTVERLLAHAEELYQRAEAGIPALPASCRPGITAASRLYRAIGHQVARQGHDSLSRRAVVPAMRKVGLMVDALKGPMPVAHYSDYPCLPETRFLVQAVHEALPALHGFKPDAADASAPVEEGAAAFVIDLFMRLEQRDQARG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCAGTGAATTCGCCTAGAGACGCAACCCTCCGCGCGGCCGATGCCGCAGCGGCGACGGCGGCGATCCGTACCGGATCGCGCAGCTTTCATGCCGCGTCGCTGGTGCTGCCGCGCCGGGTGCGGGAACCGGCGCGCGGGCTCTACGCTTTCTGTCGGGAAGCGGACGACGCCGTCGACACTCGCCCGGATCGCACGCGCGCGCTCGCAGAACTGCGCCAGCGCTTGCAGTGGATTTATGACGGTCGCCCAGGCAACAACGCCGCGGACCGGGCGTTTGCCGACGTGGTCGCCGCCTATGCGATCCCGCAGACCTTGCCCGAAGCGCTGTTGGAAGGCTTCGCCTGGGATGCCGAGGAGCGGCGTTACCGCACGATTCAGGATCTGCGCGCCTATGGCGCCCGGGTTGCCGGGGCGGTCGGCGCGATGGTCGCAATGCTGATGGGCGCGCGCCAGGCGGAGGTCGTCTCGCGGGCCACTGACCTCGGCGTGGCGATGCAGCTGACCAATATCGCCCGCGACGTTGGCGAGGATGCGCGCCAGGGGCGCGTCTATTTGCCGATCGATTGGCTGGAGGCGGAAGGCATCGACGCTGACGCTTGGCTCGCCGACCCACGGTTTGGTCCGGGCGTCGCGCGGACGGTGGAACGGCTGCTAGCCCACGCGGAGGAGCTGTATCAGCGTGCGGAAGCTGGCATTCCCGCGCTGCCGGCTTCCTGCCGCCCAGGCATCACCGCCGCCAGCCGTCTGTACCGGGCGATCGGCCATCAGGTCGCCCGGCAAGGCCACGATTCCTTGTCCCGGCGGGCGGTTGTACCGGCGATGCGCAAGGTCGGGCTGATGGTCGACGCGTTGAAGGGGCCGATGCCGGTTGCGCACTACAGCGACTATCCCTGCTTGCCGGAGACCCGGTTCCTGGTTCAGGCCGTGCACGAGGCATTGCCCGCGCTGCACGGTTTCAAGCCGGACGCAGCGGATGCGTCCGCTCCCGTCGAAGAGGGCGCCGCGGCCTTCGTGATCGACCTGTTCATGCGTCTGGAGCAGCGCGACCAGGCACGCGGGTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2195,
                        "end": 2401,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_01606",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01606</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01606</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,195 - 2,401,\n (total: 207 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDGGWIVLLEGMTVFGLLIGFGIWQLRSLKKMEREDKAKAAAEGREGESAFIRSREPRSGADTGHSEG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDGGWIVLLEGMTVFGLLIGFGIWQLRSLKKMEREDKAKAAAEGREGESAFIRSREPRSGADTGHSEG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGATGGCGGTTGGATTGTGCTGCTGGAGGGGATGACGGTCTTCGGGCTGTTGATCGGCTTCGGCATCTGGCAGTTGCGTTCGCTGAAAAAGATGGAGCGCGAAGATAAGGCCAAGGCGGCGGCCGAGGGACGGGAGGGCGAGTCCGCCTTCATCCGCTCCCGTGAACCCCGGTCAGGCGCGGATACGGGGCATTCGGAAGGGTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2369,
                        "end": 3355,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_01607",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01607</span></strong><br>\n \n  Acyclic carotenoid 1,2-hydratase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01607</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtC_1</span><br>\n \n Location: 2,369 - 3,355,\n (total: 987 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPVGGLGHQRPNTDGPGFDQPVAPGGYVWWYVDALSDDGQHGLTIIAFIGSVFSPYYAWARQRAPGGAADPLNHCSINVALYGEGPNRWAMTERGRTRIDRGARHFSVGPSGLHWDGRTLTIHLDEIAAPLPRAVQGRVRVTPHAMTTQEFAIDHQDRHHWWPMAPTAEVSVALNKPALSWHGTGYLDRNRGDEPLEAGFQEWDWARAPLPSGGTAITYDTFRRDGSDHALSLLVRKDGGIERFDNAVLNDLPSTSIWRIRRKGRADAGHRACVSKTLEDTPFYARSLVETHLAGEPVRAMHESLSLTRFDTRIVRLMLPFRMPRIRA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPVGGLGHQRPNTDGPGFDQPVAPGGYVWWYVDALSDDGQHGLTIIAFIGSVFSPYYAWARQRAPGGAADPLNHCSINVALYGEGPNRWAMTERGRTRIDRGARHFSVGPSGLHWDGRTLTIHLDEIAAPLPRAVQGRVRVTPHAMTTQEFAIDHQDRHHWWPMAPTAEVSVALNKPALSWHGTGYLDRNRGDEPLEAGFQEWDWARAPLPSGGTAITYDTFRRDGSDHALSLLVRKDGGIERFDNAVLNDLPSTSIWRIRRKGRADAGHRACVSKTLEDTPFYARSLVETHLAGEPVRAMHESLSLTRFDTRIVRLMLPFRMPRIRA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCTGTTGGCGGACTGGGGCATCAGCGACCCAACACGGACGGCCCCGGGTTCGATCAGCCGGTCGCGCCGGGCGGCTACGTCTGGTGGTACGTCGACGCGCTGAGCGACGACGGTCAGCACGGCCTGACCATCATCGCCTTCATCGGGTCGGTGTTCTCGCCGTACTACGCCTGGGCCCGACAGCGCGCACCCGGCGGCGCGGCGGACCCGCTGAACCACTGCTCGATCAATGTGGCCCTCTACGGCGAGGGGCCGAACCGCTGGGCGATGACGGAACGTGGCCGCACCCGCATCGATCGCGGCGCGCGGCACTTCTCCGTTGGTCCCAGCGGGCTGCACTGGGATGGCCGGACGCTCACCATCCACCTCGACGAGATCGCCGCGCCGCTGCCACGCGCGGTGCAAGGGCGCGTGCGCGTCACCCCGCACGCGATGACGACCCAGGAGTTCGCGATCGATCACCAGGATCGCCACCACTGGTGGCCGATGGCCCCCACGGCGGAGGTTTCGGTCGCCTTGAACAAACCGGCCCTGTCCTGGCACGGCACCGGCTACCTGGACCGCAACCGCGGCGACGAACCGCTCGAAGCCGGTTTTCAGGAATGGGACTGGGCGCGCGCCCCGCTGCCCTCCGGCGGCACCGCGATCACCTACGACACCTTCCGCCGCGACGGCTCCGACCACGCGCTGTCCCTGCTCGTCAGGAAAGATGGCGGGATCGAACGGTTCGACAACGCCGTCCTCAACGATCTGCCGTCGACATCGATCTGGCGCATCCGCCGCAAGGGCCGCGCCGATGCCGGCCATCGGGCCTGCGTGTCGAAGACGCTGGAGGACACGCCCTTCTACGCCCGCTCGCTGGTCGAGACGCACCTGGCAGGCGAACCGGTGCGGGCGATGCACGAAAGCCTGTCGTTGACGCGCTTCGACACGCGGATCGTGCGCCTGATGCTACCCTTCCGAATGCCCCGTATCCGCGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 996,
                        "end": 2061,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 0,
                        "neighbouring_end": 3563,
                        "product": "terpene",
                        "height": 2,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [],
                "type": "terpene",
                "products": [
                    "terpene"
                ],
                "anchor": "r237c1"
            }
        ]
    },
    {
        "length": 3545,
        "seq_id": "NZ_NHSD01000238",
        "regions": []
    },
    {
        "length": 6839,
        "seq_id": "NZ_NHSD01000239",
        "regions": []
    },
    {
        "length": 6702,
        "seq_id": "NZ_NHSD01000240",
        "regions": []
    },
    {
        "length": 12406,
        "seq_id": "NZ_NHSD01000241",
        "regions": []
    },
    {
        "length": 6819,
        "seq_id": "NZ_NHSD01000242",
        "regions": []
    },
    {
        "length": 6837,
        "seq_id": "NZ_NHSD01000243",
        "regions": []
    },
    {
        "length": 9782,
        "seq_id": "NZ_NHSD01000244",
        "regions": []
    },
    {
        "length": 9924,
        "seq_id": "NZ_NHSD01000245",
        "regions": []
    },
    {
        "length": 9954,
        "seq_id": "NZ_NHSD01000246",
        "regions": []
    },
    {
        "length": 10009,
        "seq_id": "NZ_NHSD01000247",
        "regions": []
    },
    {
        "length": 10093,
        "seq_id": "NZ_NHSD01000248",
        "regions": []
    },
    {
        "length": 10284,
        "seq_id": "NZ_NHSD01000249",
        "regions": []
    },
    {
        "length": 10319,
        "seq_id": "NZ_NHSD01000250",
        "regions": []
    },
    {
        "length": 10343,
        "seq_id": "NZ_NHSD01000251",
        "regions": []
    },
    {
        "length": 10405,
        "seq_id": "NZ_NHSD01000252",
        "regions": []
    },
    {
        "length": 10430,
        "seq_id": "NZ_NHSD01000253",
        "regions": []
    },
    {
        "length": 10728,
        "seq_id": "NZ_NHSD01000254",
        "regions": []
    },
    {
        "length": 10850,
        "seq_id": "NZ_NHSD01000255",
        "regions": []
    },
    {
        "length": 21048,
        "seq_id": "NZ_NHSD01000256",
        "regions": []
    },
    {
        "length": 10929,
        "seq_id": "NZ_NHSD01000257",
        "regions": []
    },
    {
        "length": 10933,
        "seq_id": "NZ_NHSD01000258",
        "regions": []
    },
    {
        "length": 10965,
        "seq_id": "NZ_NHSD01000259",
        "regions": []
    },
    {
        "length": 11075,
        "seq_id": "NZ_NHSD01000260",
        "regions": []
    },
    {
        "length": 11312,
        "seq_id": "NZ_NHSD01000261",
        "regions": []
    },
    {
        "length": 11503,
        "seq_id": "NZ_NHSD01000262",
        "regions": []
    },
    {
        "length": 11702,
        "seq_id": "NZ_NHSD01000263",
        "regions": []
    },
    {
        "length": 11723,
        "seq_id": "NZ_NHSD01000264",
        "regions": []
    },
    {
        "length": 19381,
        "seq_id": "NZ_NHSD01000265",
        "regions": []
    },
    {
        "length": 19477,
        "seq_id": "NZ_NHSD01000266",
        "regions": []
    },
    {
        "length": 19539,
        "seq_id": "NZ_NHSD01000267",
        "regions": []
    },
    {
        "length": 19746,
        "seq_id": "NZ_NHSD01000268",
        "regions": []
    },
    {
        "length": 21725,
        "seq_id": "NZ_NHSD01000269",
        "regions": []
    },
    {
        "length": 19850,
        "seq_id": "NZ_NHSD01000270",
        "regions": []
    },
    {
        "length": 20166,
        "seq_id": "NZ_NHSD01000271",
        "regions": []
    },
    {
        "length": 20199,
        "seq_id": "NZ_NHSD01000272",
        "regions": []
    },
    {
        "length": 21589,
        "seq_id": "NZ_NHSD01000273",
        "regions": [
            {
                "start": 6312,
                "end": 21589,
                "idx": 1,
                "orfs": [
                    {
                        "start": 6817,
                        "end": 7518,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02026",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02026</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02026</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,817 - 7,518,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MVAIVAGLWAPGGAAALDLPEVVRLDVTFAGLPVGVLHLAIRRTDGSYAATARLQPAGLGRLLPSARFEATVQGRLRAGRPQPLRYVEDVHTGRRESRTEIAWEGGVPRLLRLDPPRPPEPWHLDPAGQGGALDPMSAVLSVLADVPAERACALDLAVFDGRRRTQIVLAPAPDGEPGCDGVFRRVAGYDPEDLAERPEVPFRLIHGPGPGGTLRVIALEAAWELGTARLTRD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=0&amp;to=17518\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MVAIVAGLWAPGGAAALDLPEVVRLDVTFAGLPVGVLHLAIRRTDGSYAATARLQPAGLGRLLPSARFEATVQGRLRAGRPQPLRYVEDVHTGRRESRTEIAWEGGVPRLLRLDPPRPPEPWHLDPAGQGGALDPMSAVLSVLADVPAERACALDLAVFDGRRRTQIVLAPAPDGEPGCDGVFRRVAGYDPEDLAERPEVPFRLIHGPGPGGTLRVIALEAAWELGTARLTRD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGTGGCCATCGTGGCGGGGCTGTGGGCGCCCGGCGGCGCGGCGGCGCTTGATCTGCCCGAGGTGGTGCGCCTCGATGTGACTTTTGCGGGGCTGCCGGTGGGGGTGCTGCACCTTGCCATCCGCCGCACCGACGGCAGCTATGCCGCGACGGCGCGGCTGCAACCGGCGGGGCTGGGGCGTCTGCTGCCCTCGGCCCGGTTCGAGGCGACGGTGCAGGGCCGCCTGCGCGCAGGCCGCCCGCAGCCGCTGCGCTATGTCGAGGATGTGCACACCGGACGGCGCGAATCGCGCACCGAAATCGCATGGGAGGGGGGGGTGCCGCGCCTGCTGCGCCTTGACCCGCCGCGCCCGCCCGAGCCGTGGCACCTCGACCCGGCGGGGCAGGGCGGTGCGCTCGATCCGATGTCGGCGGTGCTGTCGGTGCTTGCGGATGTTCCGGCGGAGCGGGCCTGCGCGCTCGACCTTGCGGTGTTCGACGGGCGGCGGCGCACGCAGATCGTTCTGGCGCCCGCGCCGGACGGCGAGCCCGGCTGCGACGGCGTGTTTCGCCGCGTCGCAGGGTATGACCCCGAGGATCTGGCCGAGCGGCCGGAGGTGCCGTTCCGCCTGATCCACGGCCCCGGCCCGGGCGGCACCCTGCGCGTCATCGCACTGGAGGCCGCCTGGGAGCTGGGCACCGCCCGGCTGACCCGCGACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 7528,
                        "end": 10089,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02027",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02027</span></strong><br>\n \n  Aminopeptidase N<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02027</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pepN</span><br>\n \n Location: 7,528 - 10,089,\n (total: 2562 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKDATPQPIRLADYTPPPFLVEGVALTFRLAPRATRVTSRIRFRRNPDAQAQDLRLDGEGLRLISATIDGVPITAQPDATGLTLPGGDLPDAFDWAAEVEIAPEENTALEGLYMSNGMYCTQCEAEGFRKITFYPDRPDVMAPFTVRVESELPVLLSNGNPSAQGDGWAEWDDPWPKPAYLFALVAGDLVAHSDAFATASGRAVALNVWVRPGDEGRCAYAMDSLKRSMRWDEEAYGREYDLDVFNIVAVDDFNMGAMENKGLNVFNSKYVLASSETATDADFDNIERIVAHEYFHNWTGNRITCRDWFQLCLKEGLTVFRDQQFSADMRSAAVKRIEDVLSLRARQFREDQGPLAHPVRPDSYHEINNFYTATVYEKGAEIIRMLRTLVGEDGYDAGVRLYFDRHDGQACTIEDWLAVFAEATGRDLSQFARWYAQAGTPRLRVTEDWDEGTGRFTLTLEQSTPPTPGQPDKAPQVIPVAVGLLGPAGDEIMATRVIEMTDTRHSLTIEGMPARPVPSILRGFSAPVVVEHAVTPERRAFLMAHDTDPFSRWEAGRGLAREILVAMVRDGAAPGPDYLDALAVTLSDERLDPAFRALCLRAPSEDDIAQALVDAGETPDPMAIHTARERFQRAIAAHMDDGLARAFIAMETPGPYSPDARDAGRRALRLAALAYLSRNDGGDRAARLFAGADNMTEQMGALGALLQVGAGQSEVARFHRQWAHDRLVVDKWFAVQVALAAPESAVETARSLTRHPDFDWKNPNRFRSVLGALATNAAGFHAPGGAGYALLADWLIQLDPVNPQTAARLSTAFETWRRYDPARQGAMRAALERIRATPDLSRDLSEMTARMLG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=0&amp;to=20089\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKDATPQPIRLADYTPPPFLVEGVALTFRLAPRATRVTSRIRFRRNPDAQAQDLRLDGEGLRLISATIDGVPITAQPDATGLTLPGGDLPDAFDWAAEVEIAPEENTALEGLYMSNGMYCTQCEAEGFRKITFYPDRPDVMAPFTVRVESELPVLLSNGNPSAQGDGWAEWDDPWPKPAYLFALVAGDLVAHSDAFATASGRAVALNVWVRPGDEGRCAYAMDSLKRSMRWDEEAYGREYDLDVFNIVAVDDFNMGAMENKGLNVFNSKYVLASSETATDADFDNIERIVAHEYFHNWTGNRITCRDWFQLCLKEGLTVFRDQQFSADMRSAAVKRIEDVLSLRARQFREDQGPLAHPVRPDSYHEINNFYTATVYEKGAEIIRMLRTLVGEDGYDAGVRLYFDRHDGQACTIEDWLAVFAEATGRDLSQFARWYAQAGTPRLRVTEDWDEGTGRFTLTLEQSTPPTPGQPDKAPQVIPVAVGLLGPAGDEIMATRVIEMTDTRHSLTIEGMPARPVPSILRGFSAPVVVEHAVTPERRAFLMAHDTDPFSRWEAGRGLAREILVAMVRDGAAPGPDYLDALAVTLSDERLDPAFRALCLRAPSEDDIAQALVDAGETPDPMAIHTARERFQRAIAAHMDDGLARAFIAMETPGPYSPDARDAGRRALRLAALAYLSRNDGGDRAARLFAGADNMTEQMGALGALLQVGAGQSEVARFHRQWAHDRLVVDKWFAVQVALAAPESAVETARSLTRHPDFDWKNPNRFRSVLGALATNAAGFHAPGGAGYALLADWLIQLDPVNPQTAARLSTAFETWRRYDPARQGAMRAALERIRATPDLSRDLSEMTARMLG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGGACGCAACCCCCCAGCCGATCCGACTGGCGGACTACACCCCGCCGCCGTTCCTGGTGGAGGGGGTCGCGCTGACCTTCCGGCTGGCGCCACGGGCCACGCGGGTGACGTCGCGCATCCGGTTCCGGCGCAACCCCGACGCGCAGGCCCAAGATCTGCGGCTGGATGGCGAGGGGCTGCGGCTGATCTCGGCCACCATCGACGGCGTGCCGATCACCGCGCAGCCCGATGCGACGGGCCTGACGCTGCCGGGCGGGGATCTGCCGGACGCCTTTGACTGGGCCGCCGAGGTGGAGATCGCACCGGAGGAAAACACCGCGCTGGAGGGGCTTTACATGTCGAATGGCATGTATTGCACGCAGTGCGAGGCCGAAGGCTTCCGCAAGATCACCTTCTATCCCGACCGCCCGGACGTGATGGCACCGTTCACGGTGCGGGTCGAATCCGAGCTGCCGGTGCTGCTGTCGAACGGCAATCCGTCCGCCCAGGGCGATGGCTGGGCCGAATGGGACGATCCCTGGCCCAAGCCCGCCTATCTGTTCGCGCTGGTGGCGGGCGATCTGGTGGCACATTCGGACGCCTTTGCCACCGCATCGGGGCGCGCGGTCGCGCTGAATGTCTGGGTGCGCCCGGGCGACGAGGGGCGCTGCGCCTATGCGATGGATTCGCTCAAACGCTCCATGCGCTGGGATGAGGAGGCCTACGGGCGCGAATACGACCTCGATGTGTTCAACATCGTGGCGGTGGACGACTTCAACATGGGCGCGATGGAGAACAAGGGGCTCAACGTCTTCAACTCCAAATACGTCCTCGCCTCCTCCGAGACGGCGACGGATGCCGACTTCGACAACATCGAGCGCATCGTCGCGCATGAATACTTCCACAACTGGACCGGCAACCGCATCACCTGCCGCGACTGGTTCCAGCTGTGCCTCAAGGAAGGGCTGACGGTGTTCCGCGACCAGCAGTTCAGCGCCGACATGCGCTCGGCCGCCGTCAAGCGGATCGAGGACGTGCTGAGCCTGCGCGCACGCCAGTTCCGCGAGGATCAGGGCCCGCTGGCGCATCCGGTGCGCCCCGACAGCTATCACGAGATCAACAACTTCTACACCGCGACGGTGTACGAGAAGGGCGCCGAGATCATCCGCATGCTGCGCACGCTGGTGGGCGAGGACGGCTATGACGCGGGCGTGCGGCTCTATTTCGACCGCCACGACGGGCAGGCCTGCACGATCGAGGACTGGTTGGCGGTGTTCGCGGAGGCCACGGGGCGCGACCTGTCGCAATTCGCGCGCTGGTATGCCCAGGCCGGCACCCCGCGCCTGCGGGTGACCGAGGATTGGGACGAGGGCACCGGCCGCTTCACCCTGACGCTGGAGCAGTCCACCCCCCCCACCCCGGGCCAGCCCGACAAGGCACCCCAGGTGATCCCGGTGGCCGTTGGCCTGCTGGGTCCCGCGGGCGACGAGATCATGGCCACCCGCGTGATCGAGATGACCGACACCCGCCACAGCCTGACGATCGAGGGGATGCCGGCACGCCCCGTCCCGTCGATCCTGCGCGGCTTCTCCGCCCCGGTGGTGGTCGAGCACGCGGTCACGCCGGAACGCCGCGCCTTTCTGATGGCCCATGACACCGATCCGTTTTCCCGGTGGGAGGCCGGGCGCGGGCTGGCGCGCGAGATCCTTGTGGCGATGGTGCGCGACGGCGCGGCGCCCGGGCCGGATTACCTCGATGCGCTGGCGGTGACGCTGTCGGACGAACGGCTGGACCCGGCGTTCCGCGCGCTGTGCCTGCGCGCGCCCTCCGAGGATGACATCGCCCAGGCGCTGGTGGATGCCGGCGAGACGCCGGACCCCATGGCGATCCACACCGCGCGCGAGCGGTTCCAGCGCGCGATCGCGGCCCACATGGACGACGGGCTGGCGCGCGCCTTCATCGCGATGGAGACGCCCGGCCCCTACAGCCCCGACGCGCGCGACGCGGGCCGCCGGGCGCTGCGGCTGGCGGCACTGGCGTATCTGTCGCGCAATGACGGCGGGGACCGGGCCGCGCGGCTGTTCGCCGGGGCCGACAACATGACCGAACAGATGGGCGCGCTGGGGGCCCTGCTGCAGGTCGGCGCGGGCCAGTCCGAGGTCGCGCGGTTCCACCGTCAATGGGCCCACGACCGGCTGGTGGTGGACAAGTGGTTCGCCGTTCAGGTGGCCCTCGCAGCGCCCGAAAGCGCGGTGGAGACCGCGCGCAGCCTGACGCGCCACCCCGATTTCGACTGGAAGAACCCCAACCGCTTCCGCTCGGTGCTGGGTGCGCTGGCGACGAATGCGGCGGGGTTCCACGCGCCGGGGGGCGCAGGCTATGCGCTGCTGGCGGACTGGCTGATCCAGCTTGATCCGGTGAACCCGCAGACCGCGGCGCGGCTGTCGACGGCGTTCGAGACCTGGCGCCGCTACGACCCCGCGCGCCAGGGCGCGATGCGCGCGGCGCTGGAGCGGATCCGCGCGACCCCCGACCTCAGCCGCGATCTGTCGGAAATGACGGCCCGGATGCTGGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 10256,
                        "end": 11779,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02028",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02028</span></strong><br>\n \n  Cryptochrome-like protein cry2<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02028</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">cry2</span><br>\n \n Location: 10,256 - 11,779,\n (total: 1524 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTGSIVWFKRDLRVADHAALCAAAALGPVLPLYVVEPELWAQPDASARQWAFVAECLEALRGDLAALGAPLVVRTGCAVEVLETLARRHRLSRIFSHEETGTLWTFARDRRVGAWARANGMAWHEGPQSGVVRRLAARDGWAGRRDRFLAAPAAQPPGLSAVPGVAPGPIPTARTLRLAEDRCPHRQVGGRQAALTTLGGFLTSRGEGYRAAMASPVAGERACSRLSPHLAFGVLSGREVAHAAAARRAERPGGGWGASLRSFESRLAWRDHFMQKLEDAPDLEARCLHRATESLRPRTPDATRLAAFQSAETGIPFVDACLRYLAATGWLNFRMRAMLVSVAANHLWLDWRATGPFLARRFTDYEPGIHWSQMQMQSGTTGINTIRIYNPVKQGRDQDPDGRFTRAWLPELAEVPDAFLHEPWRWGGAGRVLGRAYPEPVVDVAAAARAAREAVWGLRRARGFAAEAAEVARKHASRKDRSGHFVNDRAPRRRRPAAAPGQLSLDL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=256&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTGSIVWFKRDLRVADHAALCAAAALGPVLPLYVVEPELWAQPDASARQWAFVAECLEALRGDLAALGAPLVVRTGCAVEVLETLARRHRLSRIFSHEETGTLWTFARDRRVGAWARANGMAWHEGPQSGVVRRLAARDGWAGRRDRFLAAPAAQPPGLSAVPGVAPGPIPTARTLRLAEDRCPHRQVGGRQAALTTLGGFLTSRGEGYRAAMASPVAGERACSRLSPHLAFGVLSGREVAHAAAARRAERPGGGWGASLRSFESRLAWRDHFMQKLEDAPDLEARCLHRATESLRPRTPDATRLAAFQSAETGIPFVDACLRYLAATGWLNFRMRAMLVSVAANHLWLDWRATGPFLARRFTDYEPGIHWSQMQMQSGTTGINTIRIYNPVKQGRDQDPDGRFTRAWLPELAEVPDAFLHEPWRWGGAGRVLGRAYPEPVVDVAAAARAAREAVWGLRRARGFAAEAAEVARKHASRKDRSGHFVNDRAPRRRRPAAAPGQLSLDL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGGTTCGATTGTCTGGTTCAAGCGTGACCTGCGGGTGGCCGACCACGCGGCGCTGTGTGCGGCGGCGGCGCTTGGCCCCGTGCTGCCGCTTTATGTGGTGGAGCCGGAGCTGTGGGCACAGCCCGACGCCTCGGCCCGGCAATGGGCGTTCGTTGCCGAGTGTCTGGAGGCGCTGCGCGGCGACCTGGCCGCGCTGGGGGCGCCGCTGGTCGTGCGCACTGGCTGCGCGGTCGAGGTGCTGGAGACGCTGGCCCGCCGCCACCGCCTGTCGCGCATCTTCAGCCACGAGGAGACCGGCACCCTGTGGACCTTTGCCCGCGACCGGCGTGTGGGGGCGTGGGCGCGCGCCAACGGCATGGCGTGGCACGAGGGGCCGCAGTCGGGCGTGGTGCGCCGCCTTGCCGCGCGCGATGGCTGGGCGGGGCGGCGGGATCGCTTCCTCGCCGCGCCCGCGGCCCAGCCGCCGGGGCTGTCGGCGGTGCCCGGCGTGGCGCCCGGCCCGATCCCCACCGCCCGCACCCTGCGCCTGGCCGAGGACCGCTGCCCCCACCGCCAGGTTGGCGGGCGGCAGGCCGCGCTGACCACGCTGGGCGGGTTCCTGACCTCGCGGGGCGAGGGGTACCGCGCCGCCATGGCCTCGCCCGTAGCCGGGGAACGCGCGTGTTCGCGCCTCTCGCCGCACCTGGCCTTCGGCGTGCTGTCCGGGCGCGAGGTCGCGCACGCCGCGGCCGCCCGCCGCGCCGAACGCCCCGGCGGTGGCTGGGGGGCTTCGCTGCGCAGCTTTGAATCGCGCCTCGCCTGGCGCGACCACTTCATGCAGAAGCTGGAGGACGCCCCCGACCTGGAGGCCCGCTGCCTGCACCGCGCGACCGAAAGCCTGCGCCCGCGCACGCCCGACGCCACCCGCCTCGCGGCATTCCAGTCCGCCGAGACCGGCATCCCCTTTGTCGACGCCTGCCTGCGGTATCTGGCGGCCACCGGCTGGCTGAACTTCCGCATGCGCGCGATGCTGGTGTCGGTGGCGGCGAACCACCTGTGGCTGGACTGGCGCGCCACGGGGCCGTTCCTGGCGCGGCGCTTCACCGACTACGAACCCGGCATCCACTGGAGCCAGATGCAGATGCAGTCCGGCACCACCGGCATCAACACCATCCGCATCTACAACCCCGTCAAGCAGGGCCGCGACCAGGACCCCGACGGCCGCTTCACCCGCGCCTGGCTGCCGGAGCTGGCCGAGGTGCCCGACGCCTTCCTGCACGAACCCTGGCGCTGGGGCGGGGCAGGGCGCGTGCTGGGGCGCGCCTATCCCGAGCCGGTGGTCGATGTCGCCGCCGCCGCCCGCGCCGCGCGCGAGGCGGTGTGGGGCCTGCGCCGCGCCCGCGGTTTCGCCGCCGAAGCCGCCGAGGTCGCCCGCAAGCACGCCAGCCGCAAGGACCGCTCGGGCCATTTCGTCAACGACCGCGCGCCCCGACGCCGTCGCCCCGCCGCAGCCCCGGGCCAGCTGTCGCTGGATCTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 11878,
                        "end": 12774,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02029",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02029</span></strong><br>\n \n  1,4-dihydroxy-2-naphthoate octaprenyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02029</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">menA</span><br>\n \n Location: 11,878 - 12,774,\n (total: 897 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ubiA<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSVTSDLHTRTLPQPAAMLELIKPITWFPPMWAYLCGVISSGVSPLESLFLVILGVLLAGPIVCGMSQAANDWCDRHVDAINEPHRPIPSGRIPGRWGLWIALAMSGLALVVGWFLGPWGFGATVLGVIAAWAYSCPPVRLKRSGWWGPGLVGLSYESLPWFTGAAVLAVGAPSWEIVAVAVLYGLGAHGIMTLNDFKALEGDRQMGVNSLPVTLGPELAAKVACWVMIVPQLVVIALLFQWDRPWYGFFIVISVILQFYAMSVLLRDPKAKAPWYNATGVSLYVTGMMITAFALRTL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=1878&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSVTSDLHTRTLPQPAAMLELIKPITWFPPMWAYLCGVISSGVSPLESLFLVILGVLLAGPIVCGMSQAANDWCDRHVDAINEPHRPIPSGRIPGRWGLWIALAMSGLALVVGWFLGPWGFGATVLGVIAAWAYSCPPVRLKRSGWWGPGLVGLSYESLPWFTGAAVLAVGAPSWEIVAVAVLYGLGAHGIMTLNDFKALEGDRQMGVNSLPVTLGPELAAKVACWVMIVPQLVVIALLFQWDRPWYGFFIVISVILQFYAMSVLLRDPKAKAPWYNATGVSLYVTGMMITAFALRTL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTGTCACGTCTGATTTACACACCCGCACCCTGCCACAGCCCGCCGCGATGCTGGAGCTGATCAAGCCGATCACCTGGTTTCCGCCGATGTGGGCCTATCTGTGCGGCGTCATCTCGTCCGGGGTGTCGCCGCTGGAAAGCCTGTTTCTGGTCATCCTCGGCGTCCTGCTGGCGGGTCCCATCGTCTGCGGGATGAGCCAGGCGGCCAACGACTGGTGCGACCGCCACGTCGATGCGATCAACGAACCGCACCGGCCGATCCCCTCGGGGCGCATTCCGGGCCGCTGGGGGCTGTGGATCGCGCTGGCGATGTCGGGGCTGGCGCTGGTGGTGGGCTGGTTCCTCGGGCCGTGGGGCTTTGGCGCCACCGTGCTGGGGGTGATCGCGGCCTGGGCCTATTCCTGCCCGCCGGTGCGGCTGAAGCGGTCGGGCTGGTGGGGGCCGGGGCTGGTCGGGCTGTCGTATGAATCGCTGCCGTGGTTCACCGGCGCGGCCGTCCTCGCCGTCGGCGCGCCCAGCTGGGAGATCGTCGCGGTGGCCGTGCTCTATGGCCTCGGCGCGCACGGGATCATGACGCTCAACGATTTCAAGGCGCTGGAGGGCGATCGCCAGATGGGCGTGAACTCCCTGCCCGTGACGCTGGGCCCGGAGCTGGCGGCCAAGGTCGCGTGCTGGGTGATGATCGTCCCGCAACTCGTTGTGATCGCGCTTCTCTTCCAGTGGGATCGTCCCTGGTACGGCTTCTTCATCGTGATCTCGGTGATCCTGCAGTTCTATGCCATGTCGGTGCTGCTGCGCGACCCCAAGGCCAAGGCGCCCTGGTACAATGCCACCGGTGTCAGCCTCTATGTCACCGGCATGATGATCACCGCTTTCGCGCTGCGCACGCTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 12785,
                        "end": 14089,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02030",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02030</span></strong><br>\n \n  Protein PucC<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02030</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pucC_2</span><br>\n \n Location: 12,785 - 14,089,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPVQPLSWLSIFRLGLVQLCLGAIVVLMTSTLNRLMVVELMLPAVLPGALVALHYGIQITRPNWGYRSDTCGNRTRWVIVGMGMLAAGALLAAFAIPVMEATFWLGLCVSILAYALIGMGVGASGTSLLALMATATAEHRRPAAASITWLMMIFGIAVTAITVGQVLDPYSHDRMLAIVAVVTGGAFVVTCLAIWGIERRAGVQAAPLAEPMTFRAGLREIWAERAARNFTFFVFLSMTAYFMQELIMEPFAGLVFDMTPGQTTSMSGAQNGGVFVGMVLVGVCATGLRFGALRSWVVAGCLGSAATLAAITLIASAGLKPLLVPSVITLGFFNGMFAVAAIGAMMQLAGQGRERREGTRMGLWGAAQAIAAGFGGLVGAGLADAMRTTLGNDASAFGAVFSIEAGLFLLSALVALRVMGGRGQTARMGLVAGE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=2785&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPVQPLSWLSIFRLGLVQLCLGAIVVLMTSTLNRLMVVELMLPAVLPGALVALHYGIQITRPNWGYRSDTCGNRTRWVIVGMGMLAAGALLAAFAIPVMEATFWLGLCVSILAYALIGMGVGASGTSLLALMATATAEHRRPAAASITWLMMIFGIAVTAITVGQVLDPYSHDRMLAIVAVVTGGAFVVTCLAIWGIERRAGVQAAPLAEPMTFRAGLREIWAERAARNFTFFVFLSMTAYFMQELIMEPFAGLVFDMTPGQTTSMSGAQNGGVFVGMVLVGVCATGLRFGALRSWVVAGCLGSAATLAAITLIASAGLKPLLVPSVITLGFFNGMFAVAAIGAMMQLAGQGRERREGTRMGLWGAAQAIAAGFGGLVGAGLADAMRTTLGNDASAFGAVFSIEAGLFLLSALVALRVMGGRGQTARMGLVAGE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCGTTCAACCGCTTTCATGGCTCTCCATCTTCCGGCTCGGGCTGGTGCAGCTGTGCCTCGGTGCGATCGTGGTGCTGATGACCTCGACCCTCAACCGGCTGATGGTGGTGGAGCTGATGCTGCCCGCCGTCCTGCCCGGTGCGCTGGTGGCGCTGCACTACGGCATCCAGATCACGCGGCCCAACTGGGGCTACCGCTCGGACACCTGCGGAAACCGCACGCGCTGGGTGATCGTGGGGATGGGGATGCTGGCCGCGGGCGCGCTGCTGGCGGCCTTTGCGATCCCGGTGATGGAGGCGACCTTCTGGCTGGGACTGTGCGTGTCGATCCTCGCCTATGCGCTGATCGGGATGGGGGTGGGGGCCTCGGGGACCTCTCTGCTGGCGCTGATGGCGACGGCCACGGCGGAACACCGCCGGCCGGCGGCGGCCTCGATCACCTGGCTGATGATGATCTTCGGCATCGCCGTCACCGCGATCACCGTGGGGCAGGTGCTGGACCCCTACAGCCACGACCGCATGCTCGCCATCGTCGCGGTGGTCACGGGGGGCGCTTTCGTGGTCACCTGCCTCGCCATCTGGGGGATCGAGCGGCGCGCCGGCGTCCAGGCCGCCCCCCTGGCCGAGCCCATGACCTTCCGTGCCGGCCTGCGCGAGATCTGGGCCGAGCGCGCGGCGCGCAACTTCACCTTCTTCGTGTTCCTGTCGATGACCGCCTATTTCATGCAGGAACTGATCATGGAGCCCTTCGCGGGCCTCGTCTTCGACATGACGCCGGGTCAGACGACGTCCATGTCGGGCGCGCAGAACGGCGGCGTGTTCGTCGGCATGGTGCTGGTGGGGGTGTGCGCCACGGGGCTGCGCTTCGGTGCGCTGCGCTCCTGGGTCGTCGCGGGGTGCCTCGGCTCGGCCGCGACGCTGGCGGCGATCACGCTGATCGCCAGCGCGGGGCTGAAGCCGCTGCTGGTGCCGTCGGTCATCACGCTGGGCTTCTTCAACGGCATGTTCGCGGTCGCCGCCATCGGTGCCATGATGCAGCTCGCCGGTCAGGGCCGCGAGCGCCGCGAGGGCACCCGCATGGGGCTGTGGGGCGCCGCGCAGGCCATCGCCGCGGGCTTTGGCGGGCTGGTGGGCGCGGGGCTGGCCGATGCCATGCGCACCACGCTGGGCAACGACGCCAGCGCCTTCGGCGCCGTCTTTTCGATCGAGGCCGGTCTCTTCCTCCTCAGCGCGCTGGTTGCGCTGCGGGTGATGGGGGGACGCGGCCAAACCGCCCGCATGGGCCTTGTTGCTGGGGAGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 14094,
                        "end": 15287,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02031",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02031</span></strong><br>\n \n  Menaquinone reductase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02031</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">menJ_1</span><br>\n \n Location: 14,094 - 15,287,\n (total: 1194 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1161:oxidoreductase (Score: 73.9; E-value: 2.1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTYDVVVVGGGPCGATAAEDLARAGKRVALIDRAGRIKPCGGAIPPRLIADFDIPDEMIVAKINTARMISPTGRKVDIPIEGGFVGMVDREHFDEFLRVRAAKAGAERHTGTFVRIDRDESGARVIYRDKATKEERALPTRLVIGADGARSGVGRQEVPGGDTIPYVIAYHEIITPPEGGAQAAADYDPMRCDVIYDGAISPDFYGWVFPHGKSCSVGMGTGMDGVDLKACTAALRANSGLAGCETIRREGAPIPLKPLDRWDNGRDVVLAGDAAGVVAPSSGEGIYYAMACGRAAATAVQACLASGRAKDLQMARKMFLKEHGGVFKILGAMQNAYYRSDERRERFVSLCHDIDVQKLTFEAYMNKKLVNARPFAHMKIGVKNLLHLSGLVRPTYA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=4094&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTYDVVVVGGGPCGATAAEDLARAGKRVALIDRAGRIKPCGGAIPPRLIADFDIPDEMIVAKINTARMISPTGRKVDIPIEGGFVGMVDREHFDEFLRVRAAKAGAERHTGTFVRIDRDESGARVIYRDKATKEERALPTRLVIGADGARSGVGRQEVPGGDTIPYVIAYHEIITPPEGGAQAAADYDPMRCDVIYDGAISPDFYGWVFPHGKSCSVGMGTGMDGVDLKACTAALRANSGLAGCETIRREGAPIPLKPLDRWDNGRDVVLAGDAAGVVAPSSGEGIYYAMACGRAAATAVQACLASGRAKDLQMARKMFLKEHGGVFKILGAMQNAYYRSDERRERFVSLCHDIDVQKLTFEAYMNKKLVNARPFAHMKIGVKNLLHLSGLVRPTYA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCTATGATGTCGTCGTCGTCGGAGGGGGACCCTGCGGGGCCACCGCGGCCGAGGATCTGGCCCGCGCCGGCAAGCGCGTGGCCCTGATCGACCGCGCGGGCCGGATCAAGCCCTGCGGCGGGGCCATCCCGCCCCGGCTGATCGCGGATTTCGACATCCCCGACGAGATGATCGTGGCGAAGATCAACACCGCCCGCATGATCTCGCCCACCGGCCGCAAGGTCGACATCCCCATCGAGGGCGGCTTCGTCGGCATGGTCGACCGCGAGCACTTCGACGAATTCCTGCGCGTGCGCGCAGCCAAGGCGGGCGCCGAGCGTCACACCGGCACCTTCGTGCGCATCGACCGGGATGAGAGCGGCGCCCGCGTCATCTACCGCGACAAGGCCACCAAGGAAGAGCGCGCGCTGCCCACCCGGCTCGTGATCGGCGCGGACGGCGCACGCTCCGGCGTGGGCCGGCAGGAGGTGCCGGGCGGCGACACCATCCCCTATGTCATCGCCTATCACGAGATCATCACCCCGCCCGAGGGCGGCGCACAGGCCGCCGCCGACTATGATCCCATGCGCTGCGACGTGATCTATGACGGCGCGATCTCGCCCGACTTCTATGGCTGGGTGTTCCCGCACGGGAAATCCTGTTCCGTCGGCATGGGGACGGGCATGGACGGGGTGGACCTGAAGGCCTGCACGGCGGCGTTGCGCGCGAATTCCGGCCTTGCAGGCTGCGAGACGATCCGGCGTGAAGGCGCGCCGATCCCGCTCAAGCCGCTGGACCGCTGGGACAATGGCCGTGACGTGGTGCTGGCGGGCGATGCCGCCGGTGTGGTGGCGCCCAGCTCGGGTGAGGGGATCTACTATGCCATGGCCTGCGGGCGCGCGGCGGCCACCGCGGTGCAGGCCTGCCTGGCGTCGGGCCGTGCCAAGGACCTGCAGATGGCGCGCAAGATGTTCCTCAAGGAGCACGGCGGCGTCTTCAAGATCCTCGGCGCGATGCAGAACGCCTATTACCGCTCGGACGAGCGGCGCGAACGCTTCGTCTCGCTGTGCCACGACATCGACGTGCAGAAGCTGACGTTCGAGGCCTACATGAACAAGAAGCTGGTGAACGCGCGGCCCTTTGCCCACATGAAGATCGGGGTGAAGAACCTGCTGCACCTGTCGGGCCTCGTGCGGCCCACCTACGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 15296,
                        "end": 15826,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02032",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02032</span></strong><br>\n \n  Isopentenyl-diphosphate Delta-isomerase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02032</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">idi</span><br>\n \n Location: 15,296 - 15,826,\n (total: 531 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTEMIPAWVNGRLTPVEKLEAHLQGLRHKAISVFVMDGDRVLIQQRAMGKYHTPGMWANTCCTHPHWDEGAEACATRRLREELGIEGLTLGHRDRVEYRAEVGNGLIEHEVVDIFTAAAGPTLHIAPNPDEVMAVRWVPLDTLRAEVAREPARFTPWLRIYLAEHAAAIFGAMARA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=5296&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTEMIPAWVNGRLTPVEKLEAHLQGLRHKAISVFVMDGDRVLIQQRAMGKYHTPGMWANTCCTHPHWDEGAEACATRRLREELGIEGLTLGHRDRVEYRAEVGNGLIEHEVVDIFTAAAGPTLHIAPNPDEVMAVRWVPLDTLRAEVAREPARFTPWLRIYLAEHAAAIFGAMARA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGAGATGATCCCGGCCTGGGTGAACGGCCGCCTGACCCCGGTGGAGAAGCTGGAGGCGCATCTGCAAGGGCTGCGCCACAAGGCGATCTCGGTCTTCGTCATGGACGGGGACCGGGTGCTGATCCAGCAGCGCGCGATGGGCAAGTACCACACGCCGGGGATGTGGGCGAACACCTGCTGCACCCATCCCCACTGGGACGAGGGGGCCGAGGCCTGCGCCACCCGCCGCCTGCGCGAGGAGCTGGGGATCGAGGGGCTGACCCTCGGCCACCGCGACCGCGTCGAATACCGCGCCGAGGTCGGCAACGGCCTGATCGAGCATGAGGTGGTGGACATCTTCACCGCCGCCGCCGGCCCGACGCTGCACATCGCCCCGAACCCCGACGAGGTGATGGCGGTGCGCTGGGTCCCGCTCGATACGCTGCGCGCCGAGGTCGCGCGGGAACCCGCGCGCTTCACCCCGTGGCTGCGCATCTATCTGGCAGAGCATGCCGCCGCGATCTTCGGAGCGATGGCGCGCGCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 15839,
                        "end": 16312,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02033",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02033</span></strong><br>\n \n  Tryptophan-rich sensory protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02033</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">tspO_2</span><br>\n \n Location: 15,839 - 16,312,\n (total: 474 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDWLLFSVFLFACAAAGTTGAMFEPGKWYRDLTKPSWTPPNWLFPVAWSLLYIAMSLAAMRVALAGDSALALALWSTQIAFNTLWTPVFFGLKRMRAAMGVMVALWASVAATMVAFWQVDLIAGLLFVPYLAWVTVAGALNFSVWRLNPETGTPAGA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=5839&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDWLLFSVFLFACAAAGTTGAMFEPGKWYRDLTKPSWTPPNWLFPVAWSLLYIAMSLAAMRVALAGDSALALALWSTQIAFNTLWTPVFFGLKRMRAAMGVMVALWASVAATMVAFWQVDLIAGLLFVPYLAWVTVAGALNFSVWRLNPETGTPAGA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGACTGGCTCTTGTTCTCCGTCTTTCTGTTCGCCTGCGCGGCCGCGGGCACCACTGGCGCGATGTTCGAGCCGGGAAAGTGGTATCGTGACCTCACCAAGCCGAGCTGGACGCCTCCGAACTGGCTGTTCCCGGTGGCGTGGTCGCTTCTGTACATCGCGATGTCACTGGCGGCGATGCGGGTGGCGCTGGCGGGTGACAGCGCCCTGGCGCTGGCGTTGTGGTCCACGCAGATCGCCTTCAACACGCTGTGGACACCGGTGTTCTTCGGTCTGAAACGGATGCGGGCGGCGATGGGCGTGATGGTCGCGCTGTGGGCATCGGTCGCGGCGACCATGGTGGCGTTCTGGCAGGTCGACCTGATCGCGGGGCTGTTGTTCGTGCCCTATCTTGCCTGGGTCACGGTGGCGGGTGCGCTGAACTTCAGCGTCTGGCGCCTCAACCCCGAGACAGGCACCCCGGCGGGGGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 16312,
                        "end": 17421,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02034",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02034</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02034</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,312 - 17,421,\n (total: 1110 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSTVATDAPRAAPAVRRTALLAEDLDHCEAAIRTGSRSFFTASKLLPGRVRRPALALYAFCRLSDDAVDLTREKPAAILALRDRLDLVYRGTPRNAPADRAFAAIVEEFEMPRALPEALLEGLAWDAQGRRYRTIDDLHSYSARVAAAVGAMMCVLMRVRDADALARACDLGLAMQLTNIARDVGEDAREGRLFLPTDWMEGAGIDTQAFLADPQPTAPVCRVVRRLLAEADRLYFRSEAGIAALPLSVRPGIAAARHIYAAIGTRIACAGHDSITQRAYTGPGAKLWGLATAGVHVAVTLALPRPVELHALPEPSVAFLVNAAAHAPPARETWAQGRSAALLSVLSDLESRDRARRGLMGRATEPNCE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=6312&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSTVATDAPRAAPAVRRTALLAEDLDHCEAAIRTGSRSFFTASKLLPGRVRRPALALYAFCRLSDDAVDLTREKPAAILALRDRLDLVYRGTPRNAPADRAFAAIVEEFEMPRALPEALLEGLAWDAQGRRYRTIDDLHSYSARVAAAVGAMMCVLMRVRDADALARACDLGLAMQLTNIARDVGEDAREGRLFLPTDWMEGAGIDTQAFLADPQPTAPVCRVVRRLLAEADRLYFRSEAGIAALPLSVRPGIAAARHIYAAIGTRIACAGHDSITQRAYTGPGAKLWGLATAGVHVAVTLALPRPVELHALPEPSVAFLVNAAAHAPPARETWAQGRSAALLSVLSDLESRDRARRGLMGRATEPNCE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCACCGTCGCCACCGACGCCCCCCGCGCGGCCCCGGCCGTGCGCCGCACGGCCCTGTTGGCCGAGGACCTGGACCATTGCGAGGCCGCGATCCGCACCGGGTCGCGGTCCTTCTTCACCGCCTCCAAGCTGTTGCCGGGGCGGGTGCGGCGTCCGGCGCTGGCGCTTTATGCCTTCTGCCGGCTGTCGGACGATGCGGTCGACCTGACGCGCGAGAAGCCCGCCGCGATCCTGGCGCTGCGTGACCGGCTGGACCTGGTGTATCGCGGCACGCCGCGCAATGCCCCTGCCGACCGGGCCTTCGCCGCCATCGTGGAGGAGTTCGAGATGCCGCGCGCCCTGCCGGAGGCCCTGCTGGAGGGGCTGGCGTGGGACGCGCAGGGGCGGCGCTACCGCACCATCGACGATCTGCACAGCTACTCCGCGCGGGTGGCGGCGGCGGTGGGGGCGATGATGTGCGTGCTGATGCGGGTGCGCGATGCCGATGCGCTGGCGCGGGCCTGCGATCTGGGGCTGGCGATGCAGCTGACCAACATCGCCCGCGACGTCGGCGAGGATGCGCGCGAGGGGCGGCTGTTCCTGCCCACCGACTGGATGGAGGGGGCGGGCATCGACACGCAGGCGTTCCTGGCCGATCCGCAGCCCACCGCCCCGGTATGCCGGGTGGTTCGGCGCCTTCTGGCCGAGGCCGACCGGCTGTATTTCCGCTCCGAGGCCGGGATCGCGGCGCTGCCGCTGTCGGTGCGCCCGGGAATTGCGGCGGCGCGTCACATCTATGCCGCCATCGGCACGCGGATCGCCTGTGCGGGCCACGACAGCATCACCCAGCGCGCCTATACCGGGCCGGGGGCCAAGCTGTGGGGGCTGGCCACGGCGGGGGTGCATGTCGCCGTCACCCTGGCGCTGCCGCGCCCGGTGGAGCTGCACGCCCTGCCCGAGCCGTCGGTGGCGTTTCTGGTGAATGCCGCGGCCCACGCACCGCCGGCGCGCGAAACCTGGGCACAGGGACGTTCGGCTGCGCTTTTGTCGGTGCTCTCGGACCTGGAATCGCGCGATCGCGCACGGCGGGGCTTGATGGGACGGGCGACAGAGCCTAACTGCGAGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 17418,
                        "end": 18971,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02035",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02035</span></strong><br>\n \n  Phytoene desaturase (neurosporene-forming)<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02035</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtI_2</span><br>\n \n Location: 17,418 - 18,971,\n (total: 1554 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 410.1; E-value: 2.6e-124)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLNRMQDDVAVAADGARRPRALVIGAGLGGLAAAMRLGAKGYRVTVIDRLDRAGGRGSSITQDGHRFDLGPTIVTVPQLFRELWAACGRDFDADVDLRALDPFYQIRWPDGSHFTVRQSTEAMRAEVARLSPDDLPGYDKFLKDAEARYSFGFEDLGRRSMHKFIDLVKVLPKFAMLRADRSVAAHAAARVRDPRLRMALSFHPLFIGGDPFHVTSMYILVSHLEKEYGVHYAVGGVQAIADAMVRVIEDQGGTLRLDEEVDEVLVKSGRVAGLRTTQGEVMTADIVVSNADAGHTYTRLLRNHRRRRWTDAKLKRRTWSSGLFVWYFGTKGTKDMWPDLGHHTILNGPRYEGLLRDIFLNGKLSEDMSLYIHRPSVTDPGVAPAGDDTFYVLSVVPHLGFDNPVDWKAEGERYRAAMTRVLEEQVMPGFAERVGPSLVFTPEDFRDRYLSPHGAGFSIEPRILQSAYFRPHNVSEELPGLYLVGAGTHPGAGLPGVVSSAEVLGKLVPDAQPQGVA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=7418&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLNRMQDDVAVAADGARRPRALVIGAGLGGLAAAMRLGAKGYRVTVIDRLDRAGGRGSSITQDGHRFDLGPTIVTVPQLFRELWAACGRDFDADVDLRALDPFYQIRWPDGSHFTVRQSTEAMRAEVARLSPDDLPGYDKFLKDAEARYSFGFEDLGRRSMHKFIDLVKVLPKFAMLRADRSVAAHAAARVRDPRLRMALSFHPLFIGGDPFHVTSMYILVSHLEKEYGVHYAVGGVQAIADAMVRVIEDQGGTLRLDEEVDEVLVKSGRVAGLRTTQGEVMTADIVVSNADAGHTYTRLLRNHRRRRWTDAKLKRRTWSSGLFVWYFGTKGTKDMWPDLGHHTILNGPRYEGLLRDIFLNGKLSEDMSLYIHRPSVTDPGVAPAGDDTFYVLSVVPHLGFDNPVDWKAEGERYRAAMTRVLEEQVMPGFAERVGPSLVFTPEDFRDRYLSPHGAGFSIEPRILQSAYFRPHNVSEELPGLYLVGAGTHPGAGLPGVVSSAEVLGKLVPDAQPQGVA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCAACCGCATGCAGGACGACGTGGCCGTGGCCGCGGATGGGGCGCGACGGCCGCGGGCGCTGGTGATCGGCGCGGGTCTGGGTGGGCTGGCGGCGGCGATGCGGCTGGGGGCCAAGGGCTACCGGGTGACGGTGATCGACCGGCTGGACCGGGCGGGCGGGCGCGGGTCGTCGATCACGCAGGACGGGCACCGCTTCGATCTGGGCCCGACCATCGTCACCGTGCCGCAGTTGTTTCGCGAATTGTGGGCGGCGTGCGGGCGCGATTTCGATGCGGACGTGGATTTGCGCGCGCTCGATCCGTTCTATCAGATCCGCTGGCCCGACGGCTCGCACTTCACCGTGCGCCAGTCGACCGAGGCGATGCGGGCCGAGGTGGCGCGGCTGTCGCCCGATGACCTGCCCGGCTACGACAAGTTCCTCAAGGACGCCGAGGCGCGGTATTCCTTCGGCTTCGAGGATCTGGGCCGCCGGTCGATGCACAAGTTCATCGACCTGGTGAAGGTGCTGCCGAAGTTCGCCATGCTGCGCGCCGACCGGTCGGTGGCGGCGCACGCAGCAGCCCGGGTGCGCGACCCGCGCCTGCGCATGGCGCTGTCGTTCCACCCGCTGTTCATCGGCGGCGACCCGTTCCACGTCACCTCCATGTACATCCTCGTCAGCCACCTGGAGAAGGAATACGGCGTGCATTACGCGGTGGGCGGCGTGCAGGCCATCGCCGACGCCATGGTCCGCGTGATCGAGGACCAAGGCGGCACCCTTCGGCTGGACGAGGAGGTCGACGAGGTGCTGGTGAAATCGGGCCGGGTCGCCGGTCTGCGCACCACCCAGGGCGAGGTGATGACCGCCGACATCGTGGTGTCCAACGCGGACGCCGGCCACACCTATACCCGGCTTCTGCGCAACCACCGCCGCCGGCGCTGGACGGATGCCAAGCTGAAGCGGCGCACATGGTCGTCGGGGCTGTTCGTTTGGTACTTCGGGACCAAGGGGACGAAGGACATGTGGCCGGATCTGGGCCACCACACCATCCTCAACGGTCCCCGGTACGAAGGGTTGCTGCGCGACATCTTCCTCAACGGCAAGCTGTCGGAGGACATGAGCCTCTATATCCACCGCCCCTCGGTCACCGATCCGGGCGTGGCGCCTGCGGGCGACGACACCTTCTATGTGCTGTCGGTGGTGCCGCATCTGGGCTTCGACAACCCGGTGGACTGGAAGGCGGAGGGGGAGCGGTACCGCGCCGCCATGACCAGGGTGCTGGAGGAGCAGGTGATGCCGGGCTTTGCCGAGCGTGTGGGCCCGTCGCTGGTGTTCACGCCCGAGGATTTCCGCGACCGCTACCTGTCGCCCCACGGCGCGGGGTTCTCGATCGAGCCGCGGATCCTGCAATCGGCCTATTTCCGGCCGCACAACGTGTCCGAGGAGCTGCCGGGGCTGTATCTGGTGGGCGCGGGCACGCATCCCGGCGCGGGCCTGCCGGGGGTGGTGTCCTCGGCCGAGGTGCTGGGCAAGCTCGTTCCCGACGCGCAGCCGCAGGGGGTCGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 19098,
                        "end": 19808,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02036",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02036</span></strong><br>\n \n  Spheroidene monooxygenase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02036</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtA</span><br>\n \n Location: 19,098 - 19,808,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=METVTLSLFRFPTLSARLWAFGQMALARWDLKRTPDLLQWKLCGSGTGEGFTPVPNTAVYAILATWPSEEIARERIAKSKVWARWRAHAAEDWTIFLAATSVRGKWAGVEPFHAVAEPTDGPLAALTRATVKPKVALKFWGSVPDISRMIGMDEHVAFKIGIGEVPLLHQVTFSIWPDTRTMAEFARHDGPHARAIKAVRDGQWFNEECYARFRILGECGSWDGTSPLKPLERSAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=9098&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"METVTLSLFRFPTLSARLWAFGQMALARWDLKRTPDLLQWKLCGSGTGEGFTPVPNTAVYAILATWPSEEIARERIAKSKVWARWRAHAAEDWTIFLAATSVRGKWAGVEPFHAVAEPTDGPLAALTRATVKPKVALKFWGSVPDISRMIGMDEHVAFKIGIGEVPLLHQVTFSIWPDTRTMAEFARHDGPHARAIKAVRDGQWFNEECYARFRILGECGSWDGTSPLKPLERSAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAGACCGTCACCCTCTCGCTGTTTCGCTTTCCCACCCTGTCCGCGCGGCTCTGGGCGTTCGGCCAGATGGCGCTGGCGCGCTGGGACCTCAAGCGCACCCCCGATCTGTTGCAGTGGAAGCTGTGCGGCTCGGGCACGGGCGAGGGGTTCACCCCGGTGCCCAACACCGCCGTCTATGCGATCCTCGCGACCTGGCCCTCCGAGGAGATCGCCCGGGAGCGCATCGCCAAATCGAAGGTCTGGGCCCGCTGGCGTGCGCATGCCGCCGAGGACTGGACGATCTTCCTCGCGGCGACATCGGTGCGGGGCAAATGGGCCGGGGTGGAGCCGTTCCACGCCGTGGCCGAGCCGACCGACGGCCCGCTGGCGGCGCTGACGCGTGCGACGGTGAAGCCCAAGGTCGCGCTGAAGTTCTGGGGTTCGGTCCCCGACATCTCCCGGATGATCGGCATGGACGAACATGTCGCCTTCAAGATCGGCATCGGCGAGGTGCCGCTGCTGCACCAGGTGACCTTCTCGATCTGGCCCGACACCAGGACGATGGCCGAGTTCGCCCGCCACGACGGCCCCCACGCCCGCGCCATCAAGGCCGTGCGCGACGGGCAATGGTTCAACGAAGAGTGCTATGCCCGCTTCCGCATCCTGGGCGAGTGTGGCAGTTGGGACGGAACAAGCCCGCTGAAACCGCTCGAGAGGTCCGCCGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 19805,
                        "end": 20809,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02037",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02037</span></strong><br>\n \n  Magnesium-chelatase 38 kDa subunit<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02037</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">bchI</span><br>\n \n Location: 19,805 - 20,809,\n (total: 1005 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKAPFPFSAIVGQEEMKLAMVLTAIDPGIGGVLVFGDRGTGKSTAVRALAALLPPIRQVESCPVNSARLEDCPEWARLTSREIVTRPTPVVDLPLGATEDRVVGALDIERALSQGEKAFEPGLLARANRGYLYIDEVNLLEDHIVDLLLDVAQSGQNVVEREGLSIRHPARFVLVGSGNPEEGELRPQLLDRFGLSVEVGSPKDIPTRIEVIRRRDAYENDHAAFMAKWQEEDTTLRERILAARTRLSAIATPEAALHDCAELCVALGSDGLRGELTLLRTGRAFAAYHGADTLTRDHLREVAPMSLRHRLRRDPLDEAGSGARVGRVIEEVFG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=9805&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKAPFPFSAIVGQEEMKLAMVLTAIDPGIGGVLVFGDRGTGKSTAVRALAALLPPIRQVESCPVNSARLEDCPEWARLTSREIVTRPTPVVDLPLGATEDRVVGALDIERALSQGEKAFEPGLLARANRGYLYIDEVNLLEDHIVDLLLDVAQSGQNVVEREGLSIRHPARFVLVGSGNPEEGELRPQLLDRFGLSVEVGSPKDIPTRIEVIRRRDAYENDHAAFMAKWQEEDTTLRERILAARTRLSAIATPEAALHDCAELCVALGSDGLRGELTLLRTGRAFAAYHGADTLTRDHLREVAPMSLRHRLRRDPLDEAGSGARVGRVIEEVFG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGGCTCCGTTCCCGTTCTCCGCGATCGTCGGCCAGGAGGAGATGAAGCTCGCCATGGTCCTGACCGCCATCGACCCCGGCATCGGGGGCGTTCTGGTGTTCGGGGACCGCGGAACGGGGAAATCGACGGCGGTGCGGGCGCTTGCGGCACTGCTGCCGCCCATCCGGCAGGTCGAGAGCTGCCCCGTGAACTCCGCCCGGCTGGAGGACTGCCCCGAGTGGGCGCGGCTGACCTCACGGGAGATCGTCACCCGCCCCACGCCGGTGGTCGACCTGCCGCTGGGCGCGACCGAGGACCGGGTGGTCGGCGCGCTCGACATCGAACGCGCGCTCAGCCAGGGCGAAAAGGCGTTCGAGCCGGGCCTGCTGGCGCGCGCCAACCGCGGGTATCTCTACATCGACGAGGTCAACCTGCTGGAGGACCACATCGTCGACCTGCTGCTGGACGTCGCCCAATCCGGCCAGAACGTGGTGGAGCGCGAGGGCCTCTCGATCCGCCACCCCGCGCGCTTCGTCCTCGTCGGCTCCGGCAACCCCGAGGAAGGCGAGCTGCGTCCGCAGCTTCTCGATCGCTTCGGGCTGTCGGTGGAGGTTGGCTCTCCCAAGGACATCCCCACCCGGATCGAGGTCATCCGCCGCCGCGACGCCTATGAAAACGACCACGCCGCCTTCATGGCCAAATGGCAGGAGGAGGACACCACCCTGCGCGAGCGGATCCTGGCCGCGCGCACCCGGCTGTCGGCCATCGCCACCCCCGAGGCCGCGTTGCACGACTGCGCGGAGCTGTGCGTGGCGCTCGGCTCGGACGGGCTGCGCGGAGAGCTGACGCTGCTGCGCACCGGGCGCGCCTTCGCGGCCTATCACGGCGCCGACACGCTGACCCGCGACCACCTGCGCGAGGTCGCGCCGATGTCGCTGCGCCACCGCCTGCGCCGCGATCCGCTGGACGAGGCCGGGTCGGGCGCCCGCGTCGGCCGCGTGATCGAAGAGGTCTTCGGGTGA\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 16311,
                        "end": 17421,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 6311,
                        "neighbouring_end": 21589,
                        "product": "terpene",
                        "height": 2,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [
                    {
                        "start": 11896,
                        "end": 11898,
                        "strand": 1,
                        "containedBy": [
                            "KKHPANEM_02029"
                        ]
                    }
                ],
                "type": "terpene",
                "products": [
                    "terpene"
                ],
                "anchor": "r273c1"
            }
        ]
    },
    {
        "length": 22057,
        "seq_id": "NZ_NHSD01000274",
        "regions": []
    },
    {
        "length": 22750,
        "seq_id": "NZ_NHSD01000275",
        "regions": []
    },
    {
        "length": 25097,
        "seq_id": "NZ_NHSD01000276",
        "regions": []
    },
    {
        "length": 22444,
        "seq_id": "NZ_NHSD01000277",
        "regions": []
    },
    {
        "length": 22778,
        "seq_id": "NZ_NHSD01000278",
        "regions": []
    },
    {
        "length": 5224,
        "seq_id": "NZ_NHSD01000279",
        "regions": []
    },
    {
        "length": 23221,
        "seq_id": "NZ_NHSD01000280",
        "regions": []
    },
    {
        "length": 23363,
        "seq_id": "NZ_NHSD01000281",
        "regions": []
    },
    {
        "length": 23250,
        "seq_id": "NZ_NHSD01000282",
        "regions": []
    },
    {
        "length": 23693,
        "seq_id": "NZ_NHSD01000283",
        "regions": []
    },
    {
        "length": 43730,
        "seq_id": "NZ_NHSD01000284",
        "regions": []
    },
    {
        "length": 24027,
        "seq_id": "NZ_NHSD01000285",
        "regions": []
    },
    {
        "length": 6271,
        "seq_id": "NZ_NHSD01000286",
        "regions": []
    },
    {
        "length": 34087,
        "seq_id": "NZ_NHSD01000287",
        "regions": [
            {
                "start": 1296,
                "end": 12141,
                "idx": 1,
                "orfs": [
                    {
                        "start": 4568,
                        "end": 5200,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02316",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02316</span></strong><br>\n \n  Anti-sigma-F factor NrsF<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02316</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">nrsF</span><br>\n \n Location: 4,568 - 5,200,\n (total: 633 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKTDDLLAALAADTRPGPGVAQRLSRALPGAMVVAAVVFALGWGVRQDLVAAMTSPAALKPLVPLALAGLAGTLALTLSRPEARGGRTATALWVFAVVLIAAFGAALAAGGLSGLMTDLFTPSLITCLASIPALALPLLAATLWALSAGAPRRPALTGALGGLAAGSLAASLYALYCDQDTALFVLPAYASAIGIVTLTGTVLGTRTLAW&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=15200\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKTDDLLAALAADTRPGPGVAQRLSRALPGAMVVAAVVFALGWGVRQDLVAAMTSPAALKPLVPLALAGLAGTLALTLSRPEARGGRTATALWVFAVVLIAAFGAALAAGGLSGLMTDLFTPSLITCLASIPALALPLLAATLWALSAGAPRRPALTGALGGLAAGSLAASLYALYCDQDTALFVLPAYASAIGIVTLTGTVLGTRTLAW\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGACCGACGACCTCCTCGCCGCACTCGCCGCCGACACCCGGCCGGGCCCGGGCGTCGCGCAACGGCTGTCGCGTGCACTGCCCGGGGCGATGGTCGTCGCGGCGGTCGTCTTCGCGCTGGGCTGGGGCGTGCGGCAGGACCTCGTGGCGGCAATGACCTCGCCCGCCGCGCTGAAACCGCTCGTGCCGCTCGCACTCGCCGGGCTTGCCGGCACGCTGGCCCTGACCCTGTCGCGGCCCGAGGCGCGGGGCGGTCGCACCGCCACCGCCCTTTGGGTCTTCGCCGTGGTCCTGATCGCAGCCTTCGGCGCCGCCCTCGCCGCGGGCGGCCTGTCCGGGCTGATGACCGACCTCTTCACCCCGAGCCTGATCACCTGCCTCGCCAGCATTCCCGCGCTGGCACTCCCTCTCCTCGCCGCCACCCTCTGGGCCCTCTCCGCCGGCGCCCCCCGCCGCCCGGCCCTGACTGGCGCGCTCGGCGGCCTCGCCGCCGGCAGCCTCGCCGCCTCCCTCTACGCGCTCTACTGCGACCAGGACACGGCGCTCTTCGTCCTCCCCGCCTACGCTTCCGCAATCGGGATCGTCACCCTGACCGGGACGGTACTCGGGACCCGCACACTGGCCTGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 5197,
                        "end": 5709,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02317",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02317</span></strong><br>\n \n  ECF RNA polymerase sigma factor SigF<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02317</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">sigF</span><br>\n \n Location: 5,197 - 5,709,\n (total: 513 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily (Score: 86.9; E-value: 2e-26)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRAANRGDAAAYRELLQAITPVLRGVVRARGRMLGPEGCEDVLQEVLLAVHMKRQTWREDAPLRPWLYAIARHKTADAFRARGHRIDLPIEAFSEALPAQDIPDPTQAGDMEKVLARLDPRAADIVRGFGMRGETVAETAARLQMTEGAVRVALHRALKAVARLRERMME&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=15709\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRAANRGDAAAYRELLQAITPVLRGVVRARGRMLGPEGCEDVLQEVLLAVHMKRQTWREDAPLRPWLYAIARHKTADAFRARGHRIDLPIEAFSEALPAQDIPDPTQAGDMEKVLARLDPRAADIVRGFGMRGETVAETAARLQMTEGAVRVALHRALKAVARLRERMME\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGCGCGGCCAACCGCGGCGATGCCGCCGCCTATCGCGAGCTTCTGCAGGCGATCACGCCGGTGTTGCGGGGCGTGGTGCGCGCCCGCGGTCGCATGCTGGGGCCCGAGGGCTGCGAGGATGTGCTGCAGGAGGTTCTGCTGGCCGTTCACATGAAGCGCCAGACCTGGCGCGAGGACGCGCCCCTGCGCCCGTGGCTCTATGCCATCGCGCGGCACAAGACGGCCGACGCCTTCCGCGCCCGCGGCCACCGCATCGACCTGCCGATCGAGGCGTTTTCCGAGGCTCTGCCCGCGCAGGACATCCCCGACCCGACGCAGGCCGGCGACATGGAGAAGGTGCTGGCGCGGCTGGACCCGCGCGCGGCCGACATCGTCCGCGGCTTCGGGATGCGTGGCGAGACGGTTGCCGAAACCGCCGCCCGCCTCCAGATGACCGAGGGCGCGGTGCGCGTGGCACTGCACCGGGCGTTGAAGGCCGTCGCCCGGCTGCGCGAAAGGATGATGGAATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 5912,
                        "end": 6223,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02318",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02318</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02318</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,912 - 6,223,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTTKHLALPLAASVAAALSLAGAQAHAQGATMEKCFGVSLAGQNDCAAGPGTTCSGTSTVDYQGNAWTLVPAGTCETIDLPAMADGTGRMGALEELDRDLPPA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=16223\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTTKHLALPLAASVAAALSLAGAQAHAQGATMEKCFGVSLAGQNDCAAGPGTTCSGTSTVDYQGNAWTLVPAGTCETIDLPAMADGTGRMGALEELDRDLPPA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCACCAAACACCTCGCCCTGCCGCTCGCCGCCTCTGTGGCCGCCGCCCTGTCGCTGGCCGGCGCGCAGGCCCACGCCCAGGGCGCCACCATGGAGAAGTGCTTCGGCGTCTCTCTCGCCGGGCAAAACGACTGCGCGGCGGGGCCGGGCACGACCTGCTCGGGCACCTCGACGGTGGATTACCAGGGCAACGCCTGGACGCTGGTGCCGGCCGGCACCTGCGAGACCATCGACCTGCCGGCGATGGCCGACGGCACCGGGCGCATGGGCGCGCTGGAGGAACTCGACCGCGACCTGCCGCCCGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 6296,
                        "end": 7141,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02319",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02319</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02319</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,296 - 7,141,\n (total: 846 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RiPP-like: DUF692<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPSLPVTTGLGFKPEHFRDIAAAPGAVGFYEVHAENFMGDGGAPHAMLAHLHAGHALSIHGVGLSIGGAGPLDADHLARLRRLIDRHRPESFSEHLAWSSHGAAWLNDLLPLPYTTGTLATVCAHVDAVQQALGLRMLLENPATYVTFAASTWAETDFLAEVVRRTGCGLLLDVNNVFVSATNHRFDPRAYLAAFPLEAVGEIHLAGHDTEELPSGPLLIDSHGRAVADPVWSLYAEVLSRIGPRPTLIEWDSDVPPFAVLRAEADRARALLETRGRADAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=17141\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPSLPVTTGLGFKPEHFRDIAAAPGAVGFYEVHAENFMGDGGAPHAMLAHLHAGHALSIHGVGLSIGGAGPLDADHLARLRRLIDRHRPESFSEHLAWSSHGAAWLNDLLPLPYTTGTLATVCAHVDAVQQALGLRMLLENPATYVTFAASTWAETDFLAEVVRRTGCGLLLDVNNVFVSATNHRFDPRAYLAAFPLEAVGEIHLAGHDTEELPSGPLLIDSHGRAVADPVWSLYAEVLSRIGPRPTLIEWDSDVPPFAVLRAEADRARALLETRGRADAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGTCGTTGCCCGTCACCACCGGACTGGGATTCAAGCCCGAGCATTTCCGCGACATCGCCGCCGCCCCCGGCGCGGTCGGTTTCTACGAGGTCCATGCCGAGAACTTCATGGGCGATGGCGGGGCACCGCACGCGATGCTGGCGCATCTGCATGCGGGGCACGCGCTGTCGATCCATGGCGTCGGGCTGTCGATCGGCGGCGCGGGGCCCCTCGATGCCGATCACCTGGCCCGTCTGCGGCGTCTGATCGACCGTCACCGGCCCGAGAGTTTCTCGGAGCACCTGGCGTGGTCCAGCCACGGCGCGGCCTGGCTCAACGACCTGCTGCCGCTGCCCTACACCACCGGGACGCTGGCGACCGTCTGCGCCCATGTCGACGCGGTGCAGCAGGCGCTGGGGCTGCGGATGCTGCTGGAGAACCCCGCGACCTATGTGACCTTTGCCGCCTCCACCTGGGCCGAGACCGACTTCCTGGCCGAGGTGGTCCGCCGCACCGGCTGCGGGCTGCTGCTGGACGTGAACAACGTCTTCGTCTCGGCCACCAACCACCGCTTCGACCCCCGCGCCTATCTCGCGGCCTTTCCGCTGGAGGCGGTGGGCGAGATCCATCTCGCCGGTCACGACACCGAGGAGCTGCCCTCGGGGCCGCTGCTGATCGACAGCCACGGGCGGGCGGTGGCCGATCCGGTCTGGAGCCTCTATGCCGAGGTGCTGTCCCGCATCGGCCCGCGCCCCACGCTGATCGAATGGGACAGCGATGTGCCGCCCTTCGCGGTGCTGCGGGCCGAAGCCGACCGGGCGCGCGCCCTGCTGGAAACGCGAGGCCGGGCCGATGCCGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 7131,
                        "end": 7880,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02320",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02320</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02320</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,131 - 7,880,\n (total: 750 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPPDSAHAATQAGFHAALWRPDPPQGLTAPAPDEVSRRFAVYRNNVHHSLSRALAAHFPVVAALVGPAFLTAMARVFIAEAPPASPVLQDWGAAFPGFLDRFPPVAHLPWLGDVARLEWARGRAVHAADAPAASADLLGVPDPEVLRLRLHASVALYRSDHPAVSIWRAHQPGAARGPLPPGPEHALVGRQPDFTVVVAPVDVGTHAVLSALARGETLARAAEHADPTIALTLLLRHGLITAPLTGDTP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=17880\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPPDSAHAATQAGFHAALWRPDPPQGLTAPAPDEVSRRFAVYRNNVHHSLSRALAAHFPVVAALVGPAFLTAMARVFIAEAPPASPVLQDWGAAFPGFLDRFPPVAHLPWLGDVARLEWARGRAVHAADAPAASADLLGVPDPEVLRLRLHASVALYRSDHPAVSIWRAHQPGAARGPLPPGPEHALVGRQPDFTVVVAPVDVGTHAVLSALARGETLARAAEHADPTIALTLLLRHGLITAPLTGDTP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGCCTGATTCCGCCCACGCCGCCACGCAGGCCGGTTTCCACGCCGCGCTCTGGCGTCCCGATCCGCCCCAGGGGCTGACCGCCCCGGCGCCGGACGAGGTGTCCCGCCGTTTTGCCGTCTATCGCAACAACGTCCACCACAGCCTGTCCCGGGCGCTGGCCGCACATTTTCCGGTGGTCGCGGCGCTGGTGGGGCCTGCGTTCCTGACCGCCATGGCCCGCGTCTTCATCGCCGAGGCGCCGCCCGCAAGCCCCGTTCTGCAGGACTGGGGCGCGGCCTTTCCCGGCTTCCTCGACCGCTTTCCCCCGGTCGCGCATCTGCCCTGGCTGGGGGATGTCGCCCGGCTGGAATGGGCCCGCGGCCGGGCGGTCCATGCCGCCGACGCTCCGGCCGCATCTGCCGACCTCCTCGGCGTTCCCGACCCCGAAGTGCTGCGGCTCCGCCTTCACGCCTCGGTGGCGCTCTACCGCTCGGACCACCCGGCGGTGTCGATCTGGCGGGCTCATCAGCCCGGCGCCGCCCGCGGCCCGCTGCCGCCGGGGCCCGAGCATGCCCTGGTCGGCCGGCAACCCGACTTCACCGTCGTGGTGGCGCCGGTCGATGTCGGCACGCATGCGGTGCTGAGCGCGCTGGCCCGGGGCGAGACCCTCGCCCGCGCCGCAGAACATGCCGATCCCACAATCGCCCTGACACTGCTGCTGCGCCACGGGCTGATCACTGCCCCCCTGACCGGAGACACGCCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 7877,
                        "end": 8368,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02321",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02321</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02321</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,877 - 8,368,\n (total: 492 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSQVTETTPRPGTAARARQLGRRLNTLGGLVPHDLIALAARVFPAMVFWQSARTKVEGFSIKEQTFFLFEHVYALPLIPPAWAAVLATIAEHILPVLLVLGLMSRLSALGLLIMTAVIQIFVFPGAWVTHGLWAVALLVVVAQGPGRLSLDHLFGLDRGRRQP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=18368\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSQVTETTPRPGTAARARQLGRRLNTLGGLVPHDLIALAARVFPAMVFWQSARTKVEGFSIKEQTFFLFEHVYALPLIPPAWAAVLATIAEHILPVLLVLGLMSRLSALGLLIMTAVIQIFVFPGAWVTHGLWAVALLVVVAQGPGRLSLDHLFGLDRGRRQP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCCAGGTGACCGAAACCACCCCACGCCCGGGCACCGCCGCCCGCGCGCGACAGCTGGGCCGACGCCTCAACACCCTCGGCGGGCTGGTCCCCCATGATCTGATCGCACTTGCCGCGCGGGTCTTCCCGGCCATGGTCTTCTGGCAGTCCGCCCGCACCAAGGTCGAGGGTTTCTCGATCAAGGAGCAGACCTTCTTCCTGTTCGAGCATGTCTATGCCCTGCCACTCATCCCGCCCGCCTGGGCCGCCGTGCTTGCCACCATCGCCGAGCACATCCTGCCGGTGCTGCTGGTCCTCGGCCTGATGTCCCGCCTTTCGGCGCTGGGCCTGCTGATCATGACCGCCGTGATCCAGATCTTCGTCTTTCCTGGCGCCTGGGTCACCCATGGTCTCTGGGCCGTCGCACTCCTCGTGGTCGTGGCCCAAGGCCCCGGCCGCCTCTCCCTCGACCATCTTTTCGGCCTCGACCGGGGCAGGCGGCAGCCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 8540,
                        "end": 10465,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02322",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02322</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02322</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,540 - 10,465,\n (total: 1926 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSRSLRLGLRSALVALPLSLVVGGGAAAQDLSDFGVVAGQSLTNTGPTIITGDIAVSPGTSYTGSGSVVHTGTAYLGDAVAARIQDDLTTLYLALAGRSTSTFGDLTGQDLGGRTLAPGVYNFDTSAMISAGRTLTLDAGGDPNAVFIFNVGSTLTAESGAAMVLENGAQGGNVFFRVGSSATLDTSSALVGQIVALTSISMNDTAGLGCGAAYARNGSVTLINNTIGVCVLAAPGIGDVVDVADLTEPELAVVEALGALVAAGGQIPIAFAILAATQTPEELALSLAQLPGQVATGVAPMGLQSMDDFLDAVVGSGRRPRVAAVSPRDPGVPIGMVRADSIYTGKHGPATAPLSFSTSLAVQPGQWDVWASAYGSRAVIDGNARRGWQKLTSENRGLALGLNHAVSPNTEIGIALSLNDADFELGNGFGSGTAETVMVAVRARTSMDAWYVEGALAHGRSDITTERVVTIAGVDRLVGETDATNTAAHLEAGYHMGPITPFAGLRAQSFTMDPYSETAASGTSSYALRYGKHTTTSLRSELGLDMAWSGNNDMGGTTGLGLRIAWARELASNDPGGRSFVTIPGATFRTTGAAANRDSVLVAATASVTASNGFHVGASINAQYSGRARDVGGSIVIGHRW&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=20465\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSRSLRLGLRSALVALPLSLVVGGGAAAQDLSDFGVVAGQSLTNTGPTIITGDIAVSPGTSYTGSGSVVHTGTAYLGDAVAARIQDDLTTLYLALAGRSTSTFGDLTGQDLGGRTLAPGVYNFDTSAMISAGRTLTLDAGGDPNAVFIFNVGSTLTAESGAAMVLENGAQGGNVFFRVGSSATLDTSSALVGQIVALTSISMNDTAGLGCGAAYARNGSVTLINNTIGVCVLAAPGIGDVVDVADLTEPELAVVEALGALVAAGGQIPIAFAILAATQTPEELALSLAQLPGQVATGVAPMGLQSMDDFLDAVVGSGRRPRVAAVSPRDPGVPIGMVRADSIYTGKHGPATAPLSFSTSLAVQPGQWDVWASAYGSRAVIDGNARRGWQKLTSENRGLALGLNHAVSPNTEIGIALSLNDADFELGNGFGSGTAETVMVAVRARTSMDAWYVEGALAHGRSDITTERVVTIAGVDRLVGETDATNTAAHLEAGYHMGPITPFAGLRAQSFTMDPYSETAASGTSSYALRYGKHTTTSLRSELGLDMAWSGNNDMGGTTGLGLRIAWARELASNDPGGRSFVTIPGATFRTTGAAANRDSVLVAATASVTASNGFHVGASINAQYSGRARDVGGSIVIGHRW\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCCGATCCCTTCGCCTCGGCCTGCGTTCGGCCCTCGTCGCGCTCCCGCTGAGCCTCGTCGTGGGCGGCGGCGCCGCCGCGCAGGATCTGAGCGATTTCGGCGTCGTGGCCGGCCAGTCGCTGACCAACACCGGGCCCACGATCATCACCGGGGACATCGCGGTCAGCCCGGGCACGTCCTACACCGGGTCGGGCAGCGTGGTGCACACGGGCACCGCGTATCTCGGCGATGCGGTGGCGGCACGGATCCAGGACGATCTGACGACGCTGTATCTGGCGCTGGCCGGGCGCAGCACGTCGACCTTTGGCGATCTGACGGGGCAGGATCTGGGCGGCCGGACGCTTGCGCCGGGGGTCTACAACTTCGACACCTCGGCGATGATCTCGGCGGGCCGGACGCTGACGCTGGATGCGGGGGGCGATCCCAACGCCGTCTTCATCTTCAACGTCGGATCGACGCTGACGGCCGAAAGCGGCGCGGCGATGGTGCTCGAGAACGGCGCGCAGGGCGGCAACGTGTTCTTCCGGGTTGGCAGTTCGGCGACGCTGGATACCTCCTCGGCGCTGGTGGGGCAGATCGTGGCGCTGACGAGCATCTCGATGAACGACACCGCCGGGCTGGGCTGCGGCGCCGCTTATGCCCGCAACGGGTCGGTGACGCTGATCAACAACACCATCGGGGTCTGCGTCCTCGCGGCGCCCGGCATCGGGGATGTGGTGGACGTCGCCGACCTGACGGAGCCGGAGCTGGCCGTGGTCGAGGCGCTGGGCGCGCTCGTGGCCGCCGGCGGCCAGATCCCCATCGCATTCGCCATCCTCGCGGCCACCCAGACGCCCGAGGAGCTTGCGCTGAGCCTTGCGCAACTGCCTGGGCAGGTCGCGACCGGCGTGGCGCCGATGGGCCTGCAATCGATGGACGATTTTCTGGACGCGGTCGTGGGTTCGGGGCGCAGGCCGCGCGTGGCCGCCGTGTCGCCGCGCGATCCGGGGGTTCCGATCGGCATGGTCCGGGCCGACAGCATCTACACCGGCAAGCATGGCCCGGCGACGGCCCCGCTGTCGTTTTCAACCTCCCTCGCCGTGCAGCCCGGCCAGTGGGATGTCTGGGCGTCGGCCTATGGCTCGCGCGCCGTGATCGACGGGAACGCGCGCCGCGGCTGGCAGAAGCTGACCTCGGAGAACAGGGGCCTTGCCCTGGGGCTGAACCACGCGGTCAGCCCCAACACGGAGATCGGCATCGCCCTGTCGTTGAATGACGCGGATTTCGAGCTGGGCAACGGCTTCGGCTCCGGCACCGCCGAGACGGTCATGGTGGCGGTTCGGGCGCGGACCTCGATGGACGCCTGGTATGTGGAGGGCGCGCTTGCCCACGGGCGCAGCGACATCACGACCGAGCGGGTGGTGACGATTGCCGGCGTGGACCGCCTCGTGGGCGAAACCGACGCCACCAACACCGCCGCGCATCTGGAGGCGGGCTACCACATGGGCCCGATCACGCCATTTGCGGGGCTGCGCGCGCAGTCCTTCACCATGGACCCGTATTCCGAGACCGCGGCCTCGGGCACCTCCAGCTATGCGCTGCGCTACGGGAAACACACCACCACCTCGCTGCGCAGCGAGCTGGGGCTGGACATGGCCTGGTCCGGCAACAACGACATGGGCGGGACGACCGGCCTCGGGCTGCGGATCGCCTGGGCGCGTGAACTCGCCTCGAACGATCCGGGCGGGCGGTCCTTCGTGACCATTCCCGGCGCGACCTTCCGGACCACGGGGGCGGCGGCGAACCGGGACTCCGTGCTTGTGGCCGCGACGGCGTCGGTGACGGCGTCCAACGGCTTCCATGTCGGCGCCTCGATCAATGCGCAGTATTCGGGCCGCGCCCGCGACGTGGGCGGATCGATCGTGATCGGCCACCGCTGGTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 10603,
                        "end": 10821,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02323",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02323</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02323</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,603 - 10,821,\n (total: 219 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSALRGSAVPQIGGTQVLKRTRCDWIDRRERVIGLGPSGTGKTQVDLMPFATGPEPMAPRWLTRQIGLMLLP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=603&amp;to=20821\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSALRGSAVPQIGGTQVLKRTRCDWIDRRERVIGLGPSGTGKTQVDLMPFATGPEPMAPRWLTRQIGLMLLP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAGTGCCCTGCGGGGGAGTGCGGTCCCGCAGATCGGCGGGACGCAGGTGCTCAAACGCACCCGCTGCGACTGGATCGACCGGCGCGAGCGCGTCATCGGCCTTGGCCCCAGCGGCACCGGCAAGACCCAAGTGGACCTGATGCCGTTCGCCACCGGGCCCGAACCGATGGCGCCGCGATGGCTTACCCGGCAGATCGGCTTGATGCTCCTGCCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 11226,
                        "end": 11480,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02324",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02324</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02324</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,226 - 11,480,\n (total: 255 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPRRITSAILVGHLWLALACLPVAADDFPRLVPLETLLPSPTAPEAAAPLGVRAAMLERRAAALRARVLIDADTRRRMAALAAR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=1226&amp;to=21480\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPRRITSAILVGHLWLALACLPVAADDFPRLVPLETLLPSPTAPEAAAPLGVRAAMLERRAAALRARVLIDADTRRRMAALAAR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGCGCCGCATCACATCTGCGATCCTCGTGGGACATCTGTGGCTTGCGCTGGCCTGCCTGCCTGTGGCGGCCGACGACTTTCCGCGCCTCGTCCCGCTGGAGACGCTGCTGCCGTCGCCCACGGCCCCCGAGGCGGCGGCCCCCCTCGGGGTGCGAGCGGCCATGCTGGAACGCCGGGCGGCGGCCCTGCGCGCGCGGGTCCTGATTGATGCCGATACCCGCCGCCGCATGGCGGCCCTTGCGGCCCGCTGA\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 6295,
                        "end": 7141,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 1295,
                        "neighbouring_end": 12141,
                        "product": "RiPP-like",
                        "height": 2,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [],
                "type": "RiPP-like",
                "products": [
                    "RiPP-like"
                ],
                "anchor": "r287c1"
            }
        ]
    },
    {
        "length": 6272,
        "seq_id": "NZ_NHSD01000288",
        "regions": []
    },
    {
        "length": 35029,
        "seq_id": "NZ_NHSD01000289",
        "regions": []
    },
    {
        "length": 11768,
        "seq_id": "NZ_NHSD01000290",
        "regions": []
    },
    {
        "length": 6509,
        "seq_id": "NZ_NHSD01000291",
        "regions": []
    },
    {
        "length": 36052,
        "seq_id": "NZ_NHSD01000292",
        "regions": [
            {
                "start": 11262,
                "end": 36052,
                "idx": 1,
                "orfs": [
                    {
                        "start": 14088,
                        "end": 15638,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02420",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02420</span></strong><br>\n \n  Dihydrolipoyllysine-residue succinyltransferase component of 2-oxoglutarate dehydrogenase complex<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02420</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">sucB</span><br>\n \n Location: 14,088 - 15,638,\n (total: 1551 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSIEVRVPTLGESVTEATVATWFKKPGETVAADEMLCELETDKVTVEVPSPAAGTLGEIVAAEGDTVGVDALLATLTESDGKPAPARGGAPKAAAPAAPAGDTVDVMVPALGESVSEATVATWFKAVGDSVAADEILCELETDKVSVEVPSPTAGTLSQIVAEAGTTVAAGGKLAVLAAGEGGAAATGTGAAAAPAPPTAAAAERSGAGRADVEDAPSAKKMMAEKGLTRDQVEGTGRDGRIMKEDVARAAADAAPAAQAAPAPTMPAPAAQQAPRAAVPADDAAREERVKMSRLRQTIARRLKDAQNTAAMLTTYNEVDMGPIMDLRNEYKGLFEKKHGVKLGFMSFFVKACCHALHEVPEVNAEIDGTDVVYKNYVHMGVAVGTPSGLVVPVLRDAQAMGFAEIEKTIASLGARARDGKLSMADMQGGSFTISNGGVYGSLMSSPILNPPQSGILGMHKIQDRPMVVKGQIVARPMMYLALSYDHRIVDGKGAVTFLVRVKEALEDPRRLLMDL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=4088&amp;to=25638\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSIEVRVPTLGESVTEATVATWFKKPGETVAADEMLCELETDKVTVEVPSPAAGTLGEIVAAEGDTVGVDALLATLTESDGKPAPARGGAPKAAAPAAPAGDTVDVMVPALGESVSEATVATWFKAVGDSVAADEILCELETDKVSVEVPSPTAGTLSQIVAEAGTTVAAGGKLAVLAAGEGGAAATGTGAAAAPAPPTAAAAERSGAGRADVEDAPSAKKMMAEKGLTRDQVEGTGRDGRIMKEDVARAAADAAPAAQAAPAPTMPAPAAQQAPRAAVPADDAAREERVKMSRLRQTIARRLKDAQNTAAMLTTYNEVDMGPIMDLRNEYKGLFEKKHGVKLGFMSFFVKACCHALHEVPEVNAEIDGTDVVYKNYVHMGVAVGTPSGLVVPVLRDAQAMGFAEIEKTIASLGARARDGKLSMADMQGGSFTISNGGVYGSLMSSPILNPPQSGILGMHKIQDRPMVVKGQIVARPMMYLALSYDHRIVDGKGAVTFLVRVKEALEDPRRLLMDL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCATCGAAGTCCGCGTGCCCACGTTGGGCGAATCCGTCACCGAGGCCACGGTGGCGACGTGGTTCAAGAAGCCCGGCGAGACGGTCGCCGCCGACGAAATGCTGTGCGAGCTGGAGACCGACAAGGTCACGGTGGAGGTGCCCAGCCCCGCCGCCGGCACGCTGGGCGAGATCGTCGCGGCCGAGGGCGACACGGTGGGGGTGGATGCGCTGCTGGCAACCCTGACCGAGAGCGACGGCAAACCCGCACCGGCCCGCGGCGGCGCGCCCAAGGCCGCCGCACCCGCGGCTCCGGCGGGTGACACCGTGGACGTCATGGTCCCCGCGCTGGGCGAAAGCGTCAGCGAGGCGACAGTCGCCACCTGGTTCAAGGCGGTGGGCGACAGCGTCGCCGCCGACGAGATCCTGTGCGAACTGGAGACCGACAAGGTCAGCGTCGAGGTCCCGAGCCCCACCGCCGGCACGCTGTCGCAGATCGTCGCCGAGGCCGGGACCACGGTGGCCGCGGGTGGCAAGCTTGCGGTCCTGGCGGCCGGTGAGGGCGGCGCCGCGGCCACGGGGACCGGCGCGGCCGCAGCCCCTGCCCCGCCCACCGCCGCTGCGGCCGAGCGCAGCGGCGCGGGCCGCGCGGATGTGGAAGACGCCCCTTCGGCGAAGAAGATGATGGCCGAGAAGGGGCTGACGCGCGATCAGGTCGAAGGCACCGGCCGTGACGGGCGGATCATGAAGGAGGACGTGGCGCGCGCCGCGGCGGACGCGGCCCCGGCGGCGCAGGCTGCGCCTGCCCCGACCATGCCCGCCCCCGCAGCCCAACAGGCACCGCGCGCCGCCGTCCCGGCCGACGATGCCGCCCGCGAAGAGCGGGTGAAGATGAGCCGCCTGCGCCAGACCATCGCGCGCAGGCTCAAGGATGCGCAGAACACCGCGGCCATGCTGACCACCTATAACGAGGTGGACATGGGCCCGATCATGGATCTGCGCAACGAATACAAGGGGTTGTTCGAAAAGAAGCACGGCGTGAAGCTTGGCTTCATGTCCTTCTTCGTCAAGGCCTGCTGCCACGCCCTGCACGAGGTGCCCGAGGTCAACGCCGAGATCGACGGCACCGATGTGGTCTACAAGAACTATGTCCACATGGGCGTGGCGGTGGGCACGCCGTCAGGGCTGGTGGTGCCGGTGCTGCGCGATGCGCAGGCCATGGGCTTTGCCGAGATCGAAAAGACCATCGCGTCCCTGGGCGCACGCGCGCGCGACGGCAAGCTGTCGATGGCCGACATGCAGGGCGGATCGTTCACCATCTCCAACGGCGGGGTGTATGGCTCGCTGATGTCGTCGCCGATCCTGAACCCGCCGCAGTCGGGGATCCTGGGGATGCACAAGATCCAGGATCGTCCGATGGTGGTGAAGGGTCAGATCGTGGCGCGCCCCATGATGTACCTCGCGCTGAGCTATGACCACCGGATCGTGGACGGCAAGGGCGCGGTGACGTTCCTTGTCCGCGTCAAGGAGGCGCTGGAGGACCCGCGGCGCCTGTTGATGGACCTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 15638,
                        "end": 15925,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02421",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02421</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02421</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,638 - 15,925,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLGILFLVAVALVALVVVQSVRQGRRFIRAALFLHELEGGRPKDSANAAANLLFSPESSASADAHAAQIADARRKRTSETQAQVIGAARDRGFEG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=5638&amp;to=25925\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLGILFLVAVALVALVVVQSVRQGRRFIRAALFLHELEGGRPKDSANAAANLLFSPESSASADAHAAQIADARRKRTSETQAQVIGAARDRGFEG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTGGGGATCCTGTTTCTGGTCGCGGTGGCGCTGGTGGCGCTGGTGGTGGTGCAAAGCGTGCGCCAGGGCCGGCGCTTCATCCGCGCCGCGCTGTTCCTGCACGAGCTGGAGGGCGGGCGCCCGAAGGACTCCGCCAACGCCGCAGCCAACCTGTTGTTCAGCCCGGAAAGCTCGGCCTCGGCCGATGCGCATGCCGCCCAGATCGCGGACGCGCGGCGCAAGCGCACCTCCGAGACGCAGGCGCAGGTGATCGGCGCCGCGCGCGACCGCGGGTTCGAGGGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 15930,
                        "end": 16337,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02422",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02422</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02422</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,930 - 16,337,\n (total: 408 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTGIMTTELTVLVLAALLAVVQLGWNAVRANLEMGPDWFLTPRDSAPPQPLPVALGRLKRAYENHMETLPLFAIAAIVVTLAGASSGLTAACAWIYLAARVLFVPAYRFGWMPWRSFIWAAGFVATVLMLLAALI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=5930&amp;to=26337\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTGIMTTELTVLVLAALLAVVQLGWNAVRANLEMGPDWFLTPRDSAPPQPLPVALGRLKRAYENHMETLPLFAIAAIVVTLAGASSGLTAACAWIYLAARVLFVPAYRFGWMPWRSFIWAAGFVATVLMLLAALI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACAGGGATCATGACGACGGAGCTGACGGTTCTGGTGCTGGCCGCCCTTCTGGCGGTGGTTCAGCTGGGCTGGAACGCGGTGCGCGCCAACCTGGAGATGGGGCCGGACTGGTTCCTCACGCCACGCGACAGCGCCCCGCCGCAGCCGCTGCCGGTTGCGCTGGGTCGGCTCAAGCGCGCCTATGAGAACCACATGGAGACGCTGCCGCTGTTTGCCATCGCGGCCATCGTGGTGACGCTGGCGGGCGCCTCGTCCGGCCTGACGGCGGCCTGCGCGTGGATCTACCTGGCCGCTCGGGTGCTGTTCGTGCCGGCCTACCGCTTCGGCTGGATGCCGTGGCGCTCGTTCATCTGGGCGGCGGGCTTCGTCGCCACCGTTCTGATGCTGCTGGCCGCGCTGATCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 16366,
                        "end": 17754,
                        "strand": 1,
                        "locus_tag": "KKHPANEM_02423",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02423</span></strong><br>\n \n  Dihydrolipoyl dehydrogenase 3<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02423</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">lpd3</span><br>\n \n Location: 16,366 - 17,754,\n (total: 1389 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1175:pyridine nucleotide-disulfide oxidoreductase (Score: 476.3; E-value: 1.3e-144)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MASYDVIFIGSGPGGYVGAIRAAQLGLRTACVEGRETLGGTCLNVGCIPSKALLHATHMLHEAEHNFAEMGLGGGKPKVDWGKMQSYKDDVIAQNTKGIEFLFKKNKVDWIKGWASIPAPGKVKVGDDVHEARAIVIASGSESASLPGVEVDEKVVVTSTGALELGRIPKRLAVIGGGVIGLEMGSVYARLGAQVTVLEYLDRLIPGNDMEVARTFQRILKKQGMEFILGAAVQGVEATRTKAKVSYTLKKDDSAQTLEADVVLLATGRRPFTDGLGLDTLGVTLSKRRQVEVDGRYETSVKGVYAIGDAITGPMLAHKAEDEGYAVAEILAGQAGHVNYATIPGVIYTHPEVASVGETEETLKEAGRAYKVGKFSFMGNGRAKANFAADGFVKILADKDTDRILGAHIIGPMAGDLIHEICVAMEFGAAAEDLARTCHAHPTYSEAVREAALACGDGALHA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=6366&amp;to=27754\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MASYDVIFIGSGPGGYVGAIRAAQLGLRTACVEGRETLGGTCLNVGCIPSKALLHATHMLHEAEHNFAEMGLGGGKPKVDWGKMQSYKDDVIAQNTKGIEFLFKKNKVDWIKGWASIPAPGKVKVGDDVHEARAIVIASGSESASLPGVEVDEKVVVTSTGALELGRIPKRLAVIGGGVIGLEMGSVYARLGAQVTVLEYLDRLIPGNDMEVARTFQRILKKQGMEFILGAAVQGVEATRTKAKVSYTLKKDDSAQTLEADVVLLATGRRPFTDGLGLDTLGVTLSKRRQVEVDGRYETSVKGVYAIGDAITGPMLAHKAEDEGYAVAEILAGQAGHVNYATIPGVIYTHPEVASVGETEETLKEAGRAYKVGKFSFMGNGRAKANFAADGFVKILADKDTDRILGAHIIGPMAGDLIHEICVAMEFGAAAEDLARTCHAHPTYSEAVREAALACGDGALHA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCAAGCTATGACGTGATCTTCATCGGCTCCGGCCCCGGCGGCTATGTCGGCGCCATCCGCGCAGCCCAGCTGGGCCTGCGCACCGCCTGCGTGGAGGGGCGCGAGACGCTGGGCGGCACCTGCCTGAACGTGGGCTGCATCCCCTCCAAGGCGCTGCTGCACGCCACCCACATGCTGCACGAGGCCGAGCACAACTTCGCCGAGATGGGCCTTGGCGGCGGCAAGCCCAAGGTCGACTGGGGCAAGATGCAGTCCTACAAGGACGACGTCATCGCCCAGAACACCAAGGGGATCGAGTTCCTGTTCAAGAAGAACAAGGTGGACTGGATCAAGGGCTGGGCCTCCATCCCCGCGCCGGGCAAGGTGAAGGTCGGCGACGACGTGCACGAGGCCCGGGCCATCGTGATCGCCTCGGGCTCCGAATCCGCCTCCCTTCCGGGGGTGGAGGTCGACGAGAAGGTCGTGGTCACCTCCACCGGCGCGCTGGAGCTGGGCCGCATCCCCAAGCGGCTGGCGGTGATCGGCGGCGGCGTGATCGGGCTGGAGATGGGCTCGGTCTATGCCCGCCTGGGGGCGCAGGTGACGGTGCTGGAGTACCTCGACCGGCTGATCCCCGGCAACGACATGGAGGTCGCGCGGACCTTCCAGCGCATCCTGAAGAAGCAGGGGATGGAGTTCATCCTCGGCGCCGCCGTGCAGGGGGTGGAGGCCACCAGGACCAAGGCCAAGGTCAGCTACACCCTGAAGAAGGACGACAGCGCCCAGACGCTGGAGGCCGATGTGGTGCTGCTCGCCACCGGGCGTCGTCCCTTCACCGACGGGCTGGGGCTGGACACACTGGGCGTGACCCTGTCCAAGCGCAGACAGGTGGAGGTCGATGGCCGCTACGAGACCTCGGTCAAGGGCGTCTACGCCATCGGCGACGCCATCACCGGCCCGATGCTCGCGCACAAGGCCGAGGATGAGGGCTACGCCGTGGCCGAGATCCTCGCGGGCCAGGCGGGCCATGTGAACTACGCCACCATCCCCGGCGTGATCTACACCCACCCCGAGGTCGCGAGCGTGGGCGAGACCGAGGAGACGCTGAAGGAGGCCGGGCGCGCCTACAAGGTCGGCAAGTTCAGTTTCATGGGCAATGGCCGGGCCAAGGCCAACTTCGCCGCCGACGGCTTCGTCAAGATCCTGGCTGACAAGGACACCGACCGCATCCTGGGCGCCCACATCATCGGCCCGATGGCGGGCGACCTGATCCACGAGATCTGCGTCGCGATGGAGTTCGGCGCCGCGGCCGAGGATCTTGCCCGCACCTGCCATGCCCACCCCACCTACTCCGAAGCGGTGCGCGAGGCGGCGCTGGCCTGCGGCGACGGGGCGCTGCACGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 17981,
                        "end": 19657,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02424",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02424</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02424</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,981 - 19,657,\n (total: 1677 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTDAPWQAPTPEELRALADATLAEAVALAEGLRALGPAVQVAAGLLAALVLAVVWAVLRARTRREALLRADLMARLADLEATTRRAEAAEANAAARADDLAALTARAEGLEGSLRAATVTERDLTARAAALDARLESAERRLAERRTEAEARESAIAGLRGRLEAEQAAQRALQARIAGLTQELESEQARGAEKVALLSSVREDMQARFRDLADAALKTQAEVFSNTSFARLEATLTPLKEHVGHFEKELRAVHTETARDRERLKAEIAALSKRSEEVSHEAMALTRALKGDRQRQGAWGEMILESILERCGLREGEEYETQAHRTDDEGARLRPDVVVRIPGDRTLVIDSKVSLNDYAAAVNAEDAAEAAGHRKRHVAALRAHITGLSAKGYQRAEDASVDYVIMFVPIEGALSEALREDGGLTGFALERHITIATPTTLMMALRTVAHVWAVERRNRNAEAIADRAGKLYDKLVGFLENMETVGKRLDQAQAAYGDALGQLSRGRGNLLSQVETLKTLGAKATKTIATEFEDTAPPGTLAADPETDPPKFDRKADR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=7981&amp;to=29657\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTDAPWQAPTPEELRALADATLAEAVALAEGLRALGPAVQVAAGLLAALVLAVVWAVLRARTRREALLRADLMARLADLEATTRRAEAAEANAAARADDLAALTARAEGLEGSLRAATVTERDLTARAAALDARLESAERRLAERRTEAEARESAIAGLRGRLEAEQAAQRALQARIAGLTQELESEQARGAEKVALLSSVREDMQARFRDLADAALKTQAEVFSNTSFARLEATLTPLKEHVGHFEKELRAVHTETARDRERLKAEIAALSKRSEEVSHEAMALTRALKGDRQRQGAWGEMILESILERCGLREGEEYETQAHRTDDEGARLRPDVVVRIPGDRTLVIDSKVSLNDYAAAVNAEDAAEAAGHRKRHVAALRAHITGLSAKGYQRAEDASVDYVIMFVPIEGALSEALREDGGLTGFALERHITIATPTTLMMALRTVAHVWAVERRNRNAEAIADRAGKLYDKLVGFLENMETVGKRLDQAQAAYGDALGQLSRGRGNLLSQVETLKTLGAKATKTIATEFEDTAPPGTLAADPETDPPKFDRKADR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCGACGCCCCCTGGCAGGCTCCCACCCCCGAGGAACTGCGCGCCCTGGCCGATGCCACCCTGGCCGAGGCGGTCGCGCTGGCGGAGGGGCTGCGCGCGCTGGGGCCAGCGGTGCAGGTCGCGGCGGGGCTGCTGGCCGCGCTGGTGCTGGCCGTGGTCTGGGCGGTGCTGCGCGCGCGGACCCGGCGCGAGGCGCTGCTGCGCGCCGACCTGATGGCGCGGCTGGCCGATCTGGAGGCCACCACCCGCCGGGCCGAGGCCGCCGAGGCCAACGCCGCCGCGCGCGCCGATGACCTTGCGGCGCTCACGGCCCGGGCGGAGGGGCTGGAGGGCAGCTTGCGGGCTGCCACCGTGACCGAGCGGGACCTGACCGCGCGCGCCGCCGCCCTCGATGCCCGGCTCGAGAGTGCCGAGCGCCGCCTGGCCGAGCGGCGCACCGAGGCCGAGGCGCGCGAGTCCGCCATCGCCGGGCTGCGCGGTCGGCTGGAGGCCGAGCAGGCCGCGCAGCGCGCGTTGCAGGCCCGCATCGCCGGGCTGACCCAGGAGCTGGAGAGCGAACAGGCCCGTGGCGCCGAAAAGGTGGCGCTGCTGTCGTCGGTGCGCGAGGACATGCAGGCGCGTTTCCGCGACCTCGCCGATGCCGCGCTGAAGACCCAGGCGGAGGTGTTCTCCAACACCAGCTTTGCCCGGCTGGAGGCGACGCTGACGCCGCTGAAGGAACATGTCGGCCATTTCGAGAAGGAACTGCGCGCCGTCCACACCGAGACCGCGCGGGACCGCGAGCGCCTGAAGGCCGAGATCGCCGCGCTGTCGAAACGCTCCGAGGAGGTCTCGCACGAGGCGATGGCGCTGACGCGCGCGCTCAAGGGCGACCGGCAGCGGCAGGGCGCCTGGGGGGAGATGATCCTCGAGAGCATCCTCGAACGCTGCGGCCTGCGCGAGGGCGAGGAGTACGAGACCCAGGCCCACCGCACCGACGACGAGGGCGCCCGCCTGCGCCCCGACGTGGTGGTGCGCATCCCCGGCGACCGCACGCTGGTGATCGATTCCAAGGTCTCGCTGAACGACTATGCCGCCGCCGTGAACGCCGAGGACGCGGCCGAGGCCGCCGGCCACCGCAAGCGCCATGTTGCGGCCCTGCGCGCCCACATCACCGGACTGTCGGCCAAGGGCTATCAGCGCGCCGAGGACGCCTCGGTCGACTATGTCATCATGTTCGTGCCCATCGAGGGCGCGCTGTCGGAGGCGCTGCGCGAGGACGGCGGGCTGACCGGCTTTGCGCTGGAGCGCCACATCACCATCGCCACGCCCACCACGCTGATGATGGCGCTGCGCACGGTGGCCCATGTCTGGGCCGTGGAGCGGCGCAACCGCAACGCCGAGGCGATCGCGGACCGGGCCGGCAAGCTCTATGACAAGCTGGTGGGATTTCTGGAAAACATGGAGACGGTGGGCAAGCGCCTCGACCAGGCGCAGGCGGCCTATGGCGACGCGCTGGGGCAGCTGTCGCGCGGGCGCGGCAACCTGCTGTCGCAGGTGGAGACCCTCAAGACGCTGGGCGCCAAGGCCACCAAGACCATCGCCACCGAGTTCGAGGACACCGCCCCCCCGGGCACCCTCGCCGCGGACCCCGAAACCGATCCCCCGAAGTTCGACAGGAAAGCCGACAGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 19848,
                        "end": 20525,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02425",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02425</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02425</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,848 - 20,525,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIAHGHYATLVFDCDGVVLDSNRLKTEAFRRAALPWGEAAADALVAYHIAHGGVSRYVKFRHFLDALVPEHAPGGCGPGLEGLLDAYAGAVRDGLMTCGVAPGLAELRAATPGVRWLIVSGGDQAELREVFAARGLDRHFDGGIFGSPDTKAAILARELAAGNIRRPALFLGDSRLDFEAAAGAGLDFTFVSGWSEVADWRGFVAEHRLACVAGLSDLLGGAGPA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=9848&amp;to=30525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIAHGHYATLVFDCDGVVLDSNRLKTEAFRRAALPWGEAAADALVAYHIAHGGVSRYVKFRHFLDALVPEHAPGGCGPGLEGLLDAYAGAVRDGLMTCGVAPGLAELRAATPGVRWLIVSGGDQAELREVFAARGLDRHFDGGIFGSPDTKAAILARELAAGNIRRPALFLGDSRLDFEAAAGAGLDFTFVSGWSEVADWRGFVAEHRLACVAGLSDLLGGAGPA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"TTGATTGCGCATGGCCACTACGCGACCCTCGTCTTCGATTGCGACGGCGTCGTCCTCGACTCCAATCGGCTGAAGACGGAGGCATTCCGGCGCGCGGCGCTGCCGTGGGGGGAAGCGGCGGCTGATGCGCTGGTGGCGTATCATATCGCGCACGGAGGGGTGTCGCGGTATGTCAAGTTCCGGCATTTCCTCGATGCGCTGGTGCCAGAGCATGCGCCCGGCGGCTGCGGGCCGGGGCTGGAGGGGTTGCTTGACGCATATGCCGGGGCGGTGCGCGACGGGTTGATGACCTGCGGTGTGGCGCCGGGGCTGGCAGAGCTGCGGGCGGCGACGCCGGGGGTGCGTTGGCTGATCGTGTCGGGCGGCGACCAGGCGGAGCTGCGCGAGGTGTTTGCGGCGCGGGGTCTGGACCGGCACTTCGACGGCGGGATCTTCGGCAGCCCGGACACCAAGGCGGCGATCCTCGCCCGTGAGCTTGCGGCGGGCAACATCCGCCGCCCGGCGCTGTTTCTTGGCGACAGTCGGCTGGACTTTGAGGCGGCGGCCGGTGCCGGGCTGGATTTTACCTTCGTCTCGGGCTGGTCCGAGGTGGCGGACTGGCGCGGCTTTGTTGCCGAACACCGGCTGGCCTGCGTGGCGGGGCTGTCGGATCTGTTGGGCGGGGCAGGTCCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 20522,
                        "end": 21175,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02426",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02426</span></strong><br>\n \n  3-deoxy-manno-octulosonate cytidylyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02426</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">kpsU</span><br>\n \n Location: 20,522 - 21,175,\n (total: 654 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MILWVAELSARAVGQDHVYVATEDERIAEVVRASGFAALMTSASALTGTDRVAEAAQKIDYDIYVNVQGDEPIVDPADIRRCIAIKSNNLEKVVNGYCWVGSDEDPASVNIPKVITNESDDLVYMSRVALPGFKDATNAPDRFKKQVCIYGFTRQELMEYAAFGRKSYLEKCEDIEILRFLEIERKVLMFQCKPGSLAVDVPADVSPVEALLRERLS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=10522&amp;to=31175\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MILWVAELSARAVGQDHVYVATEDERIAEVVRASGFAALMTSASALTGTDRVAEAAQKIDYDIYVNVQGDEPIVDPADIRRCIAIKSNNLEKVVNGYCWVGSDEDPASVNIPKVITNESDDLVYMSRVALPGFKDATNAPDRFKKQVCIYGFTRQELMEYAAFGRKSYLEKCEDIEILRFLEIERKVLMFQCKPGSLAVDVPADVSPVEALLRERLS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCCTGTGGGTTGCCGAACTCTCGGCAAGAGCTGTCGGGCAGGATCATGTCTATGTTGCCACGGAGGATGAGCGGATCGCTGAGGTGGTGCGCGCATCCGGATTCGCTGCGCTGATGACAAGTGCATCCGCCCTGACCGGCACGGACCGTGTTGCCGAAGCCGCACAGAAGATCGATTATGACATCTATGTCAATGTGCAGGGCGACGAGCCGATTGTGGATCCTGCGGACATCCGACGCTGTATTGCGATAAAGTCGAACAACCTTGAGAAGGTTGTGAACGGATACTGCTGGGTTGGCTCTGATGAAGACCCGGCGTCCGTGAATATTCCGAAAGTCATCACCAACGAGTCGGACGATCTGGTTTACATGTCGCGCGTGGCTTTGCCGGGGTTCAAGGATGCGACGAATGCGCCGGACAGGTTCAAGAAGCAGGTGTGCATCTATGGTTTCACCCGGCAGGAGCTCATGGAATATGCGGCGTTCGGCCGAAAGAGTTATTTGGAAAAGTGCGAAGACATCGAGATCCTTCGTTTTTTGGAGATCGAACGAAAGGTTTTGATGTTCCAATGCAAGCCGGGTAGCCTTGCAGTTGATGTTCCCGCGGACGTATCCCCAGTCGAGGCATTGTTGCGGGAACGCCTCAGTTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 21262,
                        "end": 22884,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02427",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02427</span></strong><br>\n \n  4-hydroxy-2-oxovalerate aldolase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02427</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">mhpE</span><br>\n \n Location: 21,262 - 22,884,\n (total: 1623 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n  biosynthetic-additional (smcogs) SMCOG1271:2-isopropylmalate synthase (Score: 104.2; E-value: 1.4e-31)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTINMTGGTLLDCTFRDGGYYNAWDFSPALITQYLGAMRAAQVDVVELGFRFLRNEGFKGPCAFTTDDFLRSLPIPPGLTVGVMLNGADLCTDLGRGAALQRLFPEPAASTPVDLVRFACHFHELETVLPAVGWLHERGYRVGLNLMQIADRSRTQVAELAKMSRDWPVEVLYFADSMGSMTPDDTARIVGWLRDGWEGPLGIHTHDNMGLALSNTLRAAAEGVTWLDATVTGMGRGPGNARTEELAIEAEGLRNRRANLVPLMGLIRKHFGPMKAQYGWGTNPYYFLAGKYGIHPTYIQEMLGDARYDEEDILAVIDHLRAEGGKKFSFNTLDGARQFYSGAPRGSWAPSEVMAGRDVLILGTGPGVAAHRPALEAYIRRARPLVLALNTQSAIDPALIDLRIACHPVRLLADAEAHAALPQPLITPASMLPETLRAEFGDKELLDFGIGIEPGRFEFHATHCVAPNSLVLSYALSVAASGQASRILMAGFDGYPASDRRNDEVDDMLLKFVNSEFTGPVFSITPSAYGNLPALSLYGM&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=11262&amp;to=32884\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTINMTGGTLLDCTFRDGGYYNAWDFSPALITQYLGAMRAAQVDVVELGFRFLRNEGFKGPCAFTTDDFLRSLPIPPGLTVGVMLNGADLCTDLGRGAALQRLFPEPAASTPVDLVRFACHFHELETVLPAVGWLHERGYRVGLNLMQIADRSRTQVAELAKMSRDWPVEVLYFADSMGSMTPDDTARIVGWLRDGWEGPLGIHTHDNMGLALSNTLRAAAEGVTWLDATVTGMGRGPGNARTEELAIEAEGLRNRRANLVPLMGLIRKHFGPMKAQYGWGTNPYYFLAGKYGIHPTYIQEMLGDARYDEEDILAVIDHLRAEGGKKFSFNTLDGARQFYSGAPRGSWAPSEVMAGRDVLILGTGPGVAAHRPALEAYIRRARPLVLALNTQSAIDPALIDLRIACHPVRLLADAEAHAALPQPLITPASMLPETLRAEFGDKELLDFGIGIEPGRFEFHATHCVAPNSLVLSYALSVAASGQASRILMAGFDGYPASDRRNDEVDDMLLKFVNSEFTGPVFSITPSAYGNLPALSLYGM\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACAATCAATATGACTGGCGGCACGCTTCTTGACTGCACATTCCGGGACGGCGGATACTACAACGCCTGGGATTTCTCGCCCGCGCTGATCACACAGTACCTCGGGGCCATGCGGGCCGCGCAGGTGGATGTGGTGGAGCTGGGGTTCCGTTTTCTGCGCAACGAGGGGTTCAAGGGGCCCTGCGCCTTCACCACCGATGACTTCCTGCGCAGCCTGCCGATCCCACCGGGGCTGACGGTGGGGGTGATGCTCAACGGGGCGGATCTGTGCACCGACTTGGGCCGGGGCGCCGCGCTGCAGAGGCTGTTTCCCGAACCGGCCGCATCCACGCCGGTCGATCTGGTCCGCTTTGCCTGCCATTTCCATGAGCTGGAGACGGTTCTGCCCGCCGTCGGCTGGCTGCACGAGCGCGGCTACCGGGTCGGGCTGAACCTGATGCAGATCGCCGACCGCTCGCGAACGCAGGTCGCCGAGCTTGCGAAAATGTCCCGCGACTGGCCGGTGGAGGTGCTGTATTTTGCCGACTCCATGGGCTCCATGACGCCCGACGACACCGCCCGCATCGTCGGCTGGCTGCGCGACGGGTGGGAGGGGCCGCTGGGCATCCACACCCACGACAACATGGGGCTTGCGCTGTCCAACACGCTGCGTGCCGCGGCCGAGGGCGTCACCTGGCTCGATGCCACCGTCACCGGGATGGGGCGCGGCCCGGGCAACGCCCGCACCGAGGAACTGGCGATCGAGGCGGAGGGCCTGCGCAACCGGCGCGCCAATCTCGTGCCGCTGATGGGCCTGATCCGCAAGCACTTCGGCCCGATGAAGGCGCAGTACGGCTGGGGCACCAACCCGTATTACTTCCTTGCCGGAAAGTACGGCATCCATCCCACCTATATCCAGGAAATGCTGGGCGACGCGCGCTATGACGAGGAGGACATCCTTGCCGTGATCGACCATCTGCGCGCCGAGGGCGGCAAGAAGTTCAGCTTCAACACCCTCGACGGCGCGCGGCAGTTCTACAGCGGCGCGCCGCGTGGCAGCTGGGCCCCGTCCGAGGTCATGGCCGGCCGCGACGTGCTGATCTTGGGCACCGGGCCGGGCGTGGCCGCGCATCGCCCTGCGCTGGAGGCCTATATCCGCCGCGCCCGGCCGCTGGTGCTGGCGCTCAACACCCAGTCGGCCATCGATCCCGCGCTGATCGACCTGCGCATTGCCTGCCACCCGGTCCGTCTTCTCGCCGACGCCGAGGCCCACGCGGCGCTTCCGCAACCGCTGATCACCCCGGCCTCCATGCTGCCCGAAACCCTCCGGGCCGAGTTCGGCGACAAGGAGCTTCTGGATTTCGGGATCGGTATCGAGCCTGGCCGGTTCGAGTTCCACGCGACGCACTGCGTTGCGCCCAACTCTCTGGTTCTGTCCTACGCGCTGTCTGTCGCGGCCAGCGGTCAAGCTTCGCGTATCCTGATGGCAGGCTTCGACGGCTATCCCGCCAGCGACCGCCGCAATGATGAGGTCGATGACATGCTGCTCAAGTTCGTGAATTCCGAATTCACGGGTCCGGTGTTTTCGATAACGCCAAGCGCTTACGGAAATCTTCCCGCGCTCAGCCTGTACGGTATGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 22941,
                        "end": 24263,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02428",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02428</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02428</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,941 - 24,263,\n (total: 1323 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLAWLQWRLKGLAMDLAYRLPLALVARLAPSPMRMISFYLAKADSPRALQYLDHLVRISPEVGCLMRLDERLRRGSISGVDLVDSIPSSILRKLNSYKDVHLNDAARAFNRLGCLRLGGALRGLLLIKLVQQRFRSPAKQGWELDALLLEVSANDYSRRLFSRPELWEDGLDRQVQDRIELLRCSDMLVKLRVFVDSERLPCGEHEASLSGLSVLLQGPSRRESNLAGTPCDVVGTIGYSGAGSLARLVEGRHVSFYRPYKIRAMIAEGLTERFNDVDLAVVTKRGLGVLEAQFTPECRVACSKVRERFGLGFLNGGTEFLIWLLACDLNRLFVTNVDLFLNPAYPVGYLPSNYQKSHLSKDAAQWQTQSWATLMVFGDHEPSQQYSIYKAFHGYDSVVYDSMLDAIVSAPFSAYAEALEDAYRVWPQGPVVDCCGGGSA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=12941&amp;to=34263\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLAWLQWRLKGLAMDLAYRLPLALVARLAPSPMRMISFYLAKADSPRALQYLDHLVRISPEVGCLMRLDERLRRGSISGVDLVDSIPSSILRKLNSYKDVHLNDAARAFNRLGCLRLGGALRGLLLIKLVQQRFRSPAKQGWELDALLLEVSANDYSRRLFSRPELWEDGLDRQVQDRIELLRCSDMLVKLRVFVDSERLPCGEHEASLSGLSVLLQGPSRRESNLAGTPCDVVGTIGYSGAGSLARLVEGRHVSFYRPYKIRAMIAEGLTERFNDVDLAVVTKRGLGVLEAQFTPECRVACSKVRERFGLGFLNGGTEFLIWLLACDLNRLFVTNVDLFLNPAYPVGYLPSNYQKSHLSKDAAQWQTQSWATLMVFGDHEPSQQYSIYKAFHGYDSVVYDSMLDAIVSAPFSAYAEALEDAYRVWPQGPVVDCCGGGSA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTGGCCTGGTTGCAATGGAGGCTCAAGGGTCTGGCTATGGACCTGGCCTATCGGCTGCCGCTGGCGCTTGTGGCCCGATTGGCGCCATCGCCGATGCGGATGATTTCCTTCTATCTGGCAAAAGCCGATTCACCTCGGGCGTTGCAATACCTTGACCACTTGGTTCGAATCTCGCCCGAGGTTGGCTGCCTCATGCGGCTTGACGAGCGGTTGCGGAGGGGAAGCATAAGTGGCGTCGATCTGGTGGATTCAATCCCGAGCTCGATCTTGCGGAAGCTCAATTCCTACAAGGATGTACATCTGAACGATGCCGCAAGGGCCTTCAACCGCTTGGGTTGCCTTCGGTTGGGAGGAGCCCTGCGAGGCCTTCTGCTGATCAAGCTCGTGCAGCAGAGATTTCGGAGCCCGGCGAAGCAAGGCTGGGAGCTTGACGCTTTGCTCCTTGAGGTTTCTGCCAATGACTACAGCCGCCGCCTTTTTTCGCGTCCCGAGCTTTGGGAGGATGGCCTTGACAGGCAAGTTCAGGACCGCATCGAATTGCTTCGATGCTCTGACATGTTGGTCAAGCTGCGCGTTTTTGTTGATTCGGAAAGACTGCCATGCGGGGAACACGAGGCCTCTCTGAGCGGCTTGTCGGTGCTGCTACAGGGGCCGTCGAGGAGGGAGTCCAATCTGGCTGGTACACCTTGTGACGTGGTTGGCACCATCGGTTACTCTGGAGCCGGCTCCCTCGCCAGGCTCGTTGAAGGCAGGCACGTATCCTTCTACCGGCCATACAAAATTCGCGCAATGATTGCTGAAGGGTTAACCGAAAGATTTAACGATGTTGACCTGGCGGTTGTCACCAAGCGAGGCCTCGGTGTTTTGGAGGCACAGTTCACGCCAGAGTGCAGGGTTGCCTGCTCCAAGGTGCGAGAGAGGTTTGGACTTGGTTTCCTGAACGGAGGAACGGAGTTTCTGATCTGGCTCTTGGCATGCGATCTGAACCGGCTCTTCGTCACAAATGTCGATCTTTTTCTCAACCCAGCGTACCCGGTCGGTTATCTGCCGAGCAACTACCAGAAATCTCACCTTTCAAAGGATGCTGCGCAATGGCAGACACAGTCGTGGGCGACGCTAATGGTTTTTGGAGATCATGAACCGAGTCAGCAGTACTCTATCTACAAGGCCTTTCATGGTTACGATTCCGTTGTATACGACTCGATGCTTGATGCAATTGTATCTGCGCCGTTCAGCGCATACGCGGAGGCGCTTGAAGATGCCTATCGGGTTTGGCCCCAAGGTCCCGTCGTCGATTGCTGCGGTGGTGGCTCGGCTTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 24278,
                        "end": 25579,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02429",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02429</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02429</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,278 - 25,579,\n (total: 1302 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTVRLKRLGMGVAMSVVPRLPASLAMRITPSPVWLVSLLLTRDDPAAAVRCLKRLAATSPEIAALLRIDEQLQSGAIPADAIADAMPIPVLQAFVTTGIAPLRHAAKAFNALGCLRLGGALRALVLLRVAAANIASGEDRGWQHEAVLLEIAANDHCARFMARPEVMPEACRTALQEELQAVAGWSLARKVSVLVGQDSPAMPALRARMAGRSLRFQGPSSRSSDLDDTPADLTCVVGYSGPGSLARPVDSIGVSLYKKHKIAAMRGDGLLHHMADVQVPVLNPEDLRQERAFYADLIEKYGASLTNVRWASLNSQMNAGTELFVWMLNCGASSVSVSHLDLFLNRTYPPGYLAGGKAQASRDGPGWQMEEWSQLKSFGYHEPSQQFAIYRAFHPHREVAYDGILDAIVEKPFSAYASALEDGYRVWRGRAEA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=14278&amp;to=35579\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTVRLKRLGMGVAMSVVPRLPASLAMRITPSPVWLVSLLLTRDDPAAAVRCLKRLAATSPEIAALLRIDEQLQSGAIPADAIADAMPIPVLQAFVTTGIAPLRHAAKAFNALGCLRLGGALRALVLLRVAAANIASGEDRGWQHEAVLLEIAANDHCARFMARPEVMPEACRTALQEELQAVAGWSLARKVSVLVGQDSPAMPALRARMAGRSLRFQGPSSRSSDLDDTPADLTCVVGYSGPGSLARPVDSIGVSLYKKHKIAAMRGDGLLHHMADVQVPVLNPEDLRQERAFYADLIEKYGASLTNVRWASLNSQMNAGTELFVWMLNCGASSVSVSHLDLFLNRTYPPGYLAGGKAQASRDGPGWQMEEWSQLKSFGYHEPSQQFAIYRAFHPHREVAYDGILDAIVEKPFSAYASALEDGYRVWRGRAEA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCGTTCGCCTGAAGCGCCTCGGCATGGGAGTCGCGATGTCGGTCGTGCCTCGGCTTCCTGCATCGCTGGCGATGCGGATTACTCCGTCGCCCGTCTGGCTGGTGTCGCTTCTCCTGACGCGGGACGATCCGGCCGCGGCGGTGCGGTGCCTCAAGCGGCTCGCCGCGACCAGTCCCGAGATAGCTGCCCTTCTGCGCATCGACGAACAGCTGCAGTCCGGGGCCATCCCTGCCGATGCAATCGCCGACGCGATGCCAATCCCGGTGTTGCAGGCTTTCGTCACCACCGGGATTGCGCCTCTCCGGCATGCTGCCAAGGCGTTCAACGCGCTCGGGTGCCTGCGGCTGGGGGGGGCACTGAGGGCGCTCGTGCTTTTGCGGGTTGCCGCTGCGAACATTGCCTCCGGCGAGGACCGCGGATGGCAGCACGAGGCAGTACTTCTGGAGATCGCGGCCAACGATCACTGCGCGCGGTTCATGGCCCGCCCGGAGGTGATGCCAGAGGCCTGCCGCACGGCGCTTCAGGAAGAACTGCAAGCGGTCGCCGGCTGGAGCCTGGCGCGCAAGGTCTCGGTTCTCGTGGGCCAGGACAGCCCCGCCATGCCGGCGTTGCGCGCGCGCATGGCCGGCCGCAGCCTTCGGTTCCAGGGTCCGTCGAGCCGTTCCTCCGATCTGGACGATACGCCGGCCGATCTGACATGCGTCGTCGGCTACTCCGGACCTGGCTCGCTGGCCCGCCCGGTCGACAGCATTGGTGTGTCGCTATACAAGAAGCACAAGATCGCGGCGATGCGCGGGGACGGACTGCTGCATCACATGGCGGACGTGCAGGTTCCGGTGCTCAACCCGGAGGACCTGCGCCAAGAACGTGCGTTTTATGCGGACCTGATCGAGAAATATGGAGCCAGTTTGACGAATGTGCGCTGGGCGTCCCTGAACTCCCAGATGAATGCGGGCACGGAACTGTTTGTCTGGATGTTGAACTGCGGCGCTTCCTCGGTTTCTGTCAGTCACCTTGACCTGTTCTTGAACCGAACCTATCCCCCCGGTTACCTGGCCGGCGGCAAGGCGCAAGCCTCCCGTGACGGGCCAGGCTGGCAGATGGAGGAGTGGTCGCAGTTGAAGAGCTTCGGCTACCATGAGCCCAGCCAGCAGTTCGCGATCTACAGGGCGTTTCATCCGCATCGCGAGGTGGCGTACGATGGCATACTCGATGCGATCGTGGAGAAACCATTCAGCGCCTACGCGAGCGCGCTTGAGGACGGCTATCGAGTTTGGCGCGGTCGGGCCGAGGCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 25856,
                        "end": 26299,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02430",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02430</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02430</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,856 - 26,299,\n (total: 444 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFETFLRRLIRPDPMPLPQADARLALAALLVRAARVNGDYDPAQVVAIDAALARRYGFGADDAAALRARAEGLESEAPDTVRFTRAVKQATALEDRAAELEMLWEVILSDGARDHEEDGFMRLVADLLGFSDRDSALARQRVAERMA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=15856&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFETFLRRLIRPDPMPLPQADARLALAALLVRAARVNGDYDPAQVVAIDAALARRYGFGADDAAALRARAEGLESEAPDTVRFTRAVKQATALEDRAAELEMLWEVILSDGARDHEEDGFMRLVADLLGFSDRDSALARQRVAERMA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTCGAGACATTCCTGCGCCGGCTGATCCGGCCCGATCCCATGCCCCTGCCGCAAGCCGATGCCCGGCTGGCGCTGGCGGCCCTGCTGGTGCGGGCGGCGCGCGTCAACGGCGATTATGACCCCGCACAGGTGGTTGCCATCGATGCCGCCCTCGCGCGTCGCTACGGCTTCGGGGCGGATGACGCCGCCGCCCTGCGCGCCCGCGCCGAAGGTCTGGAGAGCGAGGCGCCCGACACCGTGCGCTTCACCCGCGCCGTCAAGCAGGCAACCGCACTGGAAGATCGCGCGGCCGAGCTGGAGATGCTGTGGGAGGTGATCCTGTCCGACGGCGCGCGCGACCACGAGGAGGACGGGTTCATGCGCCTTGTGGCGGACCTGCTGGGGTTCTCCGATCGCGACAGCGCGCTGGCCCGCCAGCGCGTGGCCGAGCGGATGGCGTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 26389,
                        "end": 28062,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02431",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02431</span></strong><br>\n \n  Glucose-6-phosphate isomerase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02431</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pgi</span><br>\n \n Location: 26,389 - 28,062,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAERTTGRAPGGHDADLAPLWRALEQYRDRVAARPIAALFDADPARAEAFSVSAAGLMLDYSKTGVCAQGMAHLLALADGAGVEARRDAMFRGAAINETEGRAVLHTALRDPDGPPLVVDGVDVRPGIAGTLARMEAMAADVRAGRVRGAGGAITDVVNIGIGGSDLGPAMAVQALAPYHDGPRCHFVSNVDGAHVHDVLAGLDPARTLVIVASKTFTTLETMTNAATARDWMARAVADPGAQFVALSSAGDRAAAFGIPPDRVFGFEDWVGGRYSVWGPIGLSLMLAIGPERFRDFLAGAAAMDAHFRSAPLASSMPVLLALVGVWHAQVCGHATRAVIPYDQRLARLPAYLQQLEMESNGKRVGMDGRDLDRPSGPIVWGEPGTNGQHAFMQLIHQGTRVVPVEFLLAARGHEADLAHHHRLLVANCLAQAEALMRGRTLEAARAGLSAAALGGAELERQARHRVFPGNRPSTVLLYSRLTPRMLGAVLALYEHRVFVEGVILGINPFDQWGVELGKELAVSLTPLLEGTAEGGAHDASTLRLVAMVRADGVAPG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=16389&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAERTTGRAPGGHDADLAPLWRALEQYRDRVAARPIAALFDADPARAEAFSVSAAGLMLDYSKTGVCAQGMAHLLALADGAGVEARRDAMFRGAAINETEGRAVLHTALRDPDGPPLVVDGVDVRPGIAGTLARMEAMAADVRAGRVRGAGGAITDVVNIGIGGSDLGPAMAVQALAPYHDGPRCHFVSNVDGAHVHDVLAGLDPARTLVIVASKTFTTLETMTNAATARDWMARAVADPGAQFVALSSAGDRAAAFGIPPDRVFGFEDWVGGRYSVWGPIGLSLMLAIGPERFRDFLAGAAAMDAHFRSAPLASSMPVLLALVGVWHAQVCGHATRAVIPYDQRLARLPAYLQQLEMESNGKRVGMDGRDLDRPSGPIVWGEPGTNGQHAFMQLIHQGTRVVPVEFLLAARGHEADLAHHHRLLVANCLAQAEALMRGRTLEAARAGLSAAALGGAELERQARHRVFPGNRPSTVLLYSRLTPRMLGAVLALYEHRVFVEGVILGINPFDQWGVELGKELAVSLTPLLEGTAEGGAHDASTLRLVAMVRADGVAPG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGCGGAGCGGACAACGGGGCGGGCACCGGGCGGGCACGATGCGGATCTGGCGCCGCTGTGGCGGGCACTGGAGCAATACCGCGACCGGGTGGCCGCGCGCCCCATCGCGGCGCTGTTCGACGCCGATCCGGCGCGCGCCGAGGCGTTCTCGGTCAGCGCGGCCGGGCTGATGCTCGATTACTCCAAGACCGGGGTGTGTGCGCAGGGGATGGCGCATCTTCTGGCGCTGGCCGATGGCGCCGGGGTGGAGGCGCGCCGGGACGCGATGTTCCGGGGCGCCGCGATCAACGAGACCGAGGGCCGGGCGGTGCTGCACACCGCGTTGCGTGATCCCGACGGGCCGCCGCTGGTGGTCGACGGGGTGGATGTGCGCCCGGGCATCGCCGGGACGCTGGCGCGGATGGAGGCGATGGCCGCCGATGTGCGCGCGGGCCGGGTCCGCGGGGCGGGCGGGGCGATCACGGATGTGGTCAATATCGGGATCGGCGGATCGGACCTCGGGCCTGCGATGGCGGTGCAGGCGCTGGCGCCGTACCACGACGGGCCGCGGTGTCATTTCGTCTCGAACGTGGACGGGGCGCATGTGCATGACGTGCTGGCGGGGCTGGACCCGGCGCGGACACTGGTGATCGTGGCCTCCAAGACCTTCACCACGCTGGAGACGATGACCAACGCCGCCACCGCACGCGACTGGATGGCCCGCGCCGTGGCCGATCCGGGGGCGCAGTTCGTGGCGCTGTCGTCGGCCGGGGACCGCGCGGCGGCGTTCGGCATCCCGCCCGATCGGGTGTTCGGCTTCGAGGACTGGGTCGGCGGGCGCTACTCGGTCTGGGGGCCGATCGGGTTGTCGCTGATGCTGGCCATCGGGCCGGAGCGGTTCCGCGACTTCCTTGCGGGGGCGGCGGCGATGGACGCGCATTTCCGCAGCGCCCCGCTGGCGTCCAGCATGCCGGTGCTGCTGGCGCTGGTGGGGGTGTGGCATGCGCAGGTCTGCGGGCATGCGACCCGCGCGGTCATCCCCTATGATCAACGGCTGGCGCGGCTTCCGGCGTATCTGCAGCAGCTGGAGATGGAGTCGAACGGCAAGCGCGTGGGGATGGACGGGCGCGACCTCGATCGTCCCTCGGGGCCGATCGTGTGGGGGGAGCCGGGAACCAATGGCCAGCACGCCTTCATGCAGTTGATCCATCAGGGCACGCGCGTCGTGCCGGTGGAGTTCCTGCTGGCCGCGCGCGGTCACGAGGCGGATCTGGCGCATCACCACCGCCTGCTGGTCGCCAACTGCCTGGCGCAGGCCGAGGCGCTGATGCGGGGGCGCACGCTGGAGGCGGCGCGCGCCGGGCTGTCGGCCGCAGCCCTGGGCGGTGCCGAGCTGGAGCGCCAGGCCCGCCACCGGGTGTTTCCCGGCAACCGGCCCTCGACGGTGCTGCTGTATTCCCGGCTGACGCCGCGGATGCTGGGGGCCGTCCTGGCCCTTTATGAGCATCGGGTGTTCGTGGAGGGCGTGATCCTCGGCATCAACCCGTTCGATCAATGGGGCGTGGAGCTGGGCAAGGAGCTGGCCGTCAGCCTGACGCCGCTGCTGGAGGGGACGGCCGAGGGCGGCGCGCACGACGCCTCCACCCTGCGGCTGGTGGCGATGGTGCGCGCGGATGGTGTCGCCCCGGGATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 28927,
                        "end": 29736,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02432",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02432</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02432</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,927 - 29,736,\n (total: 810 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDHKARTALAAPLVAALVLSAAAANGATLRTLSGGDGAFNALCAAGNAVGTGNQACEFAVGEMRTGAVGGAQTWEVGVQNPPGSPVSTRNYAWGNGAAQAFVFSFSGGTLTLAVGAAGATQVVSTATGVDLGGMSSMFLRTRTAQEGFEGVKLFDMTVTGAAPGGGAVGVHDLPDLTSSAPGSTGAGYVQVSDVDWSADWTLAGSIRFSWDPDLACPCGSNLNVNFKLTDLETLSGGPPSSVIPLPAAGWLLLSGVAGLGWLGRRRAVV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=18927&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDHKARTALAAPLVAALVLSAAAANGATLRTLSGGDGAFNALCAAGNAVGTGNQACEFAVGEMRTGAVGGAQTWEVGVQNPPGSPVSTRNYAWGNGAAQAFVFSFSGGTLTLAVGAAGATQVVSTATGVDLGGMSSMFLRTRTAQEGFEGVKLFDMTVTGAAPGGGAVGVHDLPDLTSSAPGSTGAGYVQVSDVDWSADWTLAGSIRFSWDPDLACPCGSNLNVNFKLTDLETLSGGPPSSVIPLPAAGWLLLSGVAGLGWLGRRRAVV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGATCACAAGGCACGGACCGCTTTGGCAGCCCCGCTCGTGGCGGCGCTGGTGCTTTCGGCCGCGGCGGCCAATGGCGCGACCTTGCGGACGCTGTCCGGGGGGGATGGCGCCTTCAATGCGCTGTGCGCGGCGGGCAACGCGGTCGGAACCGGCAATCAGGCCTGCGAGTTTGCCGTCGGTGAAATGCGGACCGGGGCTGTCGGTGGCGCCCAGACATGGGAGGTCGGCGTGCAGAACCCGCCCGGATCGCCCGTCAGCACGCGCAATTATGCCTGGGGCAACGGCGCGGCGCAGGCGTTCGTGTTTTCCTTCAGCGGCGGCACCCTGACCCTTGCGGTCGGTGCGGCGGGGGCGACGCAGGTGGTCTCGACGGCGACGGGGGTCGACCTGGGCGGCATGTCGTCGATGTTCCTCCGCACCCGCACCGCACAGGAGGGGTTCGAGGGCGTGAAGCTGTTCGACATGACAGTGACGGGGGCCGCGCCGGGCGGGGGTGCGGTTGGTGTGCACGACCTGCCCGACCTGACCTCGTCCGCGCCGGGGTCGACCGGGGCGGGCTATGTTCAGGTGTCGGACGTGGACTGGAGCGCGGACTGGACGCTGGCGGGCTCGATCCGCTTCAGCTGGGACCCCGATCTGGCCTGCCCCTGCGGATCCAACCTGAATGTCAATTTCAAGCTGACCGATCTGGAGACGCTGTCGGGGGGGCCGCCGAGCAGTGTCATCCCGCTGCCGGCCGCCGGATGGCTGCTGCTGAGCGGGGTTGCGGGGCTGGGCTGGCTCGGGCGGCGGCGCGCGGTGGTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 30101,
                        "end": 30238,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02433",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02433</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02433</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,101 - 30,238,\n (total: 138 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGKGNNKRGNKEVKKPKQEKPKVLATANSGVAKPMTLGEKKDRSR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=20101&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGKGNNKRGNKEVKKPKQEKPKVLATANSGVAKPMTLGEKKDRSR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCAAAGGCAACAACAAGCGCGGAAACAAGGAAGTGAAGAAGCCGAAGCAGGAGAAGCCCAAGGTGCTGGCGACGGCCAACTCCGGCGTGGCGAAACCGATGACCCTGGGCGAGAAGAAAGACCGCAGCCGGTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 30442,
                        "end": 31245,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02434",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02434</span></strong><br>\n \n  D-beta-hydroxybutyrate dehydrogenase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02434</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">bdhA</span><br>\n \n Location: 30,442 - 31,245,\n (total: 804 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 200.7; E-value: 4.6e-61)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTDLTGKTALVTGSTSGIGLAIAEALGAAGARIALHGLAGDMEIHDATERVRAAGSPEVAFFGGDMRNPERIHELMAAVDAWGGVDILVNNAGIQHTAPTTEMPDDKWEAIIAINLSACFHTMKAALPGMAARGYGRVVNIASTHGLVASKEKAPYVAAKHGLVGMTKVVALEHAALGDAASGGVTANCICPGWTETALIEPQIEARAKARGGDRTAAIADLLSEKQPSQRMTSPADLGALAVWLCSPAAHNITGVAIPVDGGWTAQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=20442&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTDLTGKTALVTGSTSGIGLAIAEALGAAGARIALHGLAGDMEIHDATERVRAAGSPEVAFFGGDMRNPERIHELMAAVDAWGGVDILVNNAGIQHTAPTTEMPDDKWEAIIAINLSACFHTMKAALPGMAARGYGRVVNIASTHGLVASKEKAPYVAAKHGLVGMTKVVALEHAALGDAASGGVTANCICPGWTETALIEPQIEARAKARGGDRTAAIADLLSEKQPSQRMTSPADLGALAVWLCSPAAHNITGVAIPVDGGWTAQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGATCTGACGGGCAAGACGGCGCTGGTGACAGGCTCCACCTCGGGGATCGGGCTGGCCATCGCCGAGGCGCTGGGGGCTGCGGGCGCGCGCATCGCGCTGCACGGGCTGGCCGGCGACATGGAGATCCACGACGCGACCGAGCGGGTGCGCGCCGCCGGCAGCCCCGAGGTGGCGTTCTTCGGTGGCGACATGCGCAACCCCGAGCGCATTCACGAGCTGATGGCGGCGGTCGATGCCTGGGGCGGCGTGGACATCCTCGTCAACAACGCCGGCATCCAGCACACCGCCCCCACCACCGAGATGCCCGACGACAAGTGGGAGGCGATCATCGCCATCAACCTGTCGGCGTGTTTCCACACCATGAAGGCGGCGCTGCCTGGGATGGCCGCGCGGGGCTATGGGCGGGTTGTCAACATCGCCTCGACCCACGGGCTGGTGGCGTCGAAGGAAAAGGCGCCCTATGTCGCGGCCAAGCACGGGCTTGTGGGCATGACCAAGGTGGTGGCGCTGGAGCATGCGGCGCTGGGGGATGCGGCCTCGGGCGGGGTGACGGCGAACTGCATCTGTCCGGGCTGGACCGAAACCGCCCTGATCGAGCCGCAGATCGAGGCCCGCGCCAAGGCCCGCGGCGGCGACCGCACCGCCGCGATCGCGGATCTGCTGTCGGAGAAGCAACCCTCGCAGCGCATGACCAGCCCCGCCGATCTGGGGGCGCTGGCGGTGTGGTTGTGCAGCCCCGCCGCGCACAACATCACCGGGGTGGCGATCCCCGTGGACGGCGGCTGGACCGCGCAGTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 31242,
                        "end": 32768,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02435",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02435</span></strong><br>\n \n  Long-chain-fatty-acid--CoA ligase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02435</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">lcfB_3</span><br>\n \n Location: 31,242 - 32,768,\n (total: 1527 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 364.2; E-value: 1.5e-110)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNIANWLVRSAQTRGTAPALMAGAREVADYAGFARSAGALAGALAARGIAPGDRVALLAGNRPEYLVAVFGIWTAGAVAVPVNARLHPREAAWILSDSGAALALVAPDAAPDLAGVTEVPLMALPGPDWAAAVAGPPAPVVPRGQGDLAWLFYTSGTTGRPKGVCITHGMLAAMSLCYPVDVDPVGPQDAALYAAPMSHGAGLYAPIHVRMGARHLVPPSGGFDAAEVLDLAASHGPVSMFLAPTMVRRLLEAARASGRRGEGLRTVVYGGGPMYLADITAAVDWFGPRFVQIYGQGECPMAITALSRAEVADRTHPDWRARLGSVGRAQSLAEVAVIDDAGAPLPVGEAGEIVVRGAPVMPGYWRNPEASAKTLCDGWLRTGDVGQLDGDGYLTLVDRSRDVIISGGTNIYPREVEEALLEHPDVAEAAVIGRPSPEWGEEVVAFLVPRAALRRAALEAHCLERMARFKRPRAWYAVASLPKNNYGKVLKTELRARLAAGTEQEDIA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=21242&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNIANWLVRSAQTRGTAPALMAGAREVADYAGFARSAGALAGALAARGIAPGDRVALLAGNRPEYLVAVFGIWTAGAVAVPVNARLHPREAAWILSDSGAALALVAPDAAPDLAGVTEVPLMALPGPDWAAAVAGPPAPVVPRGQGDLAWLFYTSGTTGRPKGVCITHGMLAAMSLCYPVDVDPVGPQDAALYAAPMSHGAGLYAPIHVRMGARHLVPPSGGFDAAEVLDLAASHGPVSMFLAPTMVRRLLEAARASGRRGEGLRTVVYGGGPMYLADITAAVDWFGPRFVQIYGQGECPMAITALSRAEVADRTHPDWRARLGSVGRAQSLAEVAVIDDAGAPLPVGEAGEIVVRGAPVMPGYWRNPEASAKTLCDGWLRTGDVGQLDGDGYLTLVDRSRDVIISGGTNIYPREVEEALLEHPDVAEAAVIGRPSPEWGEEVVAFLVPRAALRRAALEAHCLERMARFKRPRAWYAVASLPKNNYGKVLKTELRARLAAGTEQEDIA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAACATCGCGAACTGGCTGGTGCGCAGCGCGCAGACGCGCGGGACGGCGCCCGCGCTGATGGCGGGCGCGCGGGAGGTGGCGGATTACGCGGGCTTTGCGCGGTCCGCTGGGGCGCTGGCGGGGGCGCTGGCGGCGCGCGGGATCGCGCCCGGCGACCGGGTCGCGCTGTTGGCGGGCAACCGGCCGGAGTATCTGGTGGCGGTGTTCGGGATCTGGACCGCCGGGGCGGTGGCGGTGCCGGTCAACGCCCGCCTGCATCCGCGCGAGGCGGCGTGGATCCTGTCCGACAGCGGCGCGGCGCTGGCGCTGGTGGCCCCCGACGCAGCACCCGATCTGGCGGGCGTGACCGAGGTGCCGCTGATGGCGCTGCCGGGTCCCGACTGGGCGGCGGCGGTGGCCGGGCCGCCCGCGCCGGTGGTGCCGCGGGGGCAGGGCGATCTGGCGTGGCTGTTCTACACCTCGGGCACCACGGGGCGGCCCAAGGGGGTGTGCATCACGCATGGCATGCTGGCGGCGATGTCGCTGTGCTATCCCGTCGACGTGGACCCGGTGGGGCCGCAGGACGCCGCGCTGTATGCGGCCCCCATGAGCCATGGGGCGGGCCTCTATGCGCCGATCCATGTGCGCATGGGGGCGCGGCATCTGGTGCCGCCCTCGGGCGGGTTCGACGCGGCCGAGGTGCTGGATCTGGCCGCATCCCACGGCCCGGTGTCGATGTTCCTGGCGCCCACCATGGTGCGCCGGCTGCTGGAGGCCGCGCGCGCCTCGGGGCGGCGGGGCGAGGGGCTGCGCACCGTCGTCTATGGCGGCGGGCCGATGTATCTGGCCGACATCACCGCCGCCGTCGACTGGTTCGGCCCGCGTTTCGTGCAGATCTATGGTCAGGGCGAATGCCCGATGGCCATCACCGCGCTGAGCCGGGCCGAGGTCGCGGACCGCACCCATCCCGACTGGCGCGCGCGCCTCGGCTCGGTCGGGCGGGCGCAGAGCCTGGCGGAGGTCGCGGTGATCGATGACGCGGGCGCGCCGCTGCCGGTGGGCGAGGCGGGCGAGATCGTGGTGCGCGGCGCCCCGGTGATGCCCGGCTACTGGCGCAATCCCGAGGCCAGCGCGAAAACCCTGTGCGACGGTTGGCTGCGGACCGGCGACGTGGGCCAGCTGGACGGCGACGGATACCTGACGCTGGTCGACCGTTCTCGGGACGTGATCATCTCGGGCGGGACCAACATCTATCCCCGCGAGGTCGAGGAGGCCCTGCTGGAACACCCCGACGTGGCCGAGGCCGCCGTCATCGGCCGCCCCAGCCCCGAGTGGGGCGAGGAGGTGGTGGCGTTCCTCGTGCCCCGCGCGGCGCTGCGCCGCGCGGCGCTGGAGGCGCATTGTCTGGAGCGGATGGCCCGGTTCAAGCGGCCCAGGGCATGGTATGCAGTGGCATCCCTTCCAAAGAACAATTACGGCAAGGTGCTGAAGACCGAGTTGCGCGCCCGGCTGGCCGCCGGGACCGAACAGGAGGACATCGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 32823,
                        "end": 36047,
                        "strand": -1,
                        "locus_tag": "KKHPANEM_02436",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02436</span></strong><br>\n \n  Sensor histidine kinase RcsC<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02436</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">rcsC_7</span><br>\n \n Location: 32,823 - 36,047,\n (total: 3225 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 66.2; E-value: 5.2e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPGRAPPQRHRLGAPGAERWVEVTAAPRGPGAAPGHVVALRDVTAAARATHEVEQLSQIARRTGDLVVITDTDHRIDWVNPAFEARTGWRLEDVRGHLPESILQSPEADAAEVARIRGALLEGASASGLLLCRTRTDDAFWAEIDAYPLRDSDGRTTGHVTLATDVTARRAQEAKLERLAQEATRARERLEMAVEALPDAFAFFDAEDRLVLCNERYRTFHPRSGYMISPGVQFADFARAVAHSGDVADAVGREEAWLAERLASHREGRPGGEHRMADGSWLRVIERVTADGGRVGMRVDITELKEAERRLADIIHGAQVGTWEWHLASGENRINARWAEIVGYCPDEIDRSGIDLWRALVHPDDLARAEARLARVFAREIDQFEYELRMRHRDGHWVWVLSRGRVARWSPDGKPEVMAGVHMDITALKRAEERLEAILHAAEAGTWETDPARGGMRINDRWAEMLGYTVDELAPLPEHGFRTLMHPDDRARLEAEFGMDLEGRPDRFSVEVRVRHKAGAWVWLLARGRVLARDANGRPVRTAGIHLDITERKRLEQQLVAERDYMSRLMETNVSGITALDGDGRIIYANREAEAILGLSAAAVDRRSYADPRWQITAPDGGPLADAELPFTRAMTEGRVVRDVRFAIAWPDGTRRQLSVNAAPLLAEGLQARVVCAITDITEQVATEAALRSAAERAEAASEAKSRFLANMSHEIRTPLNGVLGMAQVLEEELSEPRHRRMLEVIRESGEMLLGVLNDVLDMSKIEAGKVTLEQVAFVPADLARRIEAMHALRAAEKHLSLEVVAAPGAERARLGDPGRVEQMLHNLVGNAVKFTEAGGVRVTLEGGCGPLRVVVHDTGIGMTDDQLARIFEDFEQADGTVTRRFGGTGLGMSIVRRLVALMGGQITVDSIPGAGTQVRVALPLPLAEGGPRDAVPVPAQPLEGLRALAADDNATNRLILQAMLSALGGAVTMVPDGQAAVEAWAPGRFDLILLDISMPGLDGLGALAAIRLREAEAGVPPAPAVAITANAMAHQVAQYMGAGFAAHVGKPFRREDLARTLLRVLDRAPPAQR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=22823&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPGRAPPQRHRLGAPGAERWVEVTAAPRGPGAAPGHVVALRDVTAAARATHEVEQLSQIARRTGDLVVITDTDHRIDWVNPAFEARTGWRLEDVRGHLPESILQSPEADAAEVARIRGALLEGASASGLLLCRTRTDDAFWAEIDAYPLRDSDGRTTGHVTLATDVTARRAQEAKLERLAQEATRARERLEMAVEALPDAFAFFDAEDRLVLCNERYRTFHPRSGYMISPGVQFADFARAVAHSGDVADAVGREEAWLAERLASHREGRPGGEHRMADGSWLRVIERVTADGGRVGMRVDITELKEAERRLADIIHGAQVGTWEWHLASGENRINARWAEIVGYCPDEIDRSGIDLWRALVHPDDLARAEARLARVFAREIDQFEYELRMRHRDGHWVWVLSRGRVARWSPDGKPEVMAGVHMDITALKRAEERLEAILHAAEAGTWETDPARGGMRINDRWAEMLGYTVDELAPLPEHGFRTLMHPDDRARLEAEFGMDLEGRPDRFSVEVRVRHKAGAWVWLLARGRVLARDANGRPVRTAGIHLDITERKRLEQQLVAERDYMSRLMETNVSGITALDGDGRIIYANREAEAILGLSAAAVDRRSYADPRWQITAPDGGPLADAELPFTRAMTEGRVVRDVRFAIAWPDGTRRQLSVNAAPLLAEGLQARVVCAITDITEQVATEAALRSAAERAEAASEAKSRFLANMSHEIRTPLNGVLGMAQVLEEELSEPRHRRMLEVIRESGEMLLGVLNDVLDMSKIEAGKVTLEQVAFVPADLARRIEAMHALRAAEKHLSLEVVAAPGAERARLGDPGRVEQMLHNLVGNAVKFTEAGGVRVTLEGGCGPLRVVVHDTGIGMTDDQLARIFEDFEQADGTVTRRFGGTGLGMSIVRRLVALMGGQITVDSIPGAGTQVRVALPLPLAEGGPRDAVPVPAQPLEGLRALAADDNATNRLILQAMLSALGGAVTMVPDGQAAVEAWAPGRFDLILLDISMPGLDGLGALAAIRLREAEAGVPPAPAVAITANAMAHQVAQYMGAGFAAHVGKPFRREDLARTLLRVLDRAPPAQR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCGGGGCGGGCACCGCCGCAGCGCCACCGGCTGGGCGCCCCCGGCGCCGAGCGGTGGGTCGAGGTGACAGCCGCCCCGCGCGGCCCCGGTGCCGCGCCGGGCCATGTGGTGGCGCTGCGCGATGTCACCGCCGCCGCGCGCGCCACCCACGAGGTCGAACAGCTGAGCCAGATCGCCCGGCGCACCGGCGATCTGGTGGTCATCACCGATACCGACCACCGCATCGACTGGGTCAACCCGGCCTTTGAGGCGCGCACCGGCTGGCGGCTGGAGGATGTCCGCGGCCACCTCCCCGAGAGCATCCTGCAAAGCCCCGAGGCCGACGCGGCCGAGGTCGCGCGCATCCGCGGCGCGCTGCTGGAGGGGGCGTCGGCCAGCGGGCTCTTGCTGTGCCGCACCCGGACGGACGATGCCTTCTGGGCCGAGATCGACGCCTATCCGCTGCGGGACTCGGACGGGCGGACGACGGGCCATGTCACGCTGGCCACCGACGTCACCGCGCGCCGCGCGCAGGAGGCCAAGCTGGAGCGCCTTGCGCAGGAGGCCACGCGGGCGCGCGAGCGGCTGGAGATGGCGGTGGAGGCGCTGCCGGACGCGTTTGCGTTTTTCGACGCCGAGGACCGGCTGGTGCTGTGCAACGAGCGCTATCGCACCTTTCATCCGCGGTCGGGGTACATGATCTCGCCGGGGGTGCAGTTCGCGGACTTTGCCCGGGCGGTGGCCCACAGCGGCGATGTCGCCGACGCCGTGGGCCGCGAGGAGGCGTGGCTGGCCGAGCGCCTGGCCTCGCACCGCGAGGGGCGCCCGGGCGGCGAGCACCGCATGGCCGACGGCAGCTGGCTGCGGGTGATCGAGCGCGTCACCGCCGACGGCGGCCGCGTCGGCATGCGCGTCGACATCACCGAGCTGAAGGAGGCCGAGCGGCGGCTGGCCGACATCATCCACGGCGCGCAGGTCGGCACCTGGGAGTGGCACCTGGCCAGCGGCGAGAACCGCATCAACGCGCGCTGGGCCGAGATCGTGGGCTATTGCCCCGACGAGATCGACCGCTCGGGCATCGATCTGTGGCGGGCGCTGGTGCACCCCGACGACCTGGCCCGCGCCGAGGCGCGGCTGGCGCGGGTGTTCGCCCGCGAGATCGACCAGTTCGAGTATGAATTGCGCATGCGCCACCGTGACGGCCACTGGGTCTGGGTGCTGTCGCGCGGGCGGGTGGCGCGTTGGTCGCCCGACGGCAAGCCCGAGGTGATGGCCGGGGTGCACATGGACATCACCGCCCTCAAGCGCGCCGAGGAACGGCTGGAGGCGATCCTGCACGCCGCCGAAGCCGGCACCTGGGAGACCGATCCCGCGCGCGGCGGCATGCGCATCAACGACCGCTGGGCGGAGATGCTGGGCTACACCGTGGACGAGCTTGCGCCCCTGCCGGAACACGGTTTTCGCACCCTGATGCACCCCGACGACCGCGCCCGGCTGGAGGCGGAGTTCGGCATGGACCTGGAGGGCCGCCCCGATCGCTTCAGCGTGGAGGTGCGGGTGCGCCACAAGGCCGGTGCCTGGGTCTGGCTGCTGGCGCGCGGCCGGGTGCTGGCGCGCGACGCCAACGGCCGGCCGGTGCGCACCGCGGGCATCCACCTCGACATCACCGAGCGCAAGCGGCTGGAGCAGCAGCTGGTGGCCGAGCGCGATTACATGTCGCGGCTGATGGAGACGAATGTCTCGGGCATCACCGCGCTGGATGGCGACGGGCGCATCATCTATGCCAACCGCGAGGCCGAGGCGATCCTGGGCTTGTCGGCGGCGGCGGTGGACCGGCGCAGCTATGCCGATCCGCGCTGGCAGATCACCGCCCCCGACGGCGGGCCGCTGGCCGATGCCGAGCTGCCCTTTACCCGCGCCATGACCGAGGGGCGGGTGGTGCGCGACGTGCGCTTCGCCATCGCCTGGCCCGACGGCACCCGGCGGCAGCTGTCGGTCAACGCGGCGCCGCTGCTGGCCGAGGGGCTGCAGGCGCGGGTGGTCTGCGCGATCACCGACATCACCGAACAGGTCGCCACCGAAGCCGCCCTGCGCAGCGCCGCCGAGCGGGCCGAGGCCGCCAGCGAGGCCAAGTCGCGGTTCCTGGCCAACATGAGCCACGAGATTCGCACCCCCCTGAACGGGGTCCTCGGGATGGCGCAGGTGCTGGAGGAGGAGCTGTCCGAGCCGCGCCACCGCCGCATGCTGGAGGTGATCCGCGAATCCGGCGAGATGCTGCTGGGCGTGCTCAACGATGTCCTCGACATGTCCAAGATCGAGGCCGGCAAGGTTACGCTGGAGCAGGTCGCCTTCGTGCCCGCCGATCTGGCACGGCGGATCGAGGCGATGCACGCCCTGCGCGCCGCCGAGAAGCATCTGTCGCTGGAGGTCGTGGCCGCCCCCGGCGCCGAGCGCGCGCGGCTGGGCGATCCGGGCCGGGTGGAGCAGATGCTGCACAACCTGGTCGGCAACGCCGTCAAGTTCACCGAGGCGGGCGGCGTGCGGGTGACGCTGGAGGGGGGGTGTGGCCCGCTGCGGGTGGTCGTCCATGACACCGGGATCGGCATGACGGACGATCAGTTGGCGCGCATCTTCGAGGATTTCGAACAGGCCGACGGCACGGTGACCCGCCGGTTCGGGGGCACCGGGCTGGGCATGTCCATCGTGCGCCGCCTGGTGGCGCTGATGGGCGGCCAGATCACGGTCGACAGCATCCCTGGCGCGGGCACCCAGGTGCGCGTCGCGCTGCCGCTGCCGCTGGCCGAGGGTGGCCCGCGCGATGCCGTCCCCGTGCCCGCCCAGCCGCTGGAGGGGCTGCGCGCGCTGGCGGCCGACGACAACGCCACCAACCGGCTGATCCTCCAGGCGATGCTGTCGGCGCTGGGCGGGGCCGTGACGATGGTGCCCGACGGGCAGGCCGCGGTGGAGGCGTGGGCGCCGGGGCGGTTCGATCTGATCCTGCTGGACATCTCGATGCCGGGGCTGGACGGTCTGGGCGCGCTGGCCGCGATCCGCCTGCGCGAGGCCGAGGCGGGTGTGCCACCCGCGCCCGCGGTGGCGATCACCGCCAACGCCATGGCCCATCAGGTGGCGCAGTACATGGGCGCGGGCTTTGCCGCCCATGTCGGCAAGCCGTTCCGCCGCGAGGACCTGGCGCGGACGCTGTTGCGCGTGCTGGACCGCGCCCCGCCCGCGCAGCGGTGA\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 21261,
                        "end": 32768,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 11261,
                        "neighbouring_end": 36052,
                        "product": "betalactone",
                        "height": 2,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [
                    {
                        "start": 23454,
                        "end": 23456,
                        "strand": -1,
                        "containedBy": [
                            "KKHPANEM_02428"
                        ]
                    }
                ],
                "type": "betalactone",
                "products": [
                    "betalactone"
                ],
                "anchor": "r292c1"
            }
        ]
    },
    {
        "length": 6535,
        "seq_id": "NZ_NHSD01000293",
        "regions": []
    },
    {
        "length": 37000,
        "seq_id": "NZ_NHSD01000294",
        "regions": []
    },
    {
        "length": 6577,
        "seq_id": "NZ_NHSD01000295",
        "regions": []
    },
    {
        "length": 53165,
        "seq_id": "NZ_NHSD01000296",
        "regions": []
    },
    {
        "length": 11929,
        "seq_id": "NZ_NHSD01000297",
        "regions": []
    },
    {
        "length": 19069,
        "seq_id": "NZ_NHSD01000298",
        "regions": []
    },
    {
        "length": 61719,
        "seq_id": "NZ_NHSD01000299",
        "regions": []
    },
    {
        "length": 12096,
        "seq_id": "NZ_NHSD01000300",
        "regions": []
    },
    {
        "length": 6610,
        "seq_id": "NZ_NHSD01000301",
        "regions": []
    },
    {
        "length": 78689,
        "seq_id": "NZ_NHSD01000302",
        "regions": []
    },
    {
        "length": 12163,
        "seq_id": "NZ_NHSD01000303",
        "regions": []
    },
    {
        "length": 6351,
        "seq_id": "NZ_NHSD01000304",
        "regions": []
    },
    {
        "length": 46872,
        "seq_id": "NZ_NHSD01000305",
        "regions": []
    },
    {
        "length": 11806,
        "seq_id": "NZ_NHSD01000306",
        "regions": []
    },
    {
        "length": 21208,
        "seq_id": "NZ_NHSD01000307",
        "regions": []
    },
    {
        "length": 25080,
        "seq_id": "NZ_NHSD01000308",
        "regions": []
    },
    {
        "length": 6088,
        "seq_id": "NZ_NHSD01000309",
        "regions": []
    },
    {
        "length": 30200,
        "seq_id": "NZ_NHSD01000310",
        "regions": []
    },
    {
        "length": 6210,
        "seq_id": "NZ_NHSD01000311",
        "regions": []
    },
    {
        "length": 31784,
        "seq_id": "NZ_NHSD01000312",
        "regions": []
    },
    {
        "length": 6077,
        "seq_id": "NZ_NHSD01000313",
        "regions": []
    },
    {
        "length": 28055,
        "seq_id": "NZ_NHSD01000314",
        "regions": []
    },
    {
        "length": 2531,
        "seq_id": "NZ_NHSD01000315",
        "regions": []
    },
    {
        "length": 26774,
        "seq_id": "NZ_NHSD01000316",
        "regions": []
    },
    {
        "length": 5998,
        "seq_id": "NZ_NHSD01000317",
        "regions": []
    },
    {
        "length": 26232,
        "seq_id": "NZ_NHSD01000318",
        "regions": []
    },
    {
        "length": 6084,
        "seq_id": "NZ_NHSD01000319",
        "regions": []
    },
    {
        "length": 28137,
        "seq_id": "NZ_NHSD01000320",
        "regions": []
    },
    {
        "length": 5898,
        "seq_id": "NZ_NHSD01000321",
        "regions": []
    },
    {
        "length": 25654,
        "seq_id": "NZ_NHSD01000322",
        "regions": []
    },
    {
        "length": 25548,
        "seq_id": "NZ_NHSD01000323",
        "regions": []
    },
    {
        "length": 24788,
        "seq_id": "NZ_NHSD01000324",
        "regions": []
    },
    {
        "length": 24496,
        "seq_id": "NZ_NHSD01000325",
        "regions": []
    },
    {
        "length": 24374,
        "seq_id": "NZ_NHSD01000326",
        "regions": []
    },
    {
        "length": 18745,
        "seq_id": "NZ_NHSD01000327",
        "regions": []
    },
    {
        "length": 17875,
        "seq_id": "NZ_NHSD01000328",
        "regions": []
    },
    {
        "length": 17483,
        "seq_id": "NZ_NHSD01000329",
        "regions": []
    },
    {
        "length": 17469,
        "seq_id": "NZ_NHSD01000330",
        "regions": []
    },
    {
        "length": 17841,
        "seq_id": "NZ_NHSD01000331",
        "regions": []
    },
    {
        "length": 17450,
        "seq_id": "NZ_NHSD01000332",
        "regions": []
    },
    {
        "length": 16757,
        "seq_id": "NZ_NHSD01000333",
        "regions": []
    },
    {
        "length": 16628,
        "seq_id": "NZ_NHSD01000334",
        "regions": []
    }
];
var all_regions = {
    "order": [
        "r218c1",
        "r237c1",
        "r273c1",
        "r287c1",
        "r292c1"
    ],
    "r218c1": {
        "start": 1,
        "end": 9387,
        "idx": 1,
        "orfs": [
            {
                "start": 435,
                "end": 1055,
                "strand": -1,
                "locus_tag": "KKHPANEM_01436",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01436</span></strong><br>\n \n  Cytidylate kinase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01436</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">cmk</span><br>\n \n Location: 435 - 1,055,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAEGARFTVALDGPAASGKGTLGRALAQACGFAHLDTGLLYRAVGARAAAGEDPVAAARSLVPEDLSRADLRSAAAGQAASRVAALEEVRAALLAFQRDFARRPGGAVLDGRDIGTVVCPGAEVKLFVTASDAVRSRRRWLELRAHQPDLTQVEVLEDLRARDARDRERAAAPLRPAPDAMLLDTSDLTIEAAIARALSAVEAARR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=11055\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAEGARFTVALDGPAASGKGTLGRALAQACGFAHLDTGLLYRAVGARAAAGEDPVAAARSLVPEDLSRADLRSAAAGQAASRVAALEEVRAALLAFQRDFARRPGGAVLDGRDIGTVVCPGAEVKLFVTASDAVRSRRRWLELRAHQPDLTQVEVLEDLRARDARDRERAAAPLRPAPDAMLLDTSDLTIEAAIARALSAVEAARR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCTGAGGGCGCGCGGTTCACGGTCGCGCTGGATGGGCCGGCGGCGTCGGGCAAGGGCACGCTGGGGCGCGCGCTGGCGCAGGCGTGCGGGTTTGCGCATCTCGATACGGGGCTTCTGTATCGTGCCGTGGGTGCGCGGGCGGCGGCGGGCGAGGACCCGGTGGCCGCAGCGCGCAGCCTCGTGCCCGAGGATCTGTCGCGCGCCGATCTGCGCAGCGCCGCCGCAGGGCAGGCCGCCAGCCGCGTGGCGGCACTGGAAGAGGTGCGCGCGGCGCTGCTGGCATTCCAGCGGGATTTCGCGCGCAGACCCGGCGGAGCGGTGCTGGACGGGCGCGACATCGGCACCGTGGTCTGCCCGGGCGCAGAGGTGAAGCTGTTCGTCACCGCATCGGATGCGGTGCGGTCGCGGCGGCGTTGGCTGGAGCTGCGCGCGCACCAGCCCGACCTGACGCAGGTGGAGGTTCTCGAAGACCTGCGTGCCCGCGATGCCCGCGACCGCGAACGGGCAGCCGCGCCGCTGCGACCGGCGCCGGACGCGATGCTTCTGGACACCTCGGACCTGACGATCGAGGCGGCGATCGCACGGGCGCTCTCGGCGGTCGAGGCCGCCCGCCGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1048,
                "end": 2397,
                "strand": -1,
                "locus_tag": "KKHPANEM_01437",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01437</span></strong><br>\n \n  3-phosphoshikimate 1-carboxyvinyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01437</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">aroA</span><br>\n \n Location: 1,048 - 2,397,\n (total: 1350 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTATSAPMPLTARAGGALRGTTDVPGDKSISHRALILGALAVGETRITGLLEGQDVLDTAAAMRAFGAEVIRHGPGSWSVHGVGVGGFGEPSGVIDCGNSGTGVRLIMGAMATTPITATFTGDASLCRRPMGRVTDPLALFGAQAVGRAGGRLPMTLVGAADPVPVRYVLPVPSAQVKSAVLLAGLNAPGETAVIEAEPTRDHTERMLAGFGAVIRHEDTPEGRAVILTGQPELIAQPVAVPRDPSSAAFPVVAALMVPGSDVRVPGVSRNPTRDGLYCTLLEMGADLLFEAERAEGGEPVADLRARFTGTLRGVEVPPERAASMIDEFPILAALAATAEGATVMRGVRELRVKESDRIAAMATGLAACGVAVEETEDTLTVHGCGPDGVPGGTTVATHLDHRIAMSFLCLGLVARAPVTVDDAGPIATSFPDFIPLMTALGADLATHG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=12397\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTATSAPMPLTARAGGALRGTTDVPGDKSISHRALILGALAVGETRITGLLEGQDVLDTAAAMRAFGAEVIRHGPGSWSVHGVGVGGFGEPSGVIDCGNSGTGVRLIMGAMATTPITATFTGDASLCRRPMGRVTDPLALFGAQAVGRAGGRLPMTLVGAADPVPVRYVLPVPSAQVKSAVLLAGLNAPGETAVIEAEPTRDHTERMLAGFGAVIRHEDTPEGRAVILTGQPELIAQPVAVPRDPSSAAFPVVAALMVPGSDVRVPGVSRNPTRDGLYCTLLEMGADLLFEAERAEGGEPVADLRARFTGTLRGVEVPPERAASMIDEFPILAALAATAEGATVMRGVRELRVKESDRIAAMATGLAACGVAVEETEDTLTVHGCGPDGVPGGTTVATHLDHRIAMSFLCLGLVARAPVTVDDAGPIATSFPDFIPLMTALGADLATHG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCGCCACTTCCGCGCCCATGCCCCTGACCGCCCGTGCCGGCGGGGCGCTGCGGGGCACCACCGACGTGCCCGGCGACAAGTCCATCAGCCACCGCGCTCTGATCCTGGGTGCGCTGGCGGTGGGCGAGACGCGCATCACCGGGCTGCTGGAAGGGCAGGATGTCCTCGACACCGCCGCCGCGATGCGCGCCTTCGGGGCCGAGGTGATCCGCCACGGACCCGGCAGCTGGTCGGTGCATGGCGTGGGCGTGGGCGGGTTCGGCGAACCGTCGGGTGTGATCGACTGCGGCAACTCGGGCACCGGGGTGCGGCTGATCATGGGCGCGATGGCGACCACGCCGATCACCGCCACCTTCACCGGCGATGCCAGCCTGTGCCGCCGCCCCATGGGCCGCGTGACCGATCCGCTGGCGCTGTTTGGTGCACAGGCGGTGGGGCGCGCGGGCGGACGGCTGCCGATGACGCTGGTGGGCGCGGCCGATCCGGTGCCGGTGCGCTATGTGCTGCCGGTGCCCTCGGCGCAGGTGAAATCGGCGGTGCTGCTGGCCGGGCTGAACGCGCCGGGCGAGACCGCGGTGATCGAGGCCGAGCCGACCCGCGACCACACCGAACGCATGCTCGCGGGCTTCGGCGCCGTCATCCGCCACGAGGACACGCCCGAGGGCCGCGCGGTGATCCTGACGGGCCAGCCGGAGTTGATCGCGCAGCCGGTGGCGGTGCCGCGCGATCCGTCCTCGGCCGCGTTTCCGGTGGTGGCGGCGCTGATGGTGCCGGGATCGGATGTGCGGGTGCCGGGCGTCAGCCGCAACCCCACGCGCGACGGCCTTTATTGCACGCTGCTGGAGATGGGCGCCGATCTGCTGTTCGAGGCCGAGCGCGCGGAGGGCGGCGAGCCGGTGGCCGACCTGCGCGCCCGCTTCACGGGAACCTTGCGCGGGGTGGAGGTGCCGCCCGAGCGCGCCGCCAGCATGATCGACGAGTTCCCGATCCTCGCAGCCCTTGCCGCCACCGCCGAGGGCGCCACCGTCATGCGCGGCGTGCGCGAGTTGCGCGTCAAGGAAAGCGACCGCATCGCCGCGATGGCCACCGGGCTGGCCGCCTGCGGCGTCGCGGTGGAGGAGACGGAGGACACGCTGACGGTGCATGGCTGCGGCCCGGACGGCGTGCCGGGGGGCACGACGGTGGCCACGCACCTCGACCACCGCATCGCCATGAGCTTCCTGTGCCTTGGCCTCGTGGCCCGCGCGCCCGTCACGGTGGACGATGCCGGCCCCATCGCCACGTCGTTTCCCGACTTCATTCCGCTGATGACGGCCCTTGGCGCCGATCTGGCCACCCATGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2489,
                "end": 3880,
                "strand": -1,
                "locus_tag": "KKHPANEM_01438",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01438</span></strong><br>\n \n  Aspartate kinase Ask_Ect<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01438</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ask</span><br>\n \n Location: 2,489 - 3,880,\n (total: 1392 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSRSRELLETLWVGGREDVYGRIFVVSAYGGITNLLLEHKKSGEQGVYARFASDDGGSGWHQALNDTAAEMMRVHGEILEHDGDRGRADAFVRDRIEGARACMIDLQRLGSYGHFRIDGQLMTLRELLAGLGEAHSAFVSTLLLQRHGVNARFVDLSGWRDEAHPDLAERLRAALDGIDFSEELPIVTGYAHCAEGLMREYDRGYSEVVFAHIAAQTAASEAIIHKEFHLSSADPKVVGLDKVRKIGRTSYDVADQLSNLGMEAIHPNAARILRRAEVALRVKHAFEPDDPGTLIGPEGGQAGRVEMVTGLPLQALEVYEPDMVGVKGYDAGILDALTRHKLWIVSKSSNANSITHWVSGSLKALRRVERELAQRWSNAEITIRPVAMVSAIGSDLTGLGAVRRGLEALDAAGIEVLAVQQGLRRVEVQFLVPREAQDAAVAALHARLIEETGAASVQPIAAE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=13880\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSRSRELLETLWVGGREDVYGRIFVVSAYGGITNLLLEHKKSGEQGVYARFASDDGGSGWHQALNDTAAEMMRVHGEILEHDGDRGRADAFVRDRIEGARACMIDLQRLGSYGHFRIDGQLMTLRELLAGLGEAHSAFVSTLLLQRHGVNARFVDLSGWRDEAHPDLAERLRAALDGIDFSEELPIVTGYAHCAEGLMREYDRGYSEVVFAHIAAQTAASEAIIHKEFHLSSADPKVVGLDKVRKIGRTSYDVADQLSNLGMEAIHPNAARILRRAEVALRVKHAFEPDDPGTLIGPEGGQAGRVEMVTGLPLQALEVYEPDMVGVKGYDAGILDALTRHKLWIVSKSSNANSITHWVSGSLKALRRVERELAQRWSNAEITIRPVAMVSAIGSDLTGLGAVRRGLEALDAAGIEVLAVQQGLRRVEVQFLVPREAQDAAVAALHARLIEETGAASVQPIAAE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCCGGAGCCGCGAGTTGCTCGAGACCCTGTGGGTCGGAGGCCGCGAGGATGTGTATGGCCGCATCTTTGTCGTCTCGGCCTATGGCGGGATCACCAACCTGCTGCTGGAGCACAAGAAAAGCGGCGAGCAGGGGGTCTATGCCCGGTTTGCCTCGGATGACGGCGGCAGCGGCTGGCACCAGGCGCTGAACGACACCGCAGCCGAGATGATGCGCGTGCACGGAGAGATCCTGGAGCATGACGGCGACAGGGGCCGGGCGGATGCGTTCGTGCGCGACCGCATCGAGGGTGCGCGGGCCTGCATGATCGACCTTCAGCGGCTGGGCTCCTACGGGCACTTCCGCATCGACGGGCAACTGATGACGCTGCGCGAGTTGCTGGCGGGGCTGGGCGAGGCGCATTCGGCCTTTGTCAGCACGCTGCTGTTGCAGCGCCACGGGGTGAACGCGCGCTTTGTGGATCTGTCGGGTTGGCGCGACGAGGCGCATCCCGATCTGGCCGAGCGGCTGCGCGCCGCGCTCGACGGGATCGACTTCTCCGAGGAGCTGCCGATCGTCACCGGCTATGCGCATTGTGCCGAAGGGCTGATGCGCGAATACGATCGTGGCTATTCCGAGGTGGTGTTCGCCCACATCGCGGCGCAGACCGCGGCCTCCGAGGCGATCATCCACAAGGAGTTCCATCTGTCCTCGGCTGATCCCAAGGTCGTGGGGCTGGACAAGGTGCGCAAGATCGGGCGCACCAGCTATGACGTGGCCGACCAGCTGTCGAACCTCGGGATGGAGGCGATCCACCCCAACGCAGCCCGCATCCTGCGCCGCGCCGAGGTCGCGCTGCGGGTCAAGCACGCGTTTGAACCCGACGATCCCGGCACCCTGATCGGTCCCGAGGGCGGGCAGGCGGGGCGCGTGGAGATGGTCACCGGCCTGCCGTTGCAGGCGCTGGAGGTCTATGAGCCCGACATGGTCGGGGTGAAGGGCTATGACGCCGGGATCCTGGACGCGCTGACGCGCCACAAGCTGTGGATCGTGTCGAAGTCCTCCAACGCGAACTCCATCACCCACTGGGTCAGCGGCTCGCTCAAGGCCCTGCGCCGGGTGGAGCGGGAGCTGGCGCAGCGCTGGTCCAACGCCGAGATCACCATTCGTCCCGTGGCGATGGTGTCGGCCATCGGCAGCGACCTGACCGGCCTTGGTGCGGTGCGTCGGGGGCTGGAGGCGCTGGACGCCGCCGGGATCGAGGTGCTTGCGGTGCAGCAGGGCCTGCGCCGGGTGGAGGTGCAGTTCCTCGTTCCGCGCGAGGCGCAGGACGCAGCGGTCGCCGCCCTGCATGCCCGCCTGATCGAGGAGACGGGCGCGGCCAGCGTCCAGCCCATCGCCGCCGAGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 4004,
                "end": 4387,
                "strand": -1,
                "locus_tag": "KKHPANEM_01439",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01439</span></strong><br>\n \n  L-ectoine synthase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01439</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectC</span><br>\n \n Location: 4,004 - 4,387,\n (total: 384 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ectoine: ectoine_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIVRDFHEANKTDRKVANERWESVRLLLADDGMGFSFHITTIEGGSEHTFHYKNHFESVYCISGKGSIEDLATGTVHQIRPGVMYALDKHDKHTLRCEDTMVLACCFNPPVTGTEVHRADGSYAAAD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=14387\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIVRDFHEANKTDRKVANERWESVRLLLADDGMGFSFHITTIEGGSEHTFHYKNHFESVYCISGKGSIEDLATGTVHQIRPGVMYALDKHDKHTLRCEDTMVLACCFNPPVTGTEVHRADGSYAAAD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCGTTCGCGATTTCCACGAAGCCAACAAGACCGACCGCAAGGTCGCCAACGAGCGTTGGGAGTCGGTGCGCCTGCTGCTGGCCGATGACGGGATGGGGTTTTCGTTCCACATCACCACCATCGAAGGCGGCTCCGAGCACACCTTTCACTACAAGAACCATTTCGAGAGCGTGTATTGCATCTCGGGTAAGGGCTCGATCGAGGATCTCGCCACCGGCACCGTCCACCAGATCCGGCCCGGCGTGATGTACGCGCTCGACAAGCACGACAAGCACACCTTGCGCTGCGAGGACACGATGGTTCTGGCGTGCTGCTTCAACCCGCCCGTGACGGGCACCGAGGTGCACCGGGCCGACGGCTCCTACGCCGCCGCGGACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 4391,
                "end": 5689,
                "strand": -1,
                "locus_tag": "KKHPANEM_01440",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01440</span></strong><br>\n \n  Diaminobutyrate--2-oxoglutarate transaminase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01440</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectB</span><br>\n \n Location: 4,391 - 5,689,\n (total: 1299 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_3<br>\n \n  biosynthetic-additional (smcogs) SMCOG1013:aminotransferase class-III (Score: 353.4; E-value: 2.6e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTDHTQTDTGPMAVYARRESQVRSYCRSFPVEFTKGRNATLTDRAGREYIDFLAGCSSLNYGHNDPDMKAALIDHITGDGIAHGLDMHTDAKTAFLETFERVILRPRGMEHKVMMTGPTGTNAVEAAMKLARKVTGRDTIVAFTNGFHGMTMGALAATGNAGKRAGGGMALHGVVRMPYEGAMDGVDSLAMIEAMLDNPSSGFDAPAAFLIEPVQGEGGLNAASADFLRGLKRLAEKHGALLIADDIQSGIGRTGPFFSFEGMDVMPDLIPLAKSLSGMGLPFAALLVRPDLDVWKPAEHNGTFRGNQHAFVTARVALEKFWTDDTFQKQTEAKAEFLERRLSDIAALIPGARLKGRGMMRGVDVGSGETAGAICAACFEHGLVIETSGAHDEVVKVLAPLTIPEAQLAQGLDIIEAAVRSRIAGTTPIAAE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=15689\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTDHTQTDTGPMAVYARRESQVRSYCRSFPVEFTKGRNATLTDRAGREYIDFLAGCSSLNYGHNDPDMKAALIDHITGDGIAHGLDMHTDAKTAFLETFERVILRPRGMEHKVMMTGPTGTNAVEAAMKLARKVTGRDTIVAFTNGFHGMTMGALAATGNAGKRAGGGMALHGVVRMPYEGAMDGVDSLAMIEAMLDNPSSGFDAPAAFLIEPVQGEGGLNAASADFLRGLKRLAEKHGALLIADDIQSGIGRTGPFFSFEGMDVMPDLIPLAKSLSGMGLPFAALLVRPDLDVWKPAEHNGTFRGNQHAFVTARVALEKFWTDDTFQKQTEAKAEFLERRLSDIAALIPGARLKGRGMMRGVDVGSGETAGAICAACFEHGLVIETSGAHDEVVKVLAPLTIPEAQLAQGLDIIEAAVRSRIAGTTPIAAE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCGATCATACCCAGACCGACACCGGCCCCATGGCCGTCTATGCCCGCCGCGAAAGCCAGGTGCGCAGCTACTGCCGCAGCTTTCCGGTGGAGTTCACCAAGGGCCGCAACGCCACGCTGACCGACCGCGCGGGGCGGGAGTACATCGACTTCCTCGCCGGGTGCTCGTCGCTGAACTATGGCCACAACGACCCGGACATGAAGGCGGCGCTGATCGACCACATCACCGGCGACGGCATCGCCCACGGCCTGGACATGCACACCGACGCCAAGACCGCGTTCCTGGAGACGTTCGAGCGCGTGATCCTGCGCCCGCGCGGCATGGAGCACAAGGTGATGATGACCGGCCCCACCGGCACCAACGCCGTCGAGGCCGCGATGAAGCTGGCGCGCAAGGTCACCGGGCGCGACACCATCGTCGCCTTCACCAACGGCTTTCACGGCATGACGATGGGCGCGCTGGCGGCCACCGGCAACGCCGGCAAGCGCGCGGGCGGCGGCATGGCGCTGCATGGCGTCGTGCGGATGCCCTATGAGGGGGCGATGGACGGCGTCGACAGCCTCGCGATGATCGAGGCGATGCTGGACAACCCCTCCAGCGGGTTCGACGCGCCGGCCGCGTTCCTGATCGAGCCGGTGCAGGGTGAGGGCGGGCTGAACGCCGCCTCGGCCGACTTCCTGCGCGGGCTGAAGCGGCTGGCCGAGAAGCACGGCGCGCTGCTCATTGCCGACGATATCCAGTCGGGCATCGGGCGCACGGGGCCGTTCTTCAGCTTCGAGGGGATGGACGTGATGCCCGACCTGATCCCGCTGGCGAAGTCGCTGTCGGGGATGGGCCTGCCGTTCGCCGCACTTCTGGTGCGCCCGGACCTGGACGTGTGGAAGCCGGCCGAACACAACGGCACCTTCCGCGGCAACCAGCATGCCTTCGTCACCGCCCGCGTGGCGCTGGAGAAGTTCTGGACCGACGACACCTTCCAGAAGCAGACCGAAGCCAAGGCCGAGTTCCTGGAGCGCCGGCTGTCGGACATCGCCGCCCTGATCCCCGGCGCCCGGCTGAAGGGCCGCGGCATGATGCGTGGCGTCGACGTCGGTTCGGGCGAGACGGCGGGCGCGATCTGCGCGGCCTGTTTCGAGCACGGTCTGGTCATCGAGACCTCGGGCGCCCATGATGAGGTCGTCAAGGTCCTCGCGCCCCTGACAATTCCCGAGGCGCAGTTGGCGCAGGGCCTCGACATCATCGAAGCGGCGGTGCGCAGCCGGATCGCCGGCACCACCCCCATTGCAGCGGAGTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 5735,
                "end": 6277,
                "strand": -1,
                "locus_tag": "KKHPANEM_01441",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01441</span></strong><br>\n \n  L-2,4-diaminobutyric acid acetyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01441</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectA</span><br>\n \n Location: 5,735 - 6,277,\n (total: 543 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MARTNRKIIETPKGAVRLRSPVKTDGTAVQELIARCAPLDQNSLYMNLIQCDHFADTCVLAERGDDVLGWISAHVPPGREDTIFVWQVAVDARARGMGLGRHMLTALLERPLCRRVINLETTITRDNEGSWALFRSLARRLDGDLSHAPHFEREAHFGGAHDTEHLVTIALDAEAVRRAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=16277\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MARTNRKIIETPKGAVRLRSPVKTDGTAVQELIARCAPLDQNSLYMNLIQCDHFADTCVLAERGDDVLGWISAHVPPGREDTIFVWQVAVDARARGMGLGRHMLTALLERPLCRRVINLETTITRDNEGSWALFRSLARRLDGDLSHAPHFEREAHFGGAHDTEHLVTIALDAEAVRRAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCCCGGACAAATCGCAAGATCATCGAAACACCCAAGGGTGCGGTGCGCCTGCGCAGCCCCGTCAAGACTGACGGCACGGCCGTCCAGGAGCTGATCGCGCGCTGCGCGCCACTGGACCAGAATTCCCTCTACATGAACCTGATCCAGTGCGACCACTTCGCCGACACCTGTGTGCTGGCCGAGCGTGGCGACGATGTGCTGGGCTGGATCTCGGCGCATGTGCCGCCGGGGCGCGAGGACACGATCTTCGTGTGGCAGGTGGCTGTTGACGCCCGCGCACGCGGCATGGGGCTGGGACGCCACATGCTGACGGCGCTGCTGGAGCGCCCGCTGTGCCGCCGCGTCATCAACCTGGAGACCACGATCACCCGCGACAACGAGGGGTCCTGGGCACTGTTCCGCAGCCTTGCCCGGCGTCTGGACGGCGATCTGTCCCACGCGCCCCATTTTGAACGCGAGGCGCATTTCGGCGGCGCGCATGACACCGAGCATCTGGTGACCATCGCGCTCGACGCCGAAGCGGTGCGCCGGGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 6556,
                "end": 7044,
                "strand": 1,
                "locus_tag": "KKHPANEM_01442",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01442</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01442</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,556 - 7,044,\n (total: 489 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1135:MarR family transcriptional regulator (Score: 88.6; E-value: 4.5e-27)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTERVDATLIALRRVLRAIEGNARAIARASGLTHAQMLVLHALADRGQELPSDIARRLGVAQATVTTQIDRLEARGLVRRERRQTDRRTVWVILTDSGRQLLADTPDPLYGRFADRFARLADWEQGMLMTSAERLAKLFDAEAVEPLPAGEDTARKPAPPVA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=17044\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTERVDATLIALRRVLRAIEGNARAIARASGLTHAQMLVLHALADRGQELPSDIARRLGVAQATVTTQIDRLEARGLVRRERRQTDRRTVWVILTDSGRQLLADTPDPLYGRFADRFARLADWEQGMLMTSAERLAKLFDAEAVEPLPAGEDTARKPAPPVA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGAACGGGTGGATGCGACGCTGATCGCACTCAGGCGCGTGCTGCGCGCGATCGAGGGCAACGCCCGCGCGATCGCGCGGGCCTCGGGGTTGACGCACGCACAGATGCTGGTGCTGCACGCGCTGGCCGACCGCGGGCAGGAACTGCCCAGCGACATCGCCCGCCGTCTGGGCGTGGCCCAGGCCACCGTCACCACCCAGATCGATCGGCTGGAGGCGCGCGGCCTTGTGCGCCGCGAGCGTCGGCAGACCGACCGCCGCACCGTCTGGGTGATCCTGACCGACAGCGGGCGCCAGCTTCTGGCCGACACCCCCGACCCGCTCTATGGCCGCTTCGCCGACCGGTTCGCGCGGCTTGCGGATTGGGAACAGGGCATGCTGATGACCAGCGCCGAGCGTCTGGCCAAGCTGTTTGACGCCGAGGCCGTCGAGCCCCTGCCCGCGGGCGAGGACACCGCGCGCAAACCCGCGCCCCCCGTCGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 7260,
                "end": 8933,
                "strand": 1,
                "locus_tag": "KKHPANEM_01443",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01443</span></strong><br>\n \n  Cytochrome c oxidase subunit 1-beta<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01443</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ctaDII</span><br>\n \n Location: 7,260 - 8,933,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MADAVTQGGGHGDTRGFFTRWFMSTNHKDIGILYLFTSGIVGFIAVAFTVYMRMELMEPGVQYMCLEGARMTAAAAGECTPNGHLWNVLITAHGVLMMFFVVIPALFGGFGNYFMPLHIGAPDMAFPRLNNLSYWLYVAGASLAVASLFSPGGAGQTGAGVGWVLYPPLSTTETGYAMDLAIFAVHVAGASSILGAINIITTFLNMRAPGMTLHKVPLFAWSVFITAWMILLALPVLAGAITMLLTDRNFGTTFFDPSGGGDPVLYQHILWFFGHPEVYIIIIPGFGIISHVIATFSRKPIFGYLPMVYAMVAIGVLGFVVWAHHMYTVGMSLTQQSYFMLATMVIAVPTGIKIFSWIATMWGGSVEFKTPMLWAFGFLFLFTVGGVTGVVLSQAAVDRYYHDTYYVVAHFHYVMSLGAVFALFAGIYYWIGKMSGRQYPEWAGKTHFWAMFIGSNLTFFPQHFLGRQGMPRRYIDYPEAFALWNWVSSIGAFISFASFVFFIGVIYYTLRHGARVTENNYWNEHADTLEWTLPSPPPEHTFETLPKREDWDRSPAH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218&amp;from=0&amp;to=18933\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MADAVTQGGGHGDTRGFFTRWFMSTNHKDIGILYLFTSGIVGFIAVAFTVYMRMELMEPGVQYMCLEGARMTAAAAGECTPNGHLWNVLITAHGVLMMFFVVIPALFGGFGNYFMPLHIGAPDMAFPRLNNLSYWLYVAGASLAVASLFSPGGAGQTGAGVGWVLYPPLSTTETGYAMDLAIFAVHVAGASSILGAINIITTFLNMRAPGMTLHKVPLFAWSVFITAWMILLALPVLAGAITMLLTDRNFGTTFFDPSGGGDPVLYQHILWFFGHPEVYIIIIPGFGIISHVIATFSRKPIFGYLPMVYAMVAIGVLGFVVWAHHMYTVGMSLTQQSYFMLATMVIAVPTGIKIFSWIATMWGGSVEFKTPMLWAFGFLFLFTVGGVTGVVLSQAAVDRYYHDTYYVVAHFHYVMSLGAVFALFAGIYYWIGKMSGRQYPEWAGKTHFWAMFIGSNLTFFPQHFLGRQGMPRRYIDYPEAFALWNWVSSIGAFISFASFVFFIGVIYYTLRHGARVTENNYWNEHADTLEWTLPSPPPEHTFETLPKREDWDRSPAH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCCGACGCAGTCACCCAGGGCGGAGGGCACGGGGACACCCGCGGGTTCTTCACCCGCTGGTTCATGTCCACCAACCACAAGGACATCGGGATCCTGTATCTGTTCACCTCCGGCATCGTCGGATTCATCGCGGTGGCCTTCACGGTCTACATGCGCATGGAACTGATGGAGCCCGGCGTTCAGTACATGTGCCTGGAGGGCGCGCGCATGACCGCGGCCGCCGCGGGCGAGTGCACCCCCAACGGCCACCTGTGGAACGTGCTGATCACCGCCCACGGCGTGCTGATGATGTTCTTCGTCGTGATTCCGGCGCTGTTCGGGGGCTTTGGCAACTACTTCATGCCGCTGCACATCGGCGCGCCGGACATGGCGTTCCCGCGGCTCAACAACCTGTCGTACTGGCTTTATGTGGCCGGGGCGTCGCTGGCGGTGGCGTCGCTGTTCTCGCCCGGCGGCGCGGGGCAGACCGGCGCGGGGGTGGGCTGGGTGCTCTATCCGCCGCTGTCGACGACCGAGACCGGCTATGCGATGGACCTCGCGATCTTTGCGGTGCATGTCGCGGGCGCCTCGTCGATCCTGGGTGCGATCAACATCATCACCACCTTCCTGAACATGCGAGCGCCGGGCATGACGCTGCACAAGGTGCCGCTGTTCGCCTGGTCGGTGTTCATCACCGCGTGGATGATCCTGCTGGCGCTGCCGGTTCTTGCGGGCGCCATCACCATGCTGCTGACCGACCGGAACTTCGGCACCACCTTCTTCGATCCCTCGGGCGGCGGCGACCCGGTGCTGTACCAGCACATCCTGTGGTTCTTCGGCCATCCGGAGGTCTACATCATCATCATCCCCGGCTTCGGCATCATCAGCCATGTCATCGCCACGTTCTCGCGCAAGCCGATCTTCGGCTACCTGCCGATGGTCTATGCGATGGTGGCCATCGGGGTGCTGGGCTTCGTGGTGTGGGCGCACCACATGTACACCGTGGGCATGTCGCTGACGCAGCAGAGCTACTTCATGCTGGCGACGATGGTGATCGCGGTGCCGACGGGCATCAAGATCTTCAGCTGGATCGCCACGATGTGGGGCGGCTCGGTGGAGTTCAAGACGCCCATGCTGTGGGCCTTCGGGTTCCTGTTCCTGTTCACCGTGGGCGGCGTGACGGGCGTGGTGCTCAGCCAGGCCGCCGTCGACCGCTACTATCACGACACCTACTATGTGGTCGCGCACTTCCACTATGTGATGTCCTTGGGCGCCGTGTTCGCGCTGTTTGCCGGGATCTACTACTGGATCGGCAAGATGTCGGGGCGGCAGTACCCCGAATGGGCCGGCAAGACGCACTTCTGGGCGATGTTCATCGGCTCCAACCTGACCTTCTTTCCGCAGCACTTCCTCGGCCGTCAGGGGATGCCGCGCCGCTACATCGACTACCCCGAGGCGTTCGCGCTGTGGAACTGGGTAAGCTCGATCGGCGCCTTCATCTCGTTCGCCTCGTTCGTGTTCTTCATCGGGGTGATCTACTACACCCTGCGCCACGGCGCGCGCGTGACCGAGAACAACTACTGGAACGAGCACGCCGACACGCTGGAGTGGACCCTGCCCTCGCCGCCGCCCGAACATACGTTCGAGACGCTGCCGAAGCGCGAGGACTGGGACCGCTCGCCCGCCCACTGA\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 4003,
                "end": 4387,
                "tool": "rule-based-clusters",
                "neighbouring_start": 0,
                "neighbouring_end": 9387,
                "product": "ectoine",
                "height": 2,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [],
        "type": "ectoine",
        "products": [
            "ectoine"
        ],
        "anchor": "r218c1"
    },
    "r237c1": {
        "start": 1,
        "end": 3563,
        "idx": 1,
        "orfs": [
            {
                "start": 6,
                "end": 1016,
                "strand": 1,
                "locus_tag": "KKHPANEM_01604",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01604</span></strong><br>\n \n  Phytoene desaturase (neurosporene-forming)<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01604</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtI_1</span><br>\n \n Location: 6 - 1,016,\n (total: 1011 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 315.4; E-value: 1.3e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRLRGDRSVYQTVSRYVKDERLRVMLSFHPLLIGGNPFHASSVYCLISYLERHWGIHFAMGGTGRLASGLAKLVEGQGNQIRYHAQVEEIEVADGRATGVRLTTGERIPAEIVVSNADSAYTYRRMLPPQVRKRWTDRKLDRARYSMSLFVWYFGTKRQYSETAHHTILLGPRYKELIEDIFERKILADDFSLYLHRPTATDPSLAPDGCDSFYVLSPVPHMDAGIDWSQQAQAYRARIADFLERTELPGLRENIVSEHMITPQDFQDRLLSERGAAFGLEPRLTQSAWFRPHNKSEDVEGLYLVGAGTHPGAGLPGVLSSARVLDQVVPDASEFA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRLRGDRSVYQTVSRYVKDERLRVMLSFHPLLIGGNPFHASSVYCLISYLERHWGIHFAMGGTGRLASGLAKLVEGQGNQIRYHAQVEEIEVADGRATGVRLTTGERIPAEIVVSNADSAYTYRRMLPPQVRKRWTDRKLDRARYSMSLFVWYFGTKRQYSETAHHTILLGPRYKELIEDIFERKILADDFSLYLHRPTATDPSLAPDGCDSFYVLSPVPHMDAGIDWSQQAQAYRARIADFLERTELPGLRENIVSEHMITPQDFQDRLLSERGAAFGLEPRLTQSAWFRPHNKSEDVEGLYLVGAGTHPGAGLPGVLSSARVLDQVVPDASEFA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGCCTGCGCGGCGACCGCAGCGTCTATCAGACGGTCAGCCGCTACGTGAAGGACGAGCGGCTGCGGGTCATGCTGTCGTTCCATCCGCTCTTGATCGGCGGCAACCCCTTCCATGCCAGTTCGGTCTATTGCCTGATCTCCTATCTGGAACGGCACTGGGGTATCCATTTCGCGATGGGCGGCACCGGCCGGCTGGCCAGCGGTCTCGCGAAGCTGGTGGAGGGGCAGGGCAACCAGATCCGCTATCACGCGCAGGTCGAGGAGATCGAGGTTGCGGACGGCCGGGCGACCGGTGTGCGCCTTACGACCGGCGAGCGCATTCCCGCCGAGATCGTCGTCTCCAACGCCGACAGCGCCTACACCTACCGCCGGATGCTGCCGCCGCAGGTCCGCAAGCGCTGGACCGACCGCAAGCTGGACCGCGCGCGCTACTCGATGAGTCTGTTCGTCTGGTACTTCGGCACCAAGCGACAGTACTCGGAGACGGCGCACCATACGATCCTGCTTGGCCCGCGCTACAAGGAGCTGATCGAGGACATCTTCGAGCGCAAAATCCTGGCCGACGACTTCTCGCTGTATCTGCACCGGCCGACCGCGACCGATCCGTCGCTGGCGCCGGACGGCTGCGATAGCTTCTACGTGTTGTCGCCGGTGCCGCACATGGATGCCGGGATCGACTGGTCGCAGCAGGCGCAGGCGTATCGCGCGCGGATCGCGGATTTCCTGGAGCGCACCGAGTTGCCGGGCCTGCGCGAGAACATCGTGTCCGAACACATGATCACGCCGCAGGATTTTCAGGACCGCCTGCTGTCCGAGCGCGGCGCGGCCTTCGGGCTGGAGCCGCGACTGACACAGAGCGCCTGGTTCCGCCCCCACAACAAGAGCGAGGACGTCGAGGGTCTATACCTCGTTGGTGCCGGTACCCATCCCGGTGCCGGTTTGCCCGGAGTCCTCTCGTCCGCTCGCGTGCTCGACCAGGTGGTGCCCGATGCCAGTGAATTCGCCTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 997,
                "end": 2061,
                "strand": 1,
                "locus_tag": "KKHPANEM_01605",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01605</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01605</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 997 - 2,061,\n (total: 1065 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPVNSPRDATLRAADAAAATAAIRTGSRSFHAASLVLPRRVREPARGLYAFCREADDAVDTRPDRTRALAELRQRLQWIYDGRPGNNAADRAFADVVAAYAIPQTLPEALLEGFAWDAEERRYRTIQDLRAYGARVAGAVGAMVAMLMGARQAEVVSRATDLGVAMQLTNIARDVGEDARQGRVYLPIDWLEAEGIDADAWLADPRFGPGVARTVERLLAHAEELYQRAEAGIPALPASCRPGITAASRLYRAIGHQVARQGHDSLSRRAVVPAMRKVGLMVDALKGPMPVAHYSDYPCLPETRFLVQAVHEALPALHGFKPDAADASAPVEEGAAAFVIDLFMRLEQRDQARG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPVNSPRDATLRAADAAAATAAIRTGSRSFHAASLVLPRRVREPARGLYAFCREADDAVDTRPDRTRALAELRQRLQWIYDGRPGNNAADRAFADVVAAYAIPQTLPEALLEGFAWDAEERRYRTIQDLRAYGARVAGAVGAMVAMLMGARQAEVVSRATDLGVAMQLTNIARDVGEDARQGRVYLPIDWLEAEGIDADAWLADPRFGPGVARTVERLLAHAEELYQRAEAGIPALPASCRPGITAASRLYRAIGHQVARQGHDSLSRRAVVPAMRKVGLMVDALKGPMPVAHYSDYPCLPETRFLVQAVHEALPALHGFKPDAADASAPVEEGAAAFVIDLFMRLEQRDQARG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCAGTGAATTCGCCTAGAGACGCAACCCTCCGCGCGGCCGATGCCGCAGCGGCGACGGCGGCGATCCGTACCGGATCGCGCAGCTTTCATGCCGCGTCGCTGGTGCTGCCGCGCCGGGTGCGGGAACCGGCGCGCGGGCTCTACGCTTTCTGTCGGGAAGCGGACGACGCCGTCGACACTCGCCCGGATCGCACGCGCGCGCTCGCAGAACTGCGCCAGCGCTTGCAGTGGATTTATGACGGTCGCCCAGGCAACAACGCCGCGGACCGGGCGTTTGCCGACGTGGTCGCCGCCTATGCGATCCCGCAGACCTTGCCCGAAGCGCTGTTGGAAGGCTTCGCCTGGGATGCCGAGGAGCGGCGTTACCGCACGATTCAGGATCTGCGCGCCTATGGCGCCCGGGTTGCCGGGGCGGTCGGCGCGATGGTCGCAATGCTGATGGGCGCGCGCCAGGCGGAGGTCGTCTCGCGGGCCACTGACCTCGGCGTGGCGATGCAGCTGACCAATATCGCCCGCGACGTTGGCGAGGATGCGCGCCAGGGGCGCGTCTATTTGCCGATCGATTGGCTGGAGGCGGAAGGCATCGACGCTGACGCTTGGCTCGCCGACCCACGGTTTGGTCCGGGCGTCGCGCGGACGGTGGAACGGCTGCTAGCCCACGCGGAGGAGCTGTATCAGCGTGCGGAAGCTGGCATTCCCGCGCTGCCGGCTTCCTGCCGCCCAGGCATCACCGCCGCCAGCCGTCTGTACCGGGCGATCGGCCATCAGGTCGCCCGGCAAGGCCACGATTCCTTGTCCCGGCGGGCGGTTGTACCGGCGATGCGCAAGGTCGGGCTGATGGTCGACGCGTTGAAGGGGCCGATGCCGGTTGCGCACTACAGCGACTATCCCTGCTTGCCGGAGACCCGGTTCCTGGTTCAGGCCGTGCACGAGGCATTGCCCGCGCTGCACGGTTTCAAGCCGGACGCAGCGGATGCGTCCGCTCCCGTCGAAGAGGGCGCCGCGGCCTTCGTGATCGACCTGTTCATGCGTCTGGAGCAGCGCGACCAGGCACGCGGGTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2195,
                "end": 2401,
                "strand": 1,
                "locus_tag": "KKHPANEM_01606",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01606</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01606</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,195 - 2,401,\n (total: 207 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDGGWIVLLEGMTVFGLLIGFGIWQLRSLKKMEREDKAKAAAEGREGESAFIRSREPRSGADTGHSEG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDGGWIVLLEGMTVFGLLIGFGIWQLRSLKKMEREDKAKAAAEGREGESAFIRSREPRSGADTGHSEG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGATGGCGGTTGGATTGTGCTGCTGGAGGGGATGACGGTCTTCGGGCTGTTGATCGGCTTCGGCATCTGGCAGTTGCGTTCGCTGAAAAAGATGGAGCGCGAAGATAAGGCCAAGGCGGCGGCCGAGGGACGGGAGGGCGAGTCCGCCTTCATCCGCTCCCGTGAACCCCGGTCAGGCGCGGATACGGGGCATTCGGAAGGGTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2369,
                "end": 3355,
                "strand": -1,
                "locus_tag": "KKHPANEM_01607",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01607</span></strong><br>\n \n  Acyclic carotenoid 1,2-hydratase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01607</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtC_1</span><br>\n \n Location: 2,369 - 3,355,\n (total: 987 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPVGGLGHQRPNTDGPGFDQPVAPGGYVWWYVDALSDDGQHGLTIIAFIGSVFSPYYAWARQRAPGGAADPLNHCSINVALYGEGPNRWAMTERGRTRIDRGARHFSVGPSGLHWDGRTLTIHLDEIAAPLPRAVQGRVRVTPHAMTTQEFAIDHQDRHHWWPMAPTAEVSVALNKPALSWHGTGYLDRNRGDEPLEAGFQEWDWARAPLPSGGTAITYDTFRRDGSDHALSLLVRKDGGIERFDNAVLNDLPSTSIWRIRRKGRADAGHRACVSKTLEDTPFYARSLVETHLAGEPVRAMHESLSLTRFDTRIVRLMLPFRMPRIRA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPVGGLGHQRPNTDGPGFDQPVAPGGYVWWYVDALSDDGQHGLTIIAFIGSVFSPYYAWARQRAPGGAADPLNHCSINVALYGEGPNRWAMTERGRTRIDRGARHFSVGPSGLHWDGRTLTIHLDEIAAPLPRAVQGRVRVTPHAMTTQEFAIDHQDRHHWWPMAPTAEVSVALNKPALSWHGTGYLDRNRGDEPLEAGFQEWDWARAPLPSGGTAITYDTFRRDGSDHALSLLVRKDGGIERFDNAVLNDLPSTSIWRIRRKGRADAGHRACVSKTLEDTPFYARSLVETHLAGEPVRAMHESLSLTRFDTRIVRLMLPFRMPRIRA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCTGTTGGCGGACTGGGGCATCAGCGACCCAACACGGACGGCCCCGGGTTCGATCAGCCGGTCGCGCCGGGCGGCTACGTCTGGTGGTACGTCGACGCGCTGAGCGACGACGGTCAGCACGGCCTGACCATCATCGCCTTCATCGGGTCGGTGTTCTCGCCGTACTACGCCTGGGCCCGACAGCGCGCACCCGGCGGCGCGGCGGACCCGCTGAACCACTGCTCGATCAATGTGGCCCTCTACGGCGAGGGGCCGAACCGCTGGGCGATGACGGAACGTGGCCGCACCCGCATCGATCGCGGCGCGCGGCACTTCTCCGTTGGTCCCAGCGGGCTGCACTGGGATGGCCGGACGCTCACCATCCACCTCGACGAGATCGCCGCGCCGCTGCCACGCGCGGTGCAAGGGCGCGTGCGCGTCACCCCGCACGCGATGACGACCCAGGAGTTCGCGATCGATCACCAGGATCGCCACCACTGGTGGCCGATGGCCCCCACGGCGGAGGTTTCGGTCGCCTTGAACAAACCGGCCCTGTCCTGGCACGGCACCGGCTACCTGGACCGCAACCGCGGCGACGAACCGCTCGAAGCCGGTTTTCAGGAATGGGACTGGGCGCGCGCCCCGCTGCCCTCCGGCGGCACCGCGATCACCTACGACACCTTCCGCCGCGACGGCTCCGACCACGCGCTGTCCCTGCTCGTCAGGAAAGATGGCGGGATCGAACGGTTCGACAACGCCGTCCTCAACGATCTGCCGTCGACATCGATCTGGCGCATCCGCCGCAAGGGCCGCGCCGATGCCGGCCATCGGGCCTGCGTGTCGAAGACGCTGGAGGACACGCCCTTCTACGCCCGCTCGCTGGTCGAGACGCACCTGGCAGGCGAACCGGTGCGGGCGATGCACGAAAGCCTGTCGTTGACGCGCTTCGACACGCGGATCGTGCGCCTGATGCTACCCTTCCGAATGCCCCGTATCCGCGCCTGA\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 996,
                "end": 2061,
                "tool": "rule-based-clusters",
                "neighbouring_start": 0,
                "neighbouring_end": 3563,
                "product": "terpene",
                "height": 2,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [],
        "type": "terpene",
        "products": [
            "terpene"
        ],
        "anchor": "r237c1"
    },
    "r273c1": {
        "start": 6312,
        "end": 21589,
        "idx": 1,
        "orfs": [
            {
                "start": 6817,
                "end": 7518,
                "strand": 1,
                "locus_tag": "KKHPANEM_02026",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02026</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02026</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,817 - 7,518,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MVAIVAGLWAPGGAAALDLPEVVRLDVTFAGLPVGVLHLAIRRTDGSYAATARLQPAGLGRLLPSARFEATVQGRLRAGRPQPLRYVEDVHTGRRESRTEIAWEGGVPRLLRLDPPRPPEPWHLDPAGQGGALDPMSAVLSVLADVPAERACALDLAVFDGRRRTQIVLAPAPDGEPGCDGVFRRVAGYDPEDLAERPEVPFRLIHGPGPGGTLRVIALEAAWELGTARLTRD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=0&amp;to=17518\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MVAIVAGLWAPGGAAALDLPEVVRLDVTFAGLPVGVLHLAIRRTDGSYAATARLQPAGLGRLLPSARFEATVQGRLRAGRPQPLRYVEDVHTGRRESRTEIAWEGGVPRLLRLDPPRPPEPWHLDPAGQGGALDPMSAVLSVLADVPAERACALDLAVFDGRRRTQIVLAPAPDGEPGCDGVFRRVAGYDPEDLAERPEVPFRLIHGPGPGGTLRVIALEAAWELGTARLTRD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGTGGCCATCGTGGCGGGGCTGTGGGCGCCCGGCGGCGCGGCGGCGCTTGATCTGCCCGAGGTGGTGCGCCTCGATGTGACTTTTGCGGGGCTGCCGGTGGGGGTGCTGCACCTTGCCATCCGCCGCACCGACGGCAGCTATGCCGCGACGGCGCGGCTGCAACCGGCGGGGCTGGGGCGTCTGCTGCCCTCGGCCCGGTTCGAGGCGACGGTGCAGGGCCGCCTGCGCGCAGGCCGCCCGCAGCCGCTGCGCTATGTCGAGGATGTGCACACCGGACGGCGCGAATCGCGCACCGAAATCGCATGGGAGGGGGGGGTGCCGCGCCTGCTGCGCCTTGACCCGCCGCGCCCGCCCGAGCCGTGGCACCTCGACCCGGCGGGGCAGGGCGGTGCGCTCGATCCGATGTCGGCGGTGCTGTCGGTGCTTGCGGATGTTCCGGCGGAGCGGGCCTGCGCGCTCGACCTTGCGGTGTTCGACGGGCGGCGGCGCACGCAGATCGTTCTGGCGCCCGCGCCGGACGGCGAGCCCGGCTGCGACGGCGTGTTTCGCCGCGTCGCAGGGTATGACCCCGAGGATCTGGCCGAGCGGCCGGAGGTGCCGTTCCGCCTGATCCACGGCCCCGGCCCGGGCGGCACCCTGCGCGTCATCGCACTGGAGGCCGCCTGGGAGCTGGGCACCGCCCGGCTGACCCGCGACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 7528,
                "end": 10089,
                "strand": -1,
                "locus_tag": "KKHPANEM_02027",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02027</span></strong><br>\n \n  Aminopeptidase N<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02027</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pepN</span><br>\n \n Location: 7,528 - 10,089,\n (total: 2562 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKDATPQPIRLADYTPPPFLVEGVALTFRLAPRATRVTSRIRFRRNPDAQAQDLRLDGEGLRLISATIDGVPITAQPDATGLTLPGGDLPDAFDWAAEVEIAPEENTALEGLYMSNGMYCTQCEAEGFRKITFYPDRPDVMAPFTVRVESELPVLLSNGNPSAQGDGWAEWDDPWPKPAYLFALVAGDLVAHSDAFATASGRAVALNVWVRPGDEGRCAYAMDSLKRSMRWDEEAYGREYDLDVFNIVAVDDFNMGAMENKGLNVFNSKYVLASSETATDADFDNIERIVAHEYFHNWTGNRITCRDWFQLCLKEGLTVFRDQQFSADMRSAAVKRIEDVLSLRARQFREDQGPLAHPVRPDSYHEINNFYTATVYEKGAEIIRMLRTLVGEDGYDAGVRLYFDRHDGQACTIEDWLAVFAEATGRDLSQFARWYAQAGTPRLRVTEDWDEGTGRFTLTLEQSTPPTPGQPDKAPQVIPVAVGLLGPAGDEIMATRVIEMTDTRHSLTIEGMPARPVPSILRGFSAPVVVEHAVTPERRAFLMAHDTDPFSRWEAGRGLAREILVAMVRDGAAPGPDYLDALAVTLSDERLDPAFRALCLRAPSEDDIAQALVDAGETPDPMAIHTARERFQRAIAAHMDDGLARAFIAMETPGPYSPDARDAGRRALRLAALAYLSRNDGGDRAARLFAGADNMTEQMGALGALLQVGAGQSEVARFHRQWAHDRLVVDKWFAVQVALAAPESAVETARSLTRHPDFDWKNPNRFRSVLGALATNAAGFHAPGGAGYALLADWLIQLDPVNPQTAARLSTAFETWRRYDPARQGAMRAALERIRATPDLSRDLSEMTARMLG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=0&amp;to=20089\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKDATPQPIRLADYTPPPFLVEGVALTFRLAPRATRVTSRIRFRRNPDAQAQDLRLDGEGLRLISATIDGVPITAQPDATGLTLPGGDLPDAFDWAAEVEIAPEENTALEGLYMSNGMYCTQCEAEGFRKITFYPDRPDVMAPFTVRVESELPVLLSNGNPSAQGDGWAEWDDPWPKPAYLFALVAGDLVAHSDAFATASGRAVALNVWVRPGDEGRCAYAMDSLKRSMRWDEEAYGREYDLDVFNIVAVDDFNMGAMENKGLNVFNSKYVLASSETATDADFDNIERIVAHEYFHNWTGNRITCRDWFQLCLKEGLTVFRDQQFSADMRSAAVKRIEDVLSLRARQFREDQGPLAHPVRPDSYHEINNFYTATVYEKGAEIIRMLRTLVGEDGYDAGVRLYFDRHDGQACTIEDWLAVFAEATGRDLSQFARWYAQAGTPRLRVTEDWDEGTGRFTLTLEQSTPPTPGQPDKAPQVIPVAVGLLGPAGDEIMATRVIEMTDTRHSLTIEGMPARPVPSILRGFSAPVVVEHAVTPERRAFLMAHDTDPFSRWEAGRGLAREILVAMVRDGAAPGPDYLDALAVTLSDERLDPAFRALCLRAPSEDDIAQALVDAGETPDPMAIHTARERFQRAIAAHMDDGLARAFIAMETPGPYSPDARDAGRRALRLAALAYLSRNDGGDRAARLFAGADNMTEQMGALGALLQVGAGQSEVARFHRQWAHDRLVVDKWFAVQVALAAPESAVETARSLTRHPDFDWKNPNRFRSVLGALATNAAGFHAPGGAGYALLADWLIQLDPVNPQTAARLSTAFETWRRYDPARQGAMRAALERIRATPDLSRDLSEMTARMLG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGGACGCAACCCCCCAGCCGATCCGACTGGCGGACTACACCCCGCCGCCGTTCCTGGTGGAGGGGGTCGCGCTGACCTTCCGGCTGGCGCCACGGGCCACGCGGGTGACGTCGCGCATCCGGTTCCGGCGCAACCCCGACGCGCAGGCCCAAGATCTGCGGCTGGATGGCGAGGGGCTGCGGCTGATCTCGGCCACCATCGACGGCGTGCCGATCACCGCGCAGCCCGATGCGACGGGCCTGACGCTGCCGGGCGGGGATCTGCCGGACGCCTTTGACTGGGCCGCCGAGGTGGAGATCGCACCGGAGGAAAACACCGCGCTGGAGGGGCTTTACATGTCGAATGGCATGTATTGCACGCAGTGCGAGGCCGAAGGCTTCCGCAAGATCACCTTCTATCCCGACCGCCCGGACGTGATGGCACCGTTCACGGTGCGGGTCGAATCCGAGCTGCCGGTGCTGCTGTCGAACGGCAATCCGTCCGCCCAGGGCGATGGCTGGGCCGAATGGGACGATCCCTGGCCCAAGCCCGCCTATCTGTTCGCGCTGGTGGCGGGCGATCTGGTGGCACATTCGGACGCCTTTGCCACCGCATCGGGGCGCGCGGTCGCGCTGAATGTCTGGGTGCGCCCGGGCGACGAGGGGCGCTGCGCCTATGCGATGGATTCGCTCAAACGCTCCATGCGCTGGGATGAGGAGGCCTACGGGCGCGAATACGACCTCGATGTGTTCAACATCGTGGCGGTGGACGACTTCAACATGGGCGCGATGGAGAACAAGGGGCTCAACGTCTTCAACTCCAAATACGTCCTCGCCTCCTCCGAGACGGCGACGGATGCCGACTTCGACAACATCGAGCGCATCGTCGCGCATGAATACTTCCACAACTGGACCGGCAACCGCATCACCTGCCGCGACTGGTTCCAGCTGTGCCTCAAGGAAGGGCTGACGGTGTTCCGCGACCAGCAGTTCAGCGCCGACATGCGCTCGGCCGCCGTCAAGCGGATCGAGGACGTGCTGAGCCTGCGCGCACGCCAGTTCCGCGAGGATCAGGGCCCGCTGGCGCATCCGGTGCGCCCCGACAGCTATCACGAGATCAACAACTTCTACACCGCGACGGTGTACGAGAAGGGCGCCGAGATCATCCGCATGCTGCGCACGCTGGTGGGCGAGGACGGCTATGACGCGGGCGTGCGGCTCTATTTCGACCGCCACGACGGGCAGGCCTGCACGATCGAGGACTGGTTGGCGGTGTTCGCGGAGGCCACGGGGCGCGACCTGTCGCAATTCGCGCGCTGGTATGCCCAGGCCGGCACCCCGCGCCTGCGGGTGACCGAGGATTGGGACGAGGGCACCGGCCGCTTCACCCTGACGCTGGAGCAGTCCACCCCCCCCACCCCGGGCCAGCCCGACAAGGCACCCCAGGTGATCCCGGTGGCCGTTGGCCTGCTGGGTCCCGCGGGCGACGAGATCATGGCCACCCGCGTGATCGAGATGACCGACACCCGCCACAGCCTGACGATCGAGGGGATGCCGGCACGCCCCGTCCCGTCGATCCTGCGCGGCTTCTCCGCCCCGGTGGTGGTCGAGCACGCGGTCACGCCGGAACGCCGCGCCTTTCTGATGGCCCATGACACCGATCCGTTTTCCCGGTGGGAGGCCGGGCGCGGGCTGGCGCGCGAGATCCTTGTGGCGATGGTGCGCGACGGCGCGGCGCCCGGGCCGGATTACCTCGATGCGCTGGCGGTGACGCTGTCGGACGAACGGCTGGACCCGGCGTTCCGCGCGCTGTGCCTGCGCGCGCCCTCCGAGGATGACATCGCCCAGGCGCTGGTGGATGCCGGCGAGACGCCGGACCCCATGGCGATCCACACCGCGCGCGAGCGGTTCCAGCGCGCGATCGCGGCCCACATGGACGACGGGCTGGCGCGCGCCTTCATCGCGATGGAGACGCCCGGCCCCTACAGCCCCGACGCGCGCGACGCGGGCCGCCGGGCGCTGCGGCTGGCGGCACTGGCGTATCTGTCGCGCAATGACGGCGGGGACCGGGCCGCGCGGCTGTTCGCCGGGGCCGACAACATGACCGAACAGATGGGCGCGCTGGGGGCCCTGCTGCAGGTCGGCGCGGGCCAGTCCGAGGTCGCGCGGTTCCACCGTCAATGGGCCCACGACCGGCTGGTGGTGGACAAGTGGTTCGCCGTTCAGGTGGCCCTCGCAGCGCCCGAAAGCGCGGTGGAGACCGCGCGCAGCCTGACGCGCCACCCCGATTTCGACTGGAAGAACCCCAACCGCTTCCGCTCGGTGCTGGGTGCGCTGGCGACGAATGCGGCGGGGTTCCACGCGCCGGGGGGCGCAGGCTATGCGCTGCTGGCGGACTGGCTGATCCAGCTTGATCCGGTGAACCCGCAGACCGCGGCGCGGCTGTCGACGGCGTTCGAGACCTGGCGCCGCTACGACCCCGCGCGCCAGGGCGCGATGCGCGCGGCGCTGGAGCGGATCCGCGCGACCCCCGACCTCAGCCGCGATCTGTCGGAAATGACGGCCCGGATGCTGGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 10256,
                "end": 11779,
                "strand": 1,
                "locus_tag": "KKHPANEM_02028",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02028</span></strong><br>\n \n  Cryptochrome-like protein cry2<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02028</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">cry2</span><br>\n \n Location: 10,256 - 11,779,\n (total: 1524 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTGSIVWFKRDLRVADHAALCAAAALGPVLPLYVVEPELWAQPDASARQWAFVAECLEALRGDLAALGAPLVVRTGCAVEVLETLARRHRLSRIFSHEETGTLWTFARDRRVGAWARANGMAWHEGPQSGVVRRLAARDGWAGRRDRFLAAPAAQPPGLSAVPGVAPGPIPTARTLRLAEDRCPHRQVGGRQAALTTLGGFLTSRGEGYRAAMASPVAGERACSRLSPHLAFGVLSGREVAHAAAARRAERPGGGWGASLRSFESRLAWRDHFMQKLEDAPDLEARCLHRATESLRPRTPDATRLAAFQSAETGIPFVDACLRYLAATGWLNFRMRAMLVSVAANHLWLDWRATGPFLARRFTDYEPGIHWSQMQMQSGTTGINTIRIYNPVKQGRDQDPDGRFTRAWLPELAEVPDAFLHEPWRWGGAGRVLGRAYPEPVVDVAAAARAAREAVWGLRRARGFAAEAAEVARKHASRKDRSGHFVNDRAPRRRRPAAAPGQLSLDL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=256&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTGSIVWFKRDLRVADHAALCAAAALGPVLPLYVVEPELWAQPDASARQWAFVAECLEALRGDLAALGAPLVVRTGCAVEVLETLARRHRLSRIFSHEETGTLWTFARDRRVGAWARANGMAWHEGPQSGVVRRLAARDGWAGRRDRFLAAPAAQPPGLSAVPGVAPGPIPTARTLRLAEDRCPHRQVGGRQAALTTLGGFLTSRGEGYRAAMASPVAGERACSRLSPHLAFGVLSGREVAHAAAARRAERPGGGWGASLRSFESRLAWRDHFMQKLEDAPDLEARCLHRATESLRPRTPDATRLAAFQSAETGIPFVDACLRYLAATGWLNFRMRAMLVSVAANHLWLDWRATGPFLARRFTDYEPGIHWSQMQMQSGTTGINTIRIYNPVKQGRDQDPDGRFTRAWLPELAEVPDAFLHEPWRWGGAGRVLGRAYPEPVVDVAAAARAAREAVWGLRRARGFAAEAAEVARKHASRKDRSGHFVNDRAPRRRRPAAAPGQLSLDL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGGTTCGATTGTCTGGTTCAAGCGTGACCTGCGGGTGGCCGACCACGCGGCGCTGTGTGCGGCGGCGGCGCTTGGCCCCGTGCTGCCGCTTTATGTGGTGGAGCCGGAGCTGTGGGCACAGCCCGACGCCTCGGCCCGGCAATGGGCGTTCGTTGCCGAGTGTCTGGAGGCGCTGCGCGGCGACCTGGCCGCGCTGGGGGCGCCGCTGGTCGTGCGCACTGGCTGCGCGGTCGAGGTGCTGGAGACGCTGGCCCGCCGCCACCGCCTGTCGCGCATCTTCAGCCACGAGGAGACCGGCACCCTGTGGACCTTTGCCCGCGACCGGCGTGTGGGGGCGTGGGCGCGCGCCAACGGCATGGCGTGGCACGAGGGGCCGCAGTCGGGCGTGGTGCGCCGCCTTGCCGCGCGCGATGGCTGGGCGGGGCGGCGGGATCGCTTCCTCGCCGCGCCCGCGGCCCAGCCGCCGGGGCTGTCGGCGGTGCCCGGCGTGGCGCCCGGCCCGATCCCCACCGCCCGCACCCTGCGCCTGGCCGAGGACCGCTGCCCCCACCGCCAGGTTGGCGGGCGGCAGGCCGCGCTGACCACGCTGGGCGGGTTCCTGACCTCGCGGGGCGAGGGGTACCGCGCCGCCATGGCCTCGCCCGTAGCCGGGGAACGCGCGTGTTCGCGCCTCTCGCCGCACCTGGCCTTCGGCGTGCTGTCCGGGCGCGAGGTCGCGCACGCCGCGGCCGCCCGCCGCGCCGAACGCCCCGGCGGTGGCTGGGGGGCTTCGCTGCGCAGCTTTGAATCGCGCCTCGCCTGGCGCGACCACTTCATGCAGAAGCTGGAGGACGCCCCCGACCTGGAGGCCCGCTGCCTGCACCGCGCGACCGAAAGCCTGCGCCCGCGCACGCCCGACGCCACCCGCCTCGCGGCATTCCAGTCCGCCGAGACCGGCATCCCCTTTGTCGACGCCTGCCTGCGGTATCTGGCGGCCACCGGCTGGCTGAACTTCCGCATGCGCGCGATGCTGGTGTCGGTGGCGGCGAACCACCTGTGGCTGGACTGGCGCGCCACGGGGCCGTTCCTGGCGCGGCGCTTCACCGACTACGAACCCGGCATCCACTGGAGCCAGATGCAGATGCAGTCCGGCACCACCGGCATCAACACCATCCGCATCTACAACCCCGTCAAGCAGGGCCGCGACCAGGACCCCGACGGCCGCTTCACCCGCGCCTGGCTGCCGGAGCTGGCCGAGGTGCCCGACGCCTTCCTGCACGAACCCTGGCGCTGGGGCGGGGCAGGGCGCGTGCTGGGGCGCGCCTATCCCGAGCCGGTGGTCGATGTCGCCGCCGCCGCCCGCGCCGCGCGCGAGGCGGTGTGGGGCCTGCGCCGCGCCCGCGGTTTCGCCGCCGAAGCCGCCGAGGTCGCCCGCAAGCACGCCAGCCGCAAGGACCGCTCGGGCCATTTCGTCAACGACCGCGCGCCCCGACGCCGTCGCCCCGCCGCAGCCCCGGGCCAGCTGTCGCTGGATCTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 11878,
                "end": 12774,
                "strand": 1,
                "locus_tag": "KKHPANEM_02029",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02029</span></strong><br>\n \n  1,4-dihydroxy-2-naphthoate octaprenyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02029</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">menA</span><br>\n \n Location: 11,878 - 12,774,\n (total: 897 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ubiA<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSVTSDLHTRTLPQPAAMLELIKPITWFPPMWAYLCGVISSGVSPLESLFLVILGVLLAGPIVCGMSQAANDWCDRHVDAINEPHRPIPSGRIPGRWGLWIALAMSGLALVVGWFLGPWGFGATVLGVIAAWAYSCPPVRLKRSGWWGPGLVGLSYESLPWFTGAAVLAVGAPSWEIVAVAVLYGLGAHGIMTLNDFKALEGDRQMGVNSLPVTLGPELAAKVACWVMIVPQLVVIALLFQWDRPWYGFFIVISVILQFYAMSVLLRDPKAKAPWYNATGVSLYVTGMMITAFALRTL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=1878&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSVTSDLHTRTLPQPAAMLELIKPITWFPPMWAYLCGVISSGVSPLESLFLVILGVLLAGPIVCGMSQAANDWCDRHVDAINEPHRPIPSGRIPGRWGLWIALAMSGLALVVGWFLGPWGFGATVLGVIAAWAYSCPPVRLKRSGWWGPGLVGLSYESLPWFTGAAVLAVGAPSWEIVAVAVLYGLGAHGIMTLNDFKALEGDRQMGVNSLPVTLGPELAAKVACWVMIVPQLVVIALLFQWDRPWYGFFIVISVILQFYAMSVLLRDPKAKAPWYNATGVSLYVTGMMITAFALRTL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTGTCACGTCTGATTTACACACCCGCACCCTGCCACAGCCCGCCGCGATGCTGGAGCTGATCAAGCCGATCACCTGGTTTCCGCCGATGTGGGCCTATCTGTGCGGCGTCATCTCGTCCGGGGTGTCGCCGCTGGAAAGCCTGTTTCTGGTCATCCTCGGCGTCCTGCTGGCGGGTCCCATCGTCTGCGGGATGAGCCAGGCGGCCAACGACTGGTGCGACCGCCACGTCGATGCGATCAACGAACCGCACCGGCCGATCCCCTCGGGGCGCATTCCGGGCCGCTGGGGGCTGTGGATCGCGCTGGCGATGTCGGGGCTGGCGCTGGTGGTGGGCTGGTTCCTCGGGCCGTGGGGCTTTGGCGCCACCGTGCTGGGGGTGATCGCGGCCTGGGCCTATTCCTGCCCGCCGGTGCGGCTGAAGCGGTCGGGCTGGTGGGGGCCGGGGCTGGTCGGGCTGTCGTATGAATCGCTGCCGTGGTTCACCGGCGCGGCCGTCCTCGCCGTCGGCGCGCCCAGCTGGGAGATCGTCGCGGTGGCCGTGCTCTATGGCCTCGGCGCGCACGGGATCATGACGCTCAACGATTTCAAGGCGCTGGAGGGCGATCGCCAGATGGGCGTGAACTCCCTGCCCGTGACGCTGGGCCCGGAGCTGGCGGCCAAGGTCGCGTGCTGGGTGATGATCGTCCCGCAACTCGTTGTGATCGCGCTTCTCTTCCAGTGGGATCGTCCCTGGTACGGCTTCTTCATCGTGATCTCGGTGATCCTGCAGTTCTATGCCATGTCGGTGCTGCTGCGCGACCCCAAGGCCAAGGCGCCCTGGTACAATGCCACCGGTGTCAGCCTCTATGTCACCGGCATGATGATCACCGCTTTCGCGCTGCGCACGCTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 12785,
                "end": 14089,
                "strand": 1,
                "locus_tag": "KKHPANEM_02030",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02030</span></strong><br>\n \n  Protein PucC<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02030</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pucC_2</span><br>\n \n Location: 12,785 - 14,089,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPVQPLSWLSIFRLGLVQLCLGAIVVLMTSTLNRLMVVELMLPAVLPGALVALHYGIQITRPNWGYRSDTCGNRTRWVIVGMGMLAAGALLAAFAIPVMEATFWLGLCVSILAYALIGMGVGASGTSLLALMATATAEHRRPAAASITWLMMIFGIAVTAITVGQVLDPYSHDRMLAIVAVVTGGAFVVTCLAIWGIERRAGVQAAPLAEPMTFRAGLREIWAERAARNFTFFVFLSMTAYFMQELIMEPFAGLVFDMTPGQTTSMSGAQNGGVFVGMVLVGVCATGLRFGALRSWVVAGCLGSAATLAAITLIASAGLKPLLVPSVITLGFFNGMFAVAAIGAMMQLAGQGRERREGTRMGLWGAAQAIAAGFGGLVGAGLADAMRTTLGNDASAFGAVFSIEAGLFLLSALVALRVMGGRGQTARMGLVAGE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=2785&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPVQPLSWLSIFRLGLVQLCLGAIVVLMTSTLNRLMVVELMLPAVLPGALVALHYGIQITRPNWGYRSDTCGNRTRWVIVGMGMLAAGALLAAFAIPVMEATFWLGLCVSILAYALIGMGVGASGTSLLALMATATAEHRRPAAASITWLMMIFGIAVTAITVGQVLDPYSHDRMLAIVAVVTGGAFVVTCLAIWGIERRAGVQAAPLAEPMTFRAGLREIWAERAARNFTFFVFLSMTAYFMQELIMEPFAGLVFDMTPGQTTSMSGAQNGGVFVGMVLVGVCATGLRFGALRSWVVAGCLGSAATLAAITLIASAGLKPLLVPSVITLGFFNGMFAVAAIGAMMQLAGQGRERREGTRMGLWGAAQAIAAGFGGLVGAGLADAMRTTLGNDASAFGAVFSIEAGLFLLSALVALRVMGGRGQTARMGLVAGE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCGTTCAACCGCTTTCATGGCTCTCCATCTTCCGGCTCGGGCTGGTGCAGCTGTGCCTCGGTGCGATCGTGGTGCTGATGACCTCGACCCTCAACCGGCTGATGGTGGTGGAGCTGATGCTGCCCGCCGTCCTGCCCGGTGCGCTGGTGGCGCTGCACTACGGCATCCAGATCACGCGGCCCAACTGGGGCTACCGCTCGGACACCTGCGGAAACCGCACGCGCTGGGTGATCGTGGGGATGGGGATGCTGGCCGCGGGCGCGCTGCTGGCGGCCTTTGCGATCCCGGTGATGGAGGCGACCTTCTGGCTGGGACTGTGCGTGTCGATCCTCGCCTATGCGCTGATCGGGATGGGGGTGGGGGCCTCGGGGACCTCTCTGCTGGCGCTGATGGCGACGGCCACGGCGGAACACCGCCGGCCGGCGGCGGCCTCGATCACCTGGCTGATGATGATCTTCGGCATCGCCGTCACCGCGATCACCGTGGGGCAGGTGCTGGACCCCTACAGCCACGACCGCATGCTCGCCATCGTCGCGGTGGTCACGGGGGGCGCTTTCGTGGTCACCTGCCTCGCCATCTGGGGGATCGAGCGGCGCGCCGGCGTCCAGGCCGCCCCCCTGGCCGAGCCCATGACCTTCCGTGCCGGCCTGCGCGAGATCTGGGCCGAGCGCGCGGCGCGCAACTTCACCTTCTTCGTGTTCCTGTCGATGACCGCCTATTTCATGCAGGAACTGATCATGGAGCCCTTCGCGGGCCTCGTCTTCGACATGACGCCGGGTCAGACGACGTCCATGTCGGGCGCGCAGAACGGCGGCGTGTTCGTCGGCATGGTGCTGGTGGGGGTGTGCGCCACGGGGCTGCGCTTCGGTGCGCTGCGCTCCTGGGTCGTCGCGGGGTGCCTCGGCTCGGCCGCGACGCTGGCGGCGATCACGCTGATCGCCAGCGCGGGGCTGAAGCCGCTGCTGGTGCCGTCGGTCATCACGCTGGGCTTCTTCAACGGCATGTTCGCGGTCGCCGCCATCGGTGCCATGATGCAGCTCGCCGGTCAGGGCCGCGAGCGCCGCGAGGGCACCCGCATGGGGCTGTGGGGCGCCGCGCAGGCCATCGCCGCGGGCTTTGGCGGGCTGGTGGGCGCGGGGCTGGCCGATGCCATGCGCACCACGCTGGGCAACGACGCCAGCGCCTTCGGCGCCGTCTTTTCGATCGAGGCCGGTCTCTTCCTCCTCAGCGCGCTGGTTGCGCTGCGGGTGATGGGGGGACGCGGCCAAACCGCCCGCATGGGCCTTGTTGCTGGGGAGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 14094,
                "end": 15287,
                "strand": 1,
                "locus_tag": "KKHPANEM_02031",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02031</span></strong><br>\n \n  Menaquinone reductase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02031</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">menJ_1</span><br>\n \n Location: 14,094 - 15,287,\n (total: 1194 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1161:oxidoreductase (Score: 73.9; E-value: 2.1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTYDVVVVGGGPCGATAAEDLARAGKRVALIDRAGRIKPCGGAIPPRLIADFDIPDEMIVAKINTARMISPTGRKVDIPIEGGFVGMVDREHFDEFLRVRAAKAGAERHTGTFVRIDRDESGARVIYRDKATKEERALPTRLVIGADGARSGVGRQEVPGGDTIPYVIAYHEIITPPEGGAQAAADYDPMRCDVIYDGAISPDFYGWVFPHGKSCSVGMGTGMDGVDLKACTAALRANSGLAGCETIRREGAPIPLKPLDRWDNGRDVVLAGDAAGVVAPSSGEGIYYAMACGRAAATAVQACLASGRAKDLQMARKMFLKEHGGVFKILGAMQNAYYRSDERRERFVSLCHDIDVQKLTFEAYMNKKLVNARPFAHMKIGVKNLLHLSGLVRPTYA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=4094&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTYDVVVVGGGPCGATAAEDLARAGKRVALIDRAGRIKPCGGAIPPRLIADFDIPDEMIVAKINTARMISPTGRKVDIPIEGGFVGMVDREHFDEFLRVRAAKAGAERHTGTFVRIDRDESGARVIYRDKATKEERALPTRLVIGADGARSGVGRQEVPGGDTIPYVIAYHEIITPPEGGAQAAADYDPMRCDVIYDGAISPDFYGWVFPHGKSCSVGMGTGMDGVDLKACTAALRANSGLAGCETIRREGAPIPLKPLDRWDNGRDVVLAGDAAGVVAPSSGEGIYYAMACGRAAATAVQACLASGRAKDLQMARKMFLKEHGGVFKILGAMQNAYYRSDERRERFVSLCHDIDVQKLTFEAYMNKKLVNARPFAHMKIGVKNLLHLSGLVRPTYA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCTATGATGTCGTCGTCGTCGGAGGGGGACCCTGCGGGGCCACCGCGGCCGAGGATCTGGCCCGCGCCGGCAAGCGCGTGGCCCTGATCGACCGCGCGGGCCGGATCAAGCCCTGCGGCGGGGCCATCCCGCCCCGGCTGATCGCGGATTTCGACATCCCCGACGAGATGATCGTGGCGAAGATCAACACCGCCCGCATGATCTCGCCCACCGGCCGCAAGGTCGACATCCCCATCGAGGGCGGCTTCGTCGGCATGGTCGACCGCGAGCACTTCGACGAATTCCTGCGCGTGCGCGCAGCCAAGGCGGGCGCCGAGCGTCACACCGGCACCTTCGTGCGCATCGACCGGGATGAGAGCGGCGCCCGCGTCATCTACCGCGACAAGGCCACCAAGGAAGAGCGCGCGCTGCCCACCCGGCTCGTGATCGGCGCGGACGGCGCACGCTCCGGCGTGGGCCGGCAGGAGGTGCCGGGCGGCGACACCATCCCCTATGTCATCGCCTATCACGAGATCATCACCCCGCCCGAGGGCGGCGCACAGGCCGCCGCCGACTATGATCCCATGCGCTGCGACGTGATCTATGACGGCGCGATCTCGCCCGACTTCTATGGCTGGGTGTTCCCGCACGGGAAATCCTGTTCCGTCGGCATGGGGACGGGCATGGACGGGGTGGACCTGAAGGCCTGCACGGCGGCGTTGCGCGCGAATTCCGGCCTTGCAGGCTGCGAGACGATCCGGCGTGAAGGCGCGCCGATCCCGCTCAAGCCGCTGGACCGCTGGGACAATGGCCGTGACGTGGTGCTGGCGGGCGATGCCGCCGGTGTGGTGGCGCCCAGCTCGGGTGAGGGGATCTACTATGCCATGGCCTGCGGGCGCGCGGCGGCCACCGCGGTGCAGGCCTGCCTGGCGTCGGGCCGTGCCAAGGACCTGCAGATGGCGCGCAAGATGTTCCTCAAGGAGCACGGCGGCGTCTTCAAGATCCTCGGCGCGATGCAGAACGCCTATTACCGCTCGGACGAGCGGCGCGAACGCTTCGTCTCGCTGTGCCACGACATCGACGTGCAGAAGCTGACGTTCGAGGCCTACATGAACAAGAAGCTGGTGAACGCGCGGCCCTTTGCCCACATGAAGATCGGGGTGAAGAACCTGCTGCACCTGTCGGGCCTCGTGCGGCCCACCTACGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 15296,
                "end": 15826,
                "strand": 1,
                "locus_tag": "KKHPANEM_02032",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02032</span></strong><br>\n \n  Isopentenyl-diphosphate Delta-isomerase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02032</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">idi</span><br>\n \n Location: 15,296 - 15,826,\n (total: 531 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTEMIPAWVNGRLTPVEKLEAHLQGLRHKAISVFVMDGDRVLIQQRAMGKYHTPGMWANTCCTHPHWDEGAEACATRRLREELGIEGLTLGHRDRVEYRAEVGNGLIEHEVVDIFTAAAGPTLHIAPNPDEVMAVRWVPLDTLRAEVAREPARFTPWLRIYLAEHAAAIFGAMARA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=5296&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTEMIPAWVNGRLTPVEKLEAHLQGLRHKAISVFVMDGDRVLIQQRAMGKYHTPGMWANTCCTHPHWDEGAEACATRRLREELGIEGLTLGHRDRVEYRAEVGNGLIEHEVVDIFTAAAGPTLHIAPNPDEVMAVRWVPLDTLRAEVAREPARFTPWLRIYLAEHAAAIFGAMARA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGAGATGATCCCGGCCTGGGTGAACGGCCGCCTGACCCCGGTGGAGAAGCTGGAGGCGCATCTGCAAGGGCTGCGCCACAAGGCGATCTCGGTCTTCGTCATGGACGGGGACCGGGTGCTGATCCAGCAGCGCGCGATGGGCAAGTACCACACGCCGGGGATGTGGGCGAACACCTGCTGCACCCATCCCCACTGGGACGAGGGGGCCGAGGCCTGCGCCACCCGCCGCCTGCGCGAGGAGCTGGGGATCGAGGGGCTGACCCTCGGCCACCGCGACCGCGTCGAATACCGCGCCGAGGTCGGCAACGGCCTGATCGAGCATGAGGTGGTGGACATCTTCACCGCCGCCGCCGGCCCGACGCTGCACATCGCCCCGAACCCCGACGAGGTGATGGCGGTGCGCTGGGTCCCGCTCGATACGCTGCGCGCCGAGGTCGCGCGGGAACCCGCGCGCTTCACCCCGTGGCTGCGCATCTATCTGGCAGAGCATGCCGCCGCGATCTTCGGAGCGATGGCGCGCGCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 15839,
                "end": 16312,
                "strand": -1,
                "locus_tag": "KKHPANEM_02033",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02033</span></strong><br>\n \n  Tryptophan-rich sensory protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02033</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">tspO_2</span><br>\n \n Location: 15,839 - 16,312,\n (total: 474 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDWLLFSVFLFACAAAGTTGAMFEPGKWYRDLTKPSWTPPNWLFPVAWSLLYIAMSLAAMRVALAGDSALALALWSTQIAFNTLWTPVFFGLKRMRAAMGVMVALWASVAATMVAFWQVDLIAGLLFVPYLAWVTVAGALNFSVWRLNPETGTPAGA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=5839&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDWLLFSVFLFACAAAGTTGAMFEPGKWYRDLTKPSWTPPNWLFPVAWSLLYIAMSLAAMRVALAGDSALALALWSTQIAFNTLWTPVFFGLKRMRAAMGVMVALWASVAATMVAFWQVDLIAGLLFVPYLAWVTVAGALNFSVWRLNPETGTPAGA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGACTGGCTCTTGTTCTCCGTCTTTCTGTTCGCCTGCGCGGCCGCGGGCACCACTGGCGCGATGTTCGAGCCGGGAAAGTGGTATCGTGACCTCACCAAGCCGAGCTGGACGCCTCCGAACTGGCTGTTCCCGGTGGCGTGGTCGCTTCTGTACATCGCGATGTCACTGGCGGCGATGCGGGTGGCGCTGGCGGGTGACAGCGCCCTGGCGCTGGCGTTGTGGTCCACGCAGATCGCCTTCAACACGCTGTGGACACCGGTGTTCTTCGGTCTGAAACGGATGCGGGCGGCGATGGGCGTGATGGTCGCGCTGTGGGCATCGGTCGCGGCGACCATGGTGGCGTTCTGGCAGGTCGACCTGATCGCGGGGCTGTTGTTCGTGCCCTATCTTGCCTGGGTCACGGTGGCGGGTGCGCTGAACTTCAGCGTCTGGCGCCTCAACCCCGAGACAGGCACCCCGGCGGGGGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 16312,
                "end": 17421,
                "strand": -1,
                "locus_tag": "KKHPANEM_02034",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02034</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02034</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,312 - 17,421,\n (total: 1110 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSTVATDAPRAAPAVRRTALLAEDLDHCEAAIRTGSRSFFTASKLLPGRVRRPALALYAFCRLSDDAVDLTREKPAAILALRDRLDLVYRGTPRNAPADRAFAAIVEEFEMPRALPEALLEGLAWDAQGRRYRTIDDLHSYSARVAAAVGAMMCVLMRVRDADALARACDLGLAMQLTNIARDVGEDAREGRLFLPTDWMEGAGIDTQAFLADPQPTAPVCRVVRRLLAEADRLYFRSEAGIAALPLSVRPGIAAARHIYAAIGTRIACAGHDSITQRAYTGPGAKLWGLATAGVHVAVTLALPRPVELHALPEPSVAFLVNAAAHAPPARETWAQGRSAALLSVLSDLESRDRARRGLMGRATEPNCE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=6312&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSTVATDAPRAAPAVRRTALLAEDLDHCEAAIRTGSRSFFTASKLLPGRVRRPALALYAFCRLSDDAVDLTREKPAAILALRDRLDLVYRGTPRNAPADRAFAAIVEEFEMPRALPEALLEGLAWDAQGRRYRTIDDLHSYSARVAAAVGAMMCVLMRVRDADALARACDLGLAMQLTNIARDVGEDAREGRLFLPTDWMEGAGIDTQAFLADPQPTAPVCRVVRRLLAEADRLYFRSEAGIAALPLSVRPGIAAARHIYAAIGTRIACAGHDSITQRAYTGPGAKLWGLATAGVHVAVTLALPRPVELHALPEPSVAFLVNAAAHAPPARETWAQGRSAALLSVLSDLESRDRARRGLMGRATEPNCE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCACCGTCGCCACCGACGCCCCCCGCGCGGCCCCGGCCGTGCGCCGCACGGCCCTGTTGGCCGAGGACCTGGACCATTGCGAGGCCGCGATCCGCACCGGGTCGCGGTCCTTCTTCACCGCCTCCAAGCTGTTGCCGGGGCGGGTGCGGCGTCCGGCGCTGGCGCTTTATGCCTTCTGCCGGCTGTCGGACGATGCGGTCGACCTGACGCGCGAGAAGCCCGCCGCGATCCTGGCGCTGCGTGACCGGCTGGACCTGGTGTATCGCGGCACGCCGCGCAATGCCCCTGCCGACCGGGCCTTCGCCGCCATCGTGGAGGAGTTCGAGATGCCGCGCGCCCTGCCGGAGGCCCTGCTGGAGGGGCTGGCGTGGGACGCGCAGGGGCGGCGCTACCGCACCATCGACGATCTGCACAGCTACTCCGCGCGGGTGGCGGCGGCGGTGGGGGCGATGATGTGCGTGCTGATGCGGGTGCGCGATGCCGATGCGCTGGCGCGGGCCTGCGATCTGGGGCTGGCGATGCAGCTGACCAACATCGCCCGCGACGTCGGCGAGGATGCGCGCGAGGGGCGGCTGTTCCTGCCCACCGACTGGATGGAGGGGGCGGGCATCGACACGCAGGCGTTCCTGGCCGATCCGCAGCCCACCGCCCCGGTATGCCGGGTGGTTCGGCGCCTTCTGGCCGAGGCCGACCGGCTGTATTTCCGCTCCGAGGCCGGGATCGCGGCGCTGCCGCTGTCGGTGCGCCCGGGAATTGCGGCGGCGCGTCACATCTATGCCGCCATCGGCACGCGGATCGCCTGTGCGGGCCACGACAGCATCACCCAGCGCGCCTATACCGGGCCGGGGGCCAAGCTGTGGGGGCTGGCCACGGCGGGGGTGCATGTCGCCGTCACCCTGGCGCTGCCGCGCCCGGTGGAGCTGCACGCCCTGCCCGAGCCGTCGGTGGCGTTTCTGGTGAATGCCGCGGCCCACGCACCGCCGGCGCGCGAAACCTGGGCACAGGGACGTTCGGCTGCGCTTTTGTCGGTGCTCTCGGACCTGGAATCGCGCGATCGCGCACGGCGGGGCTTGATGGGACGGGCGACAGAGCCTAACTGCGAGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 17418,
                "end": 18971,
                "strand": -1,
                "locus_tag": "KKHPANEM_02035",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02035</span></strong><br>\n \n  Phytoene desaturase (neurosporene-forming)<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02035</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtI_2</span><br>\n \n Location: 17,418 - 18,971,\n (total: 1554 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 410.1; E-value: 2.6e-124)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLNRMQDDVAVAADGARRPRALVIGAGLGGLAAAMRLGAKGYRVTVIDRLDRAGGRGSSITQDGHRFDLGPTIVTVPQLFRELWAACGRDFDADVDLRALDPFYQIRWPDGSHFTVRQSTEAMRAEVARLSPDDLPGYDKFLKDAEARYSFGFEDLGRRSMHKFIDLVKVLPKFAMLRADRSVAAHAAARVRDPRLRMALSFHPLFIGGDPFHVTSMYILVSHLEKEYGVHYAVGGVQAIADAMVRVIEDQGGTLRLDEEVDEVLVKSGRVAGLRTTQGEVMTADIVVSNADAGHTYTRLLRNHRRRRWTDAKLKRRTWSSGLFVWYFGTKGTKDMWPDLGHHTILNGPRYEGLLRDIFLNGKLSEDMSLYIHRPSVTDPGVAPAGDDTFYVLSVVPHLGFDNPVDWKAEGERYRAAMTRVLEEQVMPGFAERVGPSLVFTPEDFRDRYLSPHGAGFSIEPRILQSAYFRPHNVSEELPGLYLVGAGTHPGAGLPGVVSSAEVLGKLVPDAQPQGVA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=7418&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLNRMQDDVAVAADGARRPRALVIGAGLGGLAAAMRLGAKGYRVTVIDRLDRAGGRGSSITQDGHRFDLGPTIVTVPQLFRELWAACGRDFDADVDLRALDPFYQIRWPDGSHFTVRQSTEAMRAEVARLSPDDLPGYDKFLKDAEARYSFGFEDLGRRSMHKFIDLVKVLPKFAMLRADRSVAAHAAARVRDPRLRMALSFHPLFIGGDPFHVTSMYILVSHLEKEYGVHYAVGGVQAIADAMVRVIEDQGGTLRLDEEVDEVLVKSGRVAGLRTTQGEVMTADIVVSNADAGHTYTRLLRNHRRRRWTDAKLKRRTWSSGLFVWYFGTKGTKDMWPDLGHHTILNGPRYEGLLRDIFLNGKLSEDMSLYIHRPSVTDPGVAPAGDDTFYVLSVVPHLGFDNPVDWKAEGERYRAAMTRVLEEQVMPGFAERVGPSLVFTPEDFRDRYLSPHGAGFSIEPRILQSAYFRPHNVSEELPGLYLVGAGTHPGAGLPGVVSSAEVLGKLVPDAQPQGVA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCAACCGCATGCAGGACGACGTGGCCGTGGCCGCGGATGGGGCGCGACGGCCGCGGGCGCTGGTGATCGGCGCGGGTCTGGGTGGGCTGGCGGCGGCGATGCGGCTGGGGGCCAAGGGCTACCGGGTGACGGTGATCGACCGGCTGGACCGGGCGGGCGGGCGCGGGTCGTCGATCACGCAGGACGGGCACCGCTTCGATCTGGGCCCGACCATCGTCACCGTGCCGCAGTTGTTTCGCGAATTGTGGGCGGCGTGCGGGCGCGATTTCGATGCGGACGTGGATTTGCGCGCGCTCGATCCGTTCTATCAGATCCGCTGGCCCGACGGCTCGCACTTCACCGTGCGCCAGTCGACCGAGGCGATGCGGGCCGAGGTGGCGCGGCTGTCGCCCGATGACCTGCCCGGCTACGACAAGTTCCTCAAGGACGCCGAGGCGCGGTATTCCTTCGGCTTCGAGGATCTGGGCCGCCGGTCGATGCACAAGTTCATCGACCTGGTGAAGGTGCTGCCGAAGTTCGCCATGCTGCGCGCCGACCGGTCGGTGGCGGCGCACGCAGCAGCCCGGGTGCGCGACCCGCGCCTGCGCATGGCGCTGTCGTTCCACCCGCTGTTCATCGGCGGCGACCCGTTCCACGTCACCTCCATGTACATCCTCGTCAGCCACCTGGAGAAGGAATACGGCGTGCATTACGCGGTGGGCGGCGTGCAGGCCATCGCCGACGCCATGGTCCGCGTGATCGAGGACCAAGGCGGCACCCTTCGGCTGGACGAGGAGGTCGACGAGGTGCTGGTGAAATCGGGCCGGGTCGCCGGTCTGCGCACCACCCAGGGCGAGGTGATGACCGCCGACATCGTGGTGTCCAACGCGGACGCCGGCCACACCTATACCCGGCTTCTGCGCAACCACCGCCGCCGGCGCTGGACGGATGCCAAGCTGAAGCGGCGCACATGGTCGTCGGGGCTGTTCGTTTGGTACTTCGGGACCAAGGGGACGAAGGACATGTGGCCGGATCTGGGCCACCACACCATCCTCAACGGTCCCCGGTACGAAGGGTTGCTGCGCGACATCTTCCTCAACGGCAAGCTGTCGGAGGACATGAGCCTCTATATCCACCGCCCCTCGGTCACCGATCCGGGCGTGGCGCCTGCGGGCGACGACACCTTCTATGTGCTGTCGGTGGTGCCGCATCTGGGCTTCGACAACCCGGTGGACTGGAAGGCGGAGGGGGAGCGGTACCGCGCCGCCATGACCAGGGTGCTGGAGGAGCAGGTGATGCCGGGCTTTGCCGAGCGTGTGGGCCCGTCGCTGGTGTTCACGCCCGAGGATTTCCGCGACCGCTACCTGTCGCCCCACGGCGCGGGGTTCTCGATCGAGCCGCGGATCCTGCAATCGGCCTATTTCCGGCCGCACAACGTGTCCGAGGAGCTGCCGGGGCTGTATCTGGTGGGCGCGGGCACGCATCCCGGCGCGGGCCTGCCGGGGGTGGTGTCCTCGGCCGAGGTGCTGGGCAAGCTCGTTCCCGACGCGCAGCCGCAGGGGGTCGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 19098,
                "end": 19808,
                "strand": 1,
                "locus_tag": "KKHPANEM_02036",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02036</span></strong><br>\n \n  Spheroidene monooxygenase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02036</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtA</span><br>\n \n Location: 19,098 - 19,808,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=METVTLSLFRFPTLSARLWAFGQMALARWDLKRTPDLLQWKLCGSGTGEGFTPVPNTAVYAILATWPSEEIARERIAKSKVWARWRAHAAEDWTIFLAATSVRGKWAGVEPFHAVAEPTDGPLAALTRATVKPKVALKFWGSVPDISRMIGMDEHVAFKIGIGEVPLLHQVTFSIWPDTRTMAEFARHDGPHARAIKAVRDGQWFNEECYARFRILGECGSWDGTSPLKPLERSAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=9098&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"METVTLSLFRFPTLSARLWAFGQMALARWDLKRTPDLLQWKLCGSGTGEGFTPVPNTAVYAILATWPSEEIARERIAKSKVWARWRAHAAEDWTIFLAATSVRGKWAGVEPFHAVAEPTDGPLAALTRATVKPKVALKFWGSVPDISRMIGMDEHVAFKIGIGEVPLLHQVTFSIWPDTRTMAEFARHDGPHARAIKAVRDGQWFNEECYARFRILGECGSWDGTSPLKPLERSAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAGACCGTCACCCTCTCGCTGTTTCGCTTTCCCACCCTGTCCGCGCGGCTCTGGGCGTTCGGCCAGATGGCGCTGGCGCGCTGGGACCTCAAGCGCACCCCCGATCTGTTGCAGTGGAAGCTGTGCGGCTCGGGCACGGGCGAGGGGTTCACCCCGGTGCCCAACACCGCCGTCTATGCGATCCTCGCGACCTGGCCCTCCGAGGAGATCGCCCGGGAGCGCATCGCCAAATCGAAGGTCTGGGCCCGCTGGCGTGCGCATGCCGCCGAGGACTGGACGATCTTCCTCGCGGCGACATCGGTGCGGGGCAAATGGGCCGGGGTGGAGCCGTTCCACGCCGTGGCCGAGCCGACCGACGGCCCGCTGGCGGCGCTGACGCGTGCGACGGTGAAGCCCAAGGTCGCGCTGAAGTTCTGGGGTTCGGTCCCCGACATCTCCCGGATGATCGGCATGGACGAACATGTCGCCTTCAAGATCGGCATCGGCGAGGTGCCGCTGCTGCACCAGGTGACCTTCTCGATCTGGCCCGACACCAGGACGATGGCCGAGTTCGCCCGCCACGACGGCCCCCACGCCCGCGCCATCAAGGCCGTGCGCGACGGGCAATGGTTCAACGAAGAGTGCTATGCCCGCTTCCGCATCCTGGGCGAGTGTGGCAGTTGGGACGGAACAAGCCCGCTGAAACCGCTCGAGAGGTCCGCCGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 19805,
                "end": 20809,
                "strand": 1,
                "locus_tag": "KKHPANEM_02037",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02037</span></strong><br>\n \n  Magnesium-chelatase 38 kDa subunit<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02037</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">bchI</span><br>\n \n Location: 19,805 - 20,809,\n (total: 1005 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKAPFPFSAIVGQEEMKLAMVLTAIDPGIGGVLVFGDRGTGKSTAVRALAALLPPIRQVESCPVNSARLEDCPEWARLTSREIVTRPTPVVDLPLGATEDRVVGALDIERALSQGEKAFEPGLLARANRGYLYIDEVNLLEDHIVDLLLDVAQSGQNVVEREGLSIRHPARFVLVGSGNPEEGELRPQLLDRFGLSVEVGSPKDIPTRIEVIRRRDAYENDHAAFMAKWQEEDTTLRERILAARTRLSAIATPEAALHDCAELCVALGSDGLRGELTLLRTGRAFAAYHGADTLTRDHLREVAPMSLRHRLRRDPLDEAGSGARVGRVIEEVFG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273&amp;from=9805&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKAPFPFSAIVGQEEMKLAMVLTAIDPGIGGVLVFGDRGTGKSTAVRALAALLPPIRQVESCPVNSARLEDCPEWARLTSREIVTRPTPVVDLPLGATEDRVVGALDIERALSQGEKAFEPGLLARANRGYLYIDEVNLLEDHIVDLLLDVAQSGQNVVEREGLSIRHPARFVLVGSGNPEEGELRPQLLDRFGLSVEVGSPKDIPTRIEVIRRRDAYENDHAAFMAKWQEEDTTLRERILAARTRLSAIATPEAALHDCAELCVALGSDGLRGELTLLRTGRAFAAYHGADTLTRDHLREVAPMSLRHRLRRDPLDEAGSGARVGRVIEEVFG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGGCTCCGTTCCCGTTCTCCGCGATCGTCGGCCAGGAGGAGATGAAGCTCGCCATGGTCCTGACCGCCATCGACCCCGGCATCGGGGGCGTTCTGGTGTTCGGGGACCGCGGAACGGGGAAATCGACGGCGGTGCGGGCGCTTGCGGCACTGCTGCCGCCCATCCGGCAGGTCGAGAGCTGCCCCGTGAACTCCGCCCGGCTGGAGGACTGCCCCGAGTGGGCGCGGCTGACCTCACGGGAGATCGTCACCCGCCCCACGCCGGTGGTCGACCTGCCGCTGGGCGCGACCGAGGACCGGGTGGTCGGCGCGCTCGACATCGAACGCGCGCTCAGCCAGGGCGAAAAGGCGTTCGAGCCGGGCCTGCTGGCGCGCGCCAACCGCGGGTATCTCTACATCGACGAGGTCAACCTGCTGGAGGACCACATCGTCGACCTGCTGCTGGACGTCGCCCAATCCGGCCAGAACGTGGTGGAGCGCGAGGGCCTCTCGATCCGCCACCCCGCGCGCTTCGTCCTCGTCGGCTCCGGCAACCCCGAGGAAGGCGAGCTGCGTCCGCAGCTTCTCGATCGCTTCGGGCTGTCGGTGGAGGTTGGCTCTCCCAAGGACATCCCCACCCGGATCGAGGTCATCCGCCGCCGCGACGCCTATGAAAACGACCACGCCGCCTTCATGGCCAAATGGCAGGAGGAGGACACCACCCTGCGCGAGCGGATCCTGGCCGCGCGCACCCGGCTGTCGGCCATCGCCACCCCCGAGGCCGCGTTGCACGACTGCGCGGAGCTGTGCGTGGCGCTCGGCTCGGACGGGCTGCGCGGAGAGCTGACGCTGCTGCGCACCGGGCGCGCCTTCGCGGCCTATCACGGCGCCGACACGCTGACCCGCGACCACCTGCGCGAGGTCGCGCCGATGTCGCTGCGCCACCGCCTGCGCCGCGATCCGCTGGACGAGGCCGGGTCGGGCGCCCGCGTCGGCCGCGTGATCGAAGAGGTCTTCGGGTGA\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 16311,
                "end": 17421,
                "tool": "rule-based-clusters",
                "neighbouring_start": 6311,
                "neighbouring_end": 21589,
                "product": "terpene",
                "height": 2,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [
            {
                "start": 11896,
                "end": 11898,
                "strand": 1,
                "containedBy": [
                    "KKHPANEM_02029"
                ]
            }
        ],
        "type": "terpene",
        "products": [
            "terpene"
        ],
        "anchor": "r273c1"
    },
    "r287c1": {
        "start": 1296,
        "end": 12141,
        "idx": 1,
        "orfs": [
            {
                "start": 4568,
                "end": 5200,
                "strand": -1,
                "locus_tag": "KKHPANEM_02316",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02316</span></strong><br>\n \n  Anti-sigma-F factor NrsF<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02316</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">nrsF</span><br>\n \n Location: 4,568 - 5,200,\n (total: 633 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKTDDLLAALAADTRPGPGVAQRLSRALPGAMVVAAVVFALGWGVRQDLVAAMTSPAALKPLVPLALAGLAGTLALTLSRPEARGGRTATALWVFAVVLIAAFGAALAAGGLSGLMTDLFTPSLITCLASIPALALPLLAATLWALSAGAPRRPALTGALGGLAAGSLAASLYALYCDQDTALFVLPAYASAIGIVTLTGTVLGTRTLAW&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=15200\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKTDDLLAALAADTRPGPGVAQRLSRALPGAMVVAAVVFALGWGVRQDLVAAMTSPAALKPLVPLALAGLAGTLALTLSRPEARGGRTATALWVFAVVLIAAFGAALAAGGLSGLMTDLFTPSLITCLASIPALALPLLAATLWALSAGAPRRPALTGALGGLAAGSLAASLYALYCDQDTALFVLPAYASAIGIVTLTGTVLGTRTLAW\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGACCGACGACCTCCTCGCCGCACTCGCCGCCGACACCCGGCCGGGCCCGGGCGTCGCGCAACGGCTGTCGCGTGCACTGCCCGGGGCGATGGTCGTCGCGGCGGTCGTCTTCGCGCTGGGCTGGGGCGTGCGGCAGGACCTCGTGGCGGCAATGACCTCGCCCGCCGCGCTGAAACCGCTCGTGCCGCTCGCACTCGCCGGGCTTGCCGGCACGCTGGCCCTGACCCTGTCGCGGCCCGAGGCGCGGGGCGGTCGCACCGCCACCGCCCTTTGGGTCTTCGCCGTGGTCCTGATCGCAGCCTTCGGCGCCGCCCTCGCCGCGGGCGGCCTGTCCGGGCTGATGACCGACCTCTTCACCCCGAGCCTGATCACCTGCCTCGCCAGCATTCCCGCGCTGGCACTCCCTCTCCTCGCCGCCACCCTCTGGGCCCTCTCCGCCGGCGCCCCCCGCCGCCCGGCCCTGACTGGCGCGCTCGGCGGCCTCGCCGCCGGCAGCCTCGCCGCCTCCCTCTACGCGCTCTACTGCGACCAGGACACGGCGCTCTTCGTCCTCCCCGCCTACGCTTCCGCAATCGGGATCGTCACCCTGACCGGGACGGTACTCGGGACCCGCACACTGGCCTGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 5197,
                "end": 5709,
                "strand": -1,
                "locus_tag": "KKHPANEM_02317",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02317</span></strong><br>\n \n  ECF RNA polymerase sigma factor SigF<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02317</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">sigF</span><br>\n \n Location: 5,197 - 5,709,\n (total: 513 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily (Score: 86.9; E-value: 2e-26)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRAANRGDAAAYRELLQAITPVLRGVVRARGRMLGPEGCEDVLQEVLLAVHMKRQTWREDAPLRPWLYAIARHKTADAFRARGHRIDLPIEAFSEALPAQDIPDPTQAGDMEKVLARLDPRAADIVRGFGMRGETVAETAARLQMTEGAVRVALHRALKAVARLRERMME&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=15709\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRAANRGDAAAYRELLQAITPVLRGVVRARGRMLGPEGCEDVLQEVLLAVHMKRQTWREDAPLRPWLYAIARHKTADAFRARGHRIDLPIEAFSEALPAQDIPDPTQAGDMEKVLARLDPRAADIVRGFGMRGETVAETAARLQMTEGAVRVALHRALKAVARLRERMME\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGCGCGGCCAACCGCGGCGATGCCGCCGCCTATCGCGAGCTTCTGCAGGCGATCACGCCGGTGTTGCGGGGCGTGGTGCGCGCCCGCGGTCGCATGCTGGGGCCCGAGGGCTGCGAGGATGTGCTGCAGGAGGTTCTGCTGGCCGTTCACATGAAGCGCCAGACCTGGCGCGAGGACGCGCCCCTGCGCCCGTGGCTCTATGCCATCGCGCGGCACAAGACGGCCGACGCCTTCCGCGCCCGCGGCCACCGCATCGACCTGCCGATCGAGGCGTTTTCCGAGGCTCTGCCCGCGCAGGACATCCCCGACCCGACGCAGGCCGGCGACATGGAGAAGGTGCTGGCGCGGCTGGACCCGCGCGCGGCCGACATCGTCCGCGGCTTCGGGATGCGTGGCGAGACGGTTGCCGAAACCGCCGCCCGCCTCCAGATGACCGAGGGCGCGGTGCGCGTGGCACTGCACCGGGCGTTGAAGGCCGTCGCCCGGCTGCGCGAAAGGATGATGGAATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 5912,
                "end": 6223,
                "strand": 1,
                "locus_tag": "KKHPANEM_02318",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02318</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02318</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,912 - 6,223,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTTKHLALPLAASVAAALSLAGAQAHAQGATMEKCFGVSLAGQNDCAAGPGTTCSGTSTVDYQGNAWTLVPAGTCETIDLPAMADGTGRMGALEELDRDLPPA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=16223\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTTKHLALPLAASVAAALSLAGAQAHAQGATMEKCFGVSLAGQNDCAAGPGTTCSGTSTVDYQGNAWTLVPAGTCETIDLPAMADGTGRMGALEELDRDLPPA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCACCAAACACCTCGCCCTGCCGCTCGCCGCCTCTGTGGCCGCCGCCCTGTCGCTGGCCGGCGCGCAGGCCCACGCCCAGGGCGCCACCATGGAGAAGTGCTTCGGCGTCTCTCTCGCCGGGCAAAACGACTGCGCGGCGGGGCCGGGCACGACCTGCTCGGGCACCTCGACGGTGGATTACCAGGGCAACGCCTGGACGCTGGTGCCGGCCGGCACCTGCGAGACCATCGACCTGCCGGCGATGGCCGACGGCACCGGGCGCATGGGCGCGCTGGAGGAACTCGACCGCGACCTGCCGCCCGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 6296,
                "end": 7141,
                "strand": 1,
                "locus_tag": "KKHPANEM_02319",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02319</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02319</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,296 - 7,141,\n (total: 846 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RiPP-like: DUF692<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPSLPVTTGLGFKPEHFRDIAAAPGAVGFYEVHAENFMGDGGAPHAMLAHLHAGHALSIHGVGLSIGGAGPLDADHLARLRRLIDRHRPESFSEHLAWSSHGAAWLNDLLPLPYTTGTLATVCAHVDAVQQALGLRMLLENPATYVTFAASTWAETDFLAEVVRRTGCGLLLDVNNVFVSATNHRFDPRAYLAAFPLEAVGEIHLAGHDTEELPSGPLLIDSHGRAVADPVWSLYAEVLSRIGPRPTLIEWDSDVPPFAVLRAEADRARALLETRGRADAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=17141\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPSLPVTTGLGFKPEHFRDIAAAPGAVGFYEVHAENFMGDGGAPHAMLAHLHAGHALSIHGVGLSIGGAGPLDADHLARLRRLIDRHRPESFSEHLAWSSHGAAWLNDLLPLPYTTGTLATVCAHVDAVQQALGLRMLLENPATYVTFAASTWAETDFLAEVVRRTGCGLLLDVNNVFVSATNHRFDPRAYLAAFPLEAVGEIHLAGHDTEELPSGPLLIDSHGRAVADPVWSLYAEVLSRIGPRPTLIEWDSDVPPFAVLRAEADRARALLETRGRADAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGTCGTTGCCCGTCACCACCGGACTGGGATTCAAGCCCGAGCATTTCCGCGACATCGCCGCCGCCCCCGGCGCGGTCGGTTTCTACGAGGTCCATGCCGAGAACTTCATGGGCGATGGCGGGGCACCGCACGCGATGCTGGCGCATCTGCATGCGGGGCACGCGCTGTCGATCCATGGCGTCGGGCTGTCGATCGGCGGCGCGGGGCCCCTCGATGCCGATCACCTGGCCCGTCTGCGGCGTCTGATCGACCGTCACCGGCCCGAGAGTTTCTCGGAGCACCTGGCGTGGTCCAGCCACGGCGCGGCCTGGCTCAACGACCTGCTGCCGCTGCCCTACACCACCGGGACGCTGGCGACCGTCTGCGCCCATGTCGACGCGGTGCAGCAGGCGCTGGGGCTGCGGATGCTGCTGGAGAACCCCGCGACCTATGTGACCTTTGCCGCCTCCACCTGGGCCGAGACCGACTTCCTGGCCGAGGTGGTCCGCCGCACCGGCTGCGGGCTGCTGCTGGACGTGAACAACGTCTTCGTCTCGGCCACCAACCACCGCTTCGACCCCCGCGCCTATCTCGCGGCCTTTCCGCTGGAGGCGGTGGGCGAGATCCATCTCGCCGGTCACGACACCGAGGAGCTGCCCTCGGGGCCGCTGCTGATCGACAGCCACGGGCGGGCGGTGGCCGATCCGGTCTGGAGCCTCTATGCCGAGGTGCTGTCCCGCATCGGCCCGCGCCCCACGCTGATCGAATGGGACAGCGATGTGCCGCCCTTCGCGGTGCTGCGGGCCGAAGCCGACCGGGCGCGCGCCCTGCTGGAAACGCGAGGCCGGGCCGATGCCGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 7131,
                "end": 7880,
                "strand": 1,
                "locus_tag": "KKHPANEM_02320",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02320</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02320</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,131 - 7,880,\n (total: 750 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPPDSAHAATQAGFHAALWRPDPPQGLTAPAPDEVSRRFAVYRNNVHHSLSRALAAHFPVVAALVGPAFLTAMARVFIAEAPPASPVLQDWGAAFPGFLDRFPPVAHLPWLGDVARLEWARGRAVHAADAPAASADLLGVPDPEVLRLRLHASVALYRSDHPAVSIWRAHQPGAARGPLPPGPEHALVGRQPDFTVVVAPVDVGTHAVLSALARGETLARAAEHADPTIALTLLLRHGLITAPLTGDTP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=17880\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPPDSAHAATQAGFHAALWRPDPPQGLTAPAPDEVSRRFAVYRNNVHHSLSRALAAHFPVVAALVGPAFLTAMARVFIAEAPPASPVLQDWGAAFPGFLDRFPPVAHLPWLGDVARLEWARGRAVHAADAPAASADLLGVPDPEVLRLRLHASVALYRSDHPAVSIWRAHQPGAARGPLPPGPEHALVGRQPDFTVVVAPVDVGTHAVLSALARGETLARAAEHADPTIALTLLLRHGLITAPLTGDTP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGCCTGATTCCGCCCACGCCGCCACGCAGGCCGGTTTCCACGCCGCGCTCTGGCGTCCCGATCCGCCCCAGGGGCTGACCGCCCCGGCGCCGGACGAGGTGTCCCGCCGTTTTGCCGTCTATCGCAACAACGTCCACCACAGCCTGTCCCGGGCGCTGGCCGCACATTTTCCGGTGGTCGCGGCGCTGGTGGGGCCTGCGTTCCTGACCGCCATGGCCCGCGTCTTCATCGCCGAGGCGCCGCCCGCAAGCCCCGTTCTGCAGGACTGGGGCGCGGCCTTTCCCGGCTTCCTCGACCGCTTTCCCCCGGTCGCGCATCTGCCCTGGCTGGGGGATGTCGCCCGGCTGGAATGGGCCCGCGGCCGGGCGGTCCATGCCGCCGACGCTCCGGCCGCATCTGCCGACCTCCTCGGCGTTCCCGACCCCGAAGTGCTGCGGCTCCGCCTTCACGCCTCGGTGGCGCTCTACCGCTCGGACCACCCGGCGGTGTCGATCTGGCGGGCTCATCAGCCCGGCGCCGCCCGCGGCCCGCTGCCGCCGGGGCCCGAGCATGCCCTGGTCGGCCGGCAACCCGACTTCACCGTCGTGGTGGCGCCGGTCGATGTCGGCACGCATGCGGTGCTGAGCGCGCTGGCCCGGGGCGAGACCCTCGCCCGCGCCGCAGAACATGCCGATCCCACAATCGCCCTGACACTGCTGCTGCGCCACGGGCTGATCACTGCCCCCCTGACCGGAGACACGCCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 7877,
                "end": 8368,
                "strand": 1,
                "locus_tag": "KKHPANEM_02321",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02321</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02321</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,877 - 8,368,\n (total: 492 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSQVTETTPRPGTAARARQLGRRLNTLGGLVPHDLIALAARVFPAMVFWQSARTKVEGFSIKEQTFFLFEHVYALPLIPPAWAAVLATIAEHILPVLLVLGLMSRLSALGLLIMTAVIQIFVFPGAWVTHGLWAVALLVVVAQGPGRLSLDHLFGLDRGRRQP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=18368\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSQVTETTPRPGTAARARQLGRRLNTLGGLVPHDLIALAARVFPAMVFWQSARTKVEGFSIKEQTFFLFEHVYALPLIPPAWAAVLATIAEHILPVLLVLGLMSRLSALGLLIMTAVIQIFVFPGAWVTHGLWAVALLVVVAQGPGRLSLDHLFGLDRGRRQP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCCAGGTGACCGAAACCACCCCACGCCCGGGCACCGCCGCCCGCGCGCGACAGCTGGGCCGACGCCTCAACACCCTCGGCGGGCTGGTCCCCCATGATCTGATCGCACTTGCCGCGCGGGTCTTCCCGGCCATGGTCTTCTGGCAGTCCGCCCGCACCAAGGTCGAGGGTTTCTCGATCAAGGAGCAGACCTTCTTCCTGTTCGAGCATGTCTATGCCCTGCCACTCATCCCGCCCGCCTGGGCCGCCGTGCTTGCCACCATCGCCGAGCACATCCTGCCGGTGCTGCTGGTCCTCGGCCTGATGTCCCGCCTTTCGGCGCTGGGCCTGCTGATCATGACCGCCGTGATCCAGATCTTCGTCTTTCCTGGCGCCTGGGTCACCCATGGTCTCTGGGCCGTCGCACTCCTCGTGGTCGTGGCCCAAGGCCCCGGCCGCCTCTCCCTCGACCATCTTTTCGGCCTCGACCGGGGCAGGCGGCAGCCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 8540,
                "end": 10465,
                "strand": -1,
                "locus_tag": "KKHPANEM_02322",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02322</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02322</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,540 - 10,465,\n (total: 1926 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSRSLRLGLRSALVALPLSLVVGGGAAAQDLSDFGVVAGQSLTNTGPTIITGDIAVSPGTSYTGSGSVVHTGTAYLGDAVAARIQDDLTTLYLALAGRSTSTFGDLTGQDLGGRTLAPGVYNFDTSAMISAGRTLTLDAGGDPNAVFIFNVGSTLTAESGAAMVLENGAQGGNVFFRVGSSATLDTSSALVGQIVALTSISMNDTAGLGCGAAYARNGSVTLINNTIGVCVLAAPGIGDVVDVADLTEPELAVVEALGALVAAGGQIPIAFAILAATQTPEELALSLAQLPGQVATGVAPMGLQSMDDFLDAVVGSGRRPRVAAVSPRDPGVPIGMVRADSIYTGKHGPATAPLSFSTSLAVQPGQWDVWASAYGSRAVIDGNARRGWQKLTSENRGLALGLNHAVSPNTEIGIALSLNDADFELGNGFGSGTAETVMVAVRARTSMDAWYVEGALAHGRSDITTERVVTIAGVDRLVGETDATNTAAHLEAGYHMGPITPFAGLRAQSFTMDPYSETAASGTSSYALRYGKHTTTSLRSELGLDMAWSGNNDMGGTTGLGLRIAWARELASNDPGGRSFVTIPGATFRTTGAAANRDSVLVAATASVTASNGFHVGASINAQYSGRARDVGGSIVIGHRW&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=0&amp;to=20465\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSRSLRLGLRSALVALPLSLVVGGGAAAQDLSDFGVVAGQSLTNTGPTIITGDIAVSPGTSYTGSGSVVHTGTAYLGDAVAARIQDDLTTLYLALAGRSTSTFGDLTGQDLGGRTLAPGVYNFDTSAMISAGRTLTLDAGGDPNAVFIFNVGSTLTAESGAAMVLENGAQGGNVFFRVGSSATLDTSSALVGQIVALTSISMNDTAGLGCGAAYARNGSVTLINNTIGVCVLAAPGIGDVVDVADLTEPELAVVEALGALVAAGGQIPIAFAILAATQTPEELALSLAQLPGQVATGVAPMGLQSMDDFLDAVVGSGRRPRVAAVSPRDPGVPIGMVRADSIYTGKHGPATAPLSFSTSLAVQPGQWDVWASAYGSRAVIDGNARRGWQKLTSENRGLALGLNHAVSPNTEIGIALSLNDADFELGNGFGSGTAETVMVAVRARTSMDAWYVEGALAHGRSDITTERVVTIAGVDRLVGETDATNTAAHLEAGYHMGPITPFAGLRAQSFTMDPYSETAASGTSSYALRYGKHTTTSLRSELGLDMAWSGNNDMGGTTGLGLRIAWARELASNDPGGRSFVTIPGATFRTTGAAANRDSVLVAATASVTASNGFHVGASINAQYSGRARDVGGSIVIGHRW\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCCGATCCCTTCGCCTCGGCCTGCGTTCGGCCCTCGTCGCGCTCCCGCTGAGCCTCGTCGTGGGCGGCGGCGCCGCCGCGCAGGATCTGAGCGATTTCGGCGTCGTGGCCGGCCAGTCGCTGACCAACACCGGGCCCACGATCATCACCGGGGACATCGCGGTCAGCCCGGGCACGTCCTACACCGGGTCGGGCAGCGTGGTGCACACGGGCACCGCGTATCTCGGCGATGCGGTGGCGGCACGGATCCAGGACGATCTGACGACGCTGTATCTGGCGCTGGCCGGGCGCAGCACGTCGACCTTTGGCGATCTGACGGGGCAGGATCTGGGCGGCCGGACGCTTGCGCCGGGGGTCTACAACTTCGACACCTCGGCGATGATCTCGGCGGGCCGGACGCTGACGCTGGATGCGGGGGGCGATCCCAACGCCGTCTTCATCTTCAACGTCGGATCGACGCTGACGGCCGAAAGCGGCGCGGCGATGGTGCTCGAGAACGGCGCGCAGGGCGGCAACGTGTTCTTCCGGGTTGGCAGTTCGGCGACGCTGGATACCTCCTCGGCGCTGGTGGGGCAGATCGTGGCGCTGACGAGCATCTCGATGAACGACACCGCCGGGCTGGGCTGCGGCGCCGCTTATGCCCGCAACGGGTCGGTGACGCTGATCAACAACACCATCGGGGTCTGCGTCCTCGCGGCGCCCGGCATCGGGGATGTGGTGGACGTCGCCGACCTGACGGAGCCGGAGCTGGCCGTGGTCGAGGCGCTGGGCGCGCTCGTGGCCGCCGGCGGCCAGATCCCCATCGCATTCGCCATCCTCGCGGCCACCCAGACGCCCGAGGAGCTTGCGCTGAGCCTTGCGCAACTGCCTGGGCAGGTCGCGACCGGCGTGGCGCCGATGGGCCTGCAATCGATGGACGATTTTCTGGACGCGGTCGTGGGTTCGGGGCGCAGGCCGCGCGTGGCCGCCGTGTCGCCGCGCGATCCGGGGGTTCCGATCGGCATGGTCCGGGCCGACAGCATCTACACCGGCAAGCATGGCCCGGCGACGGCCCCGCTGTCGTTTTCAACCTCCCTCGCCGTGCAGCCCGGCCAGTGGGATGTCTGGGCGTCGGCCTATGGCTCGCGCGCCGTGATCGACGGGAACGCGCGCCGCGGCTGGCAGAAGCTGACCTCGGAGAACAGGGGCCTTGCCCTGGGGCTGAACCACGCGGTCAGCCCCAACACGGAGATCGGCATCGCCCTGTCGTTGAATGACGCGGATTTCGAGCTGGGCAACGGCTTCGGCTCCGGCACCGCCGAGACGGTCATGGTGGCGGTTCGGGCGCGGACCTCGATGGACGCCTGGTATGTGGAGGGCGCGCTTGCCCACGGGCGCAGCGACATCACGACCGAGCGGGTGGTGACGATTGCCGGCGTGGACCGCCTCGTGGGCGAAACCGACGCCACCAACACCGCCGCGCATCTGGAGGCGGGCTACCACATGGGCCCGATCACGCCATTTGCGGGGCTGCGCGCGCAGTCCTTCACCATGGACCCGTATTCCGAGACCGCGGCCTCGGGCACCTCCAGCTATGCGCTGCGCTACGGGAAACACACCACCACCTCGCTGCGCAGCGAGCTGGGGCTGGACATGGCCTGGTCCGGCAACAACGACATGGGCGGGACGACCGGCCTCGGGCTGCGGATCGCCTGGGCGCGTGAACTCGCCTCGAACGATCCGGGCGGGCGGTCCTTCGTGACCATTCCCGGCGCGACCTTCCGGACCACGGGGGCGGCGGCGAACCGGGACTCCGTGCTTGTGGCCGCGACGGCGTCGGTGACGGCGTCCAACGGCTTCCATGTCGGCGCCTCGATCAATGCGCAGTATTCGGGCCGCGCCCGCGACGTGGGCGGATCGATCGTGATCGGCCACCGCTGGTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 10603,
                "end": 10821,
                "strand": 1,
                "locus_tag": "KKHPANEM_02323",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02323</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02323</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,603 - 10,821,\n (total: 219 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSALRGSAVPQIGGTQVLKRTRCDWIDRRERVIGLGPSGTGKTQVDLMPFATGPEPMAPRWLTRQIGLMLLP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=603&amp;to=20821\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSALRGSAVPQIGGTQVLKRTRCDWIDRRERVIGLGPSGTGKTQVDLMPFATGPEPMAPRWLTRQIGLMLLP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAGTGCCCTGCGGGGGAGTGCGGTCCCGCAGATCGGCGGGACGCAGGTGCTCAAACGCACCCGCTGCGACTGGATCGACCGGCGCGAGCGCGTCATCGGCCTTGGCCCCAGCGGCACCGGCAAGACCCAAGTGGACCTGATGCCGTTCGCCACCGGGCCCGAACCGATGGCGCCGCGATGGCTTACCCGGCAGATCGGCTTGATGCTCCTGCCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 11226,
                "end": 11480,
                "strand": 1,
                "locus_tag": "KKHPANEM_02324",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02324</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02324</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,226 - 11,480,\n (total: 255 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPRRITSAILVGHLWLALACLPVAADDFPRLVPLETLLPSPTAPEAAAPLGVRAAMLERRAAALRARVLIDADTRRRMAALAAR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000287&amp;from=1226&amp;to=21480\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPRRITSAILVGHLWLALACLPVAADDFPRLVPLETLLPSPTAPEAAAPLGVRAAMLERRAAALRARVLIDADTRRRMAALAAR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGCGCCGCATCACATCTGCGATCCTCGTGGGACATCTGTGGCTTGCGCTGGCCTGCCTGCCTGTGGCGGCCGACGACTTTCCGCGCCTCGTCCCGCTGGAGACGCTGCTGCCGTCGCCCACGGCCCCCGAGGCGGCGGCCCCCCTCGGGGTGCGAGCGGCCATGCTGGAACGCCGGGCGGCGGCCCTGCGCGCGCGGGTCCTGATTGATGCCGATACCCGCCGCCGCATGGCGGCCCTTGCGGCCCGCTGA\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 6295,
                "end": 7141,
                "tool": "rule-based-clusters",
                "neighbouring_start": 1295,
                "neighbouring_end": 12141,
                "product": "RiPP-like",
                "height": 2,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [],
        "type": "RiPP-like",
        "products": [
            "RiPP-like"
        ],
        "anchor": "r287c1"
    },
    "r292c1": {
        "start": 11262,
        "end": 36052,
        "idx": 1,
        "orfs": [
            {
                "start": 14088,
                "end": 15638,
                "strand": 1,
                "locus_tag": "KKHPANEM_02420",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02420</span></strong><br>\n \n  Dihydrolipoyllysine-residue succinyltransferase component of 2-oxoglutarate dehydrogenase complex<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02420</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">sucB</span><br>\n \n Location: 14,088 - 15,638,\n (total: 1551 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSIEVRVPTLGESVTEATVATWFKKPGETVAADEMLCELETDKVTVEVPSPAAGTLGEIVAAEGDTVGVDALLATLTESDGKPAPARGGAPKAAAPAAPAGDTVDVMVPALGESVSEATVATWFKAVGDSVAADEILCELETDKVSVEVPSPTAGTLSQIVAEAGTTVAAGGKLAVLAAGEGGAAATGTGAAAAPAPPTAAAAERSGAGRADVEDAPSAKKMMAEKGLTRDQVEGTGRDGRIMKEDVARAAADAAPAAQAAPAPTMPAPAAQQAPRAAVPADDAAREERVKMSRLRQTIARRLKDAQNTAAMLTTYNEVDMGPIMDLRNEYKGLFEKKHGVKLGFMSFFVKACCHALHEVPEVNAEIDGTDVVYKNYVHMGVAVGTPSGLVVPVLRDAQAMGFAEIEKTIASLGARARDGKLSMADMQGGSFTISNGGVYGSLMSSPILNPPQSGILGMHKIQDRPMVVKGQIVARPMMYLALSYDHRIVDGKGAVTFLVRVKEALEDPRRLLMDL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=4088&amp;to=25638\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSIEVRVPTLGESVTEATVATWFKKPGETVAADEMLCELETDKVTVEVPSPAAGTLGEIVAAEGDTVGVDALLATLTESDGKPAPARGGAPKAAAPAAPAGDTVDVMVPALGESVSEATVATWFKAVGDSVAADEILCELETDKVSVEVPSPTAGTLSQIVAEAGTTVAAGGKLAVLAAGEGGAAATGTGAAAAPAPPTAAAAERSGAGRADVEDAPSAKKMMAEKGLTRDQVEGTGRDGRIMKEDVARAAADAAPAAQAAPAPTMPAPAAQQAPRAAVPADDAAREERVKMSRLRQTIARRLKDAQNTAAMLTTYNEVDMGPIMDLRNEYKGLFEKKHGVKLGFMSFFVKACCHALHEVPEVNAEIDGTDVVYKNYVHMGVAVGTPSGLVVPVLRDAQAMGFAEIEKTIASLGARARDGKLSMADMQGGSFTISNGGVYGSLMSSPILNPPQSGILGMHKIQDRPMVVKGQIVARPMMYLALSYDHRIVDGKGAVTFLVRVKEALEDPRRLLMDL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCATCGAAGTCCGCGTGCCCACGTTGGGCGAATCCGTCACCGAGGCCACGGTGGCGACGTGGTTCAAGAAGCCCGGCGAGACGGTCGCCGCCGACGAAATGCTGTGCGAGCTGGAGACCGACAAGGTCACGGTGGAGGTGCCCAGCCCCGCCGCCGGCACGCTGGGCGAGATCGTCGCGGCCGAGGGCGACACGGTGGGGGTGGATGCGCTGCTGGCAACCCTGACCGAGAGCGACGGCAAACCCGCACCGGCCCGCGGCGGCGCGCCCAAGGCCGCCGCACCCGCGGCTCCGGCGGGTGACACCGTGGACGTCATGGTCCCCGCGCTGGGCGAAAGCGTCAGCGAGGCGACAGTCGCCACCTGGTTCAAGGCGGTGGGCGACAGCGTCGCCGCCGACGAGATCCTGTGCGAACTGGAGACCGACAAGGTCAGCGTCGAGGTCCCGAGCCCCACCGCCGGCACGCTGTCGCAGATCGTCGCCGAGGCCGGGACCACGGTGGCCGCGGGTGGCAAGCTTGCGGTCCTGGCGGCCGGTGAGGGCGGCGCCGCGGCCACGGGGACCGGCGCGGCCGCAGCCCCTGCCCCGCCCACCGCCGCTGCGGCCGAGCGCAGCGGCGCGGGCCGCGCGGATGTGGAAGACGCCCCTTCGGCGAAGAAGATGATGGCCGAGAAGGGGCTGACGCGCGATCAGGTCGAAGGCACCGGCCGTGACGGGCGGATCATGAAGGAGGACGTGGCGCGCGCCGCGGCGGACGCGGCCCCGGCGGCGCAGGCTGCGCCTGCCCCGACCATGCCCGCCCCCGCAGCCCAACAGGCACCGCGCGCCGCCGTCCCGGCCGACGATGCCGCCCGCGAAGAGCGGGTGAAGATGAGCCGCCTGCGCCAGACCATCGCGCGCAGGCTCAAGGATGCGCAGAACACCGCGGCCATGCTGACCACCTATAACGAGGTGGACATGGGCCCGATCATGGATCTGCGCAACGAATACAAGGGGTTGTTCGAAAAGAAGCACGGCGTGAAGCTTGGCTTCATGTCCTTCTTCGTCAAGGCCTGCTGCCACGCCCTGCACGAGGTGCCCGAGGTCAACGCCGAGATCGACGGCACCGATGTGGTCTACAAGAACTATGTCCACATGGGCGTGGCGGTGGGCACGCCGTCAGGGCTGGTGGTGCCGGTGCTGCGCGATGCGCAGGCCATGGGCTTTGCCGAGATCGAAAAGACCATCGCGTCCCTGGGCGCACGCGCGCGCGACGGCAAGCTGTCGATGGCCGACATGCAGGGCGGATCGTTCACCATCTCCAACGGCGGGGTGTATGGCTCGCTGATGTCGTCGCCGATCCTGAACCCGCCGCAGTCGGGGATCCTGGGGATGCACAAGATCCAGGATCGTCCGATGGTGGTGAAGGGTCAGATCGTGGCGCGCCCCATGATGTACCTCGCGCTGAGCTATGACCACCGGATCGTGGACGGCAAGGGCGCGGTGACGTTCCTTGTCCGCGTCAAGGAGGCGCTGGAGGACCCGCGGCGCCTGTTGATGGACCTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 15638,
                "end": 15925,
                "strand": 1,
                "locus_tag": "KKHPANEM_02421",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02421</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02421</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,638 - 15,925,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLGILFLVAVALVALVVVQSVRQGRRFIRAALFLHELEGGRPKDSANAAANLLFSPESSASADAHAAQIADARRKRTSETQAQVIGAARDRGFEG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=5638&amp;to=25925\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLGILFLVAVALVALVVVQSVRQGRRFIRAALFLHELEGGRPKDSANAAANLLFSPESSASADAHAAQIADARRKRTSETQAQVIGAARDRGFEG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTGGGGATCCTGTTTCTGGTCGCGGTGGCGCTGGTGGCGCTGGTGGTGGTGCAAAGCGTGCGCCAGGGCCGGCGCTTCATCCGCGCCGCGCTGTTCCTGCACGAGCTGGAGGGCGGGCGCCCGAAGGACTCCGCCAACGCCGCAGCCAACCTGTTGTTCAGCCCGGAAAGCTCGGCCTCGGCCGATGCGCATGCCGCCCAGATCGCGGACGCGCGGCGCAAGCGCACCTCCGAGACGCAGGCGCAGGTGATCGGCGCCGCGCGCGACCGCGGGTTCGAGGGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 15930,
                "end": 16337,
                "strand": 1,
                "locus_tag": "KKHPANEM_02422",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02422</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02422</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,930 - 16,337,\n (total: 408 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTGIMTTELTVLVLAALLAVVQLGWNAVRANLEMGPDWFLTPRDSAPPQPLPVALGRLKRAYENHMETLPLFAIAAIVVTLAGASSGLTAACAWIYLAARVLFVPAYRFGWMPWRSFIWAAGFVATVLMLLAALI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=5930&amp;to=26337\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTGIMTTELTVLVLAALLAVVQLGWNAVRANLEMGPDWFLTPRDSAPPQPLPVALGRLKRAYENHMETLPLFAIAAIVVTLAGASSGLTAACAWIYLAARVLFVPAYRFGWMPWRSFIWAAGFVATVLMLLAALI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACAGGGATCATGACGACGGAGCTGACGGTTCTGGTGCTGGCCGCCCTTCTGGCGGTGGTTCAGCTGGGCTGGAACGCGGTGCGCGCCAACCTGGAGATGGGGCCGGACTGGTTCCTCACGCCACGCGACAGCGCCCCGCCGCAGCCGCTGCCGGTTGCGCTGGGTCGGCTCAAGCGCGCCTATGAGAACCACATGGAGACGCTGCCGCTGTTTGCCATCGCGGCCATCGTGGTGACGCTGGCGGGCGCCTCGTCCGGCCTGACGGCGGCCTGCGCGTGGATCTACCTGGCCGCTCGGGTGCTGTTCGTGCCGGCCTACCGCTTCGGCTGGATGCCGTGGCGCTCGTTCATCTGGGCGGCGGGCTTCGTCGCCACCGTTCTGATGCTGCTGGCCGCGCTGATCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 16366,
                "end": 17754,
                "strand": 1,
                "locus_tag": "KKHPANEM_02423",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02423</span></strong><br>\n \n  Dihydrolipoyl dehydrogenase 3<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02423</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">lpd3</span><br>\n \n Location: 16,366 - 17,754,\n (total: 1389 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1175:pyridine nucleotide-disulfide oxidoreductase (Score: 476.3; E-value: 1.3e-144)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MASYDVIFIGSGPGGYVGAIRAAQLGLRTACVEGRETLGGTCLNVGCIPSKALLHATHMLHEAEHNFAEMGLGGGKPKVDWGKMQSYKDDVIAQNTKGIEFLFKKNKVDWIKGWASIPAPGKVKVGDDVHEARAIVIASGSESASLPGVEVDEKVVVTSTGALELGRIPKRLAVIGGGVIGLEMGSVYARLGAQVTVLEYLDRLIPGNDMEVARTFQRILKKQGMEFILGAAVQGVEATRTKAKVSYTLKKDDSAQTLEADVVLLATGRRPFTDGLGLDTLGVTLSKRRQVEVDGRYETSVKGVYAIGDAITGPMLAHKAEDEGYAVAEILAGQAGHVNYATIPGVIYTHPEVASVGETEETLKEAGRAYKVGKFSFMGNGRAKANFAADGFVKILADKDTDRILGAHIIGPMAGDLIHEICVAMEFGAAAEDLARTCHAHPTYSEAVREAALACGDGALHA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=6366&amp;to=27754\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MASYDVIFIGSGPGGYVGAIRAAQLGLRTACVEGRETLGGTCLNVGCIPSKALLHATHMLHEAEHNFAEMGLGGGKPKVDWGKMQSYKDDVIAQNTKGIEFLFKKNKVDWIKGWASIPAPGKVKVGDDVHEARAIVIASGSESASLPGVEVDEKVVVTSTGALELGRIPKRLAVIGGGVIGLEMGSVYARLGAQVTVLEYLDRLIPGNDMEVARTFQRILKKQGMEFILGAAVQGVEATRTKAKVSYTLKKDDSAQTLEADVVLLATGRRPFTDGLGLDTLGVTLSKRRQVEVDGRYETSVKGVYAIGDAITGPMLAHKAEDEGYAVAEILAGQAGHVNYATIPGVIYTHPEVASVGETEETLKEAGRAYKVGKFSFMGNGRAKANFAADGFVKILADKDTDRILGAHIIGPMAGDLIHEICVAMEFGAAAEDLARTCHAHPTYSEAVREAALACGDGALHA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCAAGCTATGACGTGATCTTCATCGGCTCCGGCCCCGGCGGCTATGTCGGCGCCATCCGCGCAGCCCAGCTGGGCCTGCGCACCGCCTGCGTGGAGGGGCGCGAGACGCTGGGCGGCACCTGCCTGAACGTGGGCTGCATCCCCTCCAAGGCGCTGCTGCACGCCACCCACATGCTGCACGAGGCCGAGCACAACTTCGCCGAGATGGGCCTTGGCGGCGGCAAGCCCAAGGTCGACTGGGGCAAGATGCAGTCCTACAAGGACGACGTCATCGCCCAGAACACCAAGGGGATCGAGTTCCTGTTCAAGAAGAACAAGGTGGACTGGATCAAGGGCTGGGCCTCCATCCCCGCGCCGGGCAAGGTGAAGGTCGGCGACGACGTGCACGAGGCCCGGGCCATCGTGATCGCCTCGGGCTCCGAATCCGCCTCCCTTCCGGGGGTGGAGGTCGACGAGAAGGTCGTGGTCACCTCCACCGGCGCGCTGGAGCTGGGCCGCATCCCCAAGCGGCTGGCGGTGATCGGCGGCGGCGTGATCGGGCTGGAGATGGGCTCGGTCTATGCCCGCCTGGGGGCGCAGGTGACGGTGCTGGAGTACCTCGACCGGCTGATCCCCGGCAACGACATGGAGGTCGCGCGGACCTTCCAGCGCATCCTGAAGAAGCAGGGGATGGAGTTCATCCTCGGCGCCGCCGTGCAGGGGGTGGAGGCCACCAGGACCAAGGCCAAGGTCAGCTACACCCTGAAGAAGGACGACAGCGCCCAGACGCTGGAGGCCGATGTGGTGCTGCTCGCCACCGGGCGTCGTCCCTTCACCGACGGGCTGGGGCTGGACACACTGGGCGTGACCCTGTCCAAGCGCAGACAGGTGGAGGTCGATGGCCGCTACGAGACCTCGGTCAAGGGCGTCTACGCCATCGGCGACGCCATCACCGGCCCGATGCTCGCGCACAAGGCCGAGGATGAGGGCTACGCCGTGGCCGAGATCCTCGCGGGCCAGGCGGGCCATGTGAACTACGCCACCATCCCCGGCGTGATCTACACCCACCCCGAGGTCGCGAGCGTGGGCGAGACCGAGGAGACGCTGAAGGAGGCCGGGCGCGCCTACAAGGTCGGCAAGTTCAGTTTCATGGGCAATGGCCGGGCCAAGGCCAACTTCGCCGCCGACGGCTTCGTCAAGATCCTGGCTGACAAGGACACCGACCGCATCCTGGGCGCCCACATCATCGGCCCGATGGCGGGCGACCTGATCCACGAGATCTGCGTCGCGATGGAGTTCGGCGCCGCGGCCGAGGATCTTGCCCGCACCTGCCATGCCCACCCCACCTACTCCGAAGCGGTGCGCGAGGCGGCGCTGGCCTGCGGCGACGGGGCGCTGCACGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 17981,
                "end": 19657,
                "strand": -1,
                "locus_tag": "KKHPANEM_02424",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02424</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02424</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,981 - 19,657,\n (total: 1677 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTDAPWQAPTPEELRALADATLAEAVALAEGLRALGPAVQVAAGLLAALVLAVVWAVLRARTRREALLRADLMARLADLEATTRRAEAAEANAAARADDLAALTARAEGLEGSLRAATVTERDLTARAAALDARLESAERRLAERRTEAEARESAIAGLRGRLEAEQAAQRALQARIAGLTQELESEQARGAEKVALLSSVREDMQARFRDLADAALKTQAEVFSNTSFARLEATLTPLKEHVGHFEKELRAVHTETARDRERLKAEIAALSKRSEEVSHEAMALTRALKGDRQRQGAWGEMILESILERCGLREGEEYETQAHRTDDEGARLRPDVVVRIPGDRTLVIDSKVSLNDYAAAVNAEDAAEAAGHRKRHVAALRAHITGLSAKGYQRAEDASVDYVIMFVPIEGALSEALREDGGLTGFALERHITIATPTTLMMALRTVAHVWAVERRNRNAEAIADRAGKLYDKLVGFLENMETVGKRLDQAQAAYGDALGQLSRGRGNLLSQVETLKTLGAKATKTIATEFEDTAPPGTLAADPETDPPKFDRKADR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=7981&amp;to=29657\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTDAPWQAPTPEELRALADATLAEAVALAEGLRALGPAVQVAAGLLAALVLAVVWAVLRARTRREALLRADLMARLADLEATTRRAEAAEANAAARADDLAALTARAEGLEGSLRAATVTERDLTARAAALDARLESAERRLAERRTEAEARESAIAGLRGRLEAEQAAQRALQARIAGLTQELESEQARGAEKVALLSSVREDMQARFRDLADAALKTQAEVFSNTSFARLEATLTPLKEHVGHFEKELRAVHTETARDRERLKAEIAALSKRSEEVSHEAMALTRALKGDRQRQGAWGEMILESILERCGLREGEEYETQAHRTDDEGARLRPDVVVRIPGDRTLVIDSKVSLNDYAAAVNAEDAAEAAGHRKRHVAALRAHITGLSAKGYQRAEDASVDYVIMFVPIEGALSEALREDGGLTGFALERHITIATPTTLMMALRTVAHVWAVERRNRNAEAIADRAGKLYDKLVGFLENMETVGKRLDQAQAAYGDALGQLSRGRGNLLSQVETLKTLGAKATKTIATEFEDTAPPGTLAADPETDPPKFDRKADR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCGACGCCCCCTGGCAGGCTCCCACCCCCGAGGAACTGCGCGCCCTGGCCGATGCCACCCTGGCCGAGGCGGTCGCGCTGGCGGAGGGGCTGCGCGCGCTGGGGCCAGCGGTGCAGGTCGCGGCGGGGCTGCTGGCCGCGCTGGTGCTGGCCGTGGTCTGGGCGGTGCTGCGCGCGCGGACCCGGCGCGAGGCGCTGCTGCGCGCCGACCTGATGGCGCGGCTGGCCGATCTGGAGGCCACCACCCGCCGGGCCGAGGCCGCCGAGGCCAACGCCGCCGCGCGCGCCGATGACCTTGCGGCGCTCACGGCCCGGGCGGAGGGGCTGGAGGGCAGCTTGCGGGCTGCCACCGTGACCGAGCGGGACCTGACCGCGCGCGCCGCCGCCCTCGATGCCCGGCTCGAGAGTGCCGAGCGCCGCCTGGCCGAGCGGCGCACCGAGGCCGAGGCGCGCGAGTCCGCCATCGCCGGGCTGCGCGGTCGGCTGGAGGCCGAGCAGGCCGCGCAGCGCGCGTTGCAGGCCCGCATCGCCGGGCTGACCCAGGAGCTGGAGAGCGAACAGGCCCGTGGCGCCGAAAAGGTGGCGCTGCTGTCGTCGGTGCGCGAGGACATGCAGGCGCGTTTCCGCGACCTCGCCGATGCCGCGCTGAAGACCCAGGCGGAGGTGTTCTCCAACACCAGCTTTGCCCGGCTGGAGGCGACGCTGACGCCGCTGAAGGAACATGTCGGCCATTTCGAGAAGGAACTGCGCGCCGTCCACACCGAGACCGCGCGGGACCGCGAGCGCCTGAAGGCCGAGATCGCCGCGCTGTCGAAACGCTCCGAGGAGGTCTCGCACGAGGCGATGGCGCTGACGCGCGCGCTCAAGGGCGACCGGCAGCGGCAGGGCGCCTGGGGGGAGATGATCCTCGAGAGCATCCTCGAACGCTGCGGCCTGCGCGAGGGCGAGGAGTACGAGACCCAGGCCCACCGCACCGACGACGAGGGCGCCCGCCTGCGCCCCGACGTGGTGGTGCGCATCCCCGGCGACCGCACGCTGGTGATCGATTCCAAGGTCTCGCTGAACGACTATGCCGCCGCCGTGAACGCCGAGGACGCGGCCGAGGCCGCCGGCCACCGCAAGCGCCATGTTGCGGCCCTGCGCGCCCACATCACCGGACTGTCGGCCAAGGGCTATCAGCGCGCCGAGGACGCCTCGGTCGACTATGTCATCATGTTCGTGCCCATCGAGGGCGCGCTGTCGGAGGCGCTGCGCGAGGACGGCGGGCTGACCGGCTTTGCGCTGGAGCGCCACATCACCATCGCCACGCCCACCACGCTGATGATGGCGCTGCGCACGGTGGCCCATGTCTGGGCCGTGGAGCGGCGCAACCGCAACGCCGAGGCGATCGCGGACCGGGCCGGCAAGCTCTATGACAAGCTGGTGGGATTTCTGGAAAACATGGAGACGGTGGGCAAGCGCCTCGACCAGGCGCAGGCGGCCTATGGCGACGCGCTGGGGCAGCTGTCGCGCGGGCGCGGCAACCTGCTGTCGCAGGTGGAGACCCTCAAGACGCTGGGCGCCAAGGCCACCAAGACCATCGCCACCGAGTTCGAGGACACCGCCCCCCCGGGCACCCTCGCCGCGGACCCCGAAACCGATCCCCCGAAGTTCGACAGGAAAGCCGACAGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 19848,
                "end": 20525,
                "strand": -1,
                "locus_tag": "KKHPANEM_02425",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02425</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02425</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,848 - 20,525,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIAHGHYATLVFDCDGVVLDSNRLKTEAFRRAALPWGEAAADALVAYHIAHGGVSRYVKFRHFLDALVPEHAPGGCGPGLEGLLDAYAGAVRDGLMTCGVAPGLAELRAATPGVRWLIVSGGDQAELREVFAARGLDRHFDGGIFGSPDTKAAILARELAAGNIRRPALFLGDSRLDFEAAAGAGLDFTFVSGWSEVADWRGFVAEHRLACVAGLSDLLGGAGPA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=9848&amp;to=30525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIAHGHYATLVFDCDGVVLDSNRLKTEAFRRAALPWGEAAADALVAYHIAHGGVSRYVKFRHFLDALVPEHAPGGCGPGLEGLLDAYAGAVRDGLMTCGVAPGLAELRAATPGVRWLIVSGGDQAELREVFAARGLDRHFDGGIFGSPDTKAAILARELAAGNIRRPALFLGDSRLDFEAAAGAGLDFTFVSGWSEVADWRGFVAEHRLACVAGLSDLLGGAGPA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"TTGATTGCGCATGGCCACTACGCGACCCTCGTCTTCGATTGCGACGGCGTCGTCCTCGACTCCAATCGGCTGAAGACGGAGGCATTCCGGCGCGCGGCGCTGCCGTGGGGGGAAGCGGCGGCTGATGCGCTGGTGGCGTATCATATCGCGCACGGAGGGGTGTCGCGGTATGTCAAGTTCCGGCATTTCCTCGATGCGCTGGTGCCAGAGCATGCGCCCGGCGGCTGCGGGCCGGGGCTGGAGGGGTTGCTTGACGCATATGCCGGGGCGGTGCGCGACGGGTTGATGACCTGCGGTGTGGCGCCGGGGCTGGCAGAGCTGCGGGCGGCGACGCCGGGGGTGCGTTGGCTGATCGTGTCGGGCGGCGACCAGGCGGAGCTGCGCGAGGTGTTTGCGGCGCGGGGTCTGGACCGGCACTTCGACGGCGGGATCTTCGGCAGCCCGGACACCAAGGCGGCGATCCTCGCCCGTGAGCTTGCGGCGGGCAACATCCGCCGCCCGGCGCTGTTTCTTGGCGACAGTCGGCTGGACTTTGAGGCGGCGGCCGGTGCCGGGCTGGATTTTACCTTCGTCTCGGGCTGGTCCGAGGTGGCGGACTGGCGCGGCTTTGTTGCCGAACACCGGCTGGCCTGCGTGGCGGGGCTGTCGGATCTGTTGGGCGGGGCAGGTCCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 20522,
                "end": 21175,
                "strand": -1,
                "locus_tag": "KKHPANEM_02426",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02426</span></strong><br>\n \n  3-deoxy-manno-octulosonate cytidylyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02426</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">kpsU</span><br>\n \n Location: 20,522 - 21,175,\n (total: 654 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MILWVAELSARAVGQDHVYVATEDERIAEVVRASGFAALMTSASALTGTDRVAEAAQKIDYDIYVNVQGDEPIVDPADIRRCIAIKSNNLEKVVNGYCWVGSDEDPASVNIPKVITNESDDLVYMSRVALPGFKDATNAPDRFKKQVCIYGFTRQELMEYAAFGRKSYLEKCEDIEILRFLEIERKVLMFQCKPGSLAVDVPADVSPVEALLRERLS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=10522&amp;to=31175\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MILWVAELSARAVGQDHVYVATEDERIAEVVRASGFAALMTSASALTGTDRVAEAAQKIDYDIYVNVQGDEPIVDPADIRRCIAIKSNNLEKVVNGYCWVGSDEDPASVNIPKVITNESDDLVYMSRVALPGFKDATNAPDRFKKQVCIYGFTRQELMEYAAFGRKSYLEKCEDIEILRFLEIERKVLMFQCKPGSLAVDVPADVSPVEALLRERLS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCCTGTGGGTTGCCGAACTCTCGGCAAGAGCTGTCGGGCAGGATCATGTCTATGTTGCCACGGAGGATGAGCGGATCGCTGAGGTGGTGCGCGCATCCGGATTCGCTGCGCTGATGACAAGTGCATCCGCCCTGACCGGCACGGACCGTGTTGCCGAAGCCGCACAGAAGATCGATTATGACATCTATGTCAATGTGCAGGGCGACGAGCCGATTGTGGATCCTGCGGACATCCGACGCTGTATTGCGATAAAGTCGAACAACCTTGAGAAGGTTGTGAACGGATACTGCTGGGTTGGCTCTGATGAAGACCCGGCGTCCGTGAATATTCCGAAAGTCATCACCAACGAGTCGGACGATCTGGTTTACATGTCGCGCGTGGCTTTGCCGGGGTTCAAGGATGCGACGAATGCGCCGGACAGGTTCAAGAAGCAGGTGTGCATCTATGGTTTCACCCGGCAGGAGCTCATGGAATATGCGGCGTTCGGCCGAAAGAGTTATTTGGAAAAGTGCGAAGACATCGAGATCCTTCGTTTTTTGGAGATCGAACGAAAGGTTTTGATGTTCCAATGCAAGCCGGGTAGCCTTGCAGTTGATGTTCCCGCGGACGTATCCCCAGTCGAGGCATTGTTGCGGGAACGCCTCAGTTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 21262,
                "end": 22884,
                "strand": -1,
                "locus_tag": "KKHPANEM_02427",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02427</span></strong><br>\n \n  4-hydroxy-2-oxovalerate aldolase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02427</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">mhpE</span><br>\n \n Location: 21,262 - 22,884,\n (total: 1623 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n  biosynthetic-additional (smcogs) SMCOG1271:2-isopropylmalate synthase (Score: 104.2; E-value: 1.4e-31)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTINMTGGTLLDCTFRDGGYYNAWDFSPALITQYLGAMRAAQVDVVELGFRFLRNEGFKGPCAFTTDDFLRSLPIPPGLTVGVMLNGADLCTDLGRGAALQRLFPEPAASTPVDLVRFACHFHELETVLPAVGWLHERGYRVGLNLMQIADRSRTQVAELAKMSRDWPVEVLYFADSMGSMTPDDTARIVGWLRDGWEGPLGIHTHDNMGLALSNTLRAAAEGVTWLDATVTGMGRGPGNARTEELAIEAEGLRNRRANLVPLMGLIRKHFGPMKAQYGWGTNPYYFLAGKYGIHPTYIQEMLGDARYDEEDILAVIDHLRAEGGKKFSFNTLDGARQFYSGAPRGSWAPSEVMAGRDVLILGTGPGVAAHRPALEAYIRRARPLVLALNTQSAIDPALIDLRIACHPVRLLADAEAHAALPQPLITPASMLPETLRAEFGDKELLDFGIGIEPGRFEFHATHCVAPNSLVLSYALSVAASGQASRILMAGFDGYPASDRRNDEVDDMLLKFVNSEFTGPVFSITPSAYGNLPALSLYGM&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=11262&amp;to=32884\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTINMTGGTLLDCTFRDGGYYNAWDFSPALITQYLGAMRAAQVDVVELGFRFLRNEGFKGPCAFTTDDFLRSLPIPPGLTVGVMLNGADLCTDLGRGAALQRLFPEPAASTPVDLVRFACHFHELETVLPAVGWLHERGYRVGLNLMQIADRSRTQVAELAKMSRDWPVEVLYFADSMGSMTPDDTARIVGWLRDGWEGPLGIHTHDNMGLALSNTLRAAAEGVTWLDATVTGMGRGPGNARTEELAIEAEGLRNRRANLVPLMGLIRKHFGPMKAQYGWGTNPYYFLAGKYGIHPTYIQEMLGDARYDEEDILAVIDHLRAEGGKKFSFNTLDGARQFYSGAPRGSWAPSEVMAGRDVLILGTGPGVAAHRPALEAYIRRARPLVLALNTQSAIDPALIDLRIACHPVRLLADAEAHAALPQPLITPASMLPETLRAEFGDKELLDFGIGIEPGRFEFHATHCVAPNSLVLSYALSVAASGQASRILMAGFDGYPASDRRNDEVDDMLLKFVNSEFTGPVFSITPSAYGNLPALSLYGM\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACAATCAATATGACTGGCGGCACGCTTCTTGACTGCACATTCCGGGACGGCGGATACTACAACGCCTGGGATTTCTCGCCCGCGCTGATCACACAGTACCTCGGGGCCATGCGGGCCGCGCAGGTGGATGTGGTGGAGCTGGGGTTCCGTTTTCTGCGCAACGAGGGGTTCAAGGGGCCCTGCGCCTTCACCACCGATGACTTCCTGCGCAGCCTGCCGATCCCACCGGGGCTGACGGTGGGGGTGATGCTCAACGGGGCGGATCTGTGCACCGACTTGGGCCGGGGCGCCGCGCTGCAGAGGCTGTTTCCCGAACCGGCCGCATCCACGCCGGTCGATCTGGTCCGCTTTGCCTGCCATTTCCATGAGCTGGAGACGGTTCTGCCCGCCGTCGGCTGGCTGCACGAGCGCGGCTACCGGGTCGGGCTGAACCTGATGCAGATCGCCGACCGCTCGCGAACGCAGGTCGCCGAGCTTGCGAAAATGTCCCGCGACTGGCCGGTGGAGGTGCTGTATTTTGCCGACTCCATGGGCTCCATGACGCCCGACGACACCGCCCGCATCGTCGGCTGGCTGCGCGACGGGTGGGAGGGGCCGCTGGGCATCCACACCCACGACAACATGGGGCTTGCGCTGTCCAACACGCTGCGTGCCGCGGCCGAGGGCGTCACCTGGCTCGATGCCACCGTCACCGGGATGGGGCGCGGCCCGGGCAACGCCCGCACCGAGGAACTGGCGATCGAGGCGGAGGGCCTGCGCAACCGGCGCGCCAATCTCGTGCCGCTGATGGGCCTGATCCGCAAGCACTTCGGCCCGATGAAGGCGCAGTACGGCTGGGGCACCAACCCGTATTACTTCCTTGCCGGAAAGTACGGCATCCATCCCACCTATATCCAGGAAATGCTGGGCGACGCGCGCTATGACGAGGAGGACATCCTTGCCGTGATCGACCATCTGCGCGCCGAGGGCGGCAAGAAGTTCAGCTTCAACACCCTCGACGGCGCGCGGCAGTTCTACAGCGGCGCGCCGCGTGGCAGCTGGGCCCCGTCCGAGGTCATGGCCGGCCGCGACGTGCTGATCTTGGGCACCGGGCCGGGCGTGGCCGCGCATCGCCCTGCGCTGGAGGCCTATATCCGCCGCGCCCGGCCGCTGGTGCTGGCGCTCAACACCCAGTCGGCCATCGATCCCGCGCTGATCGACCTGCGCATTGCCTGCCACCCGGTCCGTCTTCTCGCCGACGCCGAGGCCCACGCGGCGCTTCCGCAACCGCTGATCACCCCGGCCTCCATGCTGCCCGAAACCCTCCGGGCCGAGTTCGGCGACAAGGAGCTTCTGGATTTCGGGATCGGTATCGAGCCTGGCCGGTTCGAGTTCCACGCGACGCACTGCGTTGCGCCCAACTCTCTGGTTCTGTCCTACGCGCTGTCTGTCGCGGCCAGCGGTCAAGCTTCGCGTATCCTGATGGCAGGCTTCGACGGCTATCCCGCCAGCGACCGCCGCAATGATGAGGTCGATGACATGCTGCTCAAGTTCGTGAATTCCGAATTCACGGGTCCGGTGTTTTCGATAACGCCAAGCGCTTACGGAAATCTTCCCGCGCTCAGCCTGTACGGTATGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 22941,
                "end": 24263,
                "strand": -1,
                "locus_tag": "KKHPANEM_02428",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02428</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02428</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,941 - 24,263,\n (total: 1323 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLAWLQWRLKGLAMDLAYRLPLALVARLAPSPMRMISFYLAKADSPRALQYLDHLVRISPEVGCLMRLDERLRRGSISGVDLVDSIPSSILRKLNSYKDVHLNDAARAFNRLGCLRLGGALRGLLLIKLVQQRFRSPAKQGWELDALLLEVSANDYSRRLFSRPELWEDGLDRQVQDRIELLRCSDMLVKLRVFVDSERLPCGEHEASLSGLSVLLQGPSRRESNLAGTPCDVVGTIGYSGAGSLARLVEGRHVSFYRPYKIRAMIAEGLTERFNDVDLAVVTKRGLGVLEAQFTPECRVACSKVRERFGLGFLNGGTEFLIWLLACDLNRLFVTNVDLFLNPAYPVGYLPSNYQKSHLSKDAAQWQTQSWATLMVFGDHEPSQQYSIYKAFHGYDSVVYDSMLDAIVSAPFSAYAEALEDAYRVWPQGPVVDCCGGGSA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=12941&amp;to=34263\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLAWLQWRLKGLAMDLAYRLPLALVARLAPSPMRMISFYLAKADSPRALQYLDHLVRISPEVGCLMRLDERLRRGSISGVDLVDSIPSSILRKLNSYKDVHLNDAARAFNRLGCLRLGGALRGLLLIKLVQQRFRSPAKQGWELDALLLEVSANDYSRRLFSRPELWEDGLDRQVQDRIELLRCSDMLVKLRVFVDSERLPCGEHEASLSGLSVLLQGPSRRESNLAGTPCDVVGTIGYSGAGSLARLVEGRHVSFYRPYKIRAMIAEGLTERFNDVDLAVVTKRGLGVLEAQFTPECRVACSKVRERFGLGFLNGGTEFLIWLLACDLNRLFVTNVDLFLNPAYPVGYLPSNYQKSHLSKDAAQWQTQSWATLMVFGDHEPSQQYSIYKAFHGYDSVVYDSMLDAIVSAPFSAYAEALEDAYRVWPQGPVVDCCGGGSA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTGGCCTGGTTGCAATGGAGGCTCAAGGGTCTGGCTATGGACCTGGCCTATCGGCTGCCGCTGGCGCTTGTGGCCCGATTGGCGCCATCGCCGATGCGGATGATTTCCTTCTATCTGGCAAAAGCCGATTCACCTCGGGCGTTGCAATACCTTGACCACTTGGTTCGAATCTCGCCCGAGGTTGGCTGCCTCATGCGGCTTGACGAGCGGTTGCGGAGGGGAAGCATAAGTGGCGTCGATCTGGTGGATTCAATCCCGAGCTCGATCTTGCGGAAGCTCAATTCCTACAAGGATGTACATCTGAACGATGCCGCAAGGGCCTTCAACCGCTTGGGTTGCCTTCGGTTGGGAGGAGCCCTGCGAGGCCTTCTGCTGATCAAGCTCGTGCAGCAGAGATTTCGGAGCCCGGCGAAGCAAGGCTGGGAGCTTGACGCTTTGCTCCTTGAGGTTTCTGCCAATGACTACAGCCGCCGCCTTTTTTCGCGTCCCGAGCTTTGGGAGGATGGCCTTGACAGGCAAGTTCAGGACCGCATCGAATTGCTTCGATGCTCTGACATGTTGGTCAAGCTGCGCGTTTTTGTTGATTCGGAAAGACTGCCATGCGGGGAACACGAGGCCTCTCTGAGCGGCTTGTCGGTGCTGCTACAGGGGCCGTCGAGGAGGGAGTCCAATCTGGCTGGTACACCTTGTGACGTGGTTGGCACCATCGGTTACTCTGGAGCCGGCTCCCTCGCCAGGCTCGTTGAAGGCAGGCACGTATCCTTCTACCGGCCATACAAAATTCGCGCAATGATTGCTGAAGGGTTAACCGAAAGATTTAACGATGTTGACCTGGCGGTTGTCACCAAGCGAGGCCTCGGTGTTTTGGAGGCACAGTTCACGCCAGAGTGCAGGGTTGCCTGCTCCAAGGTGCGAGAGAGGTTTGGACTTGGTTTCCTGAACGGAGGAACGGAGTTTCTGATCTGGCTCTTGGCATGCGATCTGAACCGGCTCTTCGTCACAAATGTCGATCTTTTTCTCAACCCAGCGTACCCGGTCGGTTATCTGCCGAGCAACTACCAGAAATCTCACCTTTCAAAGGATGCTGCGCAATGGCAGACACAGTCGTGGGCGACGCTAATGGTTTTTGGAGATCATGAACCGAGTCAGCAGTACTCTATCTACAAGGCCTTTCATGGTTACGATTCCGTTGTATACGACTCGATGCTTGATGCAATTGTATCTGCGCCGTTCAGCGCATACGCGGAGGCGCTTGAAGATGCCTATCGGGTTTGGCCCCAAGGTCCCGTCGTCGATTGCTGCGGTGGTGGCTCGGCTTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 24278,
                "end": 25579,
                "strand": -1,
                "locus_tag": "KKHPANEM_02429",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02429</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02429</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,278 - 25,579,\n (total: 1302 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTVRLKRLGMGVAMSVVPRLPASLAMRITPSPVWLVSLLLTRDDPAAAVRCLKRLAATSPEIAALLRIDEQLQSGAIPADAIADAMPIPVLQAFVTTGIAPLRHAAKAFNALGCLRLGGALRALVLLRVAAANIASGEDRGWQHEAVLLEIAANDHCARFMARPEVMPEACRTALQEELQAVAGWSLARKVSVLVGQDSPAMPALRARMAGRSLRFQGPSSRSSDLDDTPADLTCVVGYSGPGSLARPVDSIGVSLYKKHKIAAMRGDGLLHHMADVQVPVLNPEDLRQERAFYADLIEKYGASLTNVRWASLNSQMNAGTELFVWMLNCGASSVSVSHLDLFLNRTYPPGYLAGGKAQASRDGPGWQMEEWSQLKSFGYHEPSQQFAIYRAFHPHREVAYDGILDAIVEKPFSAYASALEDGYRVWRGRAEA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=14278&amp;to=35579\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTVRLKRLGMGVAMSVVPRLPASLAMRITPSPVWLVSLLLTRDDPAAAVRCLKRLAATSPEIAALLRIDEQLQSGAIPADAIADAMPIPVLQAFVTTGIAPLRHAAKAFNALGCLRLGGALRALVLLRVAAANIASGEDRGWQHEAVLLEIAANDHCARFMARPEVMPEACRTALQEELQAVAGWSLARKVSVLVGQDSPAMPALRARMAGRSLRFQGPSSRSSDLDDTPADLTCVVGYSGPGSLARPVDSIGVSLYKKHKIAAMRGDGLLHHMADVQVPVLNPEDLRQERAFYADLIEKYGASLTNVRWASLNSQMNAGTELFVWMLNCGASSVSVSHLDLFLNRTYPPGYLAGGKAQASRDGPGWQMEEWSQLKSFGYHEPSQQFAIYRAFHPHREVAYDGILDAIVEKPFSAYASALEDGYRVWRGRAEA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCGTTCGCCTGAAGCGCCTCGGCATGGGAGTCGCGATGTCGGTCGTGCCTCGGCTTCCTGCATCGCTGGCGATGCGGATTACTCCGTCGCCCGTCTGGCTGGTGTCGCTTCTCCTGACGCGGGACGATCCGGCCGCGGCGGTGCGGTGCCTCAAGCGGCTCGCCGCGACCAGTCCCGAGATAGCTGCCCTTCTGCGCATCGACGAACAGCTGCAGTCCGGGGCCATCCCTGCCGATGCAATCGCCGACGCGATGCCAATCCCGGTGTTGCAGGCTTTCGTCACCACCGGGATTGCGCCTCTCCGGCATGCTGCCAAGGCGTTCAACGCGCTCGGGTGCCTGCGGCTGGGGGGGGCACTGAGGGCGCTCGTGCTTTTGCGGGTTGCCGCTGCGAACATTGCCTCCGGCGAGGACCGCGGATGGCAGCACGAGGCAGTACTTCTGGAGATCGCGGCCAACGATCACTGCGCGCGGTTCATGGCCCGCCCGGAGGTGATGCCAGAGGCCTGCCGCACGGCGCTTCAGGAAGAACTGCAAGCGGTCGCCGGCTGGAGCCTGGCGCGCAAGGTCTCGGTTCTCGTGGGCCAGGACAGCCCCGCCATGCCGGCGTTGCGCGCGCGCATGGCCGGCCGCAGCCTTCGGTTCCAGGGTCCGTCGAGCCGTTCCTCCGATCTGGACGATACGCCGGCCGATCTGACATGCGTCGTCGGCTACTCCGGACCTGGCTCGCTGGCCCGCCCGGTCGACAGCATTGGTGTGTCGCTATACAAGAAGCACAAGATCGCGGCGATGCGCGGGGACGGACTGCTGCATCACATGGCGGACGTGCAGGTTCCGGTGCTCAACCCGGAGGACCTGCGCCAAGAACGTGCGTTTTATGCGGACCTGATCGAGAAATATGGAGCCAGTTTGACGAATGTGCGCTGGGCGTCCCTGAACTCCCAGATGAATGCGGGCACGGAACTGTTTGTCTGGATGTTGAACTGCGGCGCTTCCTCGGTTTCTGTCAGTCACCTTGACCTGTTCTTGAACCGAACCTATCCCCCCGGTTACCTGGCCGGCGGCAAGGCGCAAGCCTCCCGTGACGGGCCAGGCTGGCAGATGGAGGAGTGGTCGCAGTTGAAGAGCTTCGGCTACCATGAGCCCAGCCAGCAGTTCGCGATCTACAGGGCGTTTCATCCGCATCGCGAGGTGGCGTACGATGGCATACTCGATGCGATCGTGGAGAAACCATTCAGCGCCTACGCGAGCGCGCTTGAGGACGGCTATCGAGTTTGGCGCGGTCGGGCCGAGGCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 25856,
                "end": 26299,
                "strand": -1,
                "locus_tag": "KKHPANEM_02430",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02430</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02430</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,856 - 26,299,\n (total: 444 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFETFLRRLIRPDPMPLPQADARLALAALLVRAARVNGDYDPAQVVAIDAALARRYGFGADDAAALRARAEGLESEAPDTVRFTRAVKQATALEDRAAELEMLWEVILSDGARDHEEDGFMRLVADLLGFSDRDSALARQRVAERMA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=15856&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFETFLRRLIRPDPMPLPQADARLALAALLVRAARVNGDYDPAQVVAIDAALARRYGFGADDAAALRARAEGLESEAPDTVRFTRAVKQATALEDRAAELEMLWEVILSDGARDHEEDGFMRLVADLLGFSDRDSALARQRVAERMA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTCGAGACATTCCTGCGCCGGCTGATCCGGCCCGATCCCATGCCCCTGCCGCAAGCCGATGCCCGGCTGGCGCTGGCGGCCCTGCTGGTGCGGGCGGCGCGCGTCAACGGCGATTATGACCCCGCACAGGTGGTTGCCATCGATGCCGCCCTCGCGCGTCGCTACGGCTTCGGGGCGGATGACGCCGCCGCCCTGCGCGCCCGCGCCGAAGGTCTGGAGAGCGAGGCGCCCGACACCGTGCGCTTCACCCGCGCCGTCAAGCAGGCAACCGCACTGGAAGATCGCGCGGCCGAGCTGGAGATGCTGTGGGAGGTGATCCTGTCCGACGGCGCGCGCGACCACGAGGAGGACGGGTTCATGCGCCTTGTGGCGGACCTGCTGGGGTTCTCCGATCGCGACAGCGCGCTGGCCCGCCAGCGCGTGGCCGAGCGGATGGCGTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 26389,
                "end": 28062,
                "strand": -1,
                "locus_tag": "KKHPANEM_02431",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02431</span></strong><br>\n \n  Glucose-6-phosphate isomerase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02431</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pgi</span><br>\n \n Location: 26,389 - 28,062,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAERTTGRAPGGHDADLAPLWRALEQYRDRVAARPIAALFDADPARAEAFSVSAAGLMLDYSKTGVCAQGMAHLLALADGAGVEARRDAMFRGAAINETEGRAVLHTALRDPDGPPLVVDGVDVRPGIAGTLARMEAMAADVRAGRVRGAGGAITDVVNIGIGGSDLGPAMAVQALAPYHDGPRCHFVSNVDGAHVHDVLAGLDPARTLVIVASKTFTTLETMTNAATARDWMARAVADPGAQFVALSSAGDRAAAFGIPPDRVFGFEDWVGGRYSVWGPIGLSLMLAIGPERFRDFLAGAAAMDAHFRSAPLASSMPVLLALVGVWHAQVCGHATRAVIPYDQRLARLPAYLQQLEMESNGKRVGMDGRDLDRPSGPIVWGEPGTNGQHAFMQLIHQGTRVVPVEFLLAARGHEADLAHHHRLLVANCLAQAEALMRGRTLEAARAGLSAAALGGAELERQARHRVFPGNRPSTVLLYSRLTPRMLGAVLALYEHRVFVEGVILGINPFDQWGVELGKELAVSLTPLLEGTAEGGAHDASTLRLVAMVRADGVAPG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=16389&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAERTTGRAPGGHDADLAPLWRALEQYRDRVAARPIAALFDADPARAEAFSVSAAGLMLDYSKTGVCAQGMAHLLALADGAGVEARRDAMFRGAAINETEGRAVLHTALRDPDGPPLVVDGVDVRPGIAGTLARMEAMAADVRAGRVRGAGGAITDVVNIGIGGSDLGPAMAVQALAPYHDGPRCHFVSNVDGAHVHDVLAGLDPARTLVIVASKTFTTLETMTNAATARDWMARAVADPGAQFVALSSAGDRAAAFGIPPDRVFGFEDWVGGRYSVWGPIGLSLMLAIGPERFRDFLAGAAAMDAHFRSAPLASSMPVLLALVGVWHAQVCGHATRAVIPYDQRLARLPAYLQQLEMESNGKRVGMDGRDLDRPSGPIVWGEPGTNGQHAFMQLIHQGTRVVPVEFLLAARGHEADLAHHHRLLVANCLAQAEALMRGRTLEAARAGLSAAALGGAELERQARHRVFPGNRPSTVLLYSRLTPRMLGAVLALYEHRVFVEGVILGINPFDQWGVELGKELAVSLTPLLEGTAEGGAHDASTLRLVAMVRADGVAPG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGCGGAGCGGACAACGGGGCGGGCACCGGGCGGGCACGATGCGGATCTGGCGCCGCTGTGGCGGGCACTGGAGCAATACCGCGACCGGGTGGCCGCGCGCCCCATCGCGGCGCTGTTCGACGCCGATCCGGCGCGCGCCGAGGCGTTCTCGGTCAGCGCGGCCGGGCTGATGCTCGATTACTCCAAGACCGGGGTGTGTGCGCAGGGGATGGCGCATCTTCTGGCGCTGGCCGATGGCGCCGGGGTGGAGGCGCGCCGGGACGCGATGTTCCGGGGCGCCGCGATCAACGAGACCGAGGGCCGGGCGGTGCTGCACACCGCGTTGCGTGATCCCGACGGGCCGCCGCTGGTGGTCGACGGGGTGGATGTGCGCCCGGGCATCGCCGGGACGCTGGCGCGGATGGAGGCGATGGCCGCCGATGTGCGCGCGGGCCGGGTCCGCGGGGCGGGCGGGGCGATCACGGATGTGGTCAATATCGGGATCGGCGGATCGGACCTCGGGCCTGCGATGGCGGTGCAGGCGCTGGCGCCGTACCACGACGGGCCGCGGTGTCATTTCGTCTCGAACGTGGACGGGGCGCATGTGCATGACGTGCTGGCGGGGCTGGACCCGGCGCGGACACTGGTGATCGTGGCCTCCAAGACCTTCACCACGCTGGAGACGATGACCAACGCCGCCACCGCACGCGACTGGATGGCCCGCGCCGTGGCCGATCCGGGGGCGCAGTTCGTGGCGCTGTCGTCGGCCGGGGACCGCGCGGCGGCGTTCGGCATCCCGCCCGATCGGGTGTTCGGCTTCGAGGACTGGGTCGGCGGGCGCTACTCGGTCTGGGGGCCGATCGGGTTGTCGCTGATGCTGGCCATCGGGCCGGAGCGGTTCCGCGACTTCCTTGCGGGGGCGGCGGCGATGGACGCGCATTTCCGCAGCGCCCCGCTGGCGTCCAGCATGCCGGTGCTGCTGGCGCTGGTGGGGGTGTGGCATGCGCAGGTCTGCGGGCATGCGACCCGCGCGGTCATCCCCTATGATCAACGGCTGGCGCGGCTTCCGGCGTATCTGCAGCAGCTGGAGATGGAGTCGAACGGCAAGCGCGTGGGGATGGACGGGCGCGACCTCGATCGTCCCTCGGGGCCGATCGTGTGGGGGGAGCCGGGAACCAATGGCCAGCACGCCTTCATGCAGTTGATCCATCAGGGCACGCGCGTCGTGCCGGTGGAGTTCCTGCTGGCCGCGCGCGGTCACGAGGCGGATCTGGCGCATCACCACCGCCTGCTGGTCGCCAACTGCCTGGCGCAGGCCGAGGCGCTGATGCGGGGGCGCACGCTGGAGGCGGCGCGCGCCGGGCTGTCGGCCGCAGCCCTGGGCGGTGCCGAGCTGGAGCGCCAGGCCCGCCACCGGGTGTTTCCCGGCAACCGGCCCTCGACGGTGCTGCTGTATTCCCGGCTGACGCCGCGGATGCTGGGGGCCGTCCTGGCCCTTTATGAGCATCGGGTGTTCGTGGAGGGCGTGATCCTCGGCATCAACCCGTTCGATCAATGGGGCGTGGAGCTGGGCAAGGAGCTGGCCGTCAGCCTGACGCCGCTGCTGGAGGGGACGGCCGAGGGCGGCGCGCACGACGCCTCCACCCTGCGGCTGGTGGCGATGGTGCGCGCGGATGGTGTCGCCCCGGGATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 28927,
                "end": 29736,
                "strand": -1,
                "locus_tag": "KKHPANEM_02432",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02432</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02432</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,927 - 29,736,\n (total: 810 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDHKARTALAAPLVAALVLSAAAANGATLRTLSGGDGAFNALCAAGNAVGTGNQACEFAVGEMRTGAVGGAQTWEVGVQNPPGSPVSTRNYAWGNGAAQAFVFSFSGGTLTLAVGAAGATQVVSTATGVDLGGMSSMFLRTRTAQEGFEGVKLFDMTVTGAAPGGGAVGVHDLPDLTSSAPGSTGAGYVQVSDVDWSADWTLAGSIRFSWDPDLACPCGSNLNVNFKLTDLETLSGGPPSSVIPLPAAGWLLLSGVAGLGWLGRRRAVV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=18927&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDHKARTALAAPLVAALVLSAAAANGATLRTLSGGDGAFNALCAAGNAVGTGNQACEFAVGEMRTGAVGGAQTWEVGVQNPPGSPVSTRNYAWGNGAAQAFVFSFSGGTLTLAVGAAGATQVVSTATGVDLGGMSSMFLRTRTAQEGFEGVKLFDMTVTGAAPGGGAVGVHDLPDLTSSAPGSTGAGYVQVSDVDWSADWTLAGSIRFSWDPDLACPCGSNLNVNFKLTDLETLSGGPPSSVIPLPAAGWLLLSGVAGLGWLGRRRAVV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGATCACAAGGCACGGACCGCTTTGGCAGCCCCGCTCGTGGCGGCGCTGGTGCTTTCGGCCGCGGCGGCCAATGGCGCGACCTTGCGGACGCTGTCCGGGGGGGATGGCGCCTTCAATGCGCTGTGCGCGGCGGGCAACGCGGTCGGAACCGGCAATCAGGCCTGCGAGTTTGCCGTCGGTGAAATGCGGACCGGGGCTGTCGGTGGCGCCCAGACATGGGAGGTCGGCGTGCAGAACCCGCCCGGATCGCCCGTCAGCACGCGCAATTATGCCTGGGGCAACGGCGCGGCGCAGGCGTTCGTGTTTTCCTTCAGCGGCGGCACCCTGACCCTTGCGGTCGGTGCGGCGGGGGCGACGCAGGTGGTCTCGACGGCGACGGGGGTCGACCTGGGCGGCATGTCGTCGATGTTCCTCCGCACCCGCACCGCACAGGAGGGGTTCGAGGGCGTGAAGCTGTTCGACATGACAGTGACGGGGGCCGCGCCGGGCGGGGGTGCGGTTGGTGTGCACGACCTGCCCGACCTGACCTCGTCCGCGCCGGGGTCGACCGGGGCGGGCTATGTTCAGGTGTCGGACGTGGACTGGAGCGCGGACTGGACGCTGGCGGGCTCGATCCGCTTCAGCTGGGACCCCGATCTGGCCTGCCCCTGCGGATCCAACCTGAATGTCAATTTCAAGCTGACCGATCTGGAGACGCTGTCGGGGGGGCCGCCGAGCAGTGTCATCCCGCTGCCGGCCGCCGGATGGCTGCTGCTGAGCGGGGTTGCGGGGCTGGGCTGGCTCGGGCGGCGGCGCGCGGTGGTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 30101,
                "end": 30238,
                "strand": -1,
                "locus_tag": "KKHPANEM_02433",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02433</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02433</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,101 - 30,238,\n (total: 138 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGKGNNKRGNKEVKKPKQEKPKVLATANSGVAKPMTLGEKKDRSR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=20101&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGKGNNKRGNKEVKKPKQEKPKVLATANSGVAKPMTLGEKKDRSR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCAAAGGCAACAACAAGCGCGGAAACAAGGAAGTGAAGAAGCCGAAGCAGGAGAAGCCCAAGGTGCTGGCGACGGCCAACTCCGGCGTGGCGAAACCGATGACCCTGGGCGAGAAGAAAGACCGCAGCCGGTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 30442,
                "end": 31245,
                "strand": -1,
                "locus_tag": "KKHPANEM_02434",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02434</span></strong><br>\n \n  D-beta-hydroxybutyrate dehydrogenase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02434</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">bdhA</span><br>\n \n Location: 30,442 - 31,245,\n (total: 804 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 200.7; E-value: 4.6e-61)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTDLTGKTALVTGSTSGIGLAIAEALGAAGARIALHGLAGDMEIHDATERVRAAGSPEVAFFGGDMRNPERIHELMAAVDAWGGVDILVNNAGIQHTAPTTEMPDDKWEAIIAINLSACFHTMKAALPGMAARGYGRVVNIASTHGLVASKEKAPYVAAKHGLVGMTKVVALEHAALGDAASGGVTANCICPGWTETALIEPQIEARAKARGGDRTAAIADLLSEKQPSQRMTSPADLGALAVWLCSPAAHNITGVAIPVDGGWTAQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=20442&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTDLTGKTALVTGSTSGIGLAIAEALGAAGARIALHGLAGDMEIHDATERVRAAGSPEVAFFGGDMRNPERIHELMAAVDAWGGVDILVNNAGIQHTAPTTEMPDDKWEAIIAINLSACFHTMKAALPGMAARGYGRVVNIASTHGLVASKEKAPYVAAKHGLVGMTKVVALEHAALGDAASGGVTANCICPGWTETALIEPQIEARAKARGGDRTAAIADLLSEKQPSQRMTSPADLGALAVWLCSPAAHNITGVAIPVDGGWTAQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGATCTGACGGGCAAGACGGCGCTGGTGACAGGCTCCACCTCGGGGATCGGGCTGGCCATCGCCGAGGCGCTGGGGGCTGCGGGCGCGCGCATCGCGCTGCACGGGCTGGCCGGCGACATGGAGATCCACGACGCGACCGAGCGGGTGCGCGCCGCCGGCAGCCCCGAGGTGGCGTTCTTCGGTGGCGACATGCGCAACCCCGAGCGCATTCACGAGCTGATGGCGGCGGTCGATGCCTGGGGCGGCGTGGACATCCTCGTCAACAACGCCGGCATCCAGCACACCGCCCCCACCACCGAGATGCCCGACGACAAGTGGGAGGCGATCATCGCCATCAACCTGTCGGCGTGTTTCCACACCATGAAGGCGGCGCTGCCTGGGATGGCCGCGCGGGGCTATGGGCGGGTTGTCAACATCGCCTCGACCCACGGGCTGGTGGCGTCGAAGGAAAAGGCGCCCTATGTCGCGGCCAAGCACGGGCTTGTGGGCATGACCAAGGTGGTGGCGCTGGAGCATGCGGCGCTGGGGGATGCGGCCTCGGGCGGGGTGACGGCGAACTGCATCTGTCCGGGCTGGACCGAAACCGCCCTGATCGAGCCGCAGATCGAGGCCCGCGCCAAGGCCCGCGGCGGCGACCGCACCGCCGCGATCGCGGATCTGCTGTCGGAGAAGCAACCCTCGCAGCGCATGACCAGCCCCGCCGATCTGGGGGCGCTGGCGGTGTGGTTGTGCAGCCCCGCCGCGCACAACATCACCGGGGTGGCGATCCCCGTGGACGGCGGCTGGACCGCGCAGTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 31242,
                "end": 32768,
                "strand": -1,
                "locus_tag": "KKHPANEM_02435",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02435</span></strong><br>\n \n  Long-chain-fatty-acid--CoA ligase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02435</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">lcfB_3</span><br>\n \n Location: 31,242 - 32,768,\n (total: 1527 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 364.2; E-value: 1.5e-110)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNIANWLVRSAQTRGTAPALMAGAREVADYAGFARSAGALAGALAARGIAPGDRVALLAGNRPEYLVAVFGIWTAGAVAVPVNARLHPREAAWILSDSGAALALVAPDAAPDLAGVTEVPLMALPGPDWAAAVAGPPAPVVPRGQGDLAWLFYTSGTTGRPKGVCITHGMLAAMSLCYPVDVDPVGPQDAALYAAPMSHGAGLYAPIHVRMGARHLVPPSGGFDAAEVLDLAASHGPVSMFLAPTMVRRLLEAARASGRRGEGLRTVVYGGGPMYLADITAAVDWFGPRFVQIYGQGECPMAITALSRAEVADRTHPDWRARLGSVGRAQSLAEVAVIDDAGAPLPVGEAGEIVVRGAPVMPGYWRNPEASAKTLCDGWLRTGDVGQLDGDGYLTLVDRSRDVIISGGTNIYPREVEEALLEHPDVAEAAVIGRPSPEWGEEVVAFLVPRAALRRAALEAHCLERMARFKRPRAWYAVASLPKNNYGKVLKTELRARLAAGTEQEDIA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=21242&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNIANWLVRSAQTRGTAPALMAGAREVADYAGFARSAGALAGALAARGIAPGDRVALLAGNRPEYLVAVFGIWTAGAVAVPVNARLHPREAAWILSDSGAALALVAPDAAPDLAGVTEVPLMALPGPDWAAAVAGPPAPVVPRGQGDLAWLFYTSGTTGRPKGVCITHGMLAAMSLCYPVDVDPVGPQDAALYAAPMSHGAGLYAPIHVRMGARHLVPPSGGFDAAEVLDLAASHGPVSMFLAPTMVRRLLEAARASGRRGEGLRTVVYGGGPMYLADITAAVDWFGPRFVQIYGQGECPMAITALSRAEVADRTHPDWRARLGSVGRAQSLAEVAVIDDAGAPLPVGEAGEIVVRGAPVMPGYWRNPEASAKTLCDGWLRTGDVGQLDGDGYLTLVDRSRDVIISGGTNIYPREVEEALLEHPDVAEAAVIGRPSPEWGEEVVAFLVPRAALRRAALEAHCLERMARFKRPRAWYAVASLPKNNYGKVLKTELRARLAAGTEQEDIA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAACATCGCGAACTGGCTGGTGCGCAGCGCGCAGACGCGCGGGACGGCGCCCGCGCTGATGGCGGGCGCGCGGGAGGTGGCGGATTACGCGGGCTTTGCGCGGTCCGCTGGGGCGCTGGCGGGGGCGCTGGCGGCGCGCGGGATCGCGCCCGGCGACCGGGTCGCGCTGTTGGCGGGCAACCGGCCGGAGTATCTGGTGGCGGTGTTCGGGATCTGGACCGCCGGGGCGGTGGCGGTGCCGGTCAACGCCCGCCTGCATCCGCGCGAGGCGGCGTGGATCCTGTCCGACAGCGGCGCGGCGCTGGCGCTGGTGGCCCCCGACGCAGCACCCGATCTGGCGGGCGTGACCGAGGTGCCGCTGATGGCGCTGCCGGGTCCCGACTGGGCGGCGGCGGTGGCCGGGCCGCCCGCGCCGGTGGTGCCGCGGGGGCAGGGCGATCTGGCGTGGCTGTTCTACACCTCGGGCACCACGGGGCGGCCCAAGGGGGTGTGCATCACGCATGGCATGCTGGCGGCGATGTCGCTGTGCTATCCCGTCGACGTGGACCCGGTGGGGCCGCAGGACGCCGCGCTGTATGCGGCCCCCATGAGCCATGGGGCGGGCCTCTATGCGCCGATCCATGTGCGCATGGGGGCGCGGCATCTGGTGCCGCCCTCGGGCGGGTTCGACGCGGCCGAGGTGCTGGATCTGGCCGCATCCCACGGCCCGGTGTCGATGTTCCTGGCGCCCACCATGGTGCGCCGGCTGCTGGAGGCCGCGCGCGCCTCGGGGCGGCGGGGCGAGGGGCTGCGCACCGTCGTCTATGGCGGCGGGCCGATGTATCTGGCCGACATCACCGCCGCCGTCGACTGGTTCGGCCCGCGTTTCGTGCAGATCTATGGTCAGGGCGAATGCCCGATGGCCATCACCGCGCTGAGCCGGGCCGAGGTCGCGGACCGCACCCATCCCGACTGGCGCGCGCGCCTCGGCTCGGTCGGGCGGGCGCAGAGCCTGGCGGAGGTCGCGGTGATCGATGACGCGGGCGCGCCGCTGCCGGTGGGCGAGGCGGGCGAGATCGTGGTGCGCGGCGCCCCGGTGATGCCCGGCTACTGGCGCAATCCCGAGGCCAGCGCGAAAACCCTGTGCGACGGTTGGCTGCGGACCGGCGACGTGGGCCAGCTGGACGGCGACGGATACCTGACGCTGGTCGACCGTTCTCGGGACGTGATCATCTCGGGCGGGACCAACATCTATCCCCGCGAGGTCGAGGAGGCCCTGCTGGAACACCCCGACGTGGCCGAGGCCGCCGTCATCGGCCGCCCCAGCCCCGAGTGGGGCGAGGAGGTGGTGGCGTTCCTCGTGCCCCGCGCGGCGCTGCGCCGCGCGGCGCTGGAGGCGCATTGTCTGGAGCGGATGGCCCGGTTCAAGCGGCCCAGGGCATGGTATGCAGTGGCATCCCTTCCAAAGAACAATTACGGCAAGGTGCTGAAGACCGAGTTGCGCGCCCGGCTGGCCGCCGGGACCGAACAGGAGGACATCGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 32823,
                "end": 36047,
                "strand": -1,
                "locus_tag": "KKHPANEM_02436",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02436</span></strong><br>\n \n  Sensor histidine kinase RcsC<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02436</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">rcsC_7</span><br>\n \n Location: 32,823 - 36,047,\n (total: 3225 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 66.2; E-value: 5.2e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPGRAPPQRHRLGAPGAERWVEVTAAPRGPGAAPGHVVALRDVTAAARATHEVEQLSQIARRTGDLVVITDTDHRIDWVNPAFEARTGWRLEDVRGHLPESILQSPEADAAEVARIRGALLEGASASGLLLCRTRTDDAFWAEIDAYPLRDSDGRTTGHVTLATDVTARRAQEAKLERLAQEATRARERLEMAVEALPDAFAFFDAEDRLVLCNERYRTFHPRSGYMISPGVQFADFARAVAHSGDVADAVGREEAWLAERLASHREGRPGGEHRMADGSWLRVIERVTADGGRVGMRVDITELKEAERRLADIIHGAQVGTWEWHLASGENRINARWAEIVGYCPDEIDRSGIDLWRALVHPDDLARAEARLARVFAREIDQFEYELRMRHRDGHWVWVLSRGRVARWSPDGKPEVMAGVHMDITALKRAEERLEAILHAAEAGTWETDPARGGMRINDRWAEMLGYTVDELAPLPEHGFRTLMHPDDRARLEAEFGMDLEGRPDRFSVEVRVRHKAGAWVWLLARGRVLARDANGRPVRTAGIHLDITERKRLEQQLVAERDYMSRLMETNVSGITALDGDGRIIYANREAEAILGLSAAAVDRRSYADPRWQITAPDGGPLADAELPFTRAMTEGRVVRDVRFAIAWPDGTRRQLSVNAAPLLAEGLQARVVCAITDITEQVATEAALRSAAERAEAASEAKSRFLANMSHEIRTPLNGVLGMAQVLEEELSEPRHRRMLEVIRESGEMLLGVLNDVLDMSKIEAGKVTLEQVAFVPADLARRIEAMHALRAAEKHLSLEVVAAPGAERARLGDPGRVEQMLHNLVGNAVKFTEAGGVRVTLEGGCGPLRVVVHDTGIGMTDDQLARIFEDFEQADGTVTRRFGGTGLGMSIVRRLVALMGGQITVDSIPGAGTQVRVALPLPLAEGGPRDAVPVPAQPLEGLRALAADDNATNRLILQAMLSALGGAVTMVPDGQAAVEAWAPGRFDLILLDISMPGLDGLGALAAIRLREAEAGVPPAPAVAITANAMAHQVAQYMGAGFAAHVGKPFRREDLARTLLRVLDRAPPAQR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292&amp;from=22823&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPGRAPPQRHRLGAPGAERWVEVTAAPRGPGAAPGHVVALRDVTAAARATHEVEQLSQIARRTGDLVVITDTDHRIDWVNPAFEARTGWRLEDVRGHLPESILQSPEADAAEVARIRGALLEGASASGLLLCRTRTDDAFWAEIDAYPLRDSDGRTTGHVTLATDVTARRAQEAKLERLAQEATRARERLEMAVEALPDAFAFFDAEDRLVLCNERYRTFHPRSGYMISPGVQFADFARAVAHSGDVADAVGREEAWLAERLASHREGRPGGEHRMADGSWLRVIERVTADGGRVGMRVDITELKEAERRLADIIHGAQVGTWEWHLASGENRINARWAEIVGYCPDEIDRSGIDLWRALVHPDDLARAEARLARVFAREIDQFEYELRMRHRDGHWVWVLSRGRVARWSPDGKPEVMAGVHMDITALKRAEERLEAILHAAEAGTWETDPARGGMRINDRWAEMLGYTVDELAPLPEHGFRTLMHPDDRARLEAEFGMDLEGRPDRFSVEVRVRHKAGAWVWLLARGRVLARDANGRPVRTAGIHLDITERKRLEQQLVAERDYMSRLMETNVSGITALDGDGRIIYANREAEAILGLSAAAVDRRSYADPRWQITAPDGGPLADAELPFTRAMTEGRVVRDVRFAIAWPDGTRRQLSVNAAPLLAEGLQARVVCAITDITEQVATEAALRSAAERAEAASEAKSRFLANMSHEIRTPLNGVLGMAQVLEEELSEPRHRRMLEVIRESGEMLLGVLNDVLDMSKIEAGKVTLEQVAFVPADLARRIEAMHALRAAEKHLSLEVVAAPGAERARLGDPGRVEQMLHNLVGNAVKFTEAGGVRVTLEGGCGPLRVVVHDTGIGMTDDQLARIFEDFEQADGTVTRRFGGTGLGMSIVRRLVALMGGQITVDSIPGAGTQVRVALPLPLAEGGPRDAVPVPAQPLEGLRALAADDNATNRLILQAMLSALGGAVTMVPDGQAAVEAWAPGRFDLILLDISMPGLDGLGALAAIRLREAEAGVPPAPAVAITANAMAHQVAQYMGAGFAAHVGKPFRREDLARTLLRVLDRAPPAQR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCGGGGCGGGCACCGCCGCAGCGCCACCGGCTGGGCGCCCCCGGCGCCGAGCGGTGGGTCGAGGTGACAGCCGCCCCGCGCGGCCCCGGTGCCGCGCCGGGCCATGTGGTGGCGCTGCGCGATGTCACCGCCGCCGCGCGCGCCACCCACGAGGTCGAACAGCTGAGCCAGATCGCCCGGCGCACCGGCGATCTGGTGGTCATCACCGATACCGACCACCGCATCGACTGGGTCAACCCGGCCTTTGAGGCGCGCACCGGCTGGCGGCTGGAGGATGTCCGCGGCCACCTCCCCGAGAGCATCCTGCAAAGCCCCGAGGCCGACGCGGCCGAGGTCGCGCGCATCCGCGGCGCGCTGCTGGAGGGGGCGTCGGCCAGCGGGCTCTTGCTGTGCCGCACCCGGACGGACGATGCCTTCTGGGCCGAGATCGACGCCTATCCGCTGCGGGACTCGGACGGGCGGACGACGGGCCATGTCACGCTGGCCACCGACGTCACCGCGCGCCGCGCGCAGGAGGCCAAGCTGGAGCGCCTTGCGCAGGAGGCCACGCGGGCGCGCGAGCGGCTGGAGATGGCGGTGGAGGCGCTGCCGGACGCGTTTGCGTTTTTCGACGCCGAGGACCGGCTGGTGCTGTGCAACGAGCGCTATCGCACCTTTCATCCGCGGTCGGGGTACATGATCTCGCCGGGGGTGCAGTTCGCGGACTTTGCCCGGGCGGTGGCCCACAGCGGCGATGTCGCCGACGCCGTGGGCCGCGAGGAGGCGTGGCTGGCCGAGCGCCTGGCCTCGCACCGCGAGGGGCGCCCGGGCGGCGAGCACCGCATGGCCGACGGCAGCTGGCTGCGGGTGATCGAGCGCGTCACCGCCGACGGCGGCCGCGTCGGCATGCGCGTCGACATCACCGAGCTGAAGGAGGCCGAGCGGCGGCTGGCCGACATCATCCACGGCGCGCAGGTCGGCACCTGGGAGTGGCACCTGGCCAGCGGCGAGAACCGCATCAACGCGCGCTGGGCCGAGATCGTGGGCTATTGCCCCGACGAGATCGACCGCTCGGGCATCGATCTGTGGCGGGCGCTGGTGCACCCCGACGACCTGGCCCGCGCCGAGGCGCGGCTGGCGCGGGTGTTCGCCCGCGAGATCGACCAGTTCGAGTATGAATTGCGCATGCGCCACCGTGACGGCCACTGGGTCTGGGTGCTGTCGCGCGGGCGGGTGGCGCGTTGGTCGCCCGACGGCAAGCCCGAGGTGATGGCCGGGGTGCACATGGACATCACCGCCCTCAAGCGCGCCGAGGAACGGCTGGAGGCGATCCTGCACGCCGCCGAAGCCGGCACCTGGGAGACCGATCCCGCGCGCGGCGGCATGCGCATCAACGACCGCTGGGCGGAGATGCTGGGCTACACCGTGGACGAGCTTGCGCCCCTGCCGGAACACGGTTTTCGCACCCTGATGCACCCCGACGACCGCGCCCGGCTGGAGGCGGAGTTCGGCATGGACCTGGAGGGCCGCCCCGATCGCTTCAGCGTGGAGGTGCGGGTGCGCCACAAGGCCGGTGCCTGGGTCTGGCTGCTGGCGCGCGGCCGGGTGCTGGCGCGCGACGCCAACGGCCGGCCGGTGCGCACCGCGGGCATCCACCTCGACATCACCGAGCGCAAGCGGCTGGAGCAGCAGCTGGTGGCCGAGCGCGATTACATGTCGCGGCTGATGGAGACGAATGTCTCGGGCATCACCGCGCTGGATGGCGACGGGCGCATCATCTATGCCAACCGCGAGGCCGAGGCGATCCTGGGCTTGTCGGCGGCGGCGGTGGACCGGCGCAGCTATGCCGATCCGCGCTGGCAGATCACCGCCCCCGACGGCGGGCCGCTGGCCGATGCCGAGCTGCCCTTTACCCGCGCCATGACCGAGGGGCGGGTGGTGCGCGACGTGCGCTTCGCCATCGCCTGGCCCGACGGCACCCGGCGGCAGCTGTCGGTCAACGCGGCGCCGCTGCTGGCCGAGGGGCTGCAGGCGCGGGTGGTCTGCGCGATCACCGACATCACCGAACAGGTCGCCACCGAAGCCGCCCTGCGCAGCGCCGCCGAGCGGGCCGAGGCCGCCAGCGAGGCCAAGTCGCGGTTCCTGGCCAACATGAGCCACGAGATTCGCACCCCCCTGAACGGGGTCCTCGGGATGGCGCAGGTGCTGGAGGAGGAGCTGTCCGAGCCGCGCCACCGCCGCATGCTGGAGGTGATCCGCGAATCCGGCGAGATGCTGCTGGGCGTGCTCAACGATGTCCTCGACATGTCCAAGATCGAGGCCGGCAAGGTTACGCTGGAGCAGGTCGCCTTCGTGCCCGCCGATCTGGCACGGCGGATCGAGGCGATGCACGCCCTGCGCGCCGCCGAGAAGCATCTGTCGCTGGAGGTCGTGGCCGCCCCCGGCGCCGAGCGCGCGCGGCTGGGCGATCCGGGCCGGGTGGAGCAGATGCTGCACAACCTGGTCGGCAACGCCGTCAAGTTCACCGAGGCGGGCGGCGTGCGGGTGACGCTGGAGGGGGGGTGTGGCCCGCTGCGGGTGGTCGTCCATGACACCGGGATCGGCATGACGGACGATCAGTTGGCGCGCATCTTCGAGGATTTCGAACAGGCCGACGGCACGGTGACCCGCCGGTTCGGGGGCACCGGGCTGGGCATGTCCATCGTGCGCCGCCTGGTGGCGCTGATGGGCGGCCAGATCACGGTCGACAGCATCCCTGGCGCGGGCACCCAGGTGCGCGTCGCGCTGCCGCTGCCGCTGGCCGAGGGTGGCCCGCGCGATGCCGTCCCCGTGCCCGCCCAGCCGCTGGAGGGGCTGCGCGCGCTGGCGGCCGACGACAACGCCACCAACCGGCTGATCCTCCAGGCGATGCTGTCGGCGCTGGGCGGGGCCGTGACGATGGTGCCCGACGGGCAGGCCGCGGTGGAGGCGTGGGCGCCGGGGCGGTTCGATCTGATCCTGCTGGACATCTCGATGCCGGGGCTGGACGGTCTGGGCGCGCTGGCCGCGATCCGCCTGCGCGAGGCCGAGGCGGGTGTGCCACCCGCGCCCGCGGTGGCGATCACCGCCAACGCCATGGCCCATCAGGTGGCGCAGTACATGGGCGCGGGCTTTGCCGCCCATGTCGGCAAGCCGTTCCGCCGCGAGGACCTGGCGCGGACGCTGTTGCGCGTGCTGGACCGCGCCCCGCCCGCGCAGCGGTGA\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 21261,
                "end": 32768,
                "tool": "rule-based-clusters",
                "neighbouring_start": 11261,
                "neighbouring_end": 36052,
                "product": "betalactone",
                "height": 2,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [
            {
                "start": 23454,
                "end": 23456,
                "strand": -1,
                "containedBy": [
                    "KKHPANEM_02428"
                ]
            }
        ],
        "type": "betalactone",
        "products": [
            "betalactone"
        ],
        "anchor": "r292c1"
    }
};
var details_data = {
    "nrpspks": {},
    "pfam": {}
};
var resultsData = {};
