var recordData = [
 {
  "length": 2550,
  "seq_id": "NZ_NHSD01000001.1",
  "regions": []
 },
 {
  "length": 2567,
  "seq_id": "NZ_NHSD01000002.1",
  "regions": []
 },
 {
  "length": 2513,
  "seq_id": "NZ_NHSD01000003.1",
  "regions": []
 },
 {
  "length": 2611,
  "seq_id": "NZ_NHSD01000004.1",
  "regions": []
 },
 {
  "length": 3019,
  "seq_id": "NZ_NHSD01000005.1",
  "regions": []
 },
 {
  "length": 2583,
  "seq_id": "NZ_NHSD01000006.1",
  "regions": []
 },
 {
  "length": 2589,
  "seq_id": "NZ_NHSD01000007.1",
  "regions": []
 },
 {
  "length": 2627,
  "seq_id": "NZ_NHSD01000008.1",
  "regions": []
 },
 {
  "length": 2688,
  "seq_id": "NZ_NHSD01000009.1",
  "regions": []
 },
 {
  "length": 2752,
  "seq_id": "NZ_NHSD01000010.1",
  "regions": []
 },
 {
  "length": 2763,
  "seq_id": "NZ_NHSD01000011.1",
  "regions": []
 },
 {
  "length": 2937,
  "seq_id": "NZ_NHSD01000012.1",
  "regions": []
 },
 {
  "length": 3200,
  "seq_id": "NZ_NHSD01000013.1",
  "regions": []
 },
 {
  "length": 2577,
  "seq_id": "NZ_NHSD01000014.1",
  "regions": []
 },
 {
  "length": 2599,
  "seq_id": "NZ_NHSD01000015.1",
  "regions": []
 },
 {
  "length": 2594,
  "seq_id": "NZ_NHSD01000016.1",
  "regions": []
 },
 {
  "length": 2610,
  "seq_id": "NZ_NHSD01000017.1",
  "regions": []
 },
 {
  "length": 2612,
  "seq_id": "NZ_NHSD01000018.1",
  "regions": []
 },
 {
  "length": 2657,
  "seq_id": "NZ_NHSD01000019.1",
  "regions": []
 },
 {
  "length": 2653,
  "seq_id": "NZ_NHSD01000020.1",
  "regions": []
 },
 {
  "length": 2693,
  "seq_id": "NZ_NHSD01000021.1",
  "regions": []
 },
 {
  "length": 2758,
  "seq_id": "NZ_NHSD01000022.1",
  "regions": []
 },
 {
  "length": 2780,
  "seq_id": "NZ_NHSD01000023.1",
  "regions": []
 },
 {
  "length": 2817,
  "seq_id": "NZ_NHSD01000024.1",
  "regions": []
 },
 {
  "length": 2820,
  "seq_id": "NZ_NHSD01000025.1",
  "regions": []
 },
 {
  "length": 2861,
  "seq_id": "NZ_NHSD01000026.1",
  "regions": []
 },
 {
  "length": 2873,
  "seq_id": "NZ_NHSD01000027.1",
  "regions": []
 },
 {
  "length": 2885,
  "seq_id": "NZ_NHSD01000028.1",
  "regions": []
 },
 {
  "length": 2888,
  "seq_id": "NZ_NHSD01000029.1",
  "regions": []
 },
 {
  "length": 2974,
  "seq_id": "NZ_NHSD01000030.1",
  "regions": []
 },
 {
  "length": 3041,
  "seq_id": "NZ_NHSD01000031.1",
  "regions": []
 },
 {
  "length": 3999,
  "seq_id": "NZ_NHSD01000032.1",
  "regions": []
 },
 {
  "length": 3103,
  "seq_id": "NZ_NHSD01000033.1",
  "regions": []
 },
 {
  "length": 3047,
  "seq_id": "NZ_NHSD01000034.1",
  "regions": []
 },
 {
  "length": 3124,
  "seq_id": "NZ_NHSD01000035.1",
  "regions": []
 },
 {
  "length": 3076,
  "seq_id": "NZ_NHSD01000036.1",
  "regions": []
 },
 {
  "length": 3094,
  "seq_id": "NZ_NHSD01000037.1",
  "regions": []
 },
 {
  "length": 3214,
  "seq_id": "NZ_NHSD01000038.1",
  "regions": []
 },
 {
  "length": 3230,
  "seq_id": "NZ_NHSD01000039.1",
  "regions": []
 },
 {
  "length": 3350,
  "seq_id": "NZ_NHSD01000040.1",
  "regions": []
 },
 {
  "length": 3357,
  "seq_id": "NZ_NHSD01000041.1",
  "regions": []
 },
 {
  "length": 3292,
  "seq_id": "NZ_NHSD01000042.1",
  "regions": []
 },
 {
  "length": 3339,
  "seq_id": "NZ_NHSD01000043.1",
  "regions": []
 },
 {
  "length": 3395,
  "seq_id": "NZ_NHSD01000044.1",
  "regions": []
 },
 {
  "length": 3404,
  "seq_id": "NZ_NHSD01000045.1",
  "regions": []
 },
 {
  "length": 3619,
  "seq_id": "NZ_NHSD01000046.1",
  "regions": []
 },
 {
  "length": 3517,
  "seq_id": "NZ_NHSD01000047.1",
  "regions": []
 },
 {
  "length": 3467,
  "seq_id": "NZ_NHSD01000048.1",
  "regions": []
 },
 {
  "length": 3550,
  "seq_id": "NZ_NHSD01000049.1",
  "regions": []
 },
 {
  "length": 3464,
  "seq_id": "NZ_NHSD01000050.1",
  "regions": []
 },
 {
  "length": 3526,
  "seq_id": "NZ_NHSD01000051.1",
  "regions": []
 },
 {
  "length": 3570,
  "seq_id": "NZ_NHSD01000052.1",
  "regions": []
 },
 {
  "length": 3599,
  "seq_id": "NZ_NHSD01000053.1",
  "regions": []
 },
 {
  "length": 3625,
  "seq_id": "NZ_NHSD01000054.1",
  "regions": []
 },
 {
  "length": 3690,
  "seq_id": "NZ_NHSD01000055.1",
  "regions": []
 },
 {
  "length": 3855,
  "seq_id": "NZ_NHSD01000056.1",
  "regions": []
 },
 {
  "length": 3806,
  "seq_id": "NZ_NHSD01000057.1",
  "regions": []
 },
 {
  "length": 3732,
  "seq_id": "NZ_NHSD01000058.1",
  "regions": []
 },
 {
  "length": 3877,
  "seq_id": "NZ_NHSD01000059.1",
  "regions": []
 },
 {
  "length": 3897,
  "seq_id": "NZ_NHSD01000060.1",
  "regions": []
 },
 {
  "length": 3917,
  "seq_id": "NZ_NHSD01000061.1",
  "regions": []
 },
 {
  "length": 3985,
  "seq_id": "NZ_NHSD01000062.1",
  "regions": []
 },
 {
  "length": 3929,
  "seq_id": "NZ_NHSD01000063.1",
  "regions": []
 },
 {
  "length": 4866,
  "seq_id": "NZ_NHSD01000064.1",
  "regions": []
 },
 {
  "length": 4243,
  "seq_id": "NZ_NHSD01000065.1",
  "regions": []
 },
 {
  "length": 4043,
  "seq_id": "NZ_NHSD01000066.1",
  "regions": []
 },
 {
  "length": 4157,
  "seq_id": "NZ_NHSD01000067.1",
  "regions": []
 },
 {
  "length": 4095,
  "seq_id": "NZ_NHSD01000068.1",
  "regions": []
 },
 {
  "length": 4065,
  "seq_id": "NZ_NHSD01000069.1",
  "regions": []
 },
 {
  "length": 4354,
  "seq_id": "NZ_NHSD01000070.1",
  "regions": []
 },
 {
  "length": 4477,
  "seq_id": "NZ_NHSD01000071.1",
  "regions": []
 },
 {
  "length": 4442,
  "seq_id": "NZ_NHSD01000072.1",
  "regions": []
 },
 {
  "length": 4505,
  "seq_id": "NZ_NHSD01000073.1",
  "regions": []
 },
 {
  "length": 4357,
  "seq_id": "NZ_NHSD01000074.1",
  "regions": []
 },
 {
  "length": 4470,
  "seq_id": "NZ_NHSD01000075.1",
  "regions": []
 },
 {
  "length": 4602,
  "seq_id": "NZ_NHSD01000076.1",
  "regions": []
 },
 {
  "length": 4608,
  "seq_id": "NZ_NHSD01000077.1",
  "regions": []
 },
 {
  "length": 4669,
  "seq_id": "NZ_NHSD01000078.1",
  "regions": []
 },
 {
  "length": 4718,
  "seq_id": "NZ_NHSD01000079.1",
  "regions": []
 },
 {
  "length": 4726,
  "seq_id": "NZ_NHSD01000080.1",
  "regions": []
 },
 {
  "length": 4740,
  "seq_id": "NZ_NHSD01000081.1",
  "regions": []
 },
 {
  "length": 4806,
  "seq_id": "NZ_NHSD01000082.1",
  "regions": []
 },
 {
  "length": 4806,
  "seq_id": "NZ_NHSD01000083.1",
  "regions": []
 },
 {
  "length": 4815,
  "seq_id": "NZ_NHSD01000084.1",
  "regions": []
 },
 {
  "length": 5158,
  "seq_id": "NZ_NHSD01000085.1",
  "regions": []
 },
 {
  "length": 5096,
  "seq_id": "NZ_NHSD01000086.1",
  "regions": []
 },
 {
  "length": 5023,
  "seq_id": "NZ_NHSD01000087.1",
  "regions": []
 },
 {
  "length": 5160,
  "seq_id": "NZ_NHSD01000088.1",
  "regions": []
 },
 {
  "length": 5148,
  "seq_id": "NZ_NHSD01000089.1",
  "regions": []
 },
 {
  "length": 5697,
  "seq_id": "NZ_NHSD01000090.1",
  "regions": []
 },
 {
  "length": 5288,
  "seq_id": "NZ_NHSD01000091.1",
  "regions": []
 },
 {
  "length": 5368,
  "seq_id": "NZ_NHSD01000092.1",
  "regions": []
 },
 {
  "length": 5368,
  "seq_id": "NZ_NHSD01000093.1",
  "regions": []
 },
 {
  "length": 5526,
  "seq_id": "NZ_NHSD01000094.1",
  "regions": []
 },
 {
  "length": 5549,
  "seq_id": "NZ_NHSD01000095.1",
  "regions": []
 },
 {
  "length": 5599,
  "seq_id": "NZ_NHSD01000096.1",
  "regions": []
 },
 {
  "length": 5227,
  "seq_id": "NZ_NHSD01000097.1",
  "regions": []
 },
 {
  "length": 5763,
  "seq_id": "NZ_NHSD01000098.1",
  "regions": []
 },
 {
  "length": 6019,
  "seq_id": "NZ_NHSD01000099.1",
  "regions": []
 },
 {
  "length": 5850,
  "seq_id": "NZ_NHSD01000100.1",
  "regions": []
 },
 {
  "length": 12198,
  "seq_id": "NZ_NHSD01000101.1",
  "regions": []
 },
 {
  "length": 12443,
  "seq_id": "NZ_NHSD01000102.1",
  "regions": []
 },
 {
  "length": 12493,
  "seq_id": "NZ_NHSD01000103.1",
  "regions": []
 },
 {
  "length": 12686,
  "seq_id": "NZ_NHSD01000104.1",
  "regions": []
 },
 {
  "length": 12510,
  "seq_id": "NZ_NHSD01000105.1",
  "regions": []
 },
 {
  "length": 12531,
  "seq_id": "NZ_NHSD01000106.1",
  "regions": []
 },
 {
  "length": 12716,
  "seq_id": "NZ_NHSD01000107.1",
  "regions": []
 },
 {
  "length": 13045,
  "seq_id": "NZ_NHSD01000108.1",
  "regions": []
 },
 {
  "length": 12724,
  "seq_id": "NZ_NHSD01000109.1",
  "regions": []
 },
 {
  "length": 13030,
  "seq_id": "NZ_NHSD01000110.1",
  "regions": []
 },
 {
  "length": 13082,
  "seq_id": "NZ_NHSD01000111.1",
  "regions": []
 },
 {
  "length": 13298,
  "seq_id": "NZ_NHSD01000112.1",
  "regions": []
 },
 {
  "length": 13163,
  "seq_id": "NZ_NHSD01000113.1",
  "regions": []
 },
 {
  "length": 13245,
  "seq_id": "NZ_NHSD01000114.1",
  "regions": []
 },
 {
  "length": 13309,
  "seq_id": "NZ_NHSD01000115.1",
  "regions": []
 },
 {
  "length": 13658,
  "seq_id": "NZ_NHSD01000116.1",
  "regions": []
 },
 {
  "length": 13482,
  "seq_id": "NZ_NHSD01000117.1",
  "regions": []
 },
 {
  "length": 13548,
  "seq_id": "NZ_NHSD01000118.1",
  "regions": []
 },
 {
  "length": 13820,
  "seq_id": "NZ_NHSD01000119.1",
  "regions": []
 },
 {
  "length": 14066,
  "seq_id": "NZ_NHSD01000120.1",
  "regions": []
 },
 {
  "length": 13860,
  "seq_id": "NZ_NHSD01000121.1",
  "regions": []
 },
 {
  "length": 13936,
  "seq_id": "NZ_NHSD01000122.1",
  "regions": []
 },
 {
  "length": 14025,
  "seq_id": "NZ_NHSD01000123.1",
  "regions": []
 },
 {
  "length": 14249,
  "seq_id": "NZ_NHSD01000124.1",
  "regions": []
 },
 {
  "length": 14247,
  "seq_id": "NZ_NHSD01000125.1",
  "regions": []
 },
 {
  "length": 14263,
  "seq_id": "NZ_NHSD01000126.1",
  "regions": []
 },
 {
  "length": 14603,
  "seq_id": "NZ_NHSD01000127.1",
  "regions": []
 },
 {
  "length": 16289,
  "seq_id": "NZ_NHSD01000128.1",
  "regions": []
 },
 {
  "length": 14787,
  "seq_id": "NZ_NHSD01000129.1",
  "regions": []
 },
 {
  "length": 14805,
  "seq_id": "NZ_NHSD01000130.1",
  "regions": []
 },
 {
  "length": 14820,
  "seq_id": "NZ_NHSD01000131.1",
  "regions": []
 },
 {
  "length": 15182,
  "seq_id": "NZ_NHSD01000132.1",
  "regions": []
 },
 {
  "length": 15672,
  "seq_id": "NZ_NHSD01000133.1",
  "regions": []
 },
 {
  "length": 16058,
  "seq_id": "NZ_NHSD01000134.1",
  "regions": []
 },
 {
  "length": 16597,
  "seq_id": "NZ_NHSD01000135.1",
  "regions": []
 },
 {
  "length": 16955,
  "seq_id": "NZ_NHSD01000136.1",
  "regions": []
 },
 {
  "length": 9722,
  "seq_id": "NZ_NHSD01000137.1",
  "regions": []
 },
 {
  "length": 9449,
  "seq_id": "NZ_NHSD01000138.1",
  "regions": []
 },
 {
  "length": 9345,
  "seq_id": "NZ_NHSD01000139.1",
  "regions": []
 },
 {
  "length": 9638,
  "seq_id": "NZ_NHSD01000140.1",
  "regions": []
 },
 {
  "length": 9184,
  "seq_id": "NZ_NHSD01000141.1",
  "regions": []
 },
 {
  "length": 9148,
  "seq_id": "NZ_NHSD01000142.1",
  "regions": []
 },
 {
  "length": 8901,
  "seq_id": "NZ_NHSD01000143.1",
  "regions": []
 },
 {
  "length": 9325,
  "seq_id": "NZ_NHSD01000144.1",
  "regions": []
 },
 {
  "length": 8649,
  "seq_id": "NZ_NHSD01000145.1",
  "regions": []
 },
 {
  "length": 8634,
  "seq_id": "NZ_NHSD01000146.1",
  "regions": []
 },
 {
  "length": 2649,
  "seq_id": "NZ_NHSD01000147.1",
  "regions": []
 },
 {
  "length": 8633,
  "seq_id": "NZ_NHSD01000148.1",
  "regions": []
 },
 {
  "length": 8382,
  "seq_id": "NZ_NHSD01000149.1",
  "regions": []
 },
 {
  "length": 8373,
  "seq_id": "NZ_NHSD01000150.1",
  "regions": []
 },
 {
  "length": 8364,
  "seq_id": "NZ_NHSD01000151.1",
  "regions": []
 },
 {
  "length": 8277,
  "seq_id": "NZ_NHSD01000152.1",
  "regions": []
 },
 {
  "length": 10593,
  "seq_id": "NZ_NHSD01000153.1",
  "regions": []
 },
 {
  "length": 8184,
  "seq_id": "NZ_NHSD01000154.1",
  "regions": []
 },
 {
  "length": 7899,
  "seq_id": "NZ_NHSD01000155.1",
  "regions": []
 },
 {
  "length": 7839,
  "seq_id": "NZ_NHSD01000156.1",
  "regions": []
 },
 {
  "length": 7832,
  "seq_id": "NZ_NHSD01000157.1",
  "regions": []
 },
 {
  "length": 7819,
  "seq_id": "NZ_NHSD01000158.1",
  "regions": []
 },
 {
  "length": 7809,
  "seq_id": "NZ_NHSD01000159.1",
  "regions": []
 },
 {
  "length": 7745,
  "seq_id": "NZ_NHSD01000160.1",
  "regions": []
 },
 {
  "length": 7745,
  "seq_id": "NZ_NHSD01000161.1",
  "regions": []
 },
 {
  "length": 7687,
  "seq_id": "NZ_NHSD01000162.1",
  "regions": []
 },
 {
  "length": 7553,
  "seq_id": "NZ_NHSD01000163.1",
  "regions": []
 },
 {
  "length": 7409,
  "seq_id": "NZ_NHSD01000164.1",
  "regions": []
 },
 {
  "length": 7356,
  "seq_id": "NZ_NHSD01000165.1",
  "regions": []
 },
 {
  "length": 7337,
  "seq_id": "NZ_NHSD01000166.1",
  "regions": []
 },
 {
  "length": 7293,
  "seq_id": "NZ_NHSD01000167.1",
  "regions": []
 },
 {
  "length": 7272,
  "seq_id": "NZ_NHSD01000168.1",
  "regions": []
 },
 {
  "length": 7098,
  "seq_id": "NZ_NHSD01000169.1",
  "regions": []
 },
 {
  "length": 7086,
  "seq_id": "NZ_NHSD01000170.1",
  "regions": []
 },
 {
  "length": 6926,
  "seq_id": "NZ_NHSD01000171.1",
  "regions": []
 },
 {
  "length": 6919,
  "seq_id": "NZ_NHSD01000172.1",
  "regions": []
 },
 {
  "length": 6863,
  "seq_id": "NZ_NHSD01000173.1",
  "regions": []
 },
 {
  "length": 7159,
  "seq_id": "NZ_NHSD01000174.1",
  "regions": []
 },
 {
  "length": 3668,
  "seq_id": "NZ_NHSD01000175.1",
  "regions": []
 },
 {
  "length": 9670,
  "seq_id": "NZ_NHSD01000176.1",
  "regions": []
 },
 {
  "length": 7095,
  "seq_id": "NZ_NHSD01000177.1",
  "regions": []
 },
 {
  "length": 11375,
  "seq_id": "NZ_NHSD01000178.1",
  "regions": []
 },
 {
  "length": 3160,
  "seq_id": "NZ_NHSD01000179.1",
  "regions": []
 },
 {
  "length": 8483,
  "seq_id": "NZ_NHSD01000180.1",
  "regions": []
 },
 {
  "length": 2654,
  "seq_id": "NZ_NHSD01000181.1",
  "regions": []
 },
 {
  "length": 8682,
  "seq_id": "NZ_NHSD01000182.1",
  "regions": []
 },
 {
  "length": 2881,
  "seq_id": "NZ_NHSD01000183.1",
  "regions": []
 },
 {
  "length": 10205,
  "seq_id": "NZ_NHSD01000184.1",
  "regions": []
 },
 {
  "length": 4762,
  "seq_id": "NZ_NHSD01000185.1",
  "regions": []
 },
 {
  "length": 19821,
  "seq_id": "NZ_NHSD01000186.1",
  "regions": []
 },
 {
  "length": 6760,
  "seq_id": "NZ_NHSD01000187.1",
  "regions": []
 },
 {
  "length": 6134,
  "seq_id": "NZ_NHSD01000188.1",
  "regions": []
 },
 {
  "length": 31422,
  "seq_id": "NZ_NHSD01000189.1",
  "regions": []
 },
 {
  "length": 3026,
  "seq_id": "NZ_NHSD01000190.1",
  "regions": []
 },
 {
  "length": 10812,
  "seq_id": "NZ_NHSD01000191.1",
  "regions": []
 },
 {
  "length": 7076,
  "seq_id": "NZ_NHSD01000192.1",
  "regions": []
 },
 {
  "length": 3581,
  "seq_id": "NZ_NHSD01000193.1",
  "regions": []
 },
 {
  "length": 8465,
  "seq_id": "NZ_NHSD01000194.1",
  "regions": []
 },
 {
  "length": 4652,
  "seq_id": "NZ_NHSD01000195.1",
  "regions": []
 },
 {
  "length": 19294,
  "seq_id": "NZ_NHSD01000196.1",
  "regions": []
 },
 {
  "length": 6845,
  "seq_id": "NZ_NHSD01000197.1",
  "regions": []
 },
 {
  "length": 23336,
  "seq_id": "NZ_NHSD01000198.1",
  "regions": []
 },
 {
  "length": 5275,
  "seq_id": "NZ_NHSD01000199.1",
  "regions": []
 },
 {
  "length": 7274,
  "seq_id": "NZ_NHSD01000200.1",
  "regions": []
 },
 {
  "length": 3778,
  "seq_id": "NZ_NHSD01000201.1",
  "regions": []
 },
 {
  "length": 8461,
  "seq_id": "NZ_NHSD01000202.1",
  "regions": []
 },
 {
  "length": 17762,
  "seq_id": "NZ_NHSD01000203.1",
  "regions": []
 },
 {
  "length": 6731,
  "seq_id": "NZ_NHSD01000204.1",
  "regions": []
 },
 {
  "length": 7247,
  "seq_id": "NZ_NHSD01000205.1",
  "regions": []
 },
 {
  "length": 16623,
  "seq_id": "NZ_NHSD01000206.1",
  "regions": []
 },
 {
  "length": 2568,
  "seq_id": "NZ_NHSD01000207.1",
  "regions": []
 },
 {
  "length": 7041,
  "seq_id": "NZ_NHSD01000208.1",
  "regions": []
 },
 {
  "length": 3576,
  "seq_id": "NZ_NHSD01000209.1",
  "regions": []
 },
 {
  "length": 7802,
  "seq_id": "NZ_NHSD01000210.1",
  "regions": []
 },
 {
  "length": 4030,
  "seq_id": "NZ_NHSD01000211.1",
  "regions": []
 },
 {
  "length": 7619,
  "seq_id": "NZ_NHSD01000212.1",
  "regions": []
 },
 {
  "length": 3920,
  "seq_id": "NZ_NHSD01000213.1",
  "regions": []
 },
 {
  "length": 3149,
  "seq_id": "NZ_NHSD01000214.1",
  "regions": []
 },
 {
  "length": 11364,
  "seq_id": "NZ_NHSD01000215.1",
  "regions": []
 },
 {
  "length": 8495,
  "seq_id": "NZ_NHSD01000216.1",
  "regions": []
 },
 {
  "length": 4712,
  "seq_id": "NZ_NHSD01000217.1",
  "regions": []
 },
 {
  "length": 19419,
  "seq_id": "NZ_NHSD01000218.1",
  "regions": [
   {
    "start": 1,
    "end": 9387,
    "idx": 1,
    "orfs": [
     {
      "start": 435,
      "end": 1055,
      "strand": -1,
      "locus_tag": "KKHPANEM_01436",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01436</span></strong><br>\n \n  Cytidylate kinase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01436</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">cmk</span><br>\n \n Location: 435 - 1,055,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01436 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02224.20 (Cytidylate kinase): [8:45](score: 41.0, e-value: 1.9e-10)<br>\n \n  PF02224.20 (Cytidylate kinase): [64:201](score: 127.8, e-value: 5e-37)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01436 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02224.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004127' target='_blank'>GO:0004127</a>: cytidylate kinase activity<br>\n  \n   PF02224.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02224.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006139' target='_blank'>GO:0006139</a>: nucleobase-containing compound metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01436\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=11055\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01436\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01436\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGAGGGCGCGCGGTTCACGGTCGCGCTGGATGGGCCGGCGGCGTCGGGCAAGGGCACGCTGGGGCGCGCGCTGGCGCAGGCGTGCGGGTTTGCGCATCTCGATACGGGGCTTCTGTATCGTGCCGTGGGTGCGCGGGCGGCGGCGGGCGAGGACCCGGTGGCCGCAGCGCGCAGCCTCGTGCCCGAGGATCTGTCGCGCGCCGATCTGCGCAGCGCCGCCGCAGGGCAGGCCGCCAGCCGCGTGGCGGCACTGGAAGAGGTGCGCGCGGCGCTGCTGGCATTCCAGCGGGATTTCGCGCGCAGACCCGGCGGAGCGGTGCTGGACGGGCGCGACATCGGCACCGTGGTCTGCCCGGGCGCAGAGGTGAAGCTGTTCGTCACCGCATCGGATGCGGTGCGGTCGCGGCGGCGTTGGCTGGAGCTGCGCGCGCACCAGCCCGACCTGACGCAGGTGGAGGTTCTCGAAGACCTGCGTGCCCGCGATGCCCGCGACCGCGAACGGGCAGCCGCGCCGCTGCGACCGGCGCCGGACGCGATGCTTCTGGACACCTCGGACCTGACGATCGAGGCGGCGATCGCACGGGCGCTCTCGGCGGTCGAGGCCGCCCGCCGCTGA",
      "translation": "MAEGARFTVALDGPAASGKGTLGRALAQACGFAHLDTGLLYRAVGARAAAGEDPVAAARSLVPEDLSRADLRSAAAGQAASRVAALEEVRAALLAFQRDFARRPGGAVLDGRDIGTVVCPGAEVKLFVTASDAVRSRRRWLELRAHQPDLTQVEVLEDLRARDARDRERAAAPLRPAPDAMLLDTSDLTIEAAIARALSAVEAARR",
      "product": "Cytidylate kinase"
     },
     {
      "start": 1048,
      "end": 2397,
      "strand": -1,
      "locus_tag": "KKHPANEM_01437",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01437</span></strong><br>\n \n  3-phosphoshikimate 1-carboxyvinyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01437</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">aroA</span><br>\n \n Location: 1,048 - 2,397,\n (total: 1350 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01437 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00275.22 (EPSP synthase (3-phosphoshikimate 1-carboxyvinyltransferase)): [13:436](score: 327.7, e-value: 9.4e-98)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01437 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01356 (aroA: 3-phosphoshikimate 1-carboxyvinyltransferase): [21:443](score: 382.5, e-value: 5.1e-115)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01437 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00275.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01437\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=12397\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/aroA_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01437\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01437\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGCCACTTCCGCGCCCATGCCCCTGACCGCCCGTGCCGGCGGGGCGCTGCGGGGCACCACCGACGTGCCCGGCGACAAGTCCATCAGCCACCGCGCTCTGATCCTGGGTGCGCTGGCGGTGGGCGAGACGCGCATCACCGGGCTGCTGGAAGGGCAGGATGTCCTCGACACCGCCGCCGCGATGCGCGCCTTCGGGGCCGAGGTGATCCGCCACGGACCCGGCAGCTGGTCGGTGCATGGCGTGGGCGTGGGCGGGTTCGGCGAACCGTCGGGTGTGATCGACTGCGGCAACTCGGGCACCGGGGTGCGGCTGATCATGGGCGCGATGGCGACCACGCCGATCACCGCCACCTTCACCGGCGATGCCAGCCTGTGCCGCCGCCCCATGGGCCGCGTGACCGATCCGCTGGCGCTGTTTGGTGCACAGGCGGTGGGGCGCGCGGGCGGACGGCTGCCGATGACGCTGGTGGGCGCGGCCGATCCGGTGCCGGTGCGCTATGTGCTGCCGGTGCCCTCGGCGCAGGTGAAATCGGCGGTGCTGCTGGCCGGGCTGAACGCGCCGGGCGAGACCGCGGTGATCGAGGCCGAGCCGACCCGCGACCACACCGAACGCATGCTCGCGGGCTTCGGCGCCGTCATCCGCCACGAGGACACGCCCGAGGGCCGCGCGGTGATCCTGACGGGCCAGCCGGAGTTGATCGCGCAGCCGGTGGCGGTGCCGCGCGATCCGTCCTCGGCCGCGTTTCCGGTGGTGGCGGCGCTGATGGTGCCGGGATCGGATGTGCGGGTGCCGGGCGTCAGCCGCAACCCCACGCGCGACGGCCTTTATTGCACGCTGCTGGAGATGGGCGCCGATCTGCTGTTCGAGGCCGAGCGCGCGGAGGGCGGCGAGCCGGTGGCCGACCTGCGCGCCCGCTTCACGGGAACCTTGCGCGGGGTGGAGGTGCCGCCCGAGCGCGCCGCCAGCATGATCGACGAGTTCCCGATCCTCGCAGCCCTTGCCGCCACCGCCGAGGGCGCCACCGTCATGCGCGGCGTGCGCGAGTTGCGCGTCAAGGAAAGCGACCGCATCGCCGCGATGGCCACCGGGCTGGCCGCCTGCGGCGTCGCGGTGGAGGAGACGGAGGACACGCTGACGGTGCATGGCTGCGGCCCGGACGGCGTGCCGGGGGGCACGACGGTGGCCACGCACCTCGACCACCGCATCGCCATGAGCTTCCTGTGCCTTGGCCTCGTGGCCCGCGCGCCCGTCACGGTGGACGATGCCGGCCCCATCGCCACGTCGTTTCCCGACTTCATTCCGCTGATGACGGCCCTTGGCGCCGATCTGGCCACCCATGGCTGA",
      "translation": "MTATSAPMPLTARAGGALRGTTDVPGDKSISHRALILGALAVGETRITGLLEGQDVLDTAAAMRAFGAEVIRHGPGSWSVHGVGVGGFGEPSGVIDCGNSGTGVRLIMGAMATTPITATFTGDASLCRRPMGRVTDPLALFGAQAVGRAGGRLPMTLVGAADPVPVRYVLPVPSAQVKSAVLLAGLNAPGETAVIEAEPTRDHTERMLAGFGAVIRHEDTPEGRAVILTGQPELIAQPVAVPRDPSSAAFPVVAALMVPGSDVRVPGVSRNPTRDGLYCTLLEMGADLLFEAERAEGGEPVADLRARFTGTLRGVEVPPERAASMIDEFPILAALAATAEGATVMRGVRELRVKESDRIAAMATGLAACGVAVEETEDTLTVHGCGPDGVPGGTTVATHLDHRIAMSFLCLGLVARAPVTVDDAGPIATSFPDFIPLMTALGADLATHG",
      "product": "3-phosphoshikimate 1-carboxyvinyltransferase"
     },
     {
      "start": 2489,
      "end": 3880,
      "strand": -1,
      "locus_tag": "KKHPANEM_01438",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01438</span></strong><br>\n \n  Aspartate kinase Ask_Ect<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01438</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ask</span><br>\n \n Location: 2,489 - 3,880,\n (total: 1392 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01438 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00696.30 (Amino acid kinase family): [20:283](score: 73.4, e-value: 2.2e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01438\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=13880\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ask_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01438\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01438\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCGGAGCCGCGAGTTGCTCGAGACCCTGTGGGTCGGAGGCCGCGAGGATGTGTATGGCCGCATCTTTGTCGTCTCGGCCTATGGCGGGATCACCAACCTGCTGCTGGAGCACAAGAAAAGCGGCGAGCAGGGGGTCTATGCCCGGTTTGCCTCGGATGACGGCGGCAGCGGCTGGCACCAGGCGCTGAACGACACCGCAGCCGAGATGATGCGCGTGCACGGAGAGATCCTGGAGCATGACGGCGACAGGGGCCGGGCGGATGCGTTCGTGCGCGACCGCATCGAGGGTGCGCGGGCCTGCATGATCGACCTTCAGCGGCTGGGCTCCTACGGGCACTTCCGCATCGACGGGCAACTGATGACGCTGCGCGAGTTGCTGGCGGGGCTGGGCGAGGCGCATTCGGCCTTTGTCAGCACGCTGCTGTTGCAGCGCCACGGGGTGAACGCGCGCTTTGTGGATCTGTCGGGTTGGCGCGACGAGGCGCATCCCGATCTGGCCGAGCGGCTGCGCGCCGCGCTCGACGGGATCGACTTCTCCGAGGAGCTGCCGATCGTCACCGGCTATGCGCATTGTGCCGAAGGGCTGATGCGCGAATACGATCGTGGCTATTCCGAGGTGGTGTTCGCCCACATCGCGGCGCAGACCGCGGCCTCCGAGGCGATCATCCACAAGGAGTTCCATCTGTCCTCGGCTGATCCCAAGGTCGTGGGGCTGGACAAGGTGCGCAAGATCGGGCGCACCAGCTATGACGTGGCCGACCAGCTGTCGAACCTCGGGATGGAGGCGATCCACCCCAACGCAGCCCGCATCCTGCGCCGCGCCGAGGTCGCGCTGCGGGTCAAGCACGCGTTTGAACCCGACGATCCCGGCACCCTGATCGGTCCCGAGGGCGGGCAGGCGGGGCGCGTGGAGATGGTCACCGGCCTGCCGTTGCAGGCGCTGGAGGTCTATGAGCCCGACATGGTCGGGGTGAAGGGCTATGACGCCGGGATCCTGGACGCGCTGACGCGCCACAAGCTGTGGATCGTGTCGAAGTCCTCCAACGCGAACTCCATCACCCACTGGGTCAGCGGCTCGCTCAAGGCCCTGCGCCGGGTGGAGCGGGAGCTGGCGCAGCGCTGGTCCAACGCCGAGATCACCATTCGTCCCGTGGCGATGGTGTCGGCCATCGGCAGCGACCTGACCGGCCTTGGTGCGGTGCGTCGGGGGCTGGAGGCGCTGGACGCCGCCGGGATCGAGGTGCTTGCGGTGCAGCAGGGCCTGCGCCGGGTGGAGGTGCAGTTCCTCGTTCCGCGCGAGGCGCAGGACGCAGCGGTCGCCGCCCTGCATGCCCGCCTGATCGAGGAGACGGGCGCGGCCAGCGTCCAGCCCATCGCCGCCGAGTGA",
      "translation": "MSRSRELLETLWVGGREDVYGRIFVVSAYGGITNLLLEHKKSGEQGVYARFASDDGGSGWHQALNDTAAEMMRVHGEILEHDGDRGRADAFVRDRIEGARACMIDLQRLGSYGHFRIDGQLMTLRELLAGLGEAHSAFVSTLLLQRHGVNARFVDLSGWRDEAHPDLAERLRAALDGIDFSEELPIVTGYAHCAEGLMREYDRGYSEVVFAHIAAQTAASEAIIHKEFHLSSADPKVVGLDKVRKIGRTSYDVADQLSNLGMEAIHPNAARILRRAEVALRVKHAFEPDDPGTLIGPEGGQAGRVEMVTGLPLQALEVYEPDMVGVKGYDAGILDALTRHKLWIVSKSSNANSITHWVSGSLKALRRVERELAQRWSNAEITIRPVAMVSAIGSDLTGLGAVRRGLEALDAAGIEVLAVQQGLRRVEVQFLVPREAQDAAVAALHARLIEETGAASVQPIAAE",
      "product": "Aspartate kinase Ask_Ect"
     },
     {
      "start": 4004,
      "end": 4387,
      "strand": -1,
      "locus_tag": "KKHPANEM_01439",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01439</span></strong><br>\n \n  L-ectoine synthase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01439</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectC</span><br>\n \n Location: 4,004 - 4,387,\n (total: 384 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ectoine: ectoine_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01439 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06339.14 (Ectoine synthase): [0:126](score: 197.0, e-value: 1.1e-58)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01439 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF06339.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0033990' target='_blank'>GO:0033990</a>: ectoine synthase activity<br>\n  \n   PF06339.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0019491' target='_blank'>GO:0019491</a>: ectoine biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01439\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=14387\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ectC_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01439\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01439\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCGTTCGCGATTTCCACGAAGCCAACAAGACCGACCGCAAGGTCGCCAACGAGCGTTGGGAGTCGGTGCGCCTGCTGCTGGCCGATGACGGGATGGGGTTTTCGTTCCACATCACCACCATCGAAGGCGGCTCCGAGCACACCTTTCACTACAAGAACCATTTCGAGAGCGTGTATTGCATCTCGGGTAAGGGCTCGATCGAGGATCTCGCCACCGGCACCGTCCACCAGATCCGGCCCGGCGTGATGTACGCGCTCGACAAGCACGACAAGCACACCTTGCGCTGCGAGGACACGATGGTTCTGGCGTGCTGCTTCAACCCGCCCGTGACGGGCACCGAGGTGCACCGGGCCGACGGCTCCTACGCCGCCGCGGACTGA",
      "translation": "MIVRDFHEANKTDRKVANERWESVRLLLADDGMGFSFHITTIEGGSEHTFHYKNHFESVYCISGKGSIEDLATGTVHQIRPGVMYALDKHDKHTLRCEDTMVLACCFNPPVTGTEVHRADGSYAAAD",
      "product": "L-ectoine synthase"
     },
     {
      "start": 4391,
      "end": 5689,
      "strand": -1,
      "locus_tag": "KKHPANEM_01440",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01440</span></strong><br>\n \n  Diaminobutyrate--2-oxoglutarate transaminase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01440</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectB</span><br>\n \n Location: 4,391 - 5,689,\n (total: 1299 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_3<br>\n \n  biosynthetic-additional (smcogs) SMCOG1013:aminotransferase class-III (Score: 353.4; E-value: 2.6e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01440 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00202.23 (Aminotransferase class-III): [28:419](score: 259.1, e-value: 5.9e-77)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01440 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02407 (ectoine_ectB: diaminobutyrate--2-oxoglutarate aminotransferase): [13:420](score: 572.6, e-value: 8.7e-173)<br>\n \n  TIGR00709 (dat: 2,4-diaminobutyrate 4-transaminase): [13:421](score: 418.7, e-value: 5.3e-126)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01440 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00202.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008483' target='_blank'>GO:0008483</a>: transaminase activity<br>\n  \n   PF00202.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01440\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=15689\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ectB_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01440\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01440\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGATCATACCCAGACCGACACCGGCCCCATGGCCGTCTATGCCCGCCGCGAAAGCCAGGTGCGCAGCTACTGCCGCAGCTTTCCGGTGGAGTTCACCAAGGGCCGCAACGCCACGCTGACCGACCGCGCGGGGCGGGAGTACATCGACTTCCTCGCCGGGTGCTCGTCGCTGAACTATGGCCACAACGACCCGGACATGAAGGCGGCGCTGATCGACCACATCACCGGCGACGGCATCGCCCACGGCCTGGACATGCACACCGACGCCAAGACCGCGTTCCTGGAGACGTTCGAGCGCGTGATCCTGCGCCCGCGCGGCATGGAGCACAAGGTGATGATGACCGGCCCCACCGGCACCAACGCCGTCGAGGCCGCGATGAAGCTGGCGCGCAAGGTCACCGGGCGCGACACCATCGTCGCCTTCACCAACGGCTTTCACGGCATGACGATGGGCGCGCTGGCGGCCACCGGCAACGCCGGCAAGCGCGCGGGCGGCGGCATGGCGCTGCATGGCGTCGTGCGGATGCCCTATGAGGGGGCGATGGACGGCGTCGACAGCCTCGCGATGATCGAGGCGATGCTGGACAACCCCTCCAGCGGGTTCGACGCGCCGGCCGCGTTCCTGATCGAGCCGGTGCAGGGTGAGGGCGGGCTGAACGCCGCCTCGGCCGACTTCCTGCGCGGGCTGAAGCGGCTGGCCGAGAAGCACGGCGCGCTGCTCATTGCCGACGATATCCAGTCGGGCATCGGGCGCACGGGGCCGTTCTTCAGCTTCGAGGGGATGGACGTGATGCCCGACCTGATCCCGCTGGCGAAGTCGCTGTCGGGGATGGGCCTGCCGTTCGCCGCACTTCTGGTGCGCCCGGACCTGGACGTGTGGAAGCCGGCCGAACACAACGGCACCTTCCGCGGCAACCAGCATGCCTTCGTCACCGCCCGCGTGGCGCTGGAGAAGTTCTGGACCGACGACACCTTCCAGAAGCAGACCGAAGCCAAGGCCGAGTTCCTGGAGCGCCGGCTGTCGGACATCGCCGCCCTGATCCCCGGCGCCCGGCTGAAGGGCCGCGGCATGATGCGTGGCGTCGACGTCGGTTCGGGCGAGACGGCGGGCGCGATCTGCGCGGCCTGTTTCGAGCACGGTCTGGTCATCGAGACCTCGGGCGCCCATGATGAGGTCGTCAAGGTCCTCGCGCCCCTGACAATTCCCGAGGCGCAGTTGGCGCAGGGCCTCGACATCATCGAAGCGGCGGTGCGCAGCCGGATCGCCGGCACCACCCCCATTGCAGCGGAGTAA",
      "translation": "MTDHTQTDTGPMAVYARRESQVRSYCRSFPVEFTKGRNATLTDRAGREYIDFLAGCSSLNYGHNDPDMKAALIDHITGDGIAHGLDMHTDAKTAFLETFERVILRPRGMEHKVMMTGPTGTNAVEAAMKLARKVTGRDTIVAFTNGFHGMTMGALAATGNAGKRAGGGMALHGVVRMPYEGAMDGVDSLAMIEAMLDNPSSGFDAPAAFLIEPVQGEGGLNAASADFLRGLKRLAEKHGALLIADDIQSGIGRTGPFFSFEGMDVMPDLIPLAKSLSGMGLPFAALLVRPDLDVWKPAEHNGTFRGNQHAFVTARVALEKFWTDDTFQKQTEAKAEFLERRLSDIAALIPGARLKGRGMMRGVDVGSGETAGAICAACFEHGLVIETSGAHDEVVKVLAPLTIPEAQLAQGLDIIEAAVRSRIAGTTPIAAE",
      "product": "Diaminobutyrate--2-oxoglutarate transaminase"
     },
     {
      "start": 5735,
      "end": 6277,
      "strand": -1,
      "locus_tag": "KKHPANEM_01441",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01441</span></strong><br>\n \n  L-2,4-diaminobutyric acid acetyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01441</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectA</span><br>\n \n Location: 5,735 - 6,277,\n (total: 543 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01441 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00583.27 (Acetyltransferase (GNAT) family): [49:135](score: 42.8, e-value: 5.5e-11)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01441 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02406 (ectoine_EctA: diaminobutyrate acetyltransferase): [17:169](score: 173.8, e-value: 6e-52)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01441 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00583.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01441\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=16277\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ectA_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01441\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01441\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCCCGGACAAATCGCAAGATCATCGAAACACCCAAGGGTGCGGTGCGCCTGCGCAGCCCCGTCAAGACTGACGGCACGGCCGTCCAGGAGCTGATCGCGCGCTGCGCGCCACTGGACCAGAATTCCCTCTACATGAACCTGATCCAGTGCGACCACTTCGCCGACACCTGTGTGCTGGCCGAGCGTGGCGACGATGTGCTGGGCTGGATCTCGGCGCATGTGCCGCCGGGGCGCGAGGACACGATCTTCGTGTGGCAGGTGGCTGTTGACGCCCGCGCACGCGGCATGGGGCTGGGACGCCACATGCTGACGGCGCTGCTGGAGCGCCCGCTGTGCCGCCGCGTCATCAACCTGGAGACCACGATCACCCGCGACAACGAGGGGTCCTGGGCACTGTTCCGCAGCCTTGCCCGGCGTCTGGACGGCGATCTGTCCCACGCGCCCCATTTTGAACGCGAGGCGCATTTCGGCGGCGCGCATGACACCGAGCATCTGGTGACCATCGCGCTCGACGCCGAAGCGGTGCGCCGGGCGGCCTGA",
      "translation": "MARTNRKIIETPKGAVRLRSPVKTDGTAVQELIARCAPLDQNSLYMNLIQCDHFADTCVLAERGDDVLGWISAHVPPGREDTIFVWQVAVDARARGMGLGRHMLTALLERPLCRRVINLETTITRDNEGSWALFRSLARRLDGDLSHAPHFEREAHFGGAHDTEHLVTIALDAEAVRRAA",
      "product": "L-2,4-diaminobutyric acid acetyltransferase"
     },
     {
      "start": 6556,
      "end": 7044,
      "strand": 1,
      "locus_tag": "KKHPANEM_01442",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01442</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01442</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,556 - 7,044,\n (total: 489 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1135:MarR family transcriptional regulator (Score: 88.6; E-value: 4.5e-27)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01442 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01047.24 (MarR family): [31:90](score: 56.9, e-value: 1.5e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01442 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01047.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF01047.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01442\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=17044\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/KKHPANEM_01442_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01442\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01442\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACGGAACGGGTGGATGCGACGCTGATCGCACTCAGGCGCGTGCTGCGCGCGATCGAGGGCAACGCCCGCGCGATCGCGCGGGCCTCGGGGTTGACGCACGCACAGATGCTGGTGCTGCACGCGCTGGCCGACCGCGGGCAGGAACTGCCCAGCGACATCGCCCGCCGTCTGGGCGTGGCCCAGGCCACCGTCACCACCCAGATCGATCGGCTGGAGGCGCGCGGCCTTGTGCGCCGCGAGCGTCGGCAGACCGACCGCCGCACCGTCTGGGTGATCCTGACCGACAGCGGGCGCCAGCTTCTGGCCGACACCCCCGACCCGCTCTATGGCCGCTTCGCCGACCGGTTCGCGCGGCTTGCGGATTGGGAACAGGGCATGCTGATGACCAGCGCCGAGCGTCTGGCCAAGCTGTTTGACGCCGAGGCCGTCGAGCCCCTGCCCGCGGGCGAGGACACCGCGCGCAAACCCGCGCCCCCCGTCGCCTGA",
      "translation": "MTERVDATLIALRRVLRAIEGNARAIARASGLTHAQMLVLHALADRGQELPSDIARRLGVAQATVTTQIDRLEARGLVRRERRQTDRRTVWVILTDSGRQLLADTPDPLYGRFADRFARLADWEQGMLMTSAERLAKLFDAEAVEPLPAGEDTARKPAPPVA",
      "product": "hypothetical protein"
     },
     {
      "start": 7260,
      "end": 8933,
      "strand": 1,
      "locus_tag": "KKHPANEM_01443",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01443</span></strong><br>\n \n  Cytochrome c oxidase subunit 1-beta<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01443</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ctaDII</span><br>\n \n Location: 7,260 - 8,933,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01443 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00115.22 (Cytochrome C and Quinol oxidase polypeptide I): [28:494](score: 501.7, e-value: 1.8e-150)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01443 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02891 (CtaD_CoxA: cytochrome c oxidase, subunit I): [20:547](score: 680.3, e-value: 3.8e-205)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01443 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00115.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004129' target='_blank'>GO:0004129</a>: cytochrome-c oxidase activity<br>\n  \n   PF00115.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n   PF00115.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009060' target='_blank'>GO:0009060</a>: aerobic respiration<br>\n  \n   PF00115.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01443\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=18933\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctaDII_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01443\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01443\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCCGACGCAGTCACCCAGGGCGGAGGGCACGGGGACACCCGCGGGTTCTTCACCCGCTGGTTCATGTCCACCAACCACAAGGACATCGGGATCCTGTATCTGTTCACCTCCGGCATCGTCGGATTCATCGCGGTGGCCTTCACGGTCTACATGCGCATGGAACTGATGGAGCCCGGCGTTCAGTACATGTGCCTGGAGGGCGCGCGCATGACCGCGGCCGCCGCGGGCGAGTGCACCCCCAACGGCCACCTGTGGAACGTGCTGATCACCGCCCACGGCGTGCTGATGATGTTCTTCGTCGTGATTCCGGCGCTGTTCGGGGGCTTTGGCAACTACTTCATGCCGCTGCACATCGGCGCGCCGGACATGGCGTTCCCGCGGCTCAACAACCTGTCGTACTGGCTTTATGTGGCCGGGGCGTCGCTGGCGGTGGCGTCGCTGTTCTCGCCCGGCGGCGCGGGGCAGACCGGCGCGGGGGTGGGCTGGGTGCTCTATCCGCCGCTGTCGACGACCGAGACCGGCTATGCGATGGACCTCGCGATCTTTGCGGTGCATGTCGCGGGCGCCTCGTCGATCCTGGGTGCGATCAACATCATCACCACCTTCCTGAACATGCGAGCGCCGGGCATGACGCTGCACAAGGTGCCGCTGTTCGCCTGGTCGGTGTTCATCACCGCGTGGATGATCCTGCTGGCGCTGCCGGTTCTTGCGGGCGCCATCACCATGCTGCTGACCGACCGGAACTTCGGCACCACCTTCTTCGATCCCTCGGGCGGCGGCGACCCGGTGCTGTACCAGCACATCCTGTGGTTCTTCGGCCATCCGGAGGTCTACATCATCATCATCCCCGGCTTCGGCATCATCAGCCATGTCATCGCCACGTTCTCGCGCAAGCCGATCTTCGGCTACCTGCCGATGGTCTATGCGATGGTGGCCATCGGGGTGCTGGGCTTCGTGGTGTGGGCGCACCACATGTACACCGTGGGCATGTCGCTGACGCAGCAGAGCTACTTCATGCTGGCGACGATGGTGATCGCGGTGCCGACGGGCATCAAGATCTTCAGCTGGATCGCCACGATGTGGGGCGGCTCGGTGGAGTTCAAGACGCCCATGCTGTGGGCCTTCGGGTTCCTGTTCCTGTTCACCGTGGGCGGCGTGACGGGCGTGGTGCTCAGCCAGGCCGCCGTCGACCGCTACTATCACGACACCTACTATGTGGTCGCGCACTTCCACTATGTGATGTCCTTGGGCGCCGTGTTCGCGCTGTTTGCCGGGATCTACTACTGGATCGGCAAGATGTCGGGGCGGCAGTACCCCGAATGGGCCGGCAAGACGCACTTCTGGGCGATGTTCATCGGCTCCAACCTGACCTTCTTTCCGCAGCACTTCCTCGGCCGTCAGGGGATGCCGCGCCGCTACATCGACTACCCCGAGGCGTTCGCGCTGTGGAACTGGGTAAGCTCGATCGGCGCCTTCATCTCGTTCGCCTCGTTCGTGTTCTTCATCGGGGTGATCTACTACACCCTGCGCCACGGCGCGCGCGTGACCGAGAACAACTACTGGAACGAGCACGCCGACACGCTGGAGTGGACCCTGCCCTCGCCGCCGCCCGAACATACGTTCGAGACGCTGCCGAAGCGCGAGGACTGGGACCGCTCGCCCGCCCACTGA",
      "translation": "MADAVTQGGGHGDTRGFFTRWFMSTNHKDIGILYLFTSGIVGFIAVAFTVYMRMELMEPGVQYMCLEGARMTAAAAGECTPNGHLWNVLITAHGVLMMFFVVIPALFGGFGNYFMPLHIGAPDMAFPRLNNLSYWLYVAGASLAVASLFSPGGAGQTGAGVGWVLYPPLSTTETGYAMDLAIFAVHVAGASSILGAINIITTFLNMRAPGMTLHKVPLFAWSVFITAWMILLALPVLAGAITMLLTDRNFGTTFFDPSGGGDPVLYQHILWFFGHPEVYIIIIPGFGIISHVIATFSRKPIFGYLPMVYAMVAIGVLGFVVWAHHMYTVGMSLTQQSYFMLATMVIAVPTGIKIFSWIATMWGGSVEFKTPMLWAFGFLFLFTVGGVTGVVLSQAAVDRYYHDTYYVVAHFHYVMSLGAVFALFAGIYYWIGKMSGRQYPEWAGKTHFWAMFIGSNLTFFPQHFLGRQGMPRRYIDYPEAFALWNWVSSIGAFISFASFVFFIGVIYYTLRHGARVTENNYWNEHADTLEWTLPSPPPEHTFETLPKREDWDRSPAH",
      "product": "Cytochrome c oxidase subunit 1-beta"
     }
    ],
    "clusters": [
     {
      "start": 4003,
      "end": 4387,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 9387,
      "product": "ectoine",
      "category": "other",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "ectoine",
    "products": [
     "ectoine"
    ],
    "product_categories": [
     "other"
    ],
    "cssClass": "other ectoine",
    "anchor": "r218c1"
   }
  ]
 },
 {
  "length": 6693,
  "seq_id": "NZ_NHSD01000219.1",
  "regions": []
 },
 {
  "length": 6705,
  "seq_id": "NZ_NHSD01000220.1",
  "regions": []
 },
 {
  "length": 3453,
  "seq_id": "NZ_NHSD01000221.1",
  "regions": []
 },
 {
  "length": 11862,
  "seq_id": "NZ_NHSD01000222.1",
  "regions": []
 },
 {
  "length": 6656,
  "seq_id": "NZ_NHSD01000223.1",
  "regions": []
 },
 {
  "length": 10261,
  "seq_id": "NZ_NHSD01000224.1",
  "regions": []
 },
 {
  "length": 2849,
  "seq_id": "NZ_NHSD01000225.1",
  "regions": []
 },
 {
  "length": 9960,
  "seq_id": "NZ_NHSD01000226.1",
  "regions": []
 },
 {
  "length": 33203,
  "seq_id": "NZ_NHSD01000227.1",
  "regions": []
 },
 {
  "length": 2995,
  "seq_id": "NZ_NHSD01000228.1",
  "regions": []
 },
 {
  "length": 10626,
  "seq_id": "NZ_NHSD01000229.1",
  "regions": []
 },
 {
  "length": 7906,
  "seq_id": "NZ_NHSD01000230.1",
  "regions": []
 },
 {
  "length": 3255,
  "seq_id": "NZ_NHSD01000231.1",
  "regions": []
 },
 {
  "length": 11912,
  "seq_id": "NZ_NHSD01000232.1",
  "regions": []
 },
 {
  "length": 3114,
  "seq_id": "NZ_NHSD01000233.1",
  "regions": []
 },
 {
  "length": 12186,
  "seq_id": "NZ_NHSD01000234.1",
  "regions": []
 },
 {
  "length": 6044,
  "seq_id": "NZ_NHSD01000235.1",
  "regions": []
 },
 {
  "length": 6869,
  "seq_id": "NZ_NHSD01000236.1",
  "regions": []
 },
 {
  "length": 3563,
  "seq_id": "NZ_NHSD01000237.1",
  "regions": [
   {
    "start": 1,
    "end": 3563,
    "idx": 1,
    "orfs": [
     {
      "start": 6,
      "end": 1016,
      "strand": 1,
      "locus_tag": "KKHPANEM_01604",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01604</span></strong><br>\n \n  Phytoene desaturase (neurosporene-forming)<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01604</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtI_1</span><br>\n \n Location: 6 - 1,016,\n (total: 1011 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 315.4; E-value: 1.3e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01604 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.26 (Flavin containing amine oxidoreductase): [3:323](score: 46.9, e-value: 2.6e-12)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01604 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02734 (crtI_fam: phytoene desaturase): [1:332](score: 429.8, e-value: 3.2e-129)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01604 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01604\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237.1&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/crtI_1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGCCTGCGCGGCGACCGCAGCGTCTATCAGACGGTCAGCCGCTACGTGAAGGACGAGCGGCTGCGGGTCATGCTGTCGTTCCATCCGCTCTTGATCGGCGGCAACCCCTTCCATGCCAGTTCGGTCTATTGCCTGATCTCCTATCTGGAACGGCACTGGGGTATCCATTTCGCGATGGGCGGCACCGGCCGGCTGGCCAGCGGTCTCGCGAAGCTGGTGGAGGGGCAGGGCAACCAGATCCGCTATCACGCGCAGGTCGAGGAGATCGAGGTTGCGGACGGCCGGGCGACCGGTGTGCGCCTTACGACCGGCGAGCGCATTCCCGCCGAGATCGTCGTCTCCAACGCCGACAGCGCCTACACCTACCGCCGGATGCTGCCGCCGCAGGTCCGCAAGCGCTGGACCGACCGCAAGCTGGACCGCGCGCGCTACTCGATGAGTCTGTTCGTCTGGTACTTCGGCACCAAGCGACAGTACTCGGAGACGGCGCACCATACGATCCTGCTTGGCCCGCGCTACAAGGAGCTGATCGAGGACATCTTCGAGCGCAAAATCCTGGCCGACGACTTCTCGCTGTATCTGCACCGGCCGACCGCGACCGATCCGTCGCTGGCGCCGGACGGCTGCGATAGCTTCTACGTGTTGTCGCCGGTGCCGCACATGGATGCCGGGATCGACTGGTCGCAGCAGGCGCAGGCGTATCGCGCGCGGATCGCGGATTTCCTGGAGCGCACCGAGTTGCCGGGCCTGCGCGAGAACATCGTGTCCGAACACATGATCACGCCGCAGGATTTTCAGGACCGCCTGCTGTCCGAGCGCGGCGCGGCCTTCGGGCTGGAGCCGCGACTGACACAGAGCGCCTGGTTCCGCCCCCACAACAAGAGCGAGGACGTCGAGGGTCTATACCTCGTTGGTGCCGGTACCCATCCCGGTGCCGGTTTGCCCGGAGTCCTCTCGTCCGCTCGCGTGCTCGACCAGGTGGTGCCCGATGCCAGTGAATTCGCCTAG",
      "translation": "MRLRGDRSVYQTVSRYVKDERLRVMLSFHPLLIGGNPFHASSVYCLISYLERHWGIHFAMGGTGRLASGLAKLVEGQGNQIRYHAQVEEIEVADGRATGVRLTTGERIPAEIVVSNADSAYTYRRMLPPQVRKRWTDRKLDRARYSMSLFVWYFGTKRQYSETAHHTILLGPRYKELIEDIFERKILADDFSLYLHRPTATDPSLAPDGCDSFYVLSPVPHMDAGIDWSQQAQAYRARIADFLERTELPGLRENIVSEHMITPQDFQDRLLSERGAAFGLEPRLTQSAWFRPHNKSEDVEGLYLVGAGTHPGAGLPGVLSSARVLDQVVPDASEFA",
      "product": "Phytoene desaturase (neurosporene-forming)"
     },
     {
      "start": 997,
      "end": 2061,
      "strand": 1,
      "locus_tag": "KKHPANEM_01605",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01605</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01605</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 997 - 2,061,\n (total: 1065 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01605 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.21 (Squalene/phytoene synthase): [23:274](score: 224.0, e-value: 2.5e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01605 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01605\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237.1&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/KKHPANEM_01605_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCAGTGAATTCGCCTAGAGACGCAACCCTCCGCGCGGCCGATGCCGCAGCGGCGACGGCGGCGATCCGTACCGGATCGCGCAGCTTTCATGCCGCGTCGCTGGTGCTGCCGCGCCGGGTGCGGGAACCGGCGCGCGGGCTCTACGCTTTCTGTCGGGAAGCGGACGACGCCGTCGACACTCGCCCGGATCGCACGCGCGCGCTCGCAGAACTGCGCCAGCGCTTGCAGTGGATTTATGACGGTCGCCCAGGCAACAACGCCGCGGACCGGGCGTTTGCCGACGTGGTCGCCGCCTATGCGATCCCGCAGACCTTGCCCGAAGCGCTGTTGGAAGGCTTCGCCTGGGATGCCGAGGAGCGGCGTTACCGCACGATTCAGGATCTGCGCGCCTATGGCGCCCGGGTTGCCGGGGCGGTCGGCGCGATGGTCGCAATGCTGATGGGCGCGCGCCAGGCGGAGGTCGTCTCGCGGGCCACTGACCTCGGCGTGGCGATGCAGCTGACCAATATCGCCCGCGACGTTGGCGAGGATGCGCGCCAGGGGCGCGTCTATTTGCCGATCGATTGGCTGGAGGCGGAAGGCATCGACGCTGACGCTTGGCTCGCCGACCCACGGTTTGGTCCGGGCGTCGCGCGGACGGTGGAACGGCTGCTAGCCCACGCGGAGGAGCTGTATCAGCGTGCGGAAGCTGGCATTCCCGCGCTGCCGGCTTCCTGCCGCCCAGGCATCACCGCCGCCAGCCGTCTGTACCGGGCGATCGGCCATCAGGTCGCCCGGCAAGGCCACGATTCCTTGTCCCGGCGGGCGGTTGTACCGGCGATGCGCAAGGTCGGGCTGATGGTCGACGCGTTGAAGGGGCCGATGCCGGTTGCGCACTACAGCGACTATCCCTGCTTGCCGGAGACCCGGTTCCTGGTTCAGGCCGTGCACGAGGCATTGCCCGCGCTGCACGGTTTCAAGCCGGACGCAGCGGATGCGTCCGCTCCCGTCGAAGAGGGCGCCGCGGCCTTCGTGATCGACCTGTTCATGCGTCTGGAGCAGCGCGACCAGGCACGCGGGTAG",
      "translation": "MPVNSPRDATLRAADAAAATAAIRTGSRSFHAASLVLPRRVREPARGLYAFCREADDAVDTRPDRTRALAELRQRLQWIYDGRPGNNAADRAFADVVAAYAIPQTLPEALLEGFAWDAEERRYRTIQDLRAYGARVAGAVGAMVAMLMGARQAEVVSRATDLGVAMQLTNIARDVGEDARQGRVYLPIDWLEAEGIDADAWLADPRFGPGVARTVERLLAHAEELYQRAEAGIPALPASCRPGITAASRLYRAIGHQVARQGHDSLSRRAVVPAMRKVGLMVDALKGPMPVAHYSDYPCLPETRFLVQAVHEALPALHGFKPDAADASAPVEEGAAAFVIDLFMRLEQRDQARG",
      "product": "hypothetical protein"
     },
     {
      "start": 2195,
      "end": 2401,
      "strand": 1,
      "locus_tag": "KKHPANEM_01606",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01606</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01606</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,195 - 2,401,\n (total: 207 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01606\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237.1&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATGGCGGTTGGATTGTGCTGCTGGAGGGGATGACGGTCTTCGGGCTGTTGATCGGCTTCGGCATCTGGCAGTTGCGTTCGCTGAAAAAGATGGAGCGCGAAGATAAGGCCAAGGCGGCGGCCGAGGGACGGGAGGGCGAGTCCGCCTTCATCCGCTCCCGTGAACCCCGGTCAGGCGCGGATACGGGGCATTCGGAAGGGTAG",
      "translation": "MDGGWIVLLEGMTVFGLLIGFGIWQLRSLKKMEREDKAKAAAEGREGESAFIRSREPRSGADTGHSEG",
      "product": "hypothetical protein"
     },
     {
      "start": 2369,
      "end": 3355,
      "strand": -1,
      "locus_tag": "KKHPANEM_01607",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01607</span></strong><br>\n \n  Acyclic carotenoid 1,2-hydratase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01607</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtC_1</span><br>\n \n Location: 2,369 - 3,355,\n (total: 987 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01607\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237.1&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCCTGTTGGCGGACTGGGGCATCAGCGACCCAACACGGACGGCCCCGGGTTCGATCAGCCGGTCGCGCCGGGCGGCTACGTCTGGTGGTACGTCGACGCGCTGAGCGACGACGGTCAGCACGGCCTGACCATCATCGCCTTCATCGGGTCGGTGTTCTCGCCGTACTACGCCTGGGCCCGACAGCGCGCACCCGGCGGCGCGGCGGACCCGCTGAACCACTGCTCGATCAATGTGGCCCTCTACGGCGAGGGGCCGAACCGCTGGGCGATGACGGAACGTGGCCGCACCCGCATCGATCGCGGCGCGCGGCACTTCTCCGTTGGTCCCAGCGGGCTGCACTGGGATGGCCGGACGCTCACCATCCACCTCGACGAGATCGCCGCGCCGCTGCCACGCGCGGTGCAAGGGCGCGTGCGCGTCACCCCGCACGCGATGACGACCCAGGAGTTCGCGATCGATCACCAGGATCGCCACCACTGGTGGCCGATGGCCCCCACGGCGGAGGTTTCGGTCGCCTTGAACAAACCGGCCCTGTCCTGGCACGGCACCGGCTACCTGGACCGCAACCGCGGCGACGAACCGCTCGAAGCCGGTTTTCAGGAATGGGACTGGGCGCGCGCCCCGCTGCCCTCCGGCGGCACCGCGATCACCTACGACACCTTCCGCCGCGACGGCTCCGACCACGCGCTGTCCCTGCTCGTCAGGAAAGATGGCGGGATCGAACGGTTCGACAACGCCGTCCTCAACGATCTGCCGTCGACATCGATCTGGCGCATCCGCCGCAAGGGCCGCGCCGATGCCGGCCATCGGGCCTGCGTGTCGAAGACGCTGGAGGACACGCCCTTCTACGCCCGCTCGCTGGTCGAGACGCACCTGGCAGGCGAACCGGTGCGGGCGATGCACGAAAGCCTGTCGTTGACGCGCTTCGACACGCGGATCGTGCGCCTGATGCTACCCTTCCGAATGCCCCGTATCCGCGCCTGA",
      "translation": "MPVGGLGHQRPNTDGPGFDQPVAPGGYVWWYVDALSDDGQHGLTIIAFIGSVFSPYYAWARQRAPGGAADPLNHCSINVALYGEGPNRWAMTERGRTRIDRGARHFSVGPSGLHWDGRTLTIHLDEIAAPLPRAVQGRVRVTPHAMTTQEFAIDHQDRHHWWPMAPTAEVSVALNKPALSWHGTGYLDRNRGDEPLEAGFQEWDWARAPLPSGGTAITYDTFRRDGSDHALSLLVRKDGGIERFDNAVLNDLPSTSIWRIRRKGRADAGHRACVSKTLEDTPFYARSLVETHLAGEPVRAMHESLSLTRFDTRIVRLMLPFRMPRIRA",
      "product": "Acyclic carotenoid 1,2-hydratase"
     }
    ],
    "clusters": [
     {
      "start": 996,
      "end": 2061,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 3563,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r237c1"
   }
  ]
 },
 {
  "length": 3545,
  "seq_id": "NZ_NHSD01000238.1",
  "regions": []
 },
 {
  "length": 6839,
  "seq_id": "NZ_NHSD01000239.1",
  "regions": []
 },
 {
  "length": 6702,
  "seq_id": "NZ_NHSD01000240.1",
  "regions": []
 },
 {
  "length": 12406,
  "seq_id": "NZ_NHSD01000241.1",
  "regions": []
 },
 {
  "length": 6819,
  "seq_id": "NZ_NHSD01000242.1",
  "regions": []
 },
 {
  "length": 6837,
  "seq_id": "NZ_NHSD01000243.1",
  "regions": []
 },
 {
  "length": 9782,
  "seq_id": "NZ_NHSD01000244.1",
  "regions": []
 },
 {
  "length": 9924,
  "seq_id": "NZ_NHSD01000245.1",
  "regions": []
 },
 {
  "length": 9954,
  "seq_id": "NZ_NHSD01000246.1",
  "regions": []
 },
 {
  "length": 10009,
  "seq_id": "NZ_NHSD01000247.1",
  "regions": []
 },
 {
  "length": 10093,
  "seq_id": "NZ_NHSD01000248.1",
  "regions": []
 },
 {
  "length": 10284,
  "seq_id": "NZ_NHSD01000249.1",
  "regions": []
 },
 {
  "length": 10319,
  "seq_id": "NZ_NHSD01000250.1",
  "regions": []
 },
 {
  "length": 10343,
  "seq_id": "NZ_NHSD01000251.1",
  "regions": []
 },
 {
  "length": 10405,
  "seq_id": "NZ_NHSD01000252.1",
  "regions": []
 },
 {
  "length": 10430,
  "seq_id": "NZ_NHSD01000253.1",
  "regions": []
 },
 {
  "length": 10728,
  "seq_id": "NZ_NHSD01000254.1",
  "regions": []
 },
 {
  "length": 10850,
  "seq_id": "NZ_NHSD01000255.1",
  "regions": []
 },
 {
  "length": 21048,
  "seq_id": "NZ_NHSD01000256.1",
  "regions": []
 },
 {
  "length": 10929,
  "seq_id": "NZ_NHSD01000257.1",
  "regions": []
 },
 {
  "length": 10933,
  "seq_id": "NZ_NHSD01000258.1",
  "regions": []
 },
 {
  "length": 10965,
  "seq_id": "NZ_NHSD01000259.1",
  "regions": []
 },
 {
  "length": 11075,
  "seq_id": "NZ_NHSD01000260.1",
  "regions": []
 },
 {
  "length": 11312,
  "seq_id": "NZ_NHSD01000261.1",
  "regions": []
 },
 {
  "length": 11503,
  "seq_id": "NZ_NHSD01000262.1",
  "regions": []
 },
 {
  "length": 11702,
  "seq_id": "NZ_NHSD01000263.1",
  "regions": []
 },
 {
  "length": 11723,
  "seq_id": "NZ_NHSD01000264.1",
  "regions": []
 },
 {
  "length": 19381,
  "seq_id": "NZ_NHSD01000265.1",
  "regions": []
 },
 {
  "length": 19477,
  "seq_id": "NZ_NHSD01000266.1",
  "regions": []
 },
 {
  "length": 19539,
  "seq_id": "NZ_NHSD01000267.1",
  "regions": []
 },
 {
  "length": 19746,
  "seq_id": "NZ_NHSD01000268.1",
  "regions": []
 },
 {
  "length": 21725,
  "seq_id": "NZ_NHSD01000269.1",
  "regions": []
 },
 {
  "length": 19850,
  "seq_id": "NZ_NHSD01000270.1",
  "regions": []
 },
 {
  "length": 20166,
  "seq_id": "NZ_NHSD01000271.1",
  "regions": []
 },
 {
  "length": 20199,
  "seq_id": "NZ_NHSD01000272.1",
  "regions": []
 },
 {
  "length": 21589,
  "seq_id": "NZ_NHSD01000273.1",
  "regions": [
   {
    "start": 6312,
    "end": 21589,
    "idx": 1,
    "orfs": [
     {
      "start": 6817,
      "end": 7518,
      "strand": 1,
      "locus_tag": "KKHPANEM_02026",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02026</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02026</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,817 - 7,518,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02026 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF11306.10 (Protein of unknown function (DUF3108)): [18:169](score: 44.8, e-value: 1.5e-11)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02026\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=0&amp;to=17518\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGTGGCCATCGTGGCGGGGCTGTGGGCGCCCGGCGGCGCGGCGGCGCTTGATCTGCCCGAGGTGGTGCGCCTCGATGTGACTTTTGCGGGGCTGCCGGTGGGGGTGCTGCACCTTGCCATCCGCCGCACCGACGGCAGCTATGCCGCGACGGCGCGGCTGCAACCGGCGGGGCTGGGGCGTCTGCTGCCCTCGGCCCGGTTCGAGGCGACGGTGCAGGGCCGCCTGCGCGCAGGCCGCCCGCAGCCGCTGCGCTATGTCGAGGATGTGCACACCGGACGGCGCGAATCGCGCACCGAAATCGCATGGGAGGGGGGGGTGCCGCGCCTGCTGCGCCTTGACCCGCCGCGCCCGCCCGAGCCGTGGCACCTCGACCCGGCGGGGCAGGGCGGTGCGCTCGATCCGATGTCGGCGGTGCTGTCGGTGCTTGCGGATGTTCCGGCGGAGCGGGCCTGCGCGCTCGACCTTGCGGTGTTCGACGGGCGGCGGCGCACGCAGATCGTTCTGGCGCCCGCGCCGGACGGCGAGCCCGGCTGCGACGGCGTGTTTCGCCGCGTCGCAGGGTATGACCCCGAGGATCTGGCCGAGCGGCCGGAGGTGCCGTTCCGCCTGATCCACGGCCCCGGCCCGGGCGGCACCCTGCGCGTCATCGCACTGGAGGCCGCCTGGGAGCTGGGCACCGCCCGGCTGACCCGCGACTGA",
      "translation": "MVAIVAGLWAPGGAAALDLPEVVRLDVTFAGLPVGVLHLAIRRTDGSYAATARLQPAGLGRLLPSARFEATVQGRLRAGRPQPLRYVEDVHTGRRESRTEIAWEGGVPRLLRLDPPRPPEPWHLDPAGQGGALDPMSAVLSVLADVPAERACALDLAVFDGRRRTQIVLAPAPDGEPGCDGVFRRVAGYDPEDLAERPEVPFRLIHGPGPGGTLRVIALEAAWELGTARLTRD",
      "product": "hypothetical protein"
     },
     {
      "start": 7528,
      "end": 10089,
      "strand": -1,
      "locus_tag": "KKHPANEM_02027",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02027</span></strong><br>\n \n  Aminopeptidase N<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02027</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pepN</span><br>\n \n Location: 7,528 - 10,089,\n (total: 2562 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02027 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17900.3 (Peptidase M1 N-terminal domain): [105:181](score: 35.6, e-value: 1.1e-08)<br>\n \n  PF01433.22 (Peptidase family M1 domain): [219:433](score: 172.7, e-value: 8.3e-51)<br>\n \n  PF11940.10 (Domain of unknown function (DUF3458) Ig-like fold): [438:532](score: 100.3, e-value: 6.5e-29)<br>\n \n  PF17432.4 (Domain of unknown function (DUF3458_C) ARM repeats): [536:852](score: 351.9, e-value: 3.7e-105)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02027 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02414 (pepN_proteo: aminopeptidase N): [12:851](score: 1092.9, e-value: 0.0)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02027 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01433.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008237' target='_blank'>GO:0008237</a>: metallopeptidase activity<br>\n  \n   PF01433.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02027\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=0&amp;to=20089\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGACGCAACCCCCCAGCCGATCCGACTGGCGGACTACACCCCGCCGCCGTTCCTGGTGGAGGGGGTCGCGCTGACCTTCCGGCTGGCGCCACGGGCCACGCGGGTGACGTCGCGCATCCGGTTCCGGCGCAACCCCGACGCGCAGGCCCAAGATCTGCGGCTGGATGGCGAGGGGCTGCGGCTGATCTCGGCCACCATCGACGGCGTGCCGATCACCGCGCAGCCCGATGCGACGGGCCTGACGCTGCCGGGCGGGGATCTGCCGGACGCCTTTGACTGGGCCGCCGAGGTGGAGATCGCACCGGAGGAAAACACCGCGCTGGAGGGGCTTTACATGTCGAATGGCATGTATTGCACGCAGTGCGAGGCCGAAGGCTTCCGCAAGATCACCTTCTATCCCGACCGCCCGGACGTGATGGCACCGTTCACGGTGCGGGTCGAATCCGAGCTGCCGGTGCTGCTGTCGAACGGCAATCCGTCCGCCCAGGGCGATGGCTGGGCCGAATGGGACGATCCCTGGCCCAAGCCCGCCTATCTGTTCGCGCTGGTGGCGGGCGATCTGGTGGCACATTCGGACGCCTTTGCCACCGCATCGGGGCGCGCGGTCGCGCTGAATGTCTGGGTGCGCCCGGGCGACGAGGGGCGCTGCGCCTATGCGATGGATTCGCTCAAACGCTCCATGCGCTGGGATGAGGAGGCCTACGGGCGCGAATACGACCTCGATGTGTTCAACATCGTGGCGGTGGACGACTTCAACATGGGCGCGATGGAGAACAAGGGGCTCAACGTCTTCAACTCCAAATACGTCCTCGCCTCCTCCGAGACGGCGACGGATGCCGACTTCGACAACATCGAGCGCATCGTCGCGCATGAATACTTCCACAACTGGACCGGCAACCGCATCACCTGCCGCGACTGGTTCCAGCTGTGCCTCAAGGAAGGGCTGACGGTGTTCCGCGACCAGCAGTTCAGCGCCGACATGCGCTCGGCCGCCGTCAAGCGGATCGAGGACGTGCTGAGCCTGCGCGCACGCCAGTTCCGCGAGGATCAGGGCCCGCTGGCGCATCCGGTGCGCCCCGACAGCTATCACGAGATCAACAACTTCTACACCGCGACGGTGTACGAGAAGGGCGCCGAGATCATCCGCATGCTGCGCACGCTGGTGGGCGAGGACGGCTATGACGCGGGCGTGCGGCTCTATTTCGACCGCCACGACGGGCAGGCCTGCACGATCGAGGACTGGTTGGCGGTGTTCGCGGAGGCCACGGGGCGCGACCTGTCGCAATTCGCGCGCTGGTATGCCCAGGCCGGCACCCCGCGCCTGCGGGTGACCGAGGATTGGGACGAGGGCACCGGCCGCTTCACCCTGACGCTGGAGCAGTCCACCCCCCCCACCCCGGGCCAGCCCGACAAGGCACCCCAGGTGATCCCGGTGGCCGTTGGCCTGCTGGGTCCCGCGGGCGACGAGATCATGGCCACCCGCGTGATCGAGATGACCGACACCCGCCACAGCCTGACGATCGAGGGGATGCCGGCACGCCCCGTCCCGTCGATCCTGCGCGGCTTCTCCGCCCCGGTGGTGGTCGAGCACGCGGTCACGCCGGAACGCCGCGCCTTTCTGATGGCCCATGACACCGATCCGTTTTCCCGGTGGGAGGCCGGGCGCGGGCTGGCGCGCGAGATCCTTGTGGCGATGGTGCGCGACGGCGCGGCGCCCGGGCCGGATTACCTCGATGCGCTGGCGGTGACGCTGTCGGACGAACGGCTGGACCCGGCGTTCCGCGCGCTGTGCCTGCGCGCGCCCTCCGAGGATGACATCGCCCAGGCGCTGGTGGATGCCGGCGAGACGCCGGACCCCATGGCGATCCACACCGCGCGCGAGCGGTTCCAGCGCGCGATCGCGGCCCACATGGACGACGGGCTGGCGCGCGCCTTCATCGCGATGGAGACGCCCGGCCCCTACAGCCCCGACGCGCGCGACGCGGGCCGCCGGGCGCTGCGGCTGGCGGCACTGGCGTATCTGTCGCGCAATGACGGCGGGGACCGGGCCGCGCGGCTGTTCGCCGGGGCCGACAACATGACCGAACAGATGGGCGCGCTGGGGGCCCTGCTGCAGGTCGGCGCGGGCCAGTCCGAGGTCGCGCGGTTCCACCGTCAATGGGCCCACGACCGGCTGGTGGTGGACAAGTGGTTCGCCGTTCAGGTGGCCCTCGCAGCGCCCGAAAGCGCGGTGGAGACCGCGCGCAGCCTGACGCGCCACCCCGATTTCGACTGGAAGAACCCCAACCGCTTCCGCTCGGTGCTGGGTGCGCTGGCGACGAATGCGGCGGGGTTCCACGCGCCGGGGGGCGCAGGCTATGCGCTGCTGGCGGACTGGCTGATCCAGCTTGATCCGGTGAACCCGCAGACCGCGGCGCGGCTGTCGACGGCGTTCGAGACCTGGCGCCGCTACGACCCCGCGCGCCAGGGCGCGATGCGCGCGGCGCTGGAGCGGATCCGCGCGACCCCCGACCTCAGCCGCGATCTGTCGGAAATGACGGCCCGGATGCTGGGCTGA",
      "translation": "MKDATPQPIRLADYTPPPFLVEGVALTFRLAPRATRVTSRIRFRRNPDAQAQDLRLDGEGLRLISATIDGVPITAQPDATGLTLPGGDLPDAFDWAAEVEIAPEENTALEGLYMSNGMYCTQCEAEGFRKITFYPDRPDVMAPFTVRVESELPVLLSNGNPSAQGDGWAEWDDPWPKPAYLFALVAGDLVAHSDAFATASGRAVALNVWVRPGDEGRCAYAMDSLKRSMRWDEEAYGREYDLDVFNIVAVDDFNMGAMENKGLNVFNSKYVLASSETATDADFDNIERIVAHEYFHNWTGNRITCRDWFQLCLKEGLTVFRDQQFSADMRSAAVKRIEDVLSLRARQFREDQGPLAHPVRPDSYHEINNFYTATVYEKGAEIIRMLRTLVGEDGYDAGVRLYFDRHDGQACTIEDWLAVFAEATGRDLSQFARWYAQAGTPRLRVTEDWDEGTGRFTLTLEQSTPPTPGQPDKAPQVIPVAVGLLGPAGDEIMATRVIEMTDTRHSLTIEGMPARPVPSILRGFSAPVVVEHAVTPERRAFLMAHDTDPFSRWEAGRGLAREILVAMVRDGAAPGPDYLDALAVTLSDERLDPAFRALCLRAPSEDDIAQALVDAGETPDPMAIHTARERFQRAIAAHMDDGLARAFIAMETPGPYSPDARDAGRRALRLAALAYLSRNDGGDRAARLFAGADNMTEQMGALGALLQVGAGQSEVARFHRQWAHDRLVVDKWFAVQVALAAPESAVETARSLTRHPDFDWKNPNRFRSVLGALATNAAGFHAPGGAGYALLADWLIQLDPVNPQTAARLSTAFETWRRYDPARQGAMRAALERIRATPDLSRDLSEMTARMLG",
      "product": "Aminopeptidase N"
     },
     {
      "start": 10256,
      "end": 11779,
      "strand": 1,
      "locus_tag": "KKHPANEM_02028",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02028</span></strong><br>\n \n  Cryptochrome-like protein cry2<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02028</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">cry2</span><br>\n \n Location: 10,256 - 11,779,\n (total: 1524 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02028 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00875.20 (DNA photolyase): [3:129](score: 95.5, e-value: 3.4e-27)<br>\n \n  PF03441.16 (FAD binding domain of DNA photolyase): [262:455](score: 181.8, e-value: 1.2e-53)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02028\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=256&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/cry2_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGGTTCGATTGTCTGGTTCAAGCGTGACCTGCGGGTGGCCGACCACGCGGCGCTGTGTGCGGCGGCGGCGCTTGGCCCCGTGCTGCCGCTTTATGTGGTGGAGCCGGAGCTGTGGGCACAGCCCGACGCCTCGGCCCGGCAATGGGCGTTCGTTGCCGAGTGTCTGGAGGCGCTGCGCGGCGACCTGGCCGCGCTGGGGGCGCCGCTGGTCGTGCGCACTGGCTGCGCGGTCGAGGTGCTGGAGACGCTGGCCCGCCGCCACCGCCTGTCGCGCATCTTCAGCCACGAGGAGACCGGCACCCTGTGGACCTTTGCCCGCGACCGGCGTGTGGGGGCGTGGGCGCGCGCCAACGGCATGGCGTGGCACGAGGGGCCGCAGTCGGGCGTGGTGCGCCGCCTTGCCGCGCGCGATGGCTGGGCGGGGCGGCGGGATCGCTTCCTCGCCGCGCCCGCGGCCCAGCCGCCGGGGCTGTCGGCGGTGCCCGGCGTGGCGCCCGGCCCGATCCCCACCGCCCGCACCCTGCGCCTGGCCGAGGACCGCTGCCCCCACCGCCAGGTTGGCGGGCGGCAGGCCGCGCTGACCACGCTGGGCGGGTTCCTGACCTCGCGGGGCGAGGGGTACCGCGCCGCCATGGCCTCGCCCGTAGCCGGGGAACGCGCGTGTTCGCGCCTCTCGCCGCACCTGGCCTTCGGCGTGCTGTCCGGGCGCGAGGTCGCGCACGCCGCGGCCGCCCGCCGCGCCGAACGCCCCGGCGGTGGCTGGGGGGCTTCGCTGCGCAGCTTTGAATCGCGCCTCGCCTGGCGCGACCACTTCATGCAGAAGCTGGAGGACGCCCCCGACCTGGAGGCCCGCTGCCTGCACCGCGCGACCGAAAGCCTGCGCCCGCGCACGCCCGACGCCACCCGCCTCGCGGCATTCCAGTCCGCCGAGACCGGCATCCCCTTTGTCGACGCCTGCCTGCGGTATCTGGCGGCCACCGGCTGGCTGAACTTCCGCATGCGCGCGATGCTGGTGTCGGTGGCGGCGAACCACCTGTGGCTGGACTGGCGCGCCACGGGGCCGTTCCTGGCGCGGCGCTTCACCGACTACGAACCCGGCATCCACTGGAGCCAGATGCAGATGCAGTCCGGCACCACCGGCATCAACACCATCCGCATCTACAACCCCGTCAAGCAGGGCCGCGACCAGGACCCCGACGGCCGCTTCACCCGCGCCTGGCTGCCGGAGCTGGCCGAGGTGCCCGACGCCTTCCTGCACGAACCCTGGCGCTGGGGCGGGGCAGGGCGCGTGCTGGGGCGCGCCTATCCCGAGCCGGTGGTCGATGTCGCCGCCGCCGCCCGCGCCGCGCGCGAGGCGGTGTGGGGCCTGCGCCGCGCCCGCGGTTTCGCCGCCGAAGCCGCCGAGGTCGCCCGCAAGCACGCCAGCCGCAAGGACCGCTCGGGCCATTTCGTCAACGACCGCGCGCCCCGACGCCGTCGCCCCGCCGCAGCCCCGGGCCAGCTGTCGCTGGATCTCTGA",
      "translation": "MTGSIVWFKRDLRVADHAALCAAAALGPVLPLYVVEPELWAQPDASARQWAFVAECLEALRGDLAALGAPLVVRTGCAVEVLETLARRHRLSRIFSHEETGTLWTFARDRRVGAWARANGMAWHEGPQSGVVRRLAARDGWAGRRDRFLAAPAAQPPGLSAVPGVAPGPIPTARTLRLAEDRCPHRQVGGRQAALTTLGGFLTSRGEGYRAAMASPVAGERACSRLSPHLAFGVLSGREVAHAAAARRAERPGGGWGASLRSFESRLAWRDHFMQKLEDAPDLEARCLHRATESLRPRTPDATRLAAFQSAETGIPFVDACLRYLAATGWLNFRMRAMLVSVAANHLWLDWRATGPFLARRFTDYEPGIHWSQMQMQSGTTGINTIRIYNPVKQGRDQDPDGRFTRAWLPELAEVPDAFLHEPWRWGGAGRVLGRAYPEPVVDVAAAARAAREAVWGLRRARGFAAEAAEVARKHASRKDRSGHFVNDRAPRRRRPAAAPGQLSLDL",
      "product": "Cryptochrome-like protein cry2"
     },
     {
      "start": 11878,
      "end": 12774,
      "strand": 1,
      "locus_tag": "KKHPANEM_02029",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02029</span></strong><br>\n \n  1,4-dihydroxy-2-naphthoate octaprenyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02029</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">menA</span><br>\n \n Location: 11,878 - 12,774,\n (total: 897 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ubiA<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02029 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01040.20 (UbiA prenyltransferase family): [38:275](score: 134.1, e-value: 5.2e-39)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02029 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01476 (chlor_syn_BchG: bacteriochlorophyll/chlorophyll synthetase): [16:296](score: 377.6, e-value: 8.9e-114)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02029 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01040.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups<br>\n  \n   PF01040.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02029\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=1878&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/menA_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02029\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02029\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTGTCACGTCTGATTTACACACCCGCACCCTGCCACAGCCCGCCGCGATGCTGGAGCTGATCAAGCCGATCACCTGGTTTCCGCCGATGTGGGCCTATCTGTGCGGCGTCATCTCGTCCGGGGTGTCGCCGCTGGAAAGCCTGTTTCTGGTCATCCTCGGCGTCCTGCTGGCGGGTCCCATCGTCTGCGGGATGAGCCAGGCGGCCAACGACTGGTGCGACCGCCACGTCGATGCGATCAACGAACCGCACCGGCCGATCCCCTCGGGGCGCATTCCGGGCCGCTGGGGGCTGTGGATCGCGCTGGCGATGTCGGGGCTGGCGCTGGTGGTGGGCTGGTTCCTCGGGCCGTGGGGCTTTGGCGCCACCGTGCTGGGGGTGATCGCGGCCTGGGCCTATTCCTGCCCGCCGGTGCGGCTGAAGCGGTCGGGCTGGTGGGGGCCGGGGCTGGTCGGGCTGTCGTATGAATCGCTGCCGTGGTTCACCGGCGCGGCCGTCCTCGCCGTCGGCGCGCCCAGCTGGGAGATCGTCGCGGTGGCCGTGCTCTATGGCCTCGGCGCGCACGGGATCATGACGCTCAACGATTTCAAGGCGCTGGAGGGCGATCGCCAGATGGGCGTGAACTCCCTGCCCGTGACGCTGGGCCCGGAGCTGGCGGCCAAGGTCGCGTGCTGGGTGATGATCGTCCCGCAACTCGTTGTGATCGCGCTTCTCTTCCAGTGGGATCGTCCCTGGTACGGCTTCTTCATCGTGATCTCGGTGATCCTGCAGTTCTATGCCATGTCGGTGCTGCTGCGCGACCCCAAGGCCAAGGCGCCCTGGTACAATGCCACCGGTGTCAGCCTCTATGTCACCGGCATGATGATCACCGCTTTCGCGCTGCGCACGCTCTGA",
      "translation": "MSVTSDLHTRTLPQPAAMLELIKPITWFPPMWAYLCGVISSGVSPLESLFLVILGVLLAGPIVCGMSQAANDWCDRHVDAINEPHRPIPSGRIPGRWGLWIALAMSGLALVVGWFLGPWGFGATVLGVIAAWAYSCPPVRLKRSGWWGPGLVGLSYESLPWFTGAAVLAVGAPSWEIVAVAVLYGLGAHGIMTLNDFKALEGDRQMGVNSLPVTLGPELAAKVACWVMIVPQLVVIALLFQWDRPWYGFFIVISVILQFYAMSVLLRDPKAKAPWYNATGVSLYVTGMMITAFALRTL",
      "product": "1,4-dihydroxy-2-naphthoate octaprenyltransferase"
     },
     {
      "start": 12785,
      "end": 14089,
      "strand": 1,
      "locus_tag": "KKHPANEM_02030",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02030</span></strong><br>\n \n  Protein PucC<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02030</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pucC_2</span><br>\n \n Location: 12,785 - 14,089,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02030 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03209.17 (PUCC protein): [30:420](score: 379.8, e-value: 1.6e-113)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02030\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=2785&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02030\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02030\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCGTTCAACCGCTTTCATGGCTCTCCATCTTCCGGCTCGGGCTGGTGCAGCTGTGCCTCGGTGCGATCGTGGTGCTGATGACCTCGACCCTCAACCGGCTGATGGTGGTGGAGCTGATGCTGCCCGCCGTCCTGCCCGGTGCGCTGGTGGCGCTGCACTACGGCATCCAGATCACGCGGCCCAACTGGGGCTACCGCTCGGACACCTGCGGAAACCGCACGCGCTGGGTGATCGTGGGGATGGGGATGCTGGCCGCGGGCGCGCTGCTGGCGGCCTTTGCGATCCCGGTGATGGAGGCGACCTTCTGGCTGGGACTGTGCGTGTCGATCCTCGCCTATGCGCTGATCGGGATGGGGGTGGGGGCCTCGGGGACCTCTCTGCTGGCGCTGATGGCGACGGCCACGGCGGAACACCGCCGGCCGGCGGCGGCCTCGATCACCTGGCTGATGATGATCTTCGGCATCGCCGTCACCGCGATCACCGTGGGGCAGGTGCTGGACCCCTACAGCCACGACCGCATGCTCGCCATCGTCGCGGTGGTCACGGGGGGCGCTTTCGTGGTCACCTGCCTCGCCATCTGGGGGATCGAGCGGCGCGCCGGCGTCCAGGCCGCCCCCCTGGCCGAGCCCATGACCTTCCGTGCCGGCCTGCGCGAGATCTGGGCCGAGCGCGCGGCGCGCAACTTCACCTTCTTCGTGTTCCTGTCGATGACCGCCTATTTCATGCAGGAACTGATCATGGAGCCCTTCGCGGGCCTCGTCTTCGACATGACGCCGGGTCAGACGACGTCCATGTCGGGCGCGCAGAACGGCGGCGTGTTCGTCGGCATGGTGCTGGTGGGGGTGTGCGCCACGGGGCTGCGCTTCGGTGCGCTGCGCTCCTGGGTCGTCGCGGGGTGCCTCGGCTCGGCCGCGACGCTGGCGGCGATCACGCTGATCGCCAGCGCGGGGCTGAAGCCGCTGCTGGTGCCGTCGGTCATCACGCTGGGCTTCTTCAACGGCATGTTCGCGGTCGCCGCCATCGGTGCCATGATGCAGCTCGCCGGTCAGGGCCGCGAGCGCCGCGAGGGCACCCGCATGGGGCTGTGGGGCGCCGCGCAGGCCATCGCCGCGGGCTTTGGCGGGCTGGTGGGCGCGGGGCTGGCCGATGCCATGCGCACCACGCTGGGCAACGACGCCAGCGCCTTCGGCGCCGTCTTTTCGATCGAGGCCGGTCTCTTCCTCCTCAGCGCGCTGGTTGCGCTGCGGGTGATGGGGGGACGCGGCCAAACCGCCCGCATGGGCCTTGTTGCTGGGGAGTGA",
      "translation": "MPVQPLSWLSIFRLGLVQLCLGAIVVLMTSTLNRLMVVELMLPAVLPGALVALHYGIQITRPNWGYRSDTCGNRTRWVIVGMGMLAAGALLAAFAIPVMEATFWLGLCVSILAYALIGMGVGASGTSLLALMATATAEHRRPAAASITWLMMIFGIAVTAITVGQVLDPYSHDRMLAIVAVVTGGAFVVTCLAIWGIERRAGVQAAPLAEPMTFRAGLREIWAERAARNFTFFVFLSMTAYFMQELIMEPFAGLVFDMTPGQTTSMSGAQNGGVFVGMVLVGVCATGLRFGALRSWVVAGCLGSAATLAAITLIASAGLKPLLVPSVITLGFFNGMFAVAAIGAMMQLAGQGRERREGTRMGLWGAAQAIAAGFGGLVGAGLADAMRTTLGNDASAFGAVFSIEAGLFLLSALVALRVMGGRGQTARMGLVAGE",
      "product": "Protein PucC"
     },
     {
      "start": 14094,
      "end": 15287,
      "strand": 1,
      "locus_tag": "KKHPANEM_02031",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02031</span></strong><br>\n \n  Menaquinone reductase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02031</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">menJ_1</span><br>\n \n Location: 14,094 - 15,287,\n (total: 1194 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1161:oxidoreductase (Score: 73.9; E-value: 2.1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02031 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07992.16 (Pyridine nucleotide-disulphide oxidoreductase): [2:152](score: 36.0, e-value: 4.8e-09)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02031 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02023 (BchP-ChlP: geranylgeranyl reductase): [2:388](score: 533.9, e-value: 5.1e-161)<br>\n \n  TIGR02032 (GG-red-SF: geranylgeranyl reductase family): [2:300](score: 254.2, e-value: 5e-76)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02031 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07992.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02031\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=4094&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/menJ_1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02031\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02031\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCTATGATGTCGTCGTCGTCGGAGGGGGACCCTGCGGGGCCACCGCGGCCGAGGATCTGGCCCGCGCCGGCAAGCGCGTGGCCCTGATCGACCGCGCGGGCCGGATCAAGCCCTGCGGCGGGGCCATCCCGCCCCGGCTGATCGCGGATTTCGACATCCCCGACGAGATGATCGTGGCGAAGATCAACACCGCCCGCATGATCTCGCCCACCGGCCGCAAGGTCGACATCCCCATCGAGGGCGGCTTCGTCGGCATGGTCGACCGCGAGCACTTCGACGAATTCCTGCGCGTGCGCGCAGCCAAGGCGGGCGCCGAGCGTCACACCGGCACCTTCGTGCGCATCGACCGGGATGAGAGCGGCGCCCGCGTCATCTACCGCGACAAGGCCACCAAGGAAGAGCGCGCGCTGCCCACCCGGCTCGTGATCGGCGCGGACGGCGCACGCTCCGGCGTGGGCCGGCAGGAGGTGCCGGGCGGCGACACCATCCCCTATGTCATCGCCTATCACGAGATCATCACCCCGCCCGAGGGCGGCGCACAGGCCGCCGCCGACTATGATCCCATGCGCTGCGACGTGATCTATGACGGCGCGATCTCGCCCGACTTCTATGGCTGGGTGTTCCCGCACGGGAAATCCTGTTCCGTCGGCATGGGGACGGGCATGGACGGGGTGGACCTGAAGGCCTGCACGGCGGCGTTGCGCGCGAATTCCGGCCTTGCAGGCTGCGAGACGATCCGGCGTGAAGGCGCGCCGATCCCGCTCAAGCCGCTGGACCGCTGGGACAATGGCCGTGACGTGGTGCTGGCGGGCGATGCCGCCGGTGTGGTGGCGCCCAGCTCGGGTGAGGGGATCTACTATGCCATGGCCTGCGGGCGCGCGGCGGCCACCGCGGTGCAGGCCTGCCTGGCGTCGGGCCGTGCCAAGGACCTGCAGATGGCGCGCAAGATGTTCCTCAAGGAGCACGGCGGCGTCTTCAAGATCCTCGGCGCGATGCAGAACGCCTATTACCGCTCGGACGAGCGGCGCGAACGCTTCGTCTCGCTGTGCCACGACATCGACGTGCAGAAGCTGACGTTCGAGGCCTACATGAACAAGAAGCTGGTGAACGCGCGGCCCTTTGCCCACATGAAGATCGGGGTGAAGAACCTGCTGCACCTGTCGGGCCTCGTGCGGCCCACCTACGCATGA",
      "translation": "MTYDVVVVGGGPCGATAAEDLARAGKRVALIDRAGRIKPCGGAIPPRLIADFDIPDEMIVAKINTARMISPTGRKVDIPIEGGFVGMVDREHFDEFLRVRAAKAGAERHTGTFVRIDRDESGARVIYRDKATKEERALPTRLVIGADGARSGVGRQEVPGGDTIPYVIAYHEIITPPEGGAQAAADYDPMRCDVIYDGAISPDFYGWVFPHGKSCSVGMGTGMDGVDLKACTAALRANSGLAGCETIRREGAPIPLKPLDRWDNGRDVVLAGDAAGVVAPSSGEGIYYAMACGRAAATAVQACLASGRAKDLQMARKMFLKEHGGVFKILGAMQNAYYRSDERRERFVSLCHDIDVQKLTFEAYMNKKLVNARPFAHMKIGVKNLLHLSGLVRPTYA",
      "product": "Menaquinone reductase"
     },
     {
      "start": 15296,
      "end": 15826,
      "strand": 1,
      "locus_tag": "KKHPANEM_02032",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02032</span></strong><br>\n \n  Isopentenyl-diphosphate Delta-isomerase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02032</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">idi</span><br>\n \n Location: 15,296 - 15,826,\n (total: 531 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02032 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00293.30 (NUDIX domain): [26:158](score: 77.6, e-value: 8.8e-22)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02032 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02150 (IPP_isom_1: isopentenyl-diphosphate delta-isomerase): [16:161](score: 120.8, e-value: 1.1e-35)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02032\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=5296&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/idi_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02032\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02032\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGAGATGATCCCGGCCTGGGTGAACGGCCGCCTGACCCCGGTGGAGAAGCTGGAGGCGCATCTGCAAGGGCTGCGCCACAAGGCGATCTCGGTCTTCGTCATGGACGGGGACCGGGTGCTGATCCAGCAGCGCGCGATGGGCAAGTACCACACGCCGGGGATGTGGGCGAACACCTGCTGCACCCATCCCCACTGGGACGAGGGGGCCGAGGCCTGCGCCACCCGCCGCCTGCGCGAGGAGCTGGGGATCGAGGGGCTGACCCTCGGCCACCGCGACCGCGTCGAATACCGCGCCGAGGTCGGCAACGGCCTGATCGAGCATGAGGTGGTGGACATCTTCACCGCCGCCGCCGGCCCGACGCTGCACATCGCCCCGAACCCCGACGAGGTGATGGCGGTGCGCTGGGTCCCGCTCGATACGCTGCGCGCCGAGGTCGCGCGGGAACCCGCGCGCTTCACCCCGTGGCTGCGCATCTATCTGGCAGAGCATGCCGCCGCGATCTTCGGAGCGATGGCGCGCGCGTGA",
      "translation": "MTEMIPAWVNGRLTPVEKLEAHLQGLRHKAISVFVMDGDRVLIQQRAMGKYHTPGMWANTCCTHPHWDEGAEACATRRLREELGIEGLTLGHRDRVEYRAEVGNGLIEHEVVDIFTAAAGPTLHIAPNPDEVMAVRWVPLDTLRAEVAREPARFTPWLRIYLAEHAAAIFGAMARA",
      "product": "Isopentenyl-diphosphate Delta-isomerase"
     },
     {
      "start": 15839,
      "end": 16312,
      "strand": -1,
      "locus_tag": "KKHPANEM_02033",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02033</span></strong><br>\n \n  Tryptophan-rich sensory protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02033</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">tspO_2</span><br>\n \n Location: 15,839 - 16,312,\n (total: 474 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02033 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03073.17 (TspO/MBR family): [9:145](score: 140.3, e-value: 3.9e-41)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02033 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03073.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02033\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=5839&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02033\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02033\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACTGGCTCTTGTTCTCCGTCTTTCTGTTCGCCTGCGCGGCCGCGGGCACCACTGGCGCGATGTTCGAGCCGGGAAAGTGGTATCGTGACCTCACCAAGCCGAGCTGGACGCCTCCGAACTGGCTGTTCCCGGTGGCGTGGTCGCTTCTGTACATCGCGATGTCACTGGCGGCGATGCGGGTGGCGCTGGCGGGTGACAGCGCCCTGGCGCTGGCGTTGTGGTCCACGCAGATCGCCTTCAACACGCTGTGGACACCGGTGTTCTTCGGTCTGAAACGGATGCGGGCGGCGATGGGCGTGATGGTCGCGCTGTGGGCATCGGTCGCGGCGACCATGGTGGCGTTCTGGCAGGTCGACCTGATCGCGGGGCTGTTGTTCGTGCCCTATCTTGCCTGGGTCACGGTGGCGGGTGCGCTGAACTTCAGCGTCTGGCGCCTCAACCCCGAGACAGGCACCCCGGCGGGGGCCTGA",
      "translation": "MDWLLFSVFLFACAAAGTTGAMFEPGKWYRDLTKPSWTPPNWLFPVAWSLLYIAMSLAAMRVALAGDSALALALWSTQIAFNTLWTPVFFGLKRMRAAMGVMVALWASVAATMVAFWQVDLIAGLLFVPYLAWVTVAGALNFSVWRLNPETGTPAGA",
      "product": "Tryptophan-rich sensory protein"
     },
     {
      "start": 16312,
      "end": 17421,
      "strand": -1,
      "locus_tag": "KKHPANEM_02034",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02034</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02034</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,312 - 17,421,\n (total: 1110 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02034 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.21 (Squalene/phytoene synthase): [32:279](score: 213.8, e-value: 3.2e-63)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02034 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02034\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=6312&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/KKHPANEM_02034_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02034\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02034\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCACCGTCGCCACCGACGCCCCCCGCGCGGCCCCGGCCGTGCGCCGCACGGCCCTGTTGGCCGAGGACCTGGACCATTGCGAGGCCGCGATCCGCACCGGGTCGCGGTCCTTCTTCACCGCCTCCAAGCTGTTGCCGGGGCGGGTGCGGCGTCCGGCGCTGGCGCTTTATGCCTTCTGCCGGCTGTCGGACGATGCGGTCGACCTGACGCGCGAGAAGCCCGCCGCGATCCTGGCGCTGCGTGACCGGCTGGACCTGGTGTATCGCGGCACGCCGCGCAATGCCCCTGCCGACCGGGCCTTCGCCGCCATCGTGGAGGAGTTCGAGATGCCGCGCGCCCTGCCGGAGGCCCTGCTGGAGGGGCTGGCGTGGGACGCGCAGGGGCGGCGCTACCGCACCATCGACGATCTGCACAGCTACTCCGCGCGGGTGGCGGCGGCGGTGGGGGCGATGATGTGCGTGCTGATGCGGGTGCGCGATGCCGATGCGCTGGCGCGGGCCTGCGATCTGGGGCTGGCGATGCAGCTGACCAACATCGCCCGCGACGTCGGCGAGGATGCGCGCGAGGGGCGGCTGTTCCTGCCCACCGACTGGATGGAGGGGGCGGGCATCGACACGCAGGCGTTCCTGGCCGATCCGCAGCCCACCGCCCCGGTATGCCGGGTGGTTCGGCGCCTTCTGGCCGAGGCCGACCGGCTGTATTTCCGCTCCGAGGCCGGGATCGCGGCGCTGCCGCTGTCGGTGCGCCCGGGAATTGCGGCGGCGCGTCACATCTATGCCGCCATCGGCACGCGGATCGCCTGTGCGGGCCACGACAGCATCACCCAGCGCGCCTATACCGGGCCGGGGGCCAAGCTGTGGGGGCTGGCCACGGCGGGGGTGCATGTCGCCGTCACCCTGGCGCTGCCGCGCCCGGTGGAGCTGCACGCCCTGCCCGAGCCGTCGGTGGCGTTTCTGGTGAATGCCGCGGCCCACGCACCGCCGGCGCGCGAAACCTGGGCACAGGGACGTTCGGCTGCGCTTTTGTCGGTGCTCTCGGACCTGGAATCGCGCGATCGCGCACGGCGGGGCTTGATGGGACGGGCGACAGAGCCTAACTGCGAGTGA",
      "translation": "MSTVATDAPRAAPAVRRTALLAEDLDHCEAAIRTGSRSFFTASKLLPGRVRRPALALYAFCRLSDDAVDLTREKPAAILALRDRLDLVYRGTPRNAPADRAFAAIVEEFEMPRALPEALLEGLAWDAQGRRYRTIDDLHSYSARVAAAVGAMMCVLMRVRDADALARACDLGLAMQLTNIARDVGEDAREGRLFLPTDWMEGAGIDTQAFLADPQPTAPVCRVVRRLLAEADRLYFRSEAGIAALPLSVRPGIAAARHIYAAIGTRIACAGHDSITQRAYTGPGAKLWGLATAGVHVAVTLALPRPVELHALPEPSVAFLVNAAAHAPPARETWAQGRSAALLSVLSDLESRDRARRGLMGRATEPNCE",
      "product": "hypothetical protein"
     },
     {
      "start": 17418,
      "end": 18971,
      "strand": -1,
      "locus_tag": "KKHPANEM_02035",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02035</span></strong><br>\n \n  Phytoene desaturase (neurosporene-forming)<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02035</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtI_2</span><br>\n \n Location: 17,418 - 18,971,\n (total: 1554 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 410.1; E-value: 2.6e-124)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02035 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.26 (Flavin containing amine oxidoreductase): [27:501](score: 110.8, e-value: 1e-31)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02035 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02734 (crtI_fam: phytoene desaturase): [20:511](score: 640.4, e-value: 4.8e-193)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02035 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02035\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=7418&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/crtI_2_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02035\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02035\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTCAACCGCATGCAGGACGACGTGGCCGTGGCCGCGGATGGGGCGCGACGGCCGCGGGCGCTGGTGATCGGCGCGGGTCTGGGTGGGCTGGCGGCGGCGATGCGGCTGGGGGCCAAGGGCTACCGGGTGACGGTGATCGACCGGCTGGACCGGGCGGGCGGGCGCGGGTCGTCGATCACGCAGGACGGGCACCGCTTCGATCTGGGCCCGACCATCGTCACCGTGCCGCAGTTGTTTCGCGAATTGTGGGCGGCGTGCGGGCGCGATTTCGATGCGGACGTGGATTTGCGCGCGCTCGATCCGTTCTATCAGATCCGCTGGCCCGACGGCTCGCACTTCACCGTGCGCCAGTCGACCGAGGCGATGCGGGCCGAGGTGGCGCGGCTGTCGCCCGATGACCTGCCCGGCTACGACAAGTTCCTCAAGGACGCCGAGGCGCGGTATTCCTTCGGCTTCGAGGATCTGGGCCGCCGGTCGATGCACAAGTTCATCGACCTGGTGAAGGTGCTGCCGAAGTTCGCCATGCTGCGCGCCGACCGGTCGGTGGCGGCGCACGCAGCAGCCCGGGTGCGCGACCCGCGCCTGCGCATGGCGCTGTCGTTCCACCCGCTGTTCATCGGCGGCGACCCGTTCCACGTCACCTCCATGTACATCCTCGTCAGCCACCTGGAGAAGGAATACGGCGTGCATTACGCGGTGGGCGGCGTGCAGGCCATCGCCGACGCCATGGTCCGCGTGATCGAGGACCAAGGCGGCACCCTTCGGCTGGACGAGGAGGTCGACGAGGTGCTGGTGAAATCGGGCCGGGTCGCCGGTCTGCGCACCACCCAGGGCGAGGTGATGACCGCCGACATCGTGGTGTCCAACGCGGACGCCGGCCACACCTATACCCGGCTTCTGCGCAACCACCGCCGCCGGCGCTGGACGGATGCCAAGCTGAAGCGGCGCACATGGTCGTCGGGGCTGTTCGTTTGGTACTTCGGGACCAAGGGGACGAAGGACATGTGGCCGGATCTGGGCCACCACACCATCCTCAACGGTCCCCGGTACGAAGGGTTGCTGCGCGACATCTTCCTCAACGGCAAGCTGTCGGAGGACATGAGCCTCTATATCCACCGCCCCTCGGTCACCGATCCGGGCGTGGCGCCTGCGGGCGACGACACCTTCTATGTGCTGTCGGTGGTGCCGCATCTGGGCTTCGACAACCCGGTGGACTGGAAGGCGGAGGGGGAGCGGTACCGCGCCGCCATGACCAGGGTGCTGGAGGAGCAGGTGATGCCGGGCTTTGCCGAGCGTGTGGGCCCGTCGCTGGTGTTCACGCCCGAGGATTTCCGCGACCGCTACCTGTCGCCCCACGGCGCGGGGTTCTCGATCGAGCCGCGGATCCTGCAATCGGCCTATTTCCGGCCGCACAACGTGTCCGAGGAGCTGCCGGGGCTGTATCTGGTGGGCGCGGGCACGCATCCCGGCGCGGGCCTGCCGGGGGTGGTGTCCTCGGCCGAGGTGCTGGGCAAGCTCGTTCCCGACGCGCAGCCGCAGGGGGTCGCATGA",
      "translation": "MLNRMQDDVAVAADGARRPRALVIGAGLGGLAAAMRLGAKGYRVTVIDRLDRAGGRGSSITQDGHRFDLGPTIVTVPQLFRELWAACGRDFDADVDLRALDPFYQIRWPDGSHFTVRQSTEAMRAEVARLSPDDLPGYDKFLKDAEARYSFGFEDLGRRSMHKFIDLVKVLPKFAMLRADRSVAAHAAARVRDPRLRMALSFHPLFIGGDPFHVTSMYILVSHLEKEYGVHYAVGGVQAIADAMVRVIEDQGGTLRLDEEVDEVLVKSGRVAGLRTTQGEVMTADIVVSNADAGHTYTRLLRNHRRRRWTDAKLKRRTWSSGLFVWYFGTKGTKDMWPDLGHHTILNGPRYEGLLRDIFLNGKLSEDMSLYIHRPSVTDPGVAPAGDDTFYVLSVVPHLGFDNPVDWKAEGERYRAAMTRVLEEQVMPGFAERVGPSLVFTPEDFRDRYLSPHGAGFSIEPRILQSAYFRPHNVSEELPGLYLVGAGTHPGAGLPGVVSSAEVLGKLVPDAQPQGVA",
      "product": "Phytoene desaturase (neurosporene-forming)"
     },
     {
      "start": 19098,
      "end": 19808,
      "strand": 1,
      "locus_tag": "KKHPANEM_02036",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02036</span></strong><br>\n \n  Spheroidene monooxygenase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02036</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtA</span><br>\n \n Location: 19,098 - 19,808,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02036\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=9098&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02036\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02036\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGACCGTCACCCTCTCGCTGTTTCGCTTTCCCACCCTGTCCGCGCGGCTCTGGGCGTTCGGCCAGATGGCGCTGGCGCGCTGGGACCTCAAGCGCACCCCCGATCTGTTGCAGTGGAAGCTGTGCGGCTCGGGCACGGGCGAGGGGTTCACCCCGGTGCCCAACACCGCCGTCTATGCGATCCTCGCGACCTGGCCCTCCGAGGAGATCGCCCGGGAGCGCATCGCCAAATCGAAGGTCTGGGCCCGCTGGCGTGCGCATGCCGCCGAGGACTGGACGATCTTCCTCGCGGCGACATCGGTGCGGGGCAAATGGGCCGGGGTGGAGCCGTTCCACGCCGTGGCCGAGCCGACCGACGGCCCGCTGGCGGCGCTGACGCGTGCGACGGTGAAGCCCAAGGTCGCGCTGAAGTTCTGGGGTTCGGTCCCCGACATCTCCCGGATGATCGGCATGGACGAACATGTCGCCTTCAAGATCGGCATCGGCGAGGTGCCGCTGCTGCACCAGGTGACCTTCTCGATCTGGCCCGACACCAGGACGATGGCCGAGTTCGCCCGCCACGACGGCCCCCACGCCCGCGCCATCAAGGCCGTGCGCGACGGGCAATGGTTCAACGAAGAGTGCTATGCCCGCTTCCGCATCCTGGGCGAGTGTGGCAGTTGGGACGGAACAAGCCCGCTGAAACCGCTCGAGAGGTCCGCCGCATGA",
      "translation": "METVTLSLFRFPTLSARLWAFGQMALARWDLKRTPDLLQWKLCGSGTGEGFTPVPNTAVYAILATWPSEEIARERIAKSKVWARWRAHAAEDWTIFLAATSVRGKWAGVEPFHAVAEPTDGPLAALTRATVKPKVALKFWGSVPDISRMIGMDEHVAFKIGIGEVPLLHQVTFSIWPDTRTMAEFARHDGPHARAIKAVRDGQWFNEECYARFRILGECGSWDGTSPLKPLERSAA",
      "product": "Spheroidene monooxygenase"
     },
     {
      "start": 19805,
      "end": 20809,
      "strand": 1,
      "locus_tag": "KKHPANEM_02037",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02037</span></strong><br>\n \n  Magnesium-chelatase 38 kDa subunit<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02037</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">bchI</span><br>\n \n Location: 19,805 - 20,809,\n (total: 1005 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02037 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01078.23 (Magnesium chelatase, subunit ChlI): [6:180](score: 52.9, e-value: 3.2e-14)<br>\n \n  PF17863.3 (AAA lid domain): [260:320](score: 66.4, e-value: 1.6e-18)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02037 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02030 (BchI-ChlI: magnesium chelatase ATPase subunit I): [4:333](score: 548.5, e-value: 1.2e-165)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02037 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01078.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02037\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=9805&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02037\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02037\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGCTCCGTTCCCGTTCTCCGCGATCGTCGGCCAGGAGGAGATGAAGCTCGCCATGGTCCTGACCGCCATCGACCCCGGCATCGGGGGCGTTCTGGTGTTCGGGGACCGCGGAACGGGGAAATCGACGGCGGTGCGGGCGCTTGCGGCACTGCTGCCGCCCATCCGGCAGGTCGAGAGCTGCCCCGTGAACTCCGCCCGGCTGGAGGACTGCCCCGAGTGGGCGCGGCTGACCTCACGGGAGATCGTCACCCGCCCCACGCCGGTGGTCGACCTGCCGCTGGGCGCGACCGAGGACCGGGTGGTCGGCGCGCTCGACATCGAACGCGCGCTCAGCCAGGGCGAAAAGGCGTTCGAGCCGGGCCTGCTGGCGCGCGCCAACCGCGGGTATCTCTACATCGACGAGGTCAACCTGCTGGAGGACCACATCGTCGACCTGCTGCTGGACGTCGCCCAATCCGGCCAGAACGTGGTGGAGCGCGAGGGCCTCTCGATCCGCCACCCCGCGCGCTTCGTCCTCGTCGGCTCCGGCAACCCCGAGGAAGGCGAGCTGCGTCCGCAGCTTCTCGATCGCTTCGGGCTGTCGGTGGAGGTTGGCTCTCCCAAGGACATCCCCACCCGGATCGAGGTCATCCGCCGCCGCGACGCCTATGAAAACGACCACGCCGCCTTCATGGCCAAATGGCAGGAGGAGGACACCACCCTGCGCGAGCGGATCCTGGCCGCGCGCACCCGGCTGTCGGCCATCGCCACCCCCGAGGCCGCGTTGCACGACTGCGCGGAGCTGTGCGTGGCGCTCGGCTCGGACGGGCTGCGCGGAGAGCTGACGCTGCTGCGCACCGGGCGCGCCTTCGCGGCCTATCACGGCGCCGACACGCTGACCCGCGACCACCTGCGCGAGGTCGCGCCGATGTCGCTGCGCCACCGCCTGCGCCGCGATCCGCTGGACGAGGCCGGGTCGGGCGCCCGCGTCGGCCGCGTGATCGAAGAGGTCTTCGGGTGA",
      "translation": "MKAPFPFSAIVGQEEMKLAMVLTAIDPGIGGVLVFGDRGTGKSTAVRALAALLPPIRQVESCPVNSARLEDCPEWARLTSREIVTRPTPVVDLPLGATEDRVVGALDIERALSQGEKAFEPGLLARANRGYLYIDEVNLLEDHIVDLLLDVAQSGQNVVEREGLSIRHPARFVLVGSGNPEEGELRPQLLDRFGLSVEVGSPKDIPTRIEVIRRRDAYENDHAAFMAKWQEEDTTLRERILAARTRLSAIATPEAALHDCAELCVALGSDGLRGELTLLRTGRAFAAYHGADTLTRDHLREVAPMSLRHRLRRDPLDEAGSGARVGRVIEEVFG",
      "product": "Magnesium-chelatase 38 kDa subunit"
     }
    ],
    "clusters": [
     {
      "start": 16311,
      "end": 17421,
      "tool": "rule-based-clusters",
      "neighbouring_start": 6311,
      "neighbouring_end": 21589,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 11896,
       "end": 11898,
       "strand": 1,
       "containedBy": [
        "KKHPANEM_02029"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r273c1"
   }
  ]
 },
 {
  "length": 22057,
  "seq_id": "NZ_NHSD01000274.1",
  "regions": []
 },
 {
  "length": 22750,
  "seq_id": "NZ_NHSD01000275.1",
  "regions": []
 },
 {
  "length": 25097,
  "seq_id": "NZ_NHSD01000276.1",
  "regions": []
 },
 {
  "length": 22444,
  "seq_id": "NZ_NHSD01000277.1",
  "regions": []
 },
 {
  "length": 22778,
  "seq_id": "NZ_NHSD01000278.1",
  "regions": []
 },
 {
  "length": 5224,
  "seq_id": "NZ_NHSD01000279.1",
  "regions": []
 },
 {
  "length": 23221,
  "seq_id": "NZ_NHSD01000280.1",
  "regions": []
 },
 {
  "length": 23363,
  "seq_id": "NZ_NHSD01000281.1",
  "regions": []
 },
 {
  "length": 23250,
  "seq_id": "NZ_NHSD01000282.1",
  "regions": []
 },
 {
  "length": 23693,
  "seq_id": "NZ_NHSD01000283.1",
  "regions": []
 },
 {
  "length": 43730,
  "seq_id": "NZ_NHSD01000284.1",
  "regions": []
 },
 {
  "length": 24027,
  "seq_id": "NZ_NHSD01000285.1",
  "regions": []
 },
 {
  "length": 6271,
  "seq_id": "NZ_NHSD01000286.1",
  "regions": []
 },
 {
  "length": 34087,
  "seq_id": "NZ_NHSD01000287.1",
  "regions": []
 },
 {
  "length": 6272,
  "seq_id": "NZ_NHSD01000288.1",
  "regions": []
 },
 {
  "length": 35029,
  "seq_id": "NZ_NHSD01000289.1",
  "regions": []
 },
 {
  "length": 11768,
  "seq_id": "NZ_NHSD01000290.1",
  "regions": []
 },
 {
  "length": 6509,
  "seq_id": "NZ_NHSD01000291.1",
  "regions": []
 },
 {
  "length": 36052,
  "seq_id": "NZ_NHSD01000292.1",
  "regions": [
   {
    "start": 11262,
    "end": 36052,
    "idx": 1,
    "orfs": [
     {
      "start": 14088,
      "end": 15638,
      "strand": 1,
      "locus_tag": "KKHPANEM_02420",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02420</span></strong><br>\n \n  Dihydrolipoyllysine-residue succinyltransferase component of 2-oxoglutarate dehydrogenase complex<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02420</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">sucB</span><br>\n \n Location: 14,088 - 15,638,\n (total: 1551 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02420 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00364.24 (Biotin-requiring enzyme): [3:76](score: 78.9, e-value: 2e-22)<br>\n \n  PF00364.24 (Biotin-requiring enzyme): [104:177](score: 74.6, e-value: 4.4e-21)<br>\n \n  PF02817.19 (e3 binding domain): [216:247](score: 37.3, e-value: 2.7e-09)<br>\n \n  PF00198.25 (2-oxoacid dehydrogenases acyltransferase (catalytic domain)): [285:514](score: 270.0, e-value: 1.6e-80)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02420 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01347 (sucB: dihydrolipoyllysine-residue succinyltransferase, E2 component of oxoglutarate dehydrogenase (succiny): [103:515](score: 558.3, e-value: 2.7e-168)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02420 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00198.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity<br>\n  \n   PF02817.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02420\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=4088&amp;to=25638\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/sucB_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02420\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02420\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCATCGAAGTCCGCGTGCCCACGTTGGGCGAATCCGTCACCGAGGCCACGGTGGCGACGTGGTTCAAGAAGCCCGGCGAGACGGTCGCCGCCGACGAAATGCTGTGCGAGCTGGAGACCGACAAGGTCACGGTGGAGGTGCCCAGCCCCGCCGCCGGCACGCTGGGCGAGATCGTCGCGGCCGAGGGCGACACGGTGGGGGTGGATGCGCTGCTGGCAACCCTGACCGAGAGCGACGGCAAACCCGCACCGGCCCGCGGCGGCGCGCCCAAGGCCGCCGCACCCGCGGCTCCGGCGGGTGACACCGTGGACGTCATGGTCCCCGCGCTGGGCGAAAGCGTCAGCGAGGCGACAGTCGCCACCTGGTTCAAGGCGGTGGGCGACAGCGTCGCCGCCGACGAGATCCTGTGCGAACTGGAGACCGACAAGGTCAGCGTCGAGGTCCCGAGCCCCACCGCCGGCACGCTGTCGCAGATCGTCGCCGAGGCCGGGACCACGGTGGCCGCGGGTGGCAAGCTTGCGGTCCTGGCGGCCGGTGAGGGCGGCGCCGCGGCCACGGGGACCGGCGCGGCCGCAGCCCCTGCCCCGCCCACCGCCGCTGCGGCCGAGCGCAGCGGCGCGGGCCGCGCGGATGTGGAAGACGCCCCTTCGGCGAAGAAGATGATGGCCGAGAAGGGGCTGACGCGCGATCAGGTCGAAGGCACCGGCCGTGACGGGCGGATCATGAAGGAGGACGTGGCGCGCGCCGCGGCGGACGCGGCCCCGGCGGCGCAGGCTGCGCCTGCCCCGACCATGCCCGCCCCCGCAGCCCAACAGGCACCGCGCGCCGCCGTCCCGGCCGACGATGCCGCCCGCGAAGAGCGGGTGAAGATGAGCCGCCTGCGCCAGACCATCGCGCGCAGGCTCAAGGATGCGCAGAACACCGCGGCCATGCTGACCACCTATAACGAGGTGGACATGGGCCCGATCATGGATCTGCGCAACGAATACAAGGGGTTGTTCGAAAAGAAGCACGGCGTGAAGCTTGGCTTCATGTCCTTCTTCGTCAAGGCCTGCTGCCACGCCCTGCACGAGGTGCCCGAGGTCAACGCCGAGATCGACGGCACCGATGTGGTCTACAAGAACTATGTCCACATGGGCGTGGCGGTGGGCACGCCGTCAGGGCTGGTGGTGCCGGTGCTGCGCGATGCGCAGGCCATGGGCTTTGCCGAGATCGAAAAGACCATCGCGTCCCTGGGCGCACGCGCGCGCGACGGCAAGCTGTCGATGGCCGACATGCAGGGCGGATCGTTCACCATCTCCAACGGCGGGGTGTATGGCTCGCTGATGTCGTCGCCGATCCTGAACCCGCCGCAGTCGGGGATCCTGGGGATGCACAAGATCCAGGATCGTCCGATGGTGGTGAAGGGTCAGATCGTGGCGCGCCCCATGATGTACCTCGCGCTGAGCTATGACCACCGGATCGTGGACGGCAAGGGCGCGGTGACGTTCCTTGTCCGCGTCAAGGAGGCGCTGGAGGACCCGCGGCGCCTGTTGATGGACCTCTGA",
      "translation": "MSIEVRVPTLGESVTEATVATWFKKPGETVAADEMLCELETDKVTVEVPSPAAGTLGEIVAAEGDTVGVDALLATLTESDGKPAPARGGAPKAAAPAAPAGDTVDVMVPALGESVSEATVATWFKAVGDSVAADEILCELETDKVSVEVPSPTAGTLSQIVAEAGTTVAAGGKLAVLAAGEGGAAATGTGAAAAPAPPTAAAAERSGAGRADVEDAPSAKKMMAEKGLTRDQVEGTGRDGRIMKEDVARAAADAAPAAQAAPAPTMPAPAAQQAPRAAVPADDAAREERVKMSRLRQTIARRLKDAQNTAAMLTTYNEVDMGPIMDLRNEYKGLFEKKHGVKLGFMSFFVKACCHALHEVPEVNAEIDGTDVVYKNYVHMGVAVGTPSGLVVPVLRDAQAMGFAEIEKTIASLGARARDGKLSMADMQGGSFTISNGGVYGSLMSSPILNPPQSGILGMHKIQDRPMVVKGQIVARPMMYLALSYDHRIVDGKGAVTFLVRVKEALEDPRRLLMDL",
      "product": "Dihydrolipoyllysine-residue succinyltransferase component of 2-oxoglutarate dehydrogenase complex"
     },
     {
      "start": 15638,
      "end": 15925,
      "strand": 1,
      "locus_tag": "KKHPANEM_02421",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02421</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02421</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,638 - 15,925,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02421\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=5638&amp;to=25925\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02421\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02421\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTGGGGATCCTGTTTCTGGTCGCGGTGGCGCTGGTGGCGCTGGTGGTGGTGCAAAGCGTGCGCCAGGGCCGGCGCTTCATCCGCGCCGCGCTGTTCCTGCACGAGCTGGAGGGCGGGCGCCCGAAGGACTCCGCCAACGCCGCAGCCAACCTGTTGTTCAGCCCGGAAAGCTCGGCCTCGGCCGATGCGCATGCCGCCCAGATCGCGGACGCGCGGCGCAAGCGCACCTCCGAGACGCAGGCGCAGGTGATCGGCGCCGCGCGCGACCGCGGGTTCGAGGGGTGA",
      "translation": "MLGILFLVAVALVALVVVQSVRQGRRFIRAALFLHELEGGRPKDSANAAANLLFSPESSASADAHAAQIADARRKRTSETQAQVIGAARDRGFEG",
      "product": "hypothetical protein"
     },
     {
      "start": 15930,
      "end": 16337,
      "strand": 1,
      "locus_tag": "KKHPANEM_02422",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02422</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02422</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,930 - 16,337,\n (total: 408 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02422 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01124.20 (MAPEG family): [10:134](score: 81.2, e-value: 6.1e-23)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02422 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01124.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02422\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=5930&amp;to=26337\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02422\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02422\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAGGGATCATGACGACGGAGCTGACGGTTCTGGTGCTGGCCGCCCTTCTGGCGGTGGTTCAGCTGGGCTGGAACGCGGTGCGCGCCAACCTGGAGATGGGGCCGGACTGGTTCCTCACGCCACGCGACAGCGCCCCGCCGCAGCCGCTGCCGGTTGCGCTGGGTCGGCTCAAGCGCGCCTATGAGAACCACATGGAGACGCTGCCGCTGTTTGCCATCGCGGCCATCGTGGTGACGCTGGCGGGCGCCTCGTCCGGCCTGACGGCGGCCTGCGCGTGGATCTACCTGGCCGCTCGGGTGCTGTTCGTGCCGGCCTACCGCTTCGGCTGGATGCCGTGGCGCTCGTTCATCTGGGCGGCGGGCTTCGTCGCCACCGTTCTGATGCTGCTGGCCGCGCTGATCTGA",
      "translation": "MTGIMTTELTVLVLAALLAVVQLGWNAVRANLEMGPDWFLTPRDSAPPQPLPVALGRLKRAYENHMETLPLFAIAAIVVTLAGASSGLTAACAWIYLAARVLFVPAYRFGWMPWRSFIWAAGFVATVLMLLAALI",
      "product": "hypothetical protein"
     },
     {
      "start": 16366,
      "end": 17754,
      "strand": 1,
      "locus_tag": "KKHPANEM_02423",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02423</span></strong><br>\n \n  Dihydrolipoyl dehydrogenase 3<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02423</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">lpd3</span><br>\n \n Location: 16,366 - 17,754,\n (total: 1389 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1175:pyridine nucleotide-disulfide oxidoreductase (Score: 476.3; E-value: 1.3e-144)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02423 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07992.16 (Pyridine nucleotide-disulphide oxidoreductase): [3:324](score: 216.4, e-value: 5.4e-64)<br>\n \n  PF02852.24 (Pyridine nucleotide-disulphide oxidoreductase, dimerisation domain): [342:452](score: 136.2, e-value: 5.4e-40)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02423 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01350 (lipoamide_DH: dihydrolipoyl dehydrogenase): [2:461](score: 553.7, e-value: 6.9e-167)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02423 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07992.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02423\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=6366&amp;to=27754\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/lpd3_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02423\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02423\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAAGCTATGACGTGATCTTCATCGGCTCCGGCCCCGGCGGCTATGTCGGCGCCATCCGCGCAGCCCAGCTGGGCCTGCGCACCGCCTGCGTGGAGGGGCGCGAGACGCTGGGCGGCACCTGCCTGAACGTGGGCTGCATCCCCTCCAAGGCGCTGCTGCACGCCACCCACATGCTGCACGAGGCCGAGCACAACTTCGCCGAGATGGGCCTTGGCGGCGGCAAGCCCAAGGTCGACTGGGGCAAGATGCAGTCCTACAAGGACGACGTCATCGCCCAGAACACCAAGGGGATCGAGTTCCTGTTCAAGAAGAACAAGGTGGACTGGATCAAGGGCTGGGCCTCCATCCCCGCGCCGGGCAAGGTGAAGGTCGGCGACGACGTGCACGAGGCCCGGGCCATCGTGATCGCCTCGGGCTCCGAATCCGCCTCCCTTCCGGGGGTGGAGGTCGACGAGAAGGTCGTGGTCACCTCCACCGGCGCGCTGGAGCTGGGCCGCATCCCCAAGCGGCTGGCGGTGATCGGCGGCGGCGTGATCGGGCTGGAGATGGGCTCGGTCTATGCCCGCCTGGGGGCGCAGGTGACGGTGCTGGAGTACCTCGACCGGCTGATCCCCGGCAACGACATGGAGGTCGCGCGGACCTTCCAGCGCATCCTGAAGAAGCAGGGGATGGAGTTCATCCTCGGCGCCGCCGTGCAGGGGGTGGAGGCCACCAGGACCAAGGCCAAGGTCAGCTACACCCTGAAGAAGGACGACAGCGCCCAGACGCTGGAGGCCGATGTGGTGCTGCTCGCCACCGGGCGTCGTCCCTTCACCGACGGGCTGGGGCTGGACACACTGGGCGTGACCCTGTCCAAGCGCAGACAGGTGGAGGTCGATGGCCGCTACGAGACCTCGGTCAAGGGCGTCTACGCCATCGGCGACGCCATCACCGGCCCGATGCTCGCGCACAAGGCCGAGGATGAGGGCTACGCCGTGGCCGAGATCCTCGCGGGCCAGGCGGGCCATGTGAACTACGCCACCATCCCCGGCGTGATCTACACCCACCCCGAGGTCGCGAGCGTGGGCGAGACCGAGGAGACGCTGAAGGAGGCCGGGCGCGCCTACAAGGTCGGCAAGTTCAGTTTCATGGGCAATGGCCGGGCCAAGGCCAACTTCGCCGCCGACGGCTTCGTCAAGATCCTGGCTGACAAGGACACCGACCGCATCCTGGGCGCCCACATCATCGGCCCGATGGCGGGCGACCTGATCCACGAGATCTGCGTCGCGATGGAGTTCGGCGCCGCGGCCGAGGATCTTGCCCGCACCTGCCATGCCCACCCCACCTACTCCGAAGCGGTGCGCGAGGCGGCGCTGGCCTGCGGCGACGGGGCGCTGCACGCCTGA",
      "translation": "MASYDVIFIGSGPGGYVGAIRAAQLGLRTACVEGRETLGGTCLNVGCIPSKALLHATHMLHEAEHNFAEMGLGGGKPKVDWGKMQSYKDDVIAQNTKGIEFLFKKNKVDWIKGWASIPAPGKVKVGDDVHEARAIVIASGSESASLPGVEVDEKVVVTSTGALELGRIPKRLAVIGGGVIGLEMGSVYARLGAQVTVLEYLDRLIPGNDMEVARTFQRILKKQGMEFILGAAVQGVEATRTKAKVSYTLKKDDSAQTLEADVVLLATGRRPFTDGLGLDTLGVTLSKRRQVEVDGRYETSVKGVYAIGDAITGPMLAHKAEDEGYAVAEILAGQAGHVNYATIPGVIYTHPEVASVGETEETLKEAGRAYKVGKFSFMGNGRAKANFAADGFVKILADKDTDRILGAHIIGPMAGDLIHEICVAMEFGAAAEDLARTCHAHPTYSEAVREAALACGDGALHA",
      "product": "Dihydrolipoyl dehydrogenase 3"
     },
     {
      "start": 17981,
      "end": 19657,
      "strand": -1,
      "locus_tag": "KKHPANEM_02424",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02424</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02424</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,981 - 19,657,\n (total: 1677 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02424 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02646.18 (RmuC family): [230:526](score: 323.0, e-value: 1.5e-96)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02424\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=7981&amp;to=29657\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02424\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02424\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGACGCCCCCTGGCAGGCTCCCACCCCCGAGGAACTGCGCGCCCTGGCCGATGCCACCCTGGCCGAGGCGGTCGCGCTGGCGGAGGGGCTGCGCGCGCTGGGGCCAGCGGTGCAGGTCGCGGCGGGGCTGCTGGCCGCGCTGGTGCTGGCCGTGGTCTGGGCGGTGCTGCGCGCGCGGACCCGGCGCGAGGCGCTGCTGCGCGCCGACCTGATGGCGCGGCTGGCCGATCTGGAGGCCACCACCCGCCGGGCCGAGGCCGCCGAGGCCAACGCCGCCGCGCGCGCCGATGACCTTGCGGCGCTCACGGCCCGGGCGGAGGGGCTGGAGGGCAGCTTGCGGGCTGCCACCGTGACCGAGCGGGACCTGACCGCGCGCGCCGCCGCCCTCGATGCCCGGCTCGAGAGTGCCGAGCGCCGCCTGGCCGAGCGGCGCACCGAGGCCGAGGCGCGCGAGTCCGCCATCGCCGGGCTGCGCGGTCGGCTGGAGGCCGAGCAGGCCGCGCAGCGCGCGTTGCAGGCCCGCATCGCCGGGCTGACCCAGGAGCTGGAGAGCGAACAGGCCCGTGGCGCCGAAAAGGTGGCGCTGCTGTCGTCGGTGCGCGAGGACATGCAGGCGCGTTTCCGCGACCTCGCCGATGCCGCGCTGAAGACCCAGGCGGAGGTGTTCTCCAACACCAGCTTTGCCCGGCTGGAGGCGACGCTGACGCCGCTGAAGGAACATGTCGGCCATTTCGAGAAGGAACTGCGCGCCGTCCACACCGAGACCGCGCGGGACCGCGAGCGCCTGAAGGCCGAGATCGCCGCGCTGTCGAAACGCTCCGAGGAGGTCTCGCACGAGGCGATGGCGCTGACGCGCGCGCTCAAGGGCGACCGGCAGCGGCAGGGCGCCTGGGGGGAGATGATCCTCGAGAGCATCCTCGAACGCTGCGGCCTGCGCGAGGGCGAGGAGTACGAGACCCAGGCCCACCGCACCGACGACGAGGGCGCCCGCCTGCGCCCCGACGTGGTGGTGCGCATCCCCGGCGACCGCACGCTGGTGATCGATTCCAAGGTCTCGCTGAACGACTATGCCGCCGCCGTGAACGCCGAGGACGCGGCCGAGGCCGCCGGCCACCGCAAGCGCCATGTTGCGGCCCTGCGCGCCCACATCACCGGACTGTCGGCCAAGGGCTATCAGCGCGCCGAGGACGCCTCGGTCGACTATGTCATCATGTTCGTGCCCATCGAGGGCGCGCTGTCGGAGGCGCTGCGCGAGGACGGCGGGCTGACCGGCTTTGCGCTGGAGCGCCACATCACCATCGCCACGCCCACCACGCTGATGATGGCGCTGCGCACGGTGGCCCATGTCTGGGCCGTGGAGCGGCGCAACCGCAACGCCGAGGCGATCGCGGACCGGGCCGGCAAGCTCTATGACAAGCTGGTGGGATTTCTGGAAAACATGGAGACGGTGGGCAAGCGCCTCGACCAGGCGCAGGCGGCCTATGGCGACGCGCTGGGGCAGCTGTCGCGCGGGCGCGGCAACCTGCTGTCGCAGGTGGAGACCCTCAAGACGCTGGGCGCCAAGGCCACCAAGACCATCGCCACCGAGTTCGAGGACACCGCCCCCCCGGGCACCCTCGCCGCGGACCCCGAAACCGATCCCCCGAAGTTCGACAGGAAAGCCGACAGGTGA",
      "translation": "MTDAPWQAPTPEELRALADATLAEAVALAEGLRALGPAVQVAAGLLAALVLAVVWAVLRARTRREALLRADLMARLADLEATTRRAEAAEANAAARADDLAALTARAEGLEGSLRAATVTERDLTARAAALDARLESAERRLAERRTEAEARESAIAGLRGRLEAEQAAQRALQARIAGLTQELESEQARGAEKVALLSSVREDMQARFRDLADAALKTQAEVFSNTSFARLEATLTPLKEHVGHFEKELRAVHTETARDRERLKAEIAALSKRSEEVSHEAMALTRALKGDRQRQGAWGEMILESILERCGLREGEEYETQAHRTDDEGARLRPDVVVRIPGDRTLVIDSKVSLNDYAAAVNAEDAAEAAGHRKRHVAALRAHITGLSAKGYQRAEDASVDYVIMFVPIEGALSEALREDGGLTGFALERHITIATPTTLMMALRTVAHVWAVERRNRNAEAIADRAGKLYDKLVGFLENMETVGKRLDQAQAAYGDALGQLSRGRGNLLSQVETLKTLGAKATKTIATEFEDTAPPGTLAADPETDPPKFDRKADR",
      "product": "hypothetical protein"
     },
     {
      "start": 19848,
      "end": 20525,
      "strand": -1,
      "locus_tag": "KKHPANEM_02425",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02425</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02425</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,848 - 20,525,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02425\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=9848&amp;to=30525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02425\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02425\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGATTGCGCATGGCCACTACGCGACCCTCGTCTTCGATTGCGACGGCGTCGTCCTCGACTCCAATCGGCTGAAGACGGAGGCATTCCGGCGCGCGGCGCTGCCGTGGGGGGAAGCGGCGGCTGATGCGCTGGTGGCGTATCATATCGCGCACGGAGGGGTGTCGCGGTATGTCAAGTTCCGGCATTTCCTCGATGCGCTGGTGCCAGAGCATGCGCCCGGCGGCTGCGGGCCGGGGCTGGAGGGGTTGCTTGACGCATATGCCGGGGCGGTGCGCGACGGGTTGATGACCTGCGGTGTGGCGCCGGGGCTGGCAGAGCTGCGGGCGGCGACGCCGGGGGTGCGTTGGCTGATCGTGTCGGGCGGCGACCAGGCGGAGCTGCGCGAGGTGTTTGCGGCGCGGGGTCTGGACCGGCACTTCGACGGCGGGATCTTCGGCAGCCCGGACACCAAGGCGGCGATCCTCGCCCGTGAGCTTGCGGCGGGCAACATCCGCCGCCCGGCGCTGTTTCTTGGCGACAGTCGGCTGGACTTTGAGGCGGCGGCCGGTGCCGGGCTGGATTTTACCTTCGTCTCGGGCTGGTCCGAGGTGGCGGACTGGCGCGGCTTTGTTGCCGAACACCGGCTGGCCTGCGTGGCGGGGCTGTCGGATCTGTTGGGCGGGGCAGGTCCGGCCTGA",
      "translation": "MIAHGHYATLVFDCDGVVLDSNRLKTEAFRRAALPWGEAAADALVAYHIAHGGVSRYVKFRHFLDALVPEHAPGGCGPGLEGLLDAYAGAVRDGLMTCGVAPGLAELRAATPGVRWLIVSGGDQAELREVFAARGLDRHFDGGIFGSPDTKAAILARELAAGNIRRPALFLGDSRLDFEAAAGAGLDFTFVSGWSEVADWRGFVAEHRLACVAGLSDLLGGAGPA",
      "product": "hypothetical protein"
     },
     {
      "start": 20522,
      "end": 21175,
      "strand": -1,
      "locus_tag": "KKHPANEM_02426",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02426</span></strong><br>\n \n  3-deoxy-manno-octulosonate cytidylyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02426</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">kpsU</span><br>\n \n Location: 20,522 - 21,175,\n (total: 654 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02426 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02348.21 (Cytidylyltransferase): [0:185](score: 69.8, e-value: 3.3e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02426\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=10522&amp;to=31175\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02426\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02426\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCCTGTGGGTTGCCGAACTCTCGGCAAGAGCTGTCGGGCAGGATCATGTCTATGTTGCCACGGAGGATGAGCGGATCGCTGAGGTGGTGCGCGCATCCGGATTCGCTGCGCTGATGACAAGTGCATCCGCCCTGACCGGCACGGACCGTGTTGCCGAAGCCGCACAGAAGATCGATTATGACATCTATGTCAATGTGCAGGGCGACGAGCCGATTGTGGATCCTGCGGACATCCGACGCTGTATTGCGATAAAGTCGAACAACCTTGAGAAGGTTGTGAACGGATACTGCTGGGTTGGCTCTGATGAAGACCCGGCGTCCGTGAATATTCCGAAAGTCATCACCAACGAGTCGGACGATCTGGTTTACATGTCGCGCGTGGCTTTGCCGGGGTTCAAGGATGCGACGAATGCGCCGGACAGGTTCAAGAAGCAGGTGTGCATCTATGGTTTCACCCGGCAGGAGCTCATGGAATATGCGGCGTTCGGCCGAAAGAGTTATTTGGAAAAGTGCGAAGACATCGAGATCCTTCGTTTTTTGGAGATCGAACGAAAGGTTTTGATGTTCCAATGCAAGCCGGGTAGCCTTGCAGTTGATGTTCCCGCGGACGTATCCCCAGTCGAGGCATTGTTGCGGGAACGCCTCAGTTGA",
      "translation": "MILWVAELSARAVGQDHVYVATEDERIAEVVRASGFAALMTSASALTGTDRVAEAAQKIDYDIYVNVQGDEPIVDPADIRRCIAIKSNNLEKVVNGYCWVGSDEDPASVNIPKVITNESDDLVYMSRVALPGFKDATNAPDRFKKQVCIYGFTRQELMEYAAFGRKSYLEKCEDIEILRFLEIERKVLMFQCKPGSLAVDVPADVSPVEALLRERLS",
      "product": "3-deoxy-manno-octulosonate cytidylyltransferase"
     },
     {
      "start": 21262,
      "end": 22884,
      "strand": -1,
      "locus_tag": "KKHPANEM_02427",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02427</span></strong><br>\n \n  4-hydroxy-2-oxovalerate aldolase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02427</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">mhpE</span><br>\n \n Location: 21,262 - 22,884,\n (total: 1623 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n  biosynthetic-additional (smcogs) SMCOG1271:2-isopropylmalate synthase (Score: 104.2; E-value: 1.4e-31)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02427 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00682.21 (HMGL-like): [136:254](score: 73.9, e-value: 1.6e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02427 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00682.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02427\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=11262&amp;to=32884\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02427\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02427\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAATCAATATGACTGGCGGCACGCTTCTTGACTGCACATTCCGGGACGGCGGATACTACAACGCCTGGGATTTCTCGCCCGCGCTGATCACACAGTACCTCGGGGCCATGCGGGCCGCGCAGGTGGATGTGGTGGAGCTGGGGTTCCGTTTTCTGCGCAACGAGGGGTTCAAGGGGCCCTGCGCCTTCACCACCGATGACTTCCTGCGCAGCCTGCCGATCCCACCGGGGCTGACGGTGGGGGTGATGCTCAACGGGGCGGATCTGTGCACCGACTTGGGCCGGGGCGCCGCGCTGCAGAGGCTGTTTCCCGAACCGGCCGCATCCACGCCGGTCGATCTGGTCCGCTTTGCCTGCCATTTCCATGAGCTGGAGACGGTTCTGCCCGCCGTCGGCTGGCTGCACGAGCGCGGCTACCGGGTCGGGCTGAACCTGATGCAGATCGCCGACCGCTCGCGAACGCAGGTCGCCGAGCTTGCGAAAATGTCCCGCGACTGGCCGGTGGAGGTGCTGTATTTTGCCGACTCCATGGGCTCCATGACGCCCGACGACACCGCCCGCATCGTCGGCTGGCTGCGCGACGGGTGGGAGGGGCCGCTGGGCATCCACACCCACGACAACATGGGGCTTGCGCTGTCCAACACGCTGCGTGCCGCGGCCGAGGGCGTCACCTGGCTCGATGCCACCGTCACCGGGATGGGGCGCGGCCCGGGCAACGCCCGCACCGAGGAACTGGCGATCGAGGCGGAGGGCCTGCGCAACCGGCGCGCCAATCTCGTGCCGCTGATGGGCCTGATCCGCAAGCACTTCGGCCCGATGAAGGCGCAGTACGGCTGGGGCACCAACCCGTATTACTTCCTTGCCGGAAAGTACGGCATCCATCCCACCTATATCCAGGAAATGCTGGGCGACGCGCGCTATGACGAGGAGGACATCCTTGCCGTGATCGACCATCTGCGCGCCGAGGGCGGCAAGAAGTTCAGCTTCAACACCCTCGACGGCGCGCGGCAGTTCTACAGCGGCGCGCCGCGTGGCAGCTGGGCCCCGTCCGAGGTCATGGCCGGCCGCGACGTGCTGATCTTGGGCACCGGGCCGGGCGTGGCCGCGCATCGCCCTGCGCTGGAGGCCTATATCCGCCGCGCCCGGCCGCTGGTGCTGGCGCTCAACACCCAGTCGGCCATCGATCCCGCGCTGATCGACCTGCGCATTGCCTGCCACCCGGTCCGTCTTCTCGCCGACGCCGAGGCCCACGCGGCGCTTCCGCAACCGCTGATCACCCCGGCCTCCATGCTGCCCGAAACCCTCCGGGCCGAGTTCGGCGACAAGGAGCTTCTGGATTTCGGGATCGGTATCGAGCCTGGCCGGTTCGAGTTCCACGCGACGCACTGCGTTGCGCCCAACTCTCTGGTTCTGTCCTACGCGCTGTCTGTCGCGGCCAGCGGTCAAGCTTCGCGTATCCTGATGGCAGGCTTCGACGGCTATCCCGCCAGCGACCGCCGCAATGATGAGGTCGATGACATGCTGCTCAAGTTCGTGAATTCCGAATTCACGGGTCCGGTGTTTTCGATAACGCCAAGCGCTTACGGAAATCTTCCCGCGCTCAGCCTGTACGGTATGTGA",
      "translation": "MTINMTGGTLLDCTFRDGGYYNAWDFSPALITQYLGAMRAAQVDVVELGFRFLRNEGFKGPCAFTTDDFLRSLPIPPGLTVGVMLNGADLCTDLGRGAALQRLFPEPAASTPVDLVRFACHFHELETVLPAVGWLHERGYRVGLNLMQIADRSRTQVAELAKMSRDWPVEVLYFADSMGSMTPDDTARIVGWLRDGWEGPLGIHTHDNMGLALSNTLRAAAEGVTWLDATVTGMGRGPGNARTEELAIEAEGLRNRRANLVPLMGLIRKHFGPMKAQYGWGTNPYYFLAGKYGIHPTYIQEMLGDARYDEEDILAVIDHLRAEGGKKFSFNTLDGARQFYSGAPRGSWAPSEVMAGRDVLILGTGPGVAAHRPALEAYIRRARPLVLALNTQSAIDPALIDLRIACHPVRLLADAEAHAALPQPLITPASMLPETLRAEFGDKELLDFGIGIEPGRFEFHATHCVAPNSLVLSYALSVAASGQASRILMAGFDGYPASDRRNDEVDDMLLKFVNSEFTGPVFSITPSAYGNLPALSLYGM",
      "product": "4-hydroxy-2-oxovalerate aldolase"
     },
     {
      "start": 22941,
      "end": 24263,
      "strand": -1,
      "locus_tag": "KKHPANEM_02428",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02428</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02428</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,941 - 24,263,\n (total: 1323 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02428\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=12941&amp;to=34263\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02428\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02428\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTGGCCTGGTTGCAATGGAGGCTCAAGGGTCTGGCTATGGACCTGGCCTATCGGCTGCCGCTGGCGCTTGTGGCCCGATTGGCGCCATCGCCGATGCGGATGATTTCCTTCTATCTGGCAAAAGCCGATTCACCTCGGGCGTTGCAATACCTTGACCACTTGGTTCGAATCTCGCCCGAGGTTGGCTGCCTCATGCGGCTTGACGAGCGGTTGCGGAGGGGAAGCATAAGTGGCGTCGATCTGGTGGATTCAATCCCGAGCTCGATCTTGCGGAAGCTCAATTCCTACAAGGATGTACATCTGAACGATGCCGCAAGGGCCTTCAACCGCTTGGGTTGCCTTCGGTTGGGAGGAGCCCTGCGAGGCCTTCTGCTGATCAAGCTCGTGCAGCAGAGATTTCGGAGCCCGGCGAAGCAAGGCTGGGAGCTTGACGCTTTGCTCCTTGAGGTTTCTGCCAATGACTACAGCCGCCGCCTTTTTTCGCGTCCCGAGCTTTGGGAGGATGGCCTTGACAGGCAAGTTCAGGACCGCATCGAATTGCTTCGATGCTCTGACATGTTGGTCAAGCTGCGCGTTTTTGTTGATTCGGAAAGACTGCCATGCGGGGAACACGAGGCCTCTCTGAGCGGCTTGTCGGTGCTGCTACAGGGGCCGTCGAGGAGGGAGTCCAATCTGGCTGGTACACCTTGTGACGTGGTTGGCACCATCGGTTACTCTGGAGCCGGCTCCCTCGCCAGGCTCGTTGAAGGCAGGCACGTATCCTTCTACCGGCCATACAAAATTCGCGCAATGATTGCTGAAGGGTTAACCGAAAGATTTAACGATGTTGACCTGGCGGTTGTCACCAAGCGAGGCCTCGGTGTTTTGGAGGCACAGTTCACGCCAGAGTGCAGGGTTGCCTGCTCCAAGGTGCGAGAGAGGTTTGGACTTGGTTTCCTGAACGGAGGAACGGAGTTTCTGATCTGGCTCTTGGCATGCGATCTGAACCGGCTCTTCGTCACAAATGTCGATCTTTTTCTCAACCCAGCGTACCCGGTCGGTTATCTGCCGAGCAACTACCAGAAATCTCACCTTTCAAAGGATGCTGCGCAATGGCAGACACAGTCGTGGGCGACGCTAATGGTTTTTGGAGATCATGAACCGAGTCAGCAGTACTCTATCTACAAGGCCTTTCATGGTTACGATTCCGTTGTATACGACTCGATGCTTGATGCAATTGTATCTGCGCCGTTCAGCGCATACGCGGAGGCGCTTGAAGATGCCTATCGGGTTTGGCCCCAAGGTCCCGTCGTCGATTGCTGCGGTGGTGGCTCGGCTTGA",
      "translation": "MLAWLQWRLKGLAMDLAYRLPLALVARLAPSPMRMISFYLAKADSPRALQYLDHLVRISPEVGCLMRLDERLRRGSISGVDLVDSIPSSILRKLNSYKDVHLNDAARAFNRLGCLRLGGALRGLLLIKLVQQRFRSPAKQGWELDALLLEVSANDYSRRLFSRPELWEDGLDRQVQDRIELLRCSDMLVKLRVFVDSERLPCGEHEASLSGLSVLLQGPSRRESNLAGTPCDVVGTIGYSGAGSLARLVEGRHVSFYRPYKIRAMIAEGLTERFNDVDLAVVTKRGLGVLEAQFTPECRVACSKVRERFGLGFLNGGTEFLIWLLACDLNRLFVTNVDLFLNPAYPVGYLPSNYQKSHLSKDAAQWQTQSWATLMVFGDHEPSQQYSIYKAFHGYDSVVYDSMLDAIVSAPFSAYAEALEDAYRVWPQGPVVDCCGGGSA",
      "product": "hypothetical protein"
     },
     {
      "start": 24278,
      "end": 25579,
      "strand": -1,
      "locus_tag": "KKHPANEM_02429",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02429</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02429</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,278 - 25,579,\n (total: 1302 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02429\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=14278&amp;to=35579\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02429\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02429\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGTTCGCCTGAAGCGCCTCGGCATGGGAGTCGCGATGTCGGTCGTGCCTCGGCTTCCTGCATCGCTGGCGATGCGGATTACTCCGTCGCCCGTCTGGCTGGTGTCGCTTCTCCTGACGCGGGACGATCCGGCCGCGGCGGTGCGGTGCCTCAAGCGGCTCGCCGCGACCAGTCCCGAGATAGCTGCCCTTCTGCGCATCGACGAACAGCTGCAGTCCGGGGCCATCCCTGCCGATGCAATCGCCGACGCGATGCCAATCCCGGTGTTGCAGGCTTTCGTCACCACCGGGATTGCGCCTCTCCGGCATGCTGCCAAGGCGTTCAACGCGCTCGGGTGCCTGCGGCTGGGGGGGGCACTGAGGGCGCTCGTGCTTTTGCGGGTTGCCGCTGCGAACATTGCCTCCGGCGAGGACCGCGGATGGCAGCACGAGGCAGTACTTCTGGAGATCGCGGCCAACGATCACTGCGCGCGGTTCATGGCCCGCCCGGAGGTGATGCCAGAGGCCTGCCGCACGGCGCTTCAGGAAGAACTGCAAGCGGTCGCCGGCTGGAGCCTGGCGCGCAAGGTCTCGGTTCTCGTGGGCCAGGACAGCCCCGCCATGCCGGCGTTGCGCGCGCGCATGGCCGGCCGCAGCCTTCGGTTCCAGGGTCCGTCGAGCCGTTCCTCCGATCTGGACGATACGCCGGCCGATCTGACATGCGTCGTCGGCTACTCCGGACCTGGCTCGCTGGCCCGCCCGGTCGACAGCATTGGTGTGTCGCTATACAAGAAGCACAAGATCGCGGCGATGCGCGGGGACGGACTGCTGCATCACATGGCGGACGTGCAGGTTCCGGTGCTCAACCCGGAGGACCTGCGCCAAGAACGTGCGTTTTATGCGGACCTGATCGAGAAATATGGAGCCAGTTTGACGAATGTGCGCTGGGCGTCCCTGAACTCCCAGATGAATGCGGGCACGGAACTGTTTGTCTGGATGTTGAACTGCGGCGCTTCCTCGGTTTCTGTCAGTCACCTTGACCTGTTCTTGAACCGAACCTATCCCCCCGGTTACCTGGCCGGCGGCAAGGCGCAAGCCTCCCGTGACGGGCCAGGCTGGCAGATGGAGGAGTGGTCGCAGTTGAAGAGCTTCGGCTACCATGAGCCCAGCCAGCAGTTCGCGATCTACAGGGCGTTTCATCCGCATCGCGAGGTGGCGTACGATGGCATACTCGATGCGATCGTGGAGAAACCATTCAGCGCCTACGCGAGCGCGCTTGAGGACGGCTATCGAGTTTGGCGCGGTCGGGCCGAGGCGTGA",
      "translation": "MTVRLKRLGMGVAMSVVPRLPASLAMRITPSPVWLVSLLLTRDDPAAAVRCLKRLAATSPEIAALLRIDEQLQSGAIPADAIADAMPIPVLQAFVTTGIAPLRHAAKAFNALGCLRLGGALRALVLLRVAAANIASGEDRGWQHEAVLLEIAANDHCARFMARPEVMPEACRTALQEELQAVAGWSLARKVSVLVGQDSPAMPALRARMAGRSLRFQGPSSRSSDLDDTPADLTCVVGYSGPGSLARPVDSIGVSLYKKHKIAAMRGDGLLHHMADVQVPVLNPEDLRQERAFYADLIEKYGASLTNVRWASLNSQMNAGTELFVWMLNCGASSVSVSHLDLFLNRTYPPGYLAGGKAQASRDGPGWQMEEWSQLKSFGYHEPSQQFAIYRAFHPHREVAYDGILDAIVEKPFSAYASALEDGYRVWRGRAEA",
      "product": "hypothetical protein"
     },
     {
      "start": 25856,
      "end": 26299,
      "strand": -1,
      "locus_tag": "KKHPANEM_02430",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02430</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02430</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,856 - 26,299,\n (total: 444 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02430 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05099.15 (Tellurite resistance protein TerB): [22:140](score: 89.5, e-value: 2e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02430\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=15856&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02430\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02430\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTCGAGACATTCCTGCGCCGGCTGATCCGGCCCGATCCCATGCCCCTGCCGCAAGCCGATGCCCGGCTGGCGCTGGCGGCCCTGCTGGTGCGGGCGGCGCGCGTCAACGGCGATTATGACCCCGCACAGGTGGTTGCCATCGATGCCGCCCTCGCGCGTCGCTACGGCTTCGGGGCGGATGACGCCGCCGCCCTGCGCGCCCGCGCCGAAGGTCTGGAGAGCGAGGCGCCCGACACCGTGCGCTTCACCCGCGCCGTCAAGCAGGCAACCGCACTGGAAGATCGCGCGGCCGAGCTGGAGATGCTGTGGGAGGTGATCCTGTCCGACGGCGCGCGCGACCACGAGGAGGACGGGTTCATGCGCCTTGTGGCGGACCTGCTGGGGTTCTCCGATCGCGACAGCGCGCTGGCCCGCCAGCGCGTGGCCGAGCGGATGGCGTAA",
      "translation": "MFETFLRRLIRPDPMPLPQADARLALAALLVRAARVNGDYDPAQVVAIDAALARRYGFGADDAAALRARAEGLESEAPDTVRFTRAVKQATALEDRAAELEMLWEVILSDGARDHEEDGFMRLVADLLGFSDRDSALARQRVAERMA",
      "product": "hypothetical protein"
     },
     {
      "start": 26389,
      "end": 28062,
      "strand": -1,
      "locus_tag": "KKHPANEM_02431",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02431</span></strong><br>\n \n  Glucose-6-phosphate isomerase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02431</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pgi</span><br>\n \n Location: 26,389 - 28,062,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02431 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00342.21 (Phosphoglucose isomerase): [59:545](score: 619.9, e-value: 3e-186)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02431 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00342.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004347' target='_blank'>GO:0004347</a>: glucose-6-phosphate isomerase activity<br>\n  \n   PF00342.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006094' target='_blank'>GO:0006094</a>: gluconeogenesis<br>\n  \n   PF00342.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006096' target='_blank'>GO:0006096</a>: glycolytic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02431\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=16389&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/pgi_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02431\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02431\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGCGGAGCGGACAACGGGGCGGGCACCGGGCGGGCACGATGCGGATCTGGCGCCGCTGTGGCGGGCACTGGAGCAATACCGCGACCGGGTGGCCGCGCGCCCCATCGCGGCGCTGTTCGACGCCGATCCGGCGCGCGCCGAGGCGTTCTCGGTCAGCGCGGCCGGGCTGATGCTCGATTACTCCAAGACCGGGGTGTGTGCGCAGGGGATGGCGCATCTTCTGGCGCTGGCCGATGGCGCCGGGGTGGAGGCGCGCCGGGACGCGATGTTCCGGGGCGCCGCGATCAACGAGACCGAGGGCCGGGCGGTGCTGCACACCGCGTTGCGTGATCCCGACGGGCCGCCGCTGGTGGTCGACGGGGTGGATGTGCGCCCGGGCATCGCCGGGACGCTGGCGCGGATGGAGGCGATGGCCGCCGATGTGCGCGCGGGCCGGGTCCGCGGGGCGGGCGGGGCGATCACGGATGTGGTCAATATCGGGATCGGCGGATCGGACCTCGGGCCTGCGATGGCGGTGCAGGCGCTGGCGCCGTACCACGACGGGCCGCGGTGTCATTTCGTCTCGAACGTGGACGGGGCGCATGTGCATGACGTGCTGGCGGGGCTGGACCCGGCGCGGACACTGGTGATCGTGGCCTCCAAGACCTTCACCACGCTGGAGACGATGACCAACGCCGCCACCGCACGCGACTGGATGGCCCGCGCCGTGGCCGATCCGGGGGCGCAGTTCGTGGCGCTGTCGTCGGCCGGGGACCGCGCGGCGGCGTTCGGCATCCCGCCCGATCGGGTGTTCGGCTTCGAGGACTGGGTCGGCGGGCGCTACTCGGTCTGGGGGCCGATCGGGTTGTCGCTGATGCTGGCCATCGGGCCGGAGCGGTTCCGCGACTTCCTTGCGGGGGCGGCGGCGATGGACGCGCATTTCCGCAGCGCCCCGCTGGCGTCCAGCATGCCGGTGCTGCTGGCGCTGGTGGGGGTGTGGCATGCGCAGGTCTGCGGGCATGCGACCCGCGCGGTCATCCCCTATGATCAACGGCTGGCGCGGCTTCCGGCGTATCTGCAGCAGCTGGAGATGGAGTCGAACGGCAAGCGCGTGGGGATGGACGGGCGCGACCTCGATCGTCCCTCGGGGCCGATCGTGTGGGGGGAGCCGGGAACCAATGGCCAGCACGCCTTCATGCAGTTGATCCATCAGGGCACGCGCGTCGTGCCGGTGGAGTTCCTGCTGGCCGCGCGCGGTCACGAGGCGGATCTGGCGCATCACCACCGCCTGCTGGTCGCCAACTGCCTGGCGCAGGCCGAGGCGCTGATGCGGGGGCGCACGCTGGAGGCGGCGCGCGCCGGGCTGTCGGCCGCAGCCCTGGGCGGTGCCGAGCTGGAGCGCCAGGCCCGCCACCGGGTGTTTCCCGGCAACCGGCCCTCGACGGTGCTGCTGTATTCCCGGCTGACGCCGCGGATGCTGGGGGCCGTCCTGGCCCTTTATGAGCATCGGGTGTTCGTGGAGGGCGTGATCCTCGGCATCAACCCGTTCGATCAATGGGGCGTGGAGCTGGGCAAGGAGCTGGCCGTCAGCCTGACGCCGCTGCTGGAGGGGACGGCCGAGGGCGGCGCGCACGACGCCTCCACCCTGCGGCTGGTGGCGATGGTGCGCGCGGATGGTGTCGCCCCGGGATGA",
      "translation": "MAERTTGRAPGGHDADLAPLWRALEQYRDRVAARPIAALFDADPARAEAFSVSAAGLMLDYSKTGVCAQGMAHLLALADGAGVEARRDAMFRGAAINETEGRAVLHTALRDPDGPPLVVDGVDVRPGIAGTLARMEAMAADVRAGRVRGAGGAITDVVNIGIGGSDLGPAMAVQALAPYHDGPRCHFVSNVDGAHVHDVLAGLDPARTLVIVASKTFTTLETMTNAATARDWMARAVADPGAQFVALSSAGDRAAAFGIPPDRVFGFEDWVGGRYSVWGPIGLSLMLAIGPERFRDFLAGAAAMDAHFRSAPLASSMPVLLALVGVWHAQVCGHATRAVIPYDQRLARLPAYLQQLEMESNGKRVGMDGRDLDRPSGPIVWGEPGTNGQHAFMQLIHQGTRVVPVEFLLAARGHEADLAHHHRLLVANCLAQAEALMRGRTLEAARAGLSAAALGGAELERQARHRVFPGNRPSTVLLYSRLTPRMLGAVLALYEHRVFVEGVILGINPFDQWGVELGKELAVSLTPLLEGTAEGGAHDASTLRLVAMVRADGVAPG",
      "product": "Glucose-6-phosphate isomerase"
     },
     {
      "start": 28927,
      "end": 29736,
      "strand": -1,
      "locus_tag": "KKHPANEM_02432",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02432</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02432</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,927 - 29,736,\n (total: 810 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02432 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03370 (VPLPA-CTERM: VPLPA-CTERM protein sorting domain): [242:266](score: 27.3, e-value: 6.3e-07)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02432\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=18927&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02432\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02432\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATCACAAGGCACGGACCGCTTTGGCAGCCCCGCTCGTGGCGGCGCTGGTGCTTTCGGCCGCGGCGGCCAATGGCGCGACCTTGCGGACGCTGTCCGGGGGGGATGGCGCCTTCAATGCGCTGTGCGCGGCGGGCAACGCGGTCGGAACCGGCAATCAGGCCTGCGAGTTTGCCGTCGGTGAAATGCGGACCGGGGCTGTCGGTGGCGCCCAGACATGGGAGGTCGGCGTGCAGAACCCGCCCGGATCGCCCGTCAGCACGCGCAATTATGCCTGGGGCAACGGCGCGGCGCAGGCGTTCGTGTTTTCCTTCAGCGGCGGCACCCTGACCCTTGCGGTCGGTGCGGCGGGGGCGACGCAGGTGGTCTCGACGGCGACGGGGGTCGACCTGGGCGGCATGTCGTCGATGTTCCTCCGCACCCGCACCGCACAGGAGGGGTTCGAGGGCGTGAAGCTGTTCGACATGACAGTGACGGGGGCCGCGCCGGGCGGGGGTGCGGTTGGTGTGCACGACCTGCCCGACCTGACCTCGTCCGCGCCGGGGTCGACCGGGGCGGGCTATGTTCAGGTGTCGGACGTGGACTGGAGCGCGGACTGGACGCTGGCGGGCTCGATCCGCTTCAGCTGGGACCCCGATCTGGCCTGCCCCTGCGGATCCAACCTGAATGTCAATTTCAAGCTGACCGATCTGGAGACGCTGTCGGGGGGGCCGCCGAGCAGTGTCATCCCGCTGCCGGCCGCCGGATGGCTGCTGCTGAGCGGGGTTGCGGGGCTGGGCTGGCTCGGGCGGCGGCGCGCGGTGGTCTGA",
      "translation": "MDHKARTALAAPLVAALVLSAAAANGATLRTLSGGDGAFNALCAAGNAVGTGNQACEFAVGEMRTGAVGGAQTWEVGVQNPPGSPVSTRNYAWGNGAAQAFVFSFSGGTLTLAVGAAGATQVVSTATGVDLGGMSSMFLRTRTAQEGFEGVKLFDMTVTGAAPGGGAVGVHDLPDLTSSAPGSTGAGYVQVSDVDWSADWTLAGSIRFSWDPDLACPCGSNLNVNFKLTDLETLSGGPPSSVIPLPAAGWLLLSGVAGLGWLGRRRAVV",
      "product": "hypothetical protein"
     },
     {
      "start": 30101,
      "end": 30238,
      "strand": -1,
      "locus_tag": "KKHPANEM_02433",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02433</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02433</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,101 - 30,238,\n (total: 138 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02433\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=20101&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02433\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02433\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCAAAGGCAACAACAAGCGCGGAAACAAGGAAGTGAAGAAGCCGAAGCAGGAGAAGCCCAAGGTGCTGGCGACGGCCAACTCCGGCGTGGCGAAACCGATGACCCTGGGCGAGAAGAAAGACCGCAGCCGGTAG",
      "translation": "MGKGNNKRGNKEVKKPKQEKPKVLATANSGVAKPMTLGEKKDRSR",
      "product": "hypothetical protein"
     },
     {
      "start": 30442,
      "end": 31245,
      "strand": -1,
      "locus_tag": "KKHPANEM_02434",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02434</span></strong><br>\n \n  D-beta-hydroxybutyrate dehydrogenase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02434</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">bdhA</span><br>\n \n Location: 30,442 - 31,245,\n (total: 804 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 200.7; E-value: 4.6e-61)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02434 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13561.8 (Enoyl-(Acyl carrier protein) reductase): [12:265](score: 169.4, e-value: 9.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02434\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=20442&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/bdhA_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02434\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02434\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGATCTGACGGGCAAGACGGCGCTGGTGACAGGCTCCACCTCGGGGATCGGGCTGGCCATCGCCGAGGCGCTGGGGGCTGCGGGCGCGCGCATCGCGCTGCACGGGCTGGCCGGCGACATGGAGATCCACGACGCGACCGAGCGGGTGCGCGCCGCCGGCAGCCCCGAGGTGGCGTTCTTCGGTGGCGACATGCGCAACCCCGAGCGCATTCACGAGCTGATGGCGGCGGTCGATGCCTGGGGCGGCGTGGACATCCTCGTCAACAACGCCGGCATCCAGCACACCGCCCCCACCACCGAGATGCCCGACGACAAGTGGGAGGCGATCATCGCCATCAACCTGTCGGCGTGTTTCCACACCATGAAGGCGGCGCTGCCTGGGATGGCCGCGCGGGGCTATGGGCGGGTTGTCAACATCGCCTCGACCCACGGGCTGGTGGCGTCGAAGGAAAAGGCGCCCTATGTCGCGGCCAAGCACGGGCTTGTGGGCATGACCAAGGTGGTGGCGCTGGAGCATGCGGCGCTGGGGGATGCGGCCTCGGGCGGGGTGACGGCGAACTGCATCTGTCCGGGCTGGACCGAAACCGCCCTGATCGAGCCGCAGATCGAGGCCCGCGCCAAGGCCCGCGGCGGCGACCGCACCGCCGCGATCGCGGATCTGCTGTCGGAGAAGCAACCCTCGCAGCGCATGACCAGCCCCGCCGATCTGGGGGCGCTGGCGGTGTGGTTGTGCAGCCCCGCCGCGCACAACATCACCGGGGTGGCGATCCCCGTGGACGGCGGCTGGACCGCGCAGTAA",
      "translation": "MTDLTGKTALVTGSTSGIGLAIAEALGAAGARIALHGLAGDMEIHDATERVRAAGSPEVAFFGGDMRNPERIHELMAAVDAWGGVDILVNNAGIQHTAPTTEMPDDKWEAIIAINLSACFHTMKAALPGMAARGYGRVVNIASTHGLVASKEKAPYVAAKHGLVGMTKVVALEHAALGDAASGGVTANCICPGWTETALIEPQIEARAKARGGDRTAAIADLLSEKQPSQRMTSPADLGALAVWLCSPAAHNITGVAIPVDGGWTAQ",
      "product": "D-beta-hydroxybutyrate dehydrogenase"
     },
     {
      "start": 31242,
      "end": 32768,
      "strand": -1,
      "locus_tag": "KKHPANEM_02435",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02435</span></strong><br>\n \n  Long-chain-fatty-acid--CoA ligase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02435</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">lcfB_3</span><br>\n \n Location: 31,242 - 32,768,\n (total: 1527 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 364.2; E-value: 1.5e-110)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02435 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.30 (AMP-binding enzyme): [8:406](score: 287.6, e-value: 1.4e-85)<br>\n \n  PF13193.8 (AMP-binding enzyme C-terminal domain): [414:488](score: 67.6, e-value: 1.5e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02435\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=21242&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/lcfB_3_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02435\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02435\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAACATCGCGAACTGGCTGGTGCGCAGCGCGCAGACGCGCGGGACGGCGCCCGCGCTGATGGCGGGCGCGCGGGAGGTGGCGGATTACGCGGGCTTTGCGCGGTCCGCTGGGGCGCTGGCGGGGGCGCTGGCGGCGCGCGGGATCGCGCCCGGCGACCGGGTCGCGCTGTTGGCGGGCAACCGGCCGGAGTATCTGGTGGCGGTGTTCGGGATCTGGACCGCCGGGGCGGTGGCGGTGCCGGTCAACGCCCGCCTGCATCCGCGCGAGGCGGCGTGGATCCTGTCCGACAGCGGCGCGGCGCTGGCGCTGGTGGCCCCCGACGCAGCACCCGATCTGGCGGGCGTGACCGAGGTGCCGCTGATGGCGCTGCCGGGTCCCGACTGGGCGGCGGCGGTGGCCGGGCCGCCCGCGCCGGTGGTGCCGCGGGGGCAGGGCGATCTGGCGTGGCTGTTCTACACCTCGGGCACCACGGGGCGGCCCAAGGGGGTGTGCATCACGCATGGCATGCTGGCGGCGATGTCGCTGTGCTATCCCGTCGACGTGGACCCGGTGGGGCCGCAGGACGCCGCGCTGTATGCGGCCCCCATGAGCCATGGGGCGGGCCTCTATGCGCCGATCCATGTGCGCATGGGGGCGCGGCATCTGGTGCCGCCCTCGGGCGGGTTCGACGCGGCCGAGGTGCTGGATCTGGCCGCATCCCACGGCCCGGTGTCGATGTTCCTGGCGCCCACCATGGTGCGCCGGCTGCTGGAGGCCGCGCGCGCCTCGGGGCGGCGGGGCGAGGGGCTGCGCACCGTCGTCTATGGCGGCGGGCCGATGTATCTGGCCGACATCACCGCCGCCGTCGACTGGTTCGGCCCGCGTTTCGTGCAGATCTATGGTCAGGGCGAATGCCCGATGGCCATCACCGCGCTGAGCCGGGCCGAGGTCGCGGACCGCACCCATCCCGACTGGCGCGCGCGCCTCGGCTCGGTCGGGCGGGCGCAGAGCCTGGCGGAGGTCGCGGTGATCGATGACGCGGGCGCGCCGCTGCCGGTGGGCGAGGCGGGCGAGATCGTGGTGCGCGGCGCCCCGGTGATGCCCGGCTACTGGCGCAATCCCGAGGCCAGCGCGAAAACCCTGTGCGACGGTTGGCTGCGGACCGGCGACGTGGGCCAGCTGGACGGCGACGGATACCTGACGCTGGTCGACCGTTCTCGGGACGTGATCATCTCGGGCGGGACCAACATCTATCCCCGCGAGGTCGAGGAGGCCCTGCTGGAACACCCCGACGTGGCCGAGGCCGCCGTCATCGGCCGCCCCAGCCCCGAGTGGGGCGAGGAGGTGGTGGCGTTCCTCGTGCCCCGCGCGGCGCTGCGCCGCGCGGCGCTGGAGGCGCATTGTCTGGAGCGGATGGCCCGGTTCAAGCGGCCCAGGGCATGGTATGCAGTGGCATCCCTTCCAAAGAACAATTACGGCAAGGTGCTGAAGACCGAGTTGCGCGCCCGGCTGGCCGCCGGGACCGAACAGGAGGACATCGCATGA",
      "translation": "MNIANWLVRSAQTRGTAPALMAGAREVADYAGFARSAGALAGALAARGIAPGDRVALLAGNRPEYLVAVFGIWTAGAVAVPVNARLHPREAAWILSDSGAALALVAPDAAPDLAGVTEVPLMALPGPDWAAAVAGPPAPVVPRGQGDLAWLFYTSGTTGRPKGVCITHGMLAAMSLCYPVDVDPVGPQDAALYAAPMSHGAGLYAPIHVRMGARHLVPPSGGFDAAEVLDLAASHGPVSMFLAPTMVRRLLEAARASGRRGEGLRTVVYGGGPMYLADITAAVDWFGPRFVQIYGQGECPMAITALSRAEVADRTHPDWRARLGSVGRAQSLAEVAVIDDAGAPLPVGEAGEIVVRGAPVMPGYWRNPEASAKTLCDGWLRTGDVGQLDGDGYLTLVDRSRDVIISGGTNIYPREVEEALLEHPDVAEAAVIGRPSPEWGEEVVAFLVPRAALRRAALEAHCLERMARFKRPRAWYAVASLPKNNYGKVLKTELRARLAAGTEQEDIA",
      "product": "Long-chain-fatty-acid--CoA ligase"
     },
     {
      "start": 32823,
      "end": 36047,
      "strand": -1,
      "locus_tag": "KKHPANEM_02436",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02436</span></strong><br>\n \n  Sensor histidine kinase RcsC<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02436</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">rcsC_7</span><br>\n \n Location: 32,823 - 36,047,\n (total: 3225 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 66.2; E-value: 5.2e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02436 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08448.12 (PAS fold): [62:171](score: 51.6, e-value: 9.9e-14)<br>\n \n  PF12860.9 (PAS fold): [194:309](score: 61.2, e-value: 9.9e-17)<br>\n \n  PF08447.14 (PAS fold): [333:422](score: 71.7, e-value: 5e-20)<br>\n \n  PF08447.14 (PAS fold): [456:546](score: 69.4, e-value: 2.6e-19)<br>\n \n  PF00989.27 (PAS fold): [565:681](score: 38.4, e-value: 1.1e-09)<br>\n \n  PF00512.27 (His Kinase A (phospho-acceptor) domain): [703:769](score: 68.7, e-value: 3.4e-19)<br>\n \n  PF02518.28 (Histidine kinase-, DNA gyrase B-, and HSP90-like ATPase): [815:926](score: 98.4, e-value: 3.6e-28)<br>\n \n  PF00072.26 (Response regulator receiver domain): [948:1060](score: 63.3, e-value: 2.2e-17)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02436 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00229 (sensory_box: PAS domain S-box protein): [53:176](score: 42.7, e-value: 1.3e-11)<br>\n \n  TIGR00229 (sensory_box: PAS domain S-box protein): [304:435](score: 49.3, e-value: 1.2e-13)<br>\n \n  TIGR00229 (sensory_box: PAS domain S-box protein): [429:559](score: 63.5, e-value: 4.7e-18)<br>\n \n  TIGR00229 (sensory_box: PAS domain S-box protein): [566:691](score: 37.2, e-value: 6.6e-10)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02436 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00072.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00512.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000155' target='_blank'>GO:0000155</a>: phosphorelay sensor kinase activity<br>\n  \n   PF00512.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007165' target='_blank'>GO:0007165</a>: signal transduction<br>\n  \n   PF00989.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n   PF08447.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02436\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=22823&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/rcsC_7_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02436\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02436\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCCGGGGCGGGCACCGCCGCAGCGCCACCGGCTGGGCGCCCCCGGCGCCGAGCGGTGGGTCGAGGTGACAGCCGCCCCGCGCGGCCCCGGTGCCGCGCCGGGCCATGTGGTGGCGCTGCGCGATGTCACCGCCGCCGCGCGCGCCACCCACGAGGTCGAACAGCTGAGCCAGATCGCCCGGCGCACCGGCGATCTGGTGGTCATCACCGATACCGACCACCGCATCGACTGGGTCAACCCGGCCTTTGAGGCGCGCACCGGCTGGCGGCTGGAGGATGTCCGCGGCCACCTCCCCGAGAGCATCCTGCAAAGCCCCGAGGCCGACGCGGCCGAGGTCGCGCGCATCCGCGGCGCGCTGCTGGAGGGGGCGTCGGCCAGCGGGCTCTTGCTGTGCCGCACCCGGACGGACGATGCCTTCTGGGCCGAGATCGACGCCTATCCGCTGCGGGACTCGGACGGGCGGACGACGGGCCATGTCACGCTGGCCACCGACGTCACCGCGCGCCGCGCGCAGGAGGCCAAGCTGGAGCGCCTTGCGCAGGAGGCCACGCGGGCGCGCGAGCGGCTGGAGATGGCGGTGGAGGCGCTGCCGGACGCGTTTGCGTTTTTCGACGCCGAGGACCGGCTGGTGCTGTGCAACGAGCGCTATCGCACCTTTCATCCGCGGTCGGGGTACATGATCTCGCCGGGGGTGCAGTTCGCGGACTTTGCCCGGGCGGTGGCCCACAGCGGCGATGTCGCCGACGCCGTGGGCCGCGAGGAGGCGTGGCTGGCCGAGCGCCTGGCCTCGCACCGCGAGGGGCGCCCGGGCGGCGAGCACCGCATGGCCGACGGCAGCTGGCTGCGGGTGATCGAGCGCGTCACCGCCGACGGCGGCCGCGTCGGCATGCGCGTCGACATCACCGAGCTGAAGGAGGCCGAGCGGCGGCTGGCCGACATCATCCACGGCGCGCAGGTCGGCACCTGGGAGTGGCACCTGGCCAGCGGCGAGAACCGCATCAACGCGCGCTGGGCCGAGATCGTGGGCTATTGCCCCGACGAGATCGACCGCTCGGGCATCGATCTGTGGCGGGCGCTGGTGCACCCCGACGACCTGGCCCGCGCCGAGGCGCGGCTGGCGCGGGTGTTCGCCCGCGAGATCGACCAGTTCGAGTATGAATTGCGCATGCGCCACCGTGACGGCCACTGGGTCTGGGTGCTGTCGCGCGGGCGGGTGGCGCGTTGGTCGCCCGACGGCAAGCCCGAGGTGATGGCCGGGGTGCACATGGACATCACCGCCCTCAAGCGCGCCGAGGAACGGCTGGAGGCGATCCTGCACGCCGCCGAAGCCGGCACCTGGGAGACCGATCCCGCGCGCGGCGGCATGCGCATCAACGACCGCTGGGCGGAGATGCTGGGCTACACCGTGGACGAGCTTGCGCCCCTGCCGGAACACGGTTTTCGCACCCTGATGCACCCCGACGACCGCGCCCGGCTGGAGGCGGAGTTCGGCATGGACCTGGAGGGCCGCCCCGATCGCTTCAGCGTGGAGGTGCGGGTGCGCCACAAGGCCGGTGCCTGGGTCTGGCTGCTGGCGCGCGGCCGGGTGCTGGCGCGCGACGCCAACGGCCGGCCGGTGCGCACCGCGGGCATCCACCTCGACATCACCGAGCGCAAGCGGCTGGAGCAGCAGCTGGTGGCCGAGCGCGATTACATGTCGCGGCTGATGGAGACGAATGTCTCGGGCATCACCGCGCTGGATGGCGACGGGCGCATCATCTATGCCAACCGCGAGGCCGAGGCGATCCTGGGCTTGTCGGCGGCGGCGGTGGACCGGCGCAGCTATGCCGATCCGCGCTGGCAGATCACCGCCCCCGACGGCGGGCCGCTGGCCGATGCCGAGCTGCCCTTTACCCGCGCCATGACCGAGGGGCGGGTGGTGCGCGACGTGCGCTTCGCCATCGCCTGGCCCGACGGCACCCGGCGGCAGCTGTCGGTCAACGCGGCGCCGCTGCTGGCCGAGGGGCTGCAGGCGCGGGTGGTCTGCGCGATCACCGACATCACCGAACAGGTCGCCACCGAAGCCGCCCTGCGCAGCGCCGCCGAGCGGGCCGAGGCCGCCAGCGAGGCCAAGTCGCGGTTCCTGGCCAACATGAGCCACGAGATTCGCACCCCCCTGAACGGGGTCCTCGGGATGGCGCAGGTGCTGGAGGAGGAGCTGTCCGAGCCGCGCCACCGCCGCATGCTGGAGGTGATCCGCGAATCCGGCGAGATGCTGCTGGGCGTGCTCAACGATGTCCTCGACATGTCCAAGATCGAGGCCGGCAAGGTTACGCTGGAGCAGGTCGCCTTCGTGCCCGCCGATCTGGCACGGCGGATCGAGGCGATGCACGCCCTGCGCGCCGCCGAGAAGCATCTGTCGCTGGAGGTCGTGGCCGCCCCCGGCGCCGAGCGCGCGCGGCTGGGCGATCCGGGCCGGGTGGAGCAGATGCTGCACAACCTGGTCGGCAACGCCGTCAAGTTCACCGAGGCGGGCGGCGTGCGGGTGACGCTGGAGGGGGGGTGTGGCCCGCTGCGGGTGGTCGTCCATGACACCGGGATCGGCATGACGGACGATCAGTTGGCGCGCATCTTCGAGGATTTCGAACAGGCCGACGGCACGGTGACCCGCCGGTTCGGGGGCACCGGGCTGGGCATGTCCATCGTGCGCCGCCTGGTGGCGCTGATGGGCGGCCAGATCACGGTCGACAGCATCCCTGGCGCGGGCACCCAGGTGCGCGTCGCGCTGCCGCTGCCGCTGGCCGAGGGTGGCCCGCGCGATGCCGTCCCCGTGCCCGCCCAGCCGCTGGAGGGGCTGCGCGCGCTGGCGGCCGACGACAACGCCACCAACCGGCTGATCCTCCAGGCGATGCTGTCGGCGCTGGGCGGGGCCGTGACGATGGTGCCCGACGGGCAGGCCGCGGTGGAGGCGTGGGCGCCGGGGCGGTTCGATCTGATCCTGCTGGACATCTCGATGCCGGGGCTGGACGGTCTGGGCGCGCTGGCCGCGATCCGCCTGCGCGAGGCCGAGGCGGGTGTGCCACCCGCGCCCGCGGTGGCGATCACCGCCAACGCCATGGCCCATCAGGTGGCGCAGTACATGGGCGCGGGCTTTGCCGCCCATGTCGGCAAGCCGTTCCGCCGCGAGGACCTGGCGCGGACGCTGTTGCGCGTGCTGGACCGCGCCCCGCCCGCGCAGCGGTGA",
      "translation": "MPGRAPPQRHRLGAPGAERWVEVTAAPRGPGAAPGHVVALRDVTAAARATHEVEQLSQIARRTGDLVVITDTDHRIDWVNPAFEARTGWRLEDVRGHLPESILQSPEADAAEVARIRGALLEGASASGLLLCRTRTDDAFWAEIDAYPLRDSDGRTTGHVTLATDVTARRAQEAKLERLAQEATRARERLEMAVEALPDAFAFFDAEDRLVLCNERYRTFHPRSGYMISPGVQFADFARAVAHSGDVADAVGREEAWLAERLASHREGRPGGEHRMADGSWLRVIERVTADGGRVGMRVDITELKEAERRLADIIHGAQVGTWEWHLASGENRINARWAEIVGYCPDEIDRSGIDLWRALVHPDDLARAEARLARVFAREIDQFEYELRMRHRDGHWVWVLSRGRVARWSPDGKPEVMAGVHMDITALKRAEERLEAILHAAEAGTWETDPARGGMRINDRWAEMLGYTVDELAPLPEHGFRTLMHPDDRARLEAEFGMDLEGRPDRFSVEVRVRHKAGAWVWLLARGRVLARDANGRPVRTAGIHLDITERKRLEQQLVAERDYMSRLMETNVSGITALDGDGRIIYANREAEAILGLSAAAVDRRSYADPRWQITAPDGGPLADAELPFTRAMTEGRVVRDVRFAIAWPDGTRRQLSVNAAPLLAEGLQARVVCAITDITEQVATEAALRSAAERAEAASEAKSRFLANMSHEIRTPLNGVLGMAQVLEEELSEPRHRRMLEVIRESGEMLLGVLNDVLDMSKIEAGKVTLEQVAFVPADLARRIEAMHALRAAEKHLSLEVVAAPGAERARLGDPGRVEQMLHNLVGNAVKFTEAGGVRVTLEGGCGPLRVVVHDTGIGMTDDQLARIFEDFEQADGTVTRRFGGTGLGMSIVRRLVALMGGQITVDSIPGAGTQVRVALPLPLAEGGPRDAVPVPAQPLEGLRALAADDNATNRLILQAMLSALGGAVTMVPDGQAAVEAWAPGRFDLILLDISMPGLDGLGALAAIRLREAEAGVPPAPAVAITANAMAHQVAQYMGAGFAAHVGKPFRREDLARTLLRVLDRAPPAQR",
      "product": "Sensor histidine kinase RcsC"
     }
    ],
    "clusters": [
     {
      "start": 21261,
      "end": 32768,
      "tool": "rule-based-clusters",
      "neighbouring_start": 11261,
      "neighbouring_end": 36052,
      "product": "betalactone",
      "category": "other",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 23454,
       "end": 23456,
       "strand": -1,
       "containedBy": [
        "KKHPANEM_02428"
       ]
      }
     ],
     "bindingSites": [
      {
       "loc": 12753,
       "len": 10
      },
      {
       "loc": 28313,
       "len": 12
      }
     ]
    },
    "type": "betalactone",
    "products": [
     "betalactone"
    ],
    "product_categories": [
     "other"
    ],
    "cssClass": "other betalactone",
    "anchor": "r292c1"
   }
  ]
 },
 {
  "length": 6535,
  "seq_id": "NZ_NHSD01000293.1",
  "regions": []
 },
 {
  "length": 37000,
  "seq_id": "NZ_NHSD01000294.1",
  "regions": []
 },
 {
  "length": 6577,
  "seq_id": "NZ_NHSD01000295.1",
  "regions": []
 },
 {
  "length": 53165,
  "seq_id": "NZ_NHSD01000296.1",
  "regions": []
 },
 {
  "length": 11929,
  "seq_id": "NZ_NHSD01000297.1",
  "regions": []
 },
 {
  "length": 19069,
  "seq_id": "NZ_NHSD01000298.1",
  "regions": []
 },
 {
  "length": 61719,
  "seq_id": "NZ_NHSD01000299.1",
  "regions": []
 },
 {
  "length": 12096,
  "seq_id": "NZ_NHSD01000300.1",
  "regions": []
 },
 {
  "length": 6610,
  "seq_id": "NZ_NHSD01000301.1",
  "regions": []
 },
 {
  "length": 78689,
  "seq_id": "NZ_NHSD01000302.1",
  "regions": []
 },
 {
  "length": 12163,
  "seq_id": "NZ_NHSD01000303.1",
  "regions": []
 },
 {
  "length": 6351,
  "seq_id": "NZ_NHSD01000304.1",
  "regions": []
 },
 {
  "length": 46872,
  "seq_id": "NZ_NHSD01000305.1",
  "regions": []
 },
 {
  "length": 11806,
  "seq_id": "NZ_NHSD01000306.1",
  "regions": []
 },
 {
  "length": 21208,
  "seq_id": "NZ_NHSD01000307.1",
  "regions": []
 },
 {
  "length": 25080,
  "seq_id": "NZ_NHSD01000308.1",
  "regions": []
 },
 {
  "length": 6088,
  "seq_id": "NZ_NHSD01000309.1",
  "regions": []
 },
 {
  "length": 30200,
  "seq_id": "NZ_NHSD01000310.1",
  "regions": []
 },
 {
  "length": 6210,
  "seq_id": "NZ_NHSD01000311.1",
  "regions": []
 },
 {
  "length": 31784,
  "seq_id": "NZ_NHSD01000312.1",
  "regions": []
 },
 {
  "length": 6077,
  "seq_id": "NZ_NHSD01000313.1",
  "regions": []
 },
 {
  "length": 28055,
  "seq_id": "NZ_NHSD01000314.1",
  "regions": []
 },
 {
  "length": 2531,
  "seq_id": "NZ_NHSD01000315.1",
  "regions": []
 },
 {
  "length": 26774,
  "seq_id": "NZ_NHSD01000316.1",
  "regions": []
 },
 {
  "length": 5998,
  "seq_id": "NZ_NHSD01000317.1",
  "regions": []
 },
 {
  "length": 26232,
  "seq_id": "NZ_NHSD01000318.1",
  "regions": []
 },
 {
  "length": 6084,
  "seq_id": "NZ_NHSD01000319.1",
  "regions": []
 },
 {
  "length": 28137,
  "seq_id": "NZ_NHSD01000320.1",
  "regions": []
 },
 {
  "length": 5898,
  "seq_id": "NZ_NHSD01000321.1",
  "regions": []
 },
 {
  "length": 25654,
  "seq_id": "NZ_NHSD01000322.1",
  "regions": []
 },
 {
  "length": 25548,
  "seq_id": "NZ_NHSD01000323.1",
  "regions": []
 },
 {
  "length": 24788,
  "seq_id": "NZ_NHSD01000324.1",
  "regions": []
 },
 {
  "length": 24496,
  "seq_id": "NZ_NHSD01000325.1",
  "regions": []
 },
 {
  "length": 24374,
  "seq_id": "NZ_NHSD01000326.1",
  "regions": []
 },
 {
  "length": 18745,
  "seq_id": "NZ_NHSD01000327.1",
  "regions": []
 },
 {
  "length": 17875,
  "seq_id": "NZ_NHSD01000328.1",
  "regions": []
 },
 {
  "length": 17483,
  "seq_id": "NZ_NHSD01000329.1",
  "regions": []
 },
 {
  "length": 17469,
  "seq_id": "NZ_NHSD01000330.1",
  "regions": []
 },
 {
  "length": 17841,
  "seq_id": "NZ_NHSD01000331.1",
  "regions": []
 },
 {
  "length": 17450,
  "seq_id": "NZ_NHSD01000332.1",
  "regions": []
 },
 {
  "length": 16757,
  "seq_id": "NZ_NHSD01000333.1",
  "regions": []
 },
 {
  "length": 16628,
  "seq_id": "NZ_NHSD01000334.1",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r218c1",
  "r237c1",
  "r273c1",
  "r292c1"
 ],
 "r218c1": {
  "start": 1,
  "end": 9387,
  "idx": 1,
  "orfs": [
   {
    "start": 435,
    "end": 1055,
    "strand": -1,
    "locus_tag": "KKHPANEM_01436",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01436</span></strong><br>\n \n  Cytidylate kinase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01436</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">cmk</span><br>\n \n Location: 435 - 1,055,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01436 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02224.20 (Cytidylate kinase): [8:45](score: 41.0, e-value: 1.9e-10)<br>\n \n  PF02224.20 (Cytidylate kinase): [64:201](score: 127.8, e-value: 5e-37)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01436 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02224.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004127' target='_blank'>GO:0004127</a>: cytidylate kinase activity<br>\n  \n   PF02224.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02224.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006139' target='_blank'>GO:0006139</a>: nucleobase-containing compound metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01436\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=11055\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01436\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01436\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGAGGGCGCGCGGTTCACGGTCGCGCTGGATGGGCCGGCGGCGTCGGGCAAGGGCACGCTGGGGCGCGCGCTGGCGCAGGCGTGCGGGTTTGCGCATCTCGATACGGGGCTTCTGTATCGTGCCGTGGGTGCGCGGGCGGCGGCGGGCGAGGACCCGGTGGCCGCAGCGCGCAGCCTCGTGCCCGAGGATCTGTCGCGCGCCGATCTGCGCAGCGCCGCCGCAGGGCAGGCCGCCAGCCGCGTGGCGGCACTGGAAGAGGTGCGCGCGGCGCTGCTGGCATTCCAGCGGGATTTCGCGCGCAGACCCGGCGGAGCGGTGCTGGACGGGCGCGACATCGGCACCGTGGTCTGCCCGGGCGCAGAGGTGAAGCTGTTCGTCACCGCATCGGATGCGGTGCGGTCGCGGCGGCGTTGGCTGGAGCTGCGCGCGCACCAGCCCGACCTGACGCAGGTGGAGGTTCTCGAAGACCTGCGTGCCCGCGATGCCCGCGACCGCGAACGGGCAGCCGCGCCGCTGCGACCGGCGCCGGACGCGATGCTTCTGGACACCTCGGACCTGACGATCGAGGCGGCGATCGCACGGGCGCTCTCGGCGGTCGAGGCCGCCCGCCGCTGA",
    "translation": "MAEGARFTVALDGPAASGKGTLGRALAQACGFAHLDTGLLYRAVGARAAAGEDPVAAARSLVPEDLSRADLRSAAAGQAASRVAALEEVRAALLAFQRDFARRPGGAVLDGRDIGTVVCPGAEVKLFVTASDAVRSRRRWLELRAHQPDLTQVEVLEDLRARDARDRERAAAPLRPAPDAMLLDTSDLTIEAAIARALSAVEAARR",
    "product": "Cytidylate kinase"
   },
   {
    "start": 1048,
    "end": 2397,
    "strand": -1,
    "locus_tag": "KKHPANEM_01437",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01437</span></strong><br>\n \n  3-phosphoshikimate 1-carboxyvinyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01437</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">aroA</span><br>\n \n Location: 1,048 - 2,397,\n (total: 1350 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01437 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00275.22 (EPSP synthase (3-phosphoshikimate 1-carboxyvinyltransferase)): [13:436](score: 327.7, e-value: 9.4e-98)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01437 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01356 (aroA: 3-phosphoshikimate 1-carboxyvinyltransferase): [21:443](score: 382.5, e-value: 5.1e-115)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01437 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00275.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01437\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=12397\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/aroA_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01437\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01437\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGCCACTTCCGCGCCCATGCCCCTGACCGCCCGTGCCGGCGGGGCGCTGCGGGGCACCACCGACGTGCCCGGCGACAAGTCCATCAGCCACCGCGCTCTGATCCTGGGTGCGCTGGCGGTGGGCGAGACGCGCATCACCGGGCTGCTGGAAGGGCAGGATGTCCTCGACACCGCCGCCGCGATGCGCGCCTTCGGGGCCGAGGTGATCCGCCACGGACCCGGCAGCTGGTCGGTGCATGGCGTGGGCGTGGGCGGGTTCGGCGAACCGTCGGGTGTGATCGACTGCGGCAACTCGGGCACCGGGGTGCGGCTGATCATGGGCGCGATGGCGACCACGCCGATCACCGCCACCTTCACCGGCGATGCCAGCCTGTGCCGCCGCCCCATGGGCCGCGTGACCGATCCGCTGGCGCTGTTTGGTGCACAGGCGGTGGGGCGCGCGGGCGGACGGCTGCCGATGACGCTGGTGGGCGCGGCCGATCCGGTGCCGGTGCGCTATGTGCTGCCGGTGCCCTCGGCGCAGGTGAAATCGGCGGTGCTGCTGGCCGGGCTGAACGCGCCGGGCGAGACCGCGGTGATCGAGGCCGAGCCGACCCGCGACCACACCGAACGCATGCTCGCGGGCTTCGGCGCCGTCATCCGCCACGAGGACACGCCCGAGGGCCGCGCGGTGATCCTGACGGGCCAGCCGGAGTTGATCGCGCAGCCGGTGGCGGTGCCGCGCGATCCGTCCTCGGCCGCGTTTCCGGTGGTGGCGGCGCTGATGGTGCCGGGATCGGATGTGCGGGTGCCGGGCGTCAGCCGCAACCCCACGCGCGACGGCCTTTATTGCACGCTGCTGGAGATGGGCGCCGATCTGCTGTTCGAGGCCGAGCGCGCGGAGGGCGGCGAGCCGGTGGCCGACCTGCGCGCCCGCTTCACGGGAACCTTGCGCGGGGTGGAGGTGCCGCCCGAGCGCGCCGCCAGCATGATCGACGAGTTCCCGATCCTCGCAGCCCTTGCCGCCACCGCCGAGGGCGCCACCGTCATGCGCGGCGTGCGCGAGTTGCGCGTCAAGGAAAGCGACCGCATCGCCGCGATGGCCACCGGGCTGGCCGCCTGCGGCGTCGCGGTGGAGGAGACGGAGGACACGCTGACGGTGCATGGCTGCGGCCCGGACGGCGTGCCGGGGGGCACGACGGTGGCCACGCACCTCGACCACCGCATCGCCATGAGCTTCCTGTGCCTTGGCCTCGTGGCCCGCGCGCCCGTCACGGTGGACGATGCCGGCCCCATCGCCACGTCGTTTCCCGACTTCATTCCGCTGATGACGGCCCTTGGCGCCGATCTGGCCACCCATGGCTGA",
    "translation": "MTATSAPMPLTARAGGALRGTTDVPGDKSISHRALILGALAVGETRITGLLEGQDVLDTAAAMRAFGAEVIRHGPGSWSVHGVGVGGFGEPSGVIDCGNSGTGVRLIMGAMATTPITATFTGDASLCRRPMGRVTDPLALFGAQAVGRAGGRLPMTLVGAADPVPVRYVLPVPSAQVKSAVLLAGLNAPGETAVIEAEPTRDHTERMLAGFGAVIRHEDTPEGRAVILTGQPELIAQPVAVPRDPSSAAFPVVAALMVPGSDVRVPGVSRNPTRDGLYCTLLEMGADLLFEAERAEGGEPVADLRARFTGTLRGVEVPPERAASMIDEFPILAALAATAEGATVMRGVRELRVKESDRIAAMATGLAACGVAVEETEDTLTVHGCGPDGVPGGTTVATHLDHRIAMSFLCLGLVARAPVTVDDAGPIATSFPDFIPLMTALGADLATHG",
    "product": "3-phosphoshikimate 1-carboxyvinyltransferase"
   },
   {
    "start": 2489,
    "end": 3880,
    "strand": -1,
    "locus_tag": "KKHPANEM_01438",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01438</span></strong><br>\n \n  Aspartate kinase Ask_Ect<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01438</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ask</span><br>\n \n Location: 2,489 - 3,880,\n (total: 1392 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01438 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00696.30 (Amino acid kinase family): [20:283](score: 73.4, e-value: 2.2e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01438\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=13880\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ask_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01438\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01438\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCGGAGCCGCGAGTTGCTCGAGACCCTGTGGGTCGGAGGCCGCGAGGATGTGTATGGCCGCATCTTTGTCGTCTCGGCCTATGGCGGGATCACCAACCTGCTGCTGGAGCACAAGAAAAGCGGCGAGCAGGGGGTCTATGCCCGGTTTGCCTCGGATGACGGCGGCAGCGGCTGGCACCAGGCGCTGAACGACACCGCAGCCGAGATGATGCGCGTGCACGGAGAGATCCTGGAGCATGACGGCGACAGGGGCCGGGCGGATGCGTTCGTGCGCGACCGCATCGAGGGTGCGCGGGCCTGCATGATCGACCTTCAGCGGCTGGGCTCCTACGGGCACTTCCGCATCGACGGGCAACTGATGACGCTGCGCGAGTTGCTGGCGGGGCTGGGCGAGGCGCATTCGGCCTTTGTCAGCACGCTGCTGTTGCAGCGCCACGGGGTGAACGCGCGCTTTGTGGATCTGTCGGGTTGGCGCGACGAGGCGCATCCCGATCTGGCCGAGCGGCTGCGCGCCGCGCTCGACGGGATCGACTTCTCCGAGGAGCTGCCGATCGTCACCGGCTATGCGCATTGTGCCGAAGGGCTGATGCGCGAATACGATCGTGGCTATTCCGAGGTGGTGTTCGCCCACATCGCGGCGCAGACCGCGGCCTCCGAGGCGATCATCCACAAGGAGTTCCATCTGTCCTCGGCTGATCCCAAGGTCGTGGGGCTGGACAAGGTGCGCAAGATCGGGCGCACCAGCTATGACGTGGCCGACCAGCTGTCGAACCTCGGGATGGAGGCGATCCACCCCAACGCAGCCCGCATCCTGCGCCGCGCCGAGGTCGCGCTGCGGGTCAAGCACGCGTTTGAACCCGACGATCCCGGCACCCTGATCGGTCCCGAGGGCGGGCAGGCGGGGCGCGTGGAGATGGTCACCGGCCTGCCGTTGCAGGCGCTGGAGGTCTATGAGCCCGACATGGTCGGGGTGAAGGGCTATGACGCCGGGATCCTGGACGCGCTGACGCGCCACAAGCTGTGGATCGTGTCGAAGTCCTCCAACGCGAACTCCATCACCCACTGGGTCAGCGGCTCGCTCAAGGCCCTGCGCCGGGTGGAGCGGGAGCTGGCGCAGCGCTGGTCCAACGCCGAGATCACCATTCGTCCCGTGGCGATGGTGTCGGCCATCGGCAGCGACCTGACCGGCCTTGGTGCGGTGCGTCGGGGGCTGGAGGCGCTGGACGCCGCCGGGATCGAGGTGCTTGCGGTGCAGCAGGGCCTGCGCCGGGTGGAGGTGCAGTTCCTCGTTCCGCGCGAGGCGCAGGACGCAGCGGTCGCCGCCCTGCATGCCCGCCTGATCGAGGAGACGGGCGCGGCCAGCGTCCAGCCCATCGCCGCCGAGTGA",
    "translation": "MSRSRELLETLWVGGREDVYGRIFVVSAYGGITNLLLEHKKSGEQGVYARFASDDGGSGWHQALNDTAAEMMRVHGEILEHDGDRGRADAFVRDRIEGARACMIDLQRLGSYGHFRIDGQLMTLRELLAGLGEAHSAFVSTLLLQRHGVNARFVDLSGWRDEAHPDLAERLRAALDGIDFSEELPIVTGYAHCAEGLMREYDRGYSEVVFAHIAAQTAASEAIIHKEFHLSSADPKVVGLDKVRKIGRTSYDVADQLSNLGMEAIHPNAARILRRAEVALRVKHAFEPDDPGTLIGPEGGQAGRVEMVTGLPLQALEVYEPDMVGVKGYDAGILDALTRHKLWIVSKSSNANSITHWVSGSLKALRRVERELAQRWSNAEITIRPVAMVSAIGSDLTGLGAVRRGLEALDAAGIEVLAVQQGLRRVEVQFLVPREAQDAAVAALHARLIEETGAASVQPIAAE",
    "product": "Aspartate kinase Ask_Ect"
   },
   {
    "start": 4004,
    "end": 4387,
    "strand": -1,
    "locus_tag": "KKHPANEM_01439",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01439</span></strong><br>\n \n  L-ectoine synthase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01439</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectC</span><br>\n \n Location: 4,004 - 4,387,\n (total: 384 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ectoine: ectoine_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01439 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06339.14 (Ectoine synthase): [0:126](score: 197.0, e-value: 1.1e-58)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01439 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF06339.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0033990' target='_blank'>GO:0033990</a>: ectoine synthase activity<br>\n  \n   PF06339.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0019491' target='_blank'>GO:0019491</a>: ectoine biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01439\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=14387\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ectC_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01439\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01439\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCGTTCGCGATTTCCACGAAGCCAACAAGACCGACCGCAAGGTCGCCAACGAGCGTTGGGAGTCGGTGCGCCTGCTGCTGGCCGATGACGGGATGGGGTTTTCGTTCCACATCACCACCATCGAAGGCGGCTCCGAGCACACCTTTCACTACAAGAACCATTTCGAGAGCGTGTATTGCATCTCGGGTAAGGGCTCGATCGAGGATCTCGCCACCGGCACCGTCCACCAGATCCGGCCCGGCGTGATGTACGCGCTCGACAAGCACGACAAGCACACCTTGCGCTGCGAGGACACGATGGTTCTGGCGTGCTGCTTCAACCCGCCCGTGACGGGCACCGAGGTGCACCGGGCCGACGGCTCCTACGCCGCCGCGGACTGA",
    "translation": "MIVRDFHEANKTDRKVANERWESVRLLLADDGMGFSFHITTIEGGSEHTFHYKNHFESVYCISGKGSIEDLATGTVHQIRPGVMYALDKHDKHTLRCEDTMVLACCFNPPVTGTEVHRADGSYAAAD",
    "product": "L-ectoine synthase"
   },
   {
    "start": 4391,
    "end": 5689,
    "strand": -1,
    "locus_tag": "KKHPANEM_01440",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01440</span></strong><br>\n \n  Diaminobutyrate--2-oxoglutarate transaminase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01440</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectB</span><br>\n \n Location: 4,391 - 5,689,\n (total: 1299 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_3<br>\n \n  biosynthetic-additional (smcogs) SMCOG1013:aminotransferase class-III (Score: 353.4; E-value: 2.6e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01440 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00202.23 (Aminotransferase class-III): [28:419](score: 259.1, e-value: 5.9e-77)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01440 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02407 (ectoine_ectB: diaminobutyrate--2-oxoglutarate aminotransferase): [13:420](score: 572.6, e-value: 8.7e-173)<br>\n \n  TIGR00709 (dat: 2,4-diaminobutyrate 4-transaminase): [13:421](score: 418.7, e-value: 5.3e-126)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01440 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00202.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008483' target='_blank'>GO:0008483</a>: transaminase activity<br>\n  \n   PF00202.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01440\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=15689\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ectB_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01440\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01440\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGATCATACCCAGACCGACACCGGCCCCATGGCCGTCTATGCCCGCCGCGAAAGCCAGGTGCGCAGCTACTGCCGCAGCTTTCCGGTGGAGTTCACCAAGGGCCGCAACGCCACGCTGACCGACCGCGCGGGGCGGGAGTACATCGACTTCCTCGCCGGGTGCTCGTCGCTGAACTATGGCCACAACGACCCGGACATGAAGGCGGCGCTGATCGACCACATCACCGGCGACGGCATCGCCCACGGCCTGGACATGCACACCGACGCCAAGACCGCGTTCCTGGAGACGTTCGAGCGCGTGATCCTGCGCCCGCGCGGCATGGAGCACAAGGTGATGATGACCGGCCCCACCGGCACCAACGCCGTCGAGGCCGCGATGAAGCTGGCGCGCAAGGTCACCGGGCGCGACACCATCGTCGCCTTCACCAACGGCTTTCACGGCATGACGATGGGCGCGCTGGCGGCCACCGGCAACGCCGGCAAGCGCGCGGGCGGCGGCATGGCGCTGCATGGCGTCGTGCGGATGCCCTATGAGGGGGCGATGGACGGCGTCGACAGCCTCGCGATGATCGAGGCGATGCTGGACAACCCCTCCAGCGGGTTCGACGCGCCGGCCGCGTTCCTGATCGAGCCGGTGCAGGGTGAGGGCGGGCTGAACGCCGCCTCGGCCGACTTCCTGCGCGGGCTGAAGCGGCTGGCCGAGAAGCACGGCGCGCTGCTCATTGCCGACGATATCCAGTCGGGCATCGGGCGCACGGGGCCGTTCTTCAGCTTCGAGGGGATGGACGTGATGCCCGACCTGATCCCGCTGGCGAAGTCGCTGTCGGGGATGGGCCTGCCGTTCGCCGCACTTCTGGTGCGCCCGGACCTGGACGTGTGGAAGCCGGCCGAACACAACGGCACCTTCCGCGGCAACCAGCATGCCTTCGTCACCGCCCGCGTGGCGCTGGAGAAGTTCTGGACCGACGACACCTTCCAGAAGCAGACCGAAGCCAAGGCCGAGTTCCTGGAGCGCCGGCTGTCGGACATCGCCGCCCTGATCCCCGGCGCCCGGCTGAAGGGCCGCGGCATGATGCGTGGCGTCGACGTCGGTTCGGGCGAGACGGCGGGCGCGATCTGCGCGGCCTGTTTCGAGCACGGTCTGGTCATCGAGACCTCGGGCGCCCATGATGAGGTCGTCAAGGTCCTCGCGCCCCTGACAATTCCCGAGGCGCAGTTGGCGCAGGGCCTCGACATCATCGAAGCGGCGGTGCGCAGCCGGATCGCCGGCACCACCCCCATTGCAGCGGAGTAA",
    "translation": "MTDHTQTDTGPMAVYARRESQVRSYCRSFPVEFTKGRNATLTDRAGREYIDFLAGCSSLNYGHNDPDMKAALIDHITGDGIAHGLDMHTDAKTAFLETFERVILRPRGMEHKVMMTGPTGTNAVEAAMKLARKVTGRDTIVAFTNGFHGMTMGALAATGNAGKRAGGGMALHGVVRMPYEGAMDGVDSLAMIEAMLDNPSSGFDAPAAFLIEPVQGEGGLNAASADFLRGLKRLAEKHGALLIADDIQSGIGRTGPFFSFEGMDVMPDLIPLAKSLSGMGLPFAALLVRPDLDVWKPAEHNGTFRGNQHAFVTARVALEKFWTDDTFQKQTEAKAEFLERRLSDIAALIPGARLKGRGMMRGVDVGSGETAGAICAACFEHGLVIETSGAHDEVVKVLAPLTIPEAQLAQGLDIIEAAVRSRIAGTTPIAAE",
    "product": "Diaminobutyrate--2-oxoglutarate transaminase"
   },
   {
    "start": 5735,
    "end": 6277,
    "strand": -1,
    "locus_tag": "KKHPANEM_01441",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01441</span></strong><br>\n \n  L-2,4-diaminobutyric acid acetyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01441</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ectA</span><br>\n \n Location: 5,735 - 6,277,\n (total: 543 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01441 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00583.27 (Acetyltransferase (GNAT) family): [49:135](score: 42.8, e-value: 5.5e-11)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01441 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02406 (ectoine_EctA: diaminobutyrate acetyltransferase): [17:169](score: 173.8, e-value: 6e-52)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01441 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00583.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01441\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=16277\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ectA_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01441\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01441\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCCCGGACAAATCGCAAGATCATCGAAACACCCAAGGGTGCGGTGCGCCTGCGCAGCCCCGTCAAGACTGACGGCACGGCCGTCCAGGAGCTGATCGCGCGCTGCGCGCCACTGGACCAGAATTCCCTCTACATGAACCTGATCCAGTGCGACCACTTCGCCGACACCTGTGTGCTGGCCGAGCGTGGCGACGATGTGCTGGGCTGGATCTCGGCGCATGTGCCGCCGGGGCGCGAGGACACGATCTTCGTGTGGCAGGTGGCTGTTGACGCCCGCGCACGCGGCATGGGGCTGGGACGCCACATGCTGACGGCGCTGCTGGAGCGCCCGCTGTGCCGCCGCGTCATCAACCTGGAGACCACGATCACCCGCGACAACGAGGGGTCCTGGGCACTGTTCCGCAGCCTTGCCCGGCGTCTGGACGGCGATCTGTCCCACGCGCCCCATTTTGAACGCGAGGCGCATTTCGGCGGCGCGCATGACACCGAGCATCTGGTGACCATCGCGCTCGACGCCGAAGCGGTGCGCCGGGCGGCCTGA",
    "translation": "MARTNRKIIETPKGAVRLRSPVKTDGTAVQELIARCAPLDQNSLYMNLIQCDHFADTCVLAERGDDVLGWISAHVPPGREDTIFVWQVAVDARARGMGLGRHMLTALLERPLCRRVINLETTITRDNEGSWALFRSLARRLDGDLSHAPHFEREAHFGGAHDTEHLVTIALDAEAVRRAA",
    "product": "L-2,4-diaminobutyric acid acetyltransferase"
   },
   {
    "start": 6556,
    "end": 7044,
    "strand": 1,
    "locus_tag": "KKHPANEM_01442",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01442</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01442</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,556 - 7,044,\n (total: 489 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1135:MarR family transcriptional regulator (Score: 88.6; E-value: 4.5e-27)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01442 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01047.24 (MarR family): [31:90](score: 56.9, e-value: 1.5e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01442 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01047.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF01047.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01442\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=17044\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/KKHPANEM_01442_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01442\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01442\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACGGAACGGGTGGATGCGACGCTGATCGCACTCAGGCGCGTGCTGCGCGCGATCGAGGGCAACGCCCGCGCGATCGCGCGGGCCTCGGGGTTGACGCACGCACAGATGCTGGTGCTGCACGCGCTGGCCGACCGCGGGCAGGAACTGCCCAGCGACATCGCCCGCCGTCTGGGCGTGGCCCAGGCCACCGTCACCACCCAGATCGATCGGCTGGAGGCGCGCGGCCTTGTGCGCCGCGAGCGTCGGCAGACCGACCGCCGCACCGTCTGGGTGATCCTGACCGACAGCGGGCGCCAGCTTCTGGCCGACACCCCCGACCCGCTCTATGGCCGCTTCGCCGACCGGTTCGCGCGGCTTGCGGATTGGGAACAGGGCATGCTGATGACCAGCGCCGAGCGTCTGGCCAAGCTGTTTGACGCCGAGGCCGTCGAGCCCCTGCCCGCGGGCGAGGACACCGCGCGCAAACCCGCGCCCCCCGTCGCCTGA",
    "translation": "MTERVDATLIALRRVLRAIEGNARAIARASGLTHAQMLVLHALADRGQELPSDIARRLGVAQATVTTQIDRLEARGLVRRERRQTDRRTVWVILTDSGRQLLADTPDPLYGRFADRFARLADWEQGMLMTSAERLAKLFDAEAVEPLPAGEDTARKPAPPVA",
    "product": "hypothetical protein"
   },
   {
    "start": 7260,
    "end": 8933,
    "strand": 1,
    "locus_tag": "KKHPANEM_01443",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01443</span></strong><br>\n \n  Cytochrome c oxidase subunit 1-beta<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01443</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ctaDII</span><br>\n \n Location: 7,260 - 8,933,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01443 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00115.22 (Cytochrome C and Quinol oxidase polypeptide I): [28:494](score: 501.7, e-value: 1.8e-150)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01443 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02891 (CtaD_CoxA: cytochrome c oxidase, subunit I): [20:547](score: 680.3, e-value: 3.8e-205)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01443 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00115.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004129' target='_blank'>GO:0004129</a>: cytochrome-c oxidase activity<br>\n  \n   PF00115.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n   PF00115.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009060' target='_blank'>GO:0009060</a>: aerobic respiration<br>\n  \n   PF00115.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01443\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000218.1&amp;from=0&amp;to=18933\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctaDII_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01443\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01443\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCCGACGCAGTCACCCAGGGCGGAGGGCACGGGGACACCCGCGGGTTCTTCACCCGCTGGTTCATGTCCACCAACCACAAGGACATCGGGATCCTGTATCTGTTCACCTCCGGCATCGTCGGATTCATCGCGGTGGCCTTCACGGTCTACATGCGCATGGAACTGATGGAGCCCGGCGTTCAGTACATGTGCCTGGAGGGCGCGCGCATGACCGCGGCCGCCGCGGGCGAGTGCACCCCCAACGGCCACCTGTGGAACGTGCTGATCACCGCCCACGGCGTGCTGATGATGTTCTTCGTCGTGATTCCGGCGCTGTTCGGGGGCTTTGGCAACTACTTCATGCCGCTGCACATCGGCGCGCCGGACATGGCGTTCCCGCGGCTCAACAACCTGTCGTACTGGCTTTATGTGGCCGGGGCGTCGCTGGCGGTGGCGTCGCTGTTCTCGCCCGGCGGCGCGGGGCAGACCGGCGCGGGGGTGGGCTGGGTGCTCTATCCGCCGCTGTCGACGACCGAGACCGGCTATGCGATGGACCTCGCGATCTTTGCGGTGCATGTCGCGGGCGCCTCGTCGATCCTGGGTGCGATCAACATCATCACCACCTTCCTGAACATGCGAGCGCCGGGCATGACGCTGCACAAGGTGCCGCTGTTCGCCTGGTCGGTGTTCATCACCGCGTGGATGATCCTGCTGGCGCTGCCGGTTCTTGCGGGCGCCATCACCATGCTGCTGACCGACCGGAACTTCGGCACCACCTTCTTCGATCCCTCGGGCGGCGGCGACCCGGTGCTGTACCAGCACATCCTGTGGTTCTTCGGCCATCCGGAGGTCTACATCATCATCATCCCCGGCTTCGGCATCATCAGCCATGTCATCGCCACGTTCTCGCGCAAGCCGATCTTCGGCTACCTGCCGATGGTCTATGCGATGGTGGCCATCGGGGTGCTGGGCTTCGTGGTGTGGGCGCACCACATGTACACCGTGGGCATGTCGCTGACGCAGCAGAGCTACTTCATGCTGGCGACGATGGTGATCGCGGTGCCGACGGGCATCAAGATCTTCAGCTGGATCGCCACGATGTGGGGCGGCTCGGTGGAGTTCAAGACGCCCATGCTGTGGGCCTTCGGGTTCCTGTTCCTGTTCACCGTGGGCGGCGTGACGGGCGTGGTGCTCAGCCAGGCCGCCGTCGACCGCTACTATCACGACACCTACTATGTGGTCGCGCACTTCCACTATGTGATGTCCTTGGGCGCCGTGTTCGCGCTGTTTGCCGGGATCTACTACTGGATCGGCAAGATGTCGGGGCGGCAGTACCCCGAATGGGCCGGCAAGACGCACTTCTGGGCGATGTTCATCGGCTCCAACCTGACCTTCTTTCCGCAGCACTTCCTCGGCCGTCAGGGGATGCCGCGCCGCTACATCGACTACCCCGAGGCGTTCGCGCTGTGGAACTGGGTAAGCTCGATCGGCGCCTTCATCTCGTTCGCCTCGTTCGTGTTCTTCATCGGGGTGATCTACTACACCCTGCGCCACGGCGCGCGCGTGACCGAGAACAACTACTGGAACGAGCACGCCGACACGCTGGAGTGGACCCTGCCCTCGCCGCCGCCCGAACATACGTTCGAGACGCTGCCGAAGCGCGAGGACTGGGACCGCTCGCCCGCCCACTGA",
    "translation": "MADAVTQGGGHGDTRGFFTRWFMSTNHKDIGILYLFTSGIVGFIAVAFTVYMRMELMEPGVQYMCLEGARMTAAAAGECTPNGHLWNVLITAHGVLMMFFVVIPALFGGFGNYFMPLHIGAPDMAFPRLNNLSYWLYVAGASLAVASLFSPGGAGQTGAGVGWVLYPPLSTTETGYAMDLAIFAVHVAGASSILGAINIITTFLNMRAPGMTLHKVPLFAWSVFITAWMILLALPVLAGAITMLLTDRNFGTTFFDPSGGGDPVLYQHILWFFGHPEVYIIIIPGFGIISHVIATFSRKPIFGYLPMVYAMVAIGVLGFVVWAHHMYTVGMSLTQQSYFMLATMVIAVPTGIKIFSWIATMWGGSVEFKTPMLWAFGFLFLFTVGGVTGVVLSQAAVDRYYHDTYYVVAHFHYVMSLGAVFALFAGIYYWIGKMSGRQYPEWAGKTHFWAMFIGSNLTFFPQHFLGRQGMPRRYIDYPEAFALWNWVSSIGAFISFASFVFFIGVIYYTLRHGARVTENNYWNEHADTLEWTLPSPPPEHTFETLPKREDWDRSPAH",
    "product": "Cytochrome c oxidase subunit 1-beta"
   }
  ],
  "clusters": [
   {
    "start": 4003,
    "end": 4387,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 9387,
    "product": "ectoine",
    "category": "other",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "ectoine",
  "products": [
   "ectoine"
  ],
  "product_categories": [
   "other"
  ],
  "cssClass": "other ectoine",
  "anchor": "r218c1"
 },
 "r237c1": {
  "start": 1,
  "end": 3563,
  "idx": 1,
  "orfs": [
   {
    "start": 6,
    "end": 1016,
    "strand": 1,
    "locus_tag": "KKHPANEM_01604",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01604</span></strong><br>\n \n  Phytoene desaturase (neurosporene-forming)<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01604</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtI_1</span><br>\n \n Location: 6 - 1,016,\n (total: 1011 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 315.4; E-value: 1.3e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01604 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.26 (Flavin containing amine oxidoreductase): [3:323](score: 46.9, e-value: 2.6e-12)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01604 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02734 (crtI_fam: phytoene desaturase): [1:332](score: 429.8, e-value: 3.2e-129)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01604 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01604\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237.1&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/crtI_1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGCCTGCGCGGCGACCGCAGCGTCTATCAGACGGTCAGCCGCTACGTGAAGGACGAGCGGCTGCGGGTCATGCTGTCGTTCCATCCGCTCTTGATCGGCGGCAACCCCTTCCATGCCAGTTCGGTCTATTGCCTGATCTCCTATCTGGAACGGCACTGGGGTATCCATTTCGCGATGGGCGGCACCGGCCGGCTGGCCAGCGGTCTCGCGAAGCTGGTGGAGGGGCAGGGCAACCAGATCCGCTATCACGCGCAGGTCGAGGAGATCGAGGTTGCGGACGGCCGGGCGACCGGTGTGCGCCTTACGACCGGCGAGCGCATTCCCGCCGAGATCGTCGTCTCCAACGCCGACAGCGCCTACACCTACCGCCGGATGCTGCCGCCGCAGGTCCGCAAGCGCTGGACCGACCGCAAGCTGGACCGCGCGCGCTACTCGATGAGTCTGTTCGTCTGGTACTTCGGCACCAAGCGACAGTACTCGGAGACGGCGCACCATACGATCCTGCTTGGCCCGCGCTACAAGGAGCTGATCGAGGACATCTTCGAGCGCAAAATCCTGGCCGACGACTTCTCGCTGTATCTGCACCGGCCGACCGCGACCGATCCGTCGCTGGCGCCGGACGGCTGCGATAGCTTCTACGTGTTGTCGCCGGTGCCGCACATGGATGCCGGGATCGACTGGTCGCAGCAGGCGCAGGCGTATCGCGCGCGGATCGCGGATTTCCTGGAGCGCACCGAGTTGCCGGGCCTGCGCGAGAACATCGTGTCCGAACACATGATCACGCCGCAGGATTTTCAGGACCGCCTGCTGTCCGAGCGCGGCGCGGCCTTCGGGCTGGAGCCGCGACTGACACAGAGCGCCTGGTTCCGCCCCCACAACAAGAGCGAGGACGTCGAGGGTCTATACCTCGTTGGTGCCGGTACCCATCCCGGTGCCGGTTTGCCCGGAGTCCTCTCGTCCGCTCGCGTGCTCGACCAGGTGGTGCCCGATGCCAGTGAATTCGCCTAG",
    "translation": "MRLRGDRSVYQTVSRYVKDERLRVMLSFHPLLIGGNPFHASSVYCLISYLERHWGIHFAMGGTGRLASGLAKLVEGQGNQIRYHAQVEEIEVADGRATGVRLTTGERIPAEIVVSNADSAYTYRRMLPPQVRKRWTDRKLDRARYSMSLFVWYFGTKRQYSETAHHTILLGPRYKELIEDIFERKILADDFSLYLHRPTATDPSLAPDGCDSFYVLSPVPHMDAGIDWSQQAQAYRARIADFLERTELPGLRENIVSEHMITPQDFQDRLLSERGAAFGLEPRLTQSAWFRPHNKSEDVEGLYLVGAGTHPGAGLPGVLSSARVLDQVVPDASEFA",
    "product": "Phytoene desaturase (neurosporene-forming)"
   },
   {
    "start": 997,
    "end": 2061,
    "strand": 1,
    "locus_tag": "KKHPANEM_01605",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01605</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01605</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 997 - 2,061,\n (total: 1065 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_01605 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.21 (Squalene/phytoene synthase): [23:274](score: 224.0, e-value: 2.5e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_01605 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01605\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237.1&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/KKHPANEM_01605_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCAGTGAATTCGCCTAGAGACGCAACCCTCCGCGCGGCCGATGCCGCAGCGGCGACGGCGGCGATCCGTACCGGATCGCGCAGCTTTCATGCCGCGTCGCTGGTGCTGCCGCGCCGGGTGCGGGAACCGGCGCGCGGGCTCTACGCTTTCTGTCGGGAAGCGGACGACGCCGTCGACACTCGCCCGGATCGCACGCGCGCGCTCGCAGAACTGCGCCAGCGCTTGCAGTGGATTTATGACGGTCGCCCAGGCAACAACGCCGCGGACCGGGCGTTTGCCGACGTGGTCGCCGCCTATGCGATCCCGCAGACCTTGCCCGAAGCGCTGTTGGAAGGCTTCGCCTGGGATGCCGAGGAGCGGCGTTACCGCACGATTCAGGATCTGCGCGCCTATGGCGCCCGGGTTGCCGGGGCGGTCGGCGCGATGGTCGCAATGCTGATGGGCGCGCGCCAGGCGGAGGTCGTCTCGCGGGCCACTGACCTCGGCGTGGCGATGCAGCTGACCAATATCGCCCGCGACGTTGGCGAGGATGCGCGCCAGGGGCGCGTCTATTTGCCGATCGATTGGCTGGAGGCGGAAGGCATCGACGCTGACGCTTGGCTCGCCGACCCACGGTTTGGTCCGGGCGTCGCGCGGACGGTGGAACGGCTGCTAGCCCACGCGGAGGAGCTGTATCAGCGTGCGGAAGCTGGCATTCCCGCGCTGCCGGCTTCCTGCCGCCCAGGCATCACCGCCGCCAGCCGTCTGTACCGGGCGATCGGCCATCAGGTCGCCCGGCAAGGCCACGATTCCTTGTCCCGGCGGGCGGTTGTACCGGCGATGCGCAAGGTCGGGCTGATGGTCGACGCGTTGAAGGGGCCGATGCCGGTTGCGCACTACAGCGACTATCCCTGCTTGCCGGAGACCCGGTTCCTGGTTCAGGCCGTGCACGAGGCATTGCCCGCGCTGCACGGTTTCAAGCCGGACGCAGCGGATGCGTCCGCTCCCGTCGAAGAGGGCGCCGCGGCCTTCGTGATCGACCTGTTCATGCGTCTGGAGCAGCGCGACCAGGCACGCGGGTAG",
    "translation": "MPVNSPRDATLRAADAAAATAAIRTGSRSFHAASLVLPRRVREPARGLYAFCREADDAVDTRPDRTRALAELRQRLQWIYDGRPGNNAADRAFADVVAAYAIPQTLPEALLEGFAWDAEERRYRTIQDLRAYGARVAGAVGAMVAMLMGARQAEVVSRATDLGVAMQLTNIARDVGEDARQGRVYLPIDWLEAEGIDADAWLADPRFGPGVARTVERLLAHAEELYQRAEAGIPALPASCRPGITAASRLYRAIGHQVARQGHDSLSRRAVVPAMRKVGLMVDALKGPMPVAHYSDYPCLPETRFLVQAVHEALPALHGFKPDAADASAPVEEGAAAFVIDLFMRLEQRDQARG",
    "product": "hypothetical protein"
   },
   {
    "start": 2195,
    "end": 2401,
    "strand": 1,
    "locus_tag": "KKHPANEM_01606",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01606</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01606</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,195 - 2,401,\n (total: 207 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01606\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237.1&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATGGCGGTTGGATTGTGCTGCTGGAGGGGATGACGGTCTTCGGGCTGTTGATCGGCTTCGGCATCTGGCAGTTGCGTTCGCTGAAAAAGATGGAGCGCGAAGATAAGGCCAAGGCGGCGGCCGAGGGACGGGAGGGCGAGTCCGCCTTCATCCGCTCCCGTGAACCCCGGTCAGGCGCGGATACGGGGCATTCGGAAGGGTAG",
    "translation": "MDGGWIVLLEGMTVFGLLIGFGIWQLRSLKKMEREDKAKAAAEGREGESAFIRSREPRSGADTGHSEG",
    "product": "hypothetical protein"
   },
   {
    "start": 2369,
    "end": 3355,
    "strand": -1,
    "locus_tag": "KKHPANEM_01607",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_01607</span></strong><br>\n \n  Acyclic carotenoid 1,2-hydratase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_01607</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtC_1</span><br>\n \n Location: 2,369 - 3,355,\n (total: 987 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_01607\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000237.1&amp;from=0&amp;to=3563\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_01607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCCTGTTGGCGGACTGGGGCATCAGCGACCCAACACGGACGGCCCCGGGTTCGATCAGCCGGTCGCGCCGGGCGGCTACGTCTGGTGGTACGTCGACGCGCTGAGCGACGACGGTCAGCACGGCCTGACCATCATCGCCTTCATCGGGTCGGTGTTCTCGCCGTACTACGCCTGGGCCCGACAGCGCGCACCCGGCGGCGCGGCGGACCCGCTGAACCACTGCTCGATCAATGTGGCCCTCTACGGCGAGGGGCCGAACCGCTGGGCGATGACGGAACGTGGCCGCACCCGCATCGATCGCGGCGCGCGGCACTTCTCCGTTGGTCCCAGCGGGCTGCACTGGGATGGCCGGACGCTCACCATCCACCTCGACGAGATCGCCGCGCCGCTGCCACGCGCGGTGCAAGGGCGCGTGCGCGTCACCCCGCACGCGATGACGACCCAGGAGTTCGCGATCGATCACCAGGATCGCCACCACTGGTGGCCGATGGCCCCCACGGCGGAGGTTTCGGTCGCCTTGAACAAACCGGCCCTGTCCTGGCACGGCACCGGCTACCTGGACCGCAACCGCGGCGACGAACCGCTCGAAGCCGGTTTTCAGGAATGGGACTGGGCGCGCGCCCCGCTGCCCTCCGGCGGCACCGCGATCACCTACGACACCTTCCGCCGCGACGGCTCCGACCACGCGCTGTCCCTGCTCGTCAGGAAAGATGGCGGGATCGAACGGTTCGACAACGCCGTCCTCAACGATCTGCCGTCGACATCGATCTGGCGCATCCGCCGCAAGGGCCGCGCCGATGCCGGCCATCGGGCCTGCGTGTCGAAGACGCTGGAGGACACGCCCTTCTACGCCCGCTCGCTGGTCGAGACGCACCTGGCAGGCGAACCGGTGCGGGCGATGCACGAAAGCCTGTCGTTGACGCGCTTCGACACGCGGATCGTGCGCCTGATGCTACCCTTCCGAATGCCCCGTATCCGCGCCTGA",
    "translation": "MPVGGLGHQRPNTDGPGFDQPVAPGGYVWWYVDALSDDGQHGLTIIAFIGSVFSPYYAWARQRAPGGAADPLNHCSINVALYGEGPNRWAMTERGRTRIDRGARHFSVGPSGLHWDGRTLTIHLDEIAAPLPRAVQGRVRVTPHAMTTQEFAIDHQDRHHWWPMAPTAEVSVALNKPALSWHGTGYLDRNRGDEPLEAGFQEWDWARAPLPSGGTAITYDTFRRDGSDHALSLLVRKDGGIERFDNAVLNDLPSTSIWRIRRKGRADAGHRACVSKTLEDTPFYARSLVETHLAGEPVRAMHESLSLTRFDTRIVRLMLPFRMPRIRA",
    "product": "Acyclic carotenoid 1,2-hydratase"
   }
  ],
  "clusters": [
   {
    "start": 996,
    "end": 2061,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 3563,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r237c1"
 },
 "r273c1": {
  "start": 6312,
  "end": 21589,
  "idx": 1,
  "orfs": [
   {
    "start": 6817,
    "end": 7518,
    "strand": 1,
    "locus_tag": "KKHPANEM_02026",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02026</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02026</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,817 - 7,518,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02026 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF11306.10 (Protein of unknown function (DUF3108)): [18:169](score: 44.8, e-value: 1.5e-11)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02026\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=0&amp;to=17518\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGTGGCCATCGTGGCGGGGCTGTGGGCGCCCGGCGGCGCGGCGGCGCTTGATCTGCCCGAGGTGGTGCGCCTCGATGTGACTTTTGCGGGGCTGCCGGTGGGGGTGCTGCACCTTGCCATCCGCCGCACCGACGGCAGCTATGCCGCGACGGCGCGGCTGCAACCGGCGGGGCTGGGGCGTCTGCTGCCCTCGGCCCGGTTCGAGGCGACGGTGCAGGGCCGCCTGCGCGCAGGCCGCCCGCAGCCGCTGCGCTATGTCGAGGATGTGCACACCGGACGGCGCGAATCGCGCACCGAAATCGCATGGGAGGGGGGGGTGCCGCGCCTGCTGCGCCTTGACCCGCCGCGCCCGCCCGAGCCGTGGCACCTCGACCCGGCGGGGCAGGGCGGTGCGCTCGATCCGATGTCGGCGGTGCTGTCGGTGCTTGCGGATGTTCCGGCGGAGCGGGCCTGCGCGCTCGACCTTGCGGTGTTCGACGGGCGGCGGCGCACGCAGATCGTTCTGGCGCCCGCGCCGGACGGCGAGCCCGGCTGCGACGGCGTGTTTCGCCGCGTCGCAGGGTATGACCCCGAGGATCTGGCCGAGCGGCCGGAGGTGCCGTTCCGCCTGATCCACGGCCCCGGCCCGGGCGGCACCCTGCGCGTCATCGCACTGGAGGCCGCCTGGGAGCTGGGCACCGCCCGGCTGACCCGCGACTGA",
    "translation": "MVAIVAGLWAPGGAAALDLPEVVRLDVTFAGLPVGVLHLAIRRTDGSYAATARLQPAGLGRLLPSARFEATVQGRLRAGRPQPLRYVEDVHTGRRESRTEIAWEGGVPRLLRLDPPRPPEPWHLDPAGQGGALDPMSAVLSVLADVPAERACALDLAVFDGRRRTQIVLAPAPDGEPGCDGVFRRVAGYDPEDLAERPEVPFRLIHGPGPGGTLRVIALEAAWELGTARLTRD",
    "product": "hypothetical protein"
   },
   {
    "start": 7528,
    "end": 10089,
    "strand": -1,
    "locus_tag": "KKHPANEM_02027",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02027</span></strong><br>\n \n  Aminopeptidase N<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02027</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pepN</span><br>\n \n Location: 7,528 - 10,089,\n (total: 2562 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02027 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17900.3 (Peptidase M1 N-terminal domain): [105:181](score: 35.6, e-value: 1.1e-08)<br>\n \n  PF01433.22 (Peptidase family M1 domain): [219:433](score: 172.7, e-value: 8.3e-51)<br>\n \n  PF11940.10 (Domain of unknown function (DUF3458) Ig-like fold): [438:532](score: 100.3, e-value: 6.5e-29)<br>\n \n  PF17432.4 (Domain of unknown function (DUF3458_C) ARM repeats): [536:852](score: 351.9, e-value: 3.7e-105)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02027 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02414 (pepN_proteo: aminopeptidase N): [12:851](score: 1092.9, e-value: 0.0)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02027 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01433.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008237' target='_blank'>GO:0008237</a>: metallopeptidase activity<br>\n  \n   PF01433.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02027\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=0&amp;to=20089\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGACGCAACCCCCCAGCCGATCCGACTGGCGGACTACACCCCGCCGCCGTTCCTGGTGGAGGGGGTCGCGCTGACCTTCCGGCTGGCGCCACGGGCCACGCGGGTGACGTCGCGCATCCGGTTCCGGCGCAACCCCGACGCGCAGGCCCAAGATCTGCGGCTGGATGGCGAGGGGCTGCGGCTGATCTCGGCCACCATCGACGGCGTGCCGATCACCGCGCAGCCCGATGCGACGGGCCTGACGCTGCCGGGCGGGGATCTGCCGGACGCCTTTGACTGGGCCGCCGAGGTGGAGATCGCACCGGAGGAAAACACCGCGCTGGAGGGGCTTTACATGTCGAATGGCATGTATTGCACGCAGTGCGAGGCCGAAGGCTTCCGCAAGATCACCTTCTATCCCGACCGCCCGGACGTGATGGCACCGTTCACGGTGCGGGTCGAATCCGAGCTGCCGGTGCTGCTGTCGAACGGCAATCCGTCCGCCCAGGGCGATGGCTGGGCCGAATGGGACGATCCCTGGCCCAAGCCCGCCTATCTGTTCGCGCTGGTGGCGGGCGATCTGGTGGCACATTCGGACGCCTTTGCCACCGCATCGGGGCGCGCGGTCGCGCTGAATGTCTGGGTGCGCCCGGGCGACGAGGGGCGCTGCGCCTATGCGATGGATTCGCTCAAACGCTCCATGCGCTGGGATGAGGAGGCCTACGGGCGCGAATACGACCTCGATGTGTTCAACATCGTGGCGGTGGACGACTTCAACATGGGCGCGATGGAGAACAAGGGGCTCAACGTCTTCAACTCCAAATACGTCCTCGCCTCCTCCGAGACGGCGACGGATGCCGACTTCGACAACATCGAGCGCATCGTCGCGCATGAATACTTCCACAACTGGACCGGCAACCGCATCACCTGCCGCGACTGGTTCCAGCTGTGCCTCAAGGAAGGGCTGACGGTGTTCCGCGACCAGCAGTTCAGCGCCGACATGCGCTCGGCCGCCGTCAAGCGGATCGAGGACGTGCTGAGCCTGCGCGCACGCCAGTTCCGCGAGGATCAGGGCCCGCTGGCGCATCCGGTGCGCCCCGACAGCTATCACGAGATCAACAACTTCTACACCGCGACGGTGTACGAGAAGGGCGCCGAGATCATCCGCATGCTGCGCACGCTGGTGGGCGAGGACGGCTATGACGCGGGCGTGCGGCTCTATTTCGACCGCCACGACGGGCAGGCCTGCACGATCGAGGACTGGTTGGCGGTGTTCGCGGAGGCCACGGGGCGCGACCTGTCGCAATTCGCGCGCTGGTATGCCCAGGCCGGCACCCCGCGCCTGCGGGTGACCGAGGATTGGGACGAGGGCACCGGCCGCTTCACCCTGACGCTGGAGCAGTCCACCCCCCCCACCCCGGGCCAGCCCGACAAGGCACCCCAGGTGATCCCGGTGGCCGTTGGCCTGCTGGGTCCCGCGGGCGACGAGATCATGGCCACCCGCGTGATCGAGATGACCGACACCCGCCACAGCCTGACGATCGAGGGGATGCCGGCACGCCCCGTCCCGTCGATCCTGCGCGGCTTCTCCGCCCCGGTGGTGGTCGAGCACGCGGTCACGCCGGAACGCCGCGCCTTTCTGATGGCCCATGACACCGATCCGTTTTCCCGGTGGGAGGCCGGGCGCGGGCTGGCGCGCGAGATCCTTGTGGCGATGGTGCGCGACGGCGCGGCGCCCGGGCCGGATTACCTCGATGCGCTGGCGGTGACGCTGTCGGACGAACGGCTGGACCCGGCGTTCCGCGCGCTGTGCCTGCGCGCGCCCTCCGAGGATGACATCGCCCAGGCGCTGGTGGATGCCGGCGAGACGCCGGACCCCATGGCGATCCACACCGCGCGCGAGCGGTTCCAGCGCGCGATCGCGGCCCACATGGACGACGGGCTGGCGCGCGCCTTCATCGCGATGGAGACGCCCGGCCCCTACAGCCCCGACGCGCGCGACGCGGGCCGCCGGGCGCTGCGGCTGGCGGCACTGGCGTATCTGTCGCGCAATGACGGCGGGGACCGGGCCGCGCGGCTGTTCGCCGGGGCCGACAACATGACCGAACAGATGGGCGCGCTGGGGGCCCTGCTGCAGGTCGGCGCGGGCCAGTCCGAGGTCGCGCGGTTCCACCGTCAATGGGCCCACGACCGGCTGGTGGTGGACAAGTGGTTCGCCGTTCAGGTGGCCCTCGCAGCGCCCGAAAGCGCGGTGGAGACCGCGCGCAGCCTGACGCGCCACCCCGATTTCGACTGGAAGAACCCCAACCGCTTCCGCTCGGTGCTGGGTGCGCTGGCGACGAATGCGGCGGGGTTCCACGCGCCGGGGGGCGCAGGCTATGCGCTGCTGGCGGACTGGCTGATCCAGCTTGATCCGGTGAACCCGCAGACCGCGGCGCGGCTGTCGACGGCGTTCGAGACCTGGCGCCGCTACGACCCCGCGCGCCAGGGCGCGATGCGCGCGGCGCTGGAGCGGATCCGCGCGACCCCCGACCTCAGCCGCGATCTGTCGGAAATGACGGCCCGGATGCTGGGCTGA",
    "translation": "MKDATPQPIRLADYTPPPFLVEGVALTFRLAPRATRVTSRIRFRRNPDAQAQDLRLDGEGLRLISATIDGVPITAQPDATGLTLPGGDLPDAFDWAAEVEIAPEENTALEGLYMSNGMYCTQCEAEGFRKITFYPDRPDVMAPFTVRVESELPVLLSNGNPSAQGDGWAEWDDPWPKPAYLFALVAGDLVAHSDAFATASGRAVALNVWVRPGDEGRCAYAMDSLKRSMRWDEEAYGREYDLDVFNIVAVDDFNMGAMENKGLNVFNSKYVLASSETATDADFDNIERIVAHEYFHNWTGNRITCRDWFQLCLKEGLTVFRDQQFSADMRSAAVKRIEDVLSLRARQFREDQGPLAHPVRPDSYHEINNFYTATVYEKGAEIIRMLRTLVGEDGYDAGVRLYFDRHDGQACTIEDWLAVFAEATGRDLSQFARWYAQAGTPRLRVTEDWDEGTGRFTLTLEQSTPPTPGQPDKAPQVIPVAVGLLGPAGDEIMATRVIEMTDTRHSLTIEGMPARPVPSILRGFSAPVVVEHAVTPERRAFLMAHDTDPFSRWEAGRGLAREILVAMVRDGAAPGPDYLDALAVTLSDERLDPAFRALCLRAPSEDDIAQALVDAGETPDPMAIHTARERFQRAIAAHMDDGLARAFIAMETPGPYSPDARDAGRRALRLAALAYLSRNDGGDRAARLFAGADNMTEQMGALGALLQVGAGQSEVARFHRQWAHDRLVVDKWFAVQVALAAPESAVETARSLTRHPDFDWKNPNRFRSVLGALATNAAGFHAPGGAGYALLADWLIQLDPVNPQTAARLSTAFETWRRYDPARQGAMRAALERIRATPDLSRDLSEMTARMLG",
    "product": "Aminopeptidase N"
   },
   {
    "start": 10256,
    "end": 11779,
    "strand": 1,
    "locus_tag": "KKHPANEM_02028",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02028</span></strong><br>\n \n  Cryptochrome-like protein cry2<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02028</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">cry2</span><br>\n \n Location: 10,256 - 11,779,\n (total: 1524 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02028 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00875.20 (DNA photolyase): [3:129](score: 95.5, e-value: 3.4e-27)<br>\n \n  PF03441.16 (FAD binding domain of DNA photolyase): [262:455](score: 181.8, e-value: 1.2e-53)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02028\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=256&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/cry2_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGGTTCGATTGTCTGGTTCAAGCGTGACCTGCGGGTGGCCGACCACGCGGCGCTGTGTGCGGCGGCGGCGCTTGGCCCCGTGCTGCCGCTTTATGTGGTGGAGCCGGAGCTGTGGGCACAGCCCGACGCCTCGGCCCGGCAATGGGCGTTCGTTGCCGAGTGTCTGGAGGCGCTGCGCGGCGACCTGGCCGCGCTGGGGGCGCCGCTGGTCGTGCGCACTGGCTGCGCGGTCGAGGTGCTGGAGACGCTGGCCCGCCGCCACCGCCTGTCGCGCATCTTCAGCCACGAGGAGACCGGCACCCTGTGGACCTTTGCCCGCGACCGGCGTGTGGGGGCGTGGGCGCGCGCCAACGGCATGGCGTGGCACGAGGGGCCGCAGTCGGGCGTGGTGCGCCGCCTTGCCGCGCGCGATGGCTGGGCGGGGCGGCGGGATCGCTTCCTCGCCGCGCCCGCGGCCCAGCCGCCGGGGCTGTCGGCGGTGCCCGGCGTGGCGCCCGGCCCGATCCCCACCGCCCGCACCCTGCGCCTGGCCGAGGACCGCTGCCCCCACCGCCAGGTTGGCGGGCGGCAGGCCGCGCTGACCACGCTGGGCGGGTTCCTGACCTCGCGGGGCGAGGGGTACCGCGCCGCCATGGCCTCGCCCGTAGCCGGGGAACGCGCGTGTTCGCGCCTCTCGCCGCACCTGGCCTTCGGCGTGCTGTCCGGGCGCGAGGTCGCGCACGCCGCGGCCGCCCGCCGCGCCGAACGCCCCGGCGGTGGCTGGGGGGCTTCGCTGCGCAGCTTTGAATCGCGCCTCGCCTGGCGCGACCACTTCATGCAGAAGCTGGAGGACGCCCCCGACCTGGAGGCCCGCTGCCTGCACCGCGCGACCGAAAGCCTGCGCCCGCGCACGCCCGACGCCACCCGCCTCGCGGCATTCCAGTCCGCCGAGACCGGCATCCCCTTTGTCGACGCCTGCCTGCGGTATCTGGCGGCCACCGGCTGGCTGAACTTCCGCATGCGCGCGATGCTGGTGTCGGTGGCGGCGAACCACCTGTGGCTGGACTGGCGCGCCACGGGGCCGTTCCTGGCGCGGCGCTTCACCGACTACGAACCCGGCATCCACTGGAGCCAGATGCAGATGCAGTCCGGCACCACCGGCATCAACACCATCCGCATCTACAACCCCGTCAAGCAGGGCCGCGACCAGGACCCCGACGGCCGCTTCACCCGCGCCTGGCTGCCGGAGCTGGCCGAGGTGCCCGACGCCTTCCTGCACGAACCCTGGCGCTGGGGCGGGGCAGGGCGCGTGCTGGGGCGCGCCTATCCCGAGCCGGTGGTCGATGTCGCCGCCGCCGCCCGCGCCGCGCGCGAGGCGGTGTGGGGCCTGCGCCGCGCCCGCGGTTTCGCCGCCGAAGCCGCCGAGGTCGCCCGCAAGCACGCCAGCCGCAAGGACCGCTCGGGCCATTTCGTCAACGACCGCGCGCCCCGACGCCGTCGCCCCGCCGCAGCCCCGGGCCAGCTGTCGCTGGATCTCTGA",
    "translation": "MTGSIVWFKRDLRVADHAALCAAAALGPVLPLYVVEPELWAQPDASARQWAFVAECLEALRGDLAALGAPLVVRTGCAVEVLETLARRHRLSRIFSHEETGTLWTFARDRRVGAWARANGMAWHEGPQSGVVRRLAARDGWAGRRDRFLAAPAAQPPGLSAVPGVAPGPIPTARTLRLAEDRCPHRQVGGRQAALTTLGGFLTSRGEGYRAAMASPVAGERACSRLSPHLAFGVLSGREVAHAAAARRAERPGGGWGASLRSFESRLAWRDHFMQKLEDAPDLEARCLHRATESLRPRTPDATRLAAFQSAETGIPFVDACLRYLAATGWLNFRMRAMLVSVAANHLWLDWRATGPFLARRFTDYEPGIHWSQMQMQSGTTGINTIRIYNPVKQGRDQDPDGRFTRAWLPELAEVPDAFLHEPWRWGGAGRVLGRAYPEPVVDVAAAARAAREAVWGLRRARGFAAEAAEVARKHASRKDRSGHFVNDRAPRRRRPAAAPGQLSLDL",
    "product": "Cryptochrome-like protein cry2"
   },
   {
    "start": 11878,
    "end": 12774,
    "strand": 1,
    "locus_tag": "KKHPANEM_02029",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02029</span></strong><br>\n \n  1,4-dihydroxy-2-naphthoate octaprenyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02029</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">menA</span><br>\n \n Location: 11,878 - 12,774,\n (total: 897 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ubiA<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02029 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01040.20 (UbiA prenyltransferase family): [38:275](score: 134.1, e-value: 5.2e-39)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02029 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01476 (chlor_syn_BchG: bacteriochlorophyll/chlorophyll synthetase): [16:296](score: 377.6, e-value: 8.9e-114)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02029 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01040.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups<br>\n  \n   PF01040.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02029\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=1878&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/menA_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02029\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02029\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTGTCACGTCTGATTTACACACCCGCACCCTGCCACAGCCCGCCGCGATGCTGGAGCTGATCAAGCCGATCACCTGGTTTCCGCCGATGTGGGCCTATCTGTGCGGCGTCATCTCGTCCGGGGTGTCGCCGCTGGAAAGCCTGTTTCTGGTCATCCTCGGCGTCCTGCTGGCGGGTCCCATCGTCTGCGGGATGAGCCAGGCGGCCAACGACTGGTGCGACCGCCACGTCGATGCGATCAACGAACCGCACCGGCCGATCCCCTCGGGGCGCATTCCGGGCCGCTGGGGGCTGTGGATCGCGCTGGCGATGTCGGGGCTGGCGCTGGTGGTGGGCTGGTTCCTCGGGCCGTGGGGCTTTGGCGCCACCGTGCTGGGGGTGATCGCGGCCTGGGCCTATTCCTGCCCGCCGGTGCGGCTGAAGCGGTCGGGCTGGTGGGGGCCGGGGCTGGTCGGGCTGTCGTATGAATCGCTGCCGTGGTTCACCGGCGCGGCCGTCCTCGCCGTCGGCGCGCCCAGCTGGGAGATCGTCGCGGTGGCCGTGCTCTATGGCCTCGGCGCGCACGGGATCATGACGCTCAACGATTTCAAGGCGCTGGAGGGCGATCGCCAGATGGGCGTGAACTCCCTGCCCGTGACGCTGGGCCCGGAGCTGGCGGCCAAGGTCGCGTGCTGGGTGATGATCGTCCCGCAACTCGTTGTGATCGCGCTTCTCTTCCAGTGGGATCGTCCCTGGTACGGCTTCTTCATCGTGATCTCGGTGATCCTGCAGTTCTATGCCATGTCGGTGCTGCTGCGCGACCCCAAGGCCAAGGCGCCCTGGTACAATGCCACCGGTGTCAGCCTCTATGTCACCGGCATGATGATCACCGCTTTCGCGCTGCGCACGCTCTGA",
    "translation": "MSVTSDLHTRTLPQPAAMLELIKPITWFPPMWAYLCGVISSGVSPLESLFLVILGVLLAGPIVCGMSQAANDWCDRHVDAINEPHRPIPSGRIPGRWGLWIALAMSGLALVVGWFLGPWGFGATVLGVIAAWAYSCPPVRLKRSGWWGPGLVGLSYESLPWFTGAAVLAVGAPSWEIVAVAVLYGLGAHGIMTLNDFKALEGDRQMGVNSLPVTLGPELAAKVACWVMIVPQLVVIALLFQWDRPWYGFFIVISVILQFYAMSVLLRDPKAKAPWYNATGVSLYVTGMMITAFALRTL",
    "product": "1,4-dihydroxy-2-naphthoate octaprenyltransferase"
   },
   {
    "start": 12785,
    "end": 14089,
    "strand": 1,
    "locus_tag": "KKHPANEM_02030",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02030</span></strong><br>\n \n  Protein PucC<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02030</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pucC_2</span><br>\n \n Location: 12,785 - 14,089,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02030 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03209.17 (PUCC protein): [30:420](score: 379.8, e-value: 1.6e-113)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02030\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=2785&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02030\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02030\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCGTTCAACCGCTTTCATGGCTCTCCATCTTCCGGCTCGGGCTGGTGCAGCTGTGCCTCGGTGCGATCGTGGTGCTGATGACCTCGACCCTCAACCGGCTGATGGTGGTGGAGCTGATGCTGCCCGCCGTCCTGCCCGGTGCGCTGGTGGCGCTGCACTACGGCATCCAGATCACGCGGCCCAACTGGGGCTACCGCTCGGACACCTGCGGAAACCGCACGCGCTGGGTGATCGTGGGGATGGGGATGCTGGCCGCGGGCGCGCTGCTGGCGGCCTTTGCGATCCCGGTGATGGAGGCGACCTTCTGGCTGGGACTGTGCGTGTCGATCCTCGCCTATGCGCTGATCGGGATGGGGGTGGGGGCCTCGGGGACCTCTCTGCTGGCGCTGATGGCGACGGCCACGGCGGAACACCGCCGGCCGGCGGCGGCCTCGATCACCTGGCTGATGATGATCTTCGGCATCGCCGTCACCGCGATCACCGTGGGGCAGGTGCTGGACCCCTACAGCCACGACCGCATGCTCGCCATCGTCGCGGTGGTCACGGGGGGCGCTTTCGTGGTCACCTGCCTCGCCATCTGGGGGATCGAGCGGCGCGCCGGCGTCCAGGCCGCCCCCCTGGCCGAGCCCATGACCTTCCGTGCCGGCCTGCGCGAGATCTGGGCCGAGCGCGCGGCGCGCAACTTCACCTTCTTCGTGTTCCTGTCGATGACCGCCTATTTCATGCAGGAACTGATCATGGAGCCCTTCGCGGGCCTCGTCTTCGACATGACGCCGGGTCAGACGACGTCCATGTCGGGCGCGCAGAACGGCGGCGTGTTCGTCGGCATGGTGCTGGTGGGGGTGTGCGCCACGGGGCTGCGCTTCGGTGCGCTGCGCTCCTGGGTCGTCGCGGGGTGCCTCGGCTCGGCCGCGACGCTGGCGGCGATCACGCTGATCGCCAGCGCGGGGCTGAAGCCGCTGCTGGTGCCGTCGGTCATCACGCTGGGCTTCTTCAACGGCATGTTCGCGGTCGCCGCCATCGGTGCCATGATGCAGCTCGCCGGTCAGGGCCGCGAGCGCCGCGAGGGCACCCGCATGGGGCTGTGGGGCGCCGCGCAGGCCATCGCCGCGGGCTTTGGCGGGCTGGTGGGCGCGGGGCTGGCCGATGCCATGCGCACCACGCTGGGCAACGACGCCAGCGCCTTCGGCGCCGTCTTTTCGATCGAGGCCGGTCTCTTCCTCCTCAGCGCGCTGGTTGCGCTGCGGGTGATGGGGGGACGCGGCCAAACCGCCCGCATGGGCCTTGTTGCTGGGGAGTGA",
    "translation": "MPVQPLSWLSIFRLGLVQLCLGAIVVLMTSTLNRLMVVELMLPAVLPGALVALHYGIQITRPNWGYRSDTCGNRTRWVIVGMGMLAAGALLAAFAIPVMEATFWLGLCVSILAYALIGMGVGASGTSLLALMATATAEHRRPAAASITWLMMIFGIAVTAITVGQVLDPYSHDRMLAIVAVVTGGAFVVTCLAIWGIERRAGVQAAPLAEPMTFRAGLREIWAERAARNFTFFVFLSMTAYFMQELIMEPFAGLVFDMTPGQTTSMSGAQNGGVFVGMVLVGVCATGLRFGALRSWVVAGCLGSAATLAAITLIASAGLKPLLVPSVITLGFFNGMFAVAAIGAMMQLAGQGRERREGTRMGLWGAAQAIAAGFGGLVGAGLADAMRTTLGNDASAFGAVFSIEAGLFLLSALVALRVMGGRGQTARMGLVAGE",
    "product": "Protein PucC"
   },
   {
    "start": 14094,
    "end": 15287,
    "strand": 1,
    "locus_tag": "KKHPANEM_02031",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02031</span></strong><br>\n \n  Menaquinone reductase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02031</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">menJ_1</span><br>\n \n Location: 14,094 - 15,287,\n (total: 1194 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1161:oxidoreductase (Score: 73.9; E-value: 2.1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02031 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07992.16 (Pyridine nucleotide-disulphide oxidoreductase): [2:152](score: 36.0, e-value: 4.8e-09)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02031 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02023 (BchP-ChlP: geranylgeranyl reductase): [2:388](score: 533.9, e-value: 5.1e-161)<br>\n \n  TIGR02032 (GG-red-SF: geranylgeranyl reductase family): [2:300](score: 254.2, e-value: 5e-76)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02031 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07992.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02031\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=4094&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/menJ_1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02031\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02031\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCTATGATGTCGTCGTCGTCGGAGGGGGACCCTGCGGGGCCACCGCGGCCGAGGATCTGGCCCGCGCCGGCAAGCGCGTGGCCCTGATCGACCGCGCGGGCCGGATCAAGCCCTGCGGCGGGGCCATCCCGCCCCGGCTGATCGCGGATTTCGACATCCCCGACGAGATGATCGTGGCGAAGATCAACACCGCCCGCATGATCTCGCCCACCGGCCGCAAGGTCGACATCCCCATCGAGGGCGGCTTCGTCGGCATGGTCGACCGCGAGCACTTCGACGAATTCCTGCGCGTGCGCGCAGCCAAGGCGGGCGCCGAGCGTCACACCGGCACCTTCGTGCGCATCGACCGGGATGAGAGCGGCGCCCGCGTCATCTACCGCGACAAGGCCACCAAGGAAGAGCGCGCGCTGCCCACCCGGCTCGTGATCGGCGCGGACGGCGCACGCTCCGGCGTGGGCCGGCAGGAGGTGCCGGGCGGCGACACCATCCCCTATGTCATCGCCTATCACGAGATCATCACCCCGCCCGAGGGCGGCGCACAGGCCGCCGCCGACTATGATCCCATGCGCTGCGACGTGATCTATGACGGCGCGATCTCGCCCGACTTCTATGGCTGGGTGTTCCCGCACGGGAAATCCTGTTCCGTCGGCATGGGGACGGGCATGGACGGGGTGGACCTGAAGGCCTGCACGGCGGCGTTGCGCGCGAATTCCGGCCTTGCAGGCTGCGAGACGATCCGGCGTGAAGGCGCGCCGATCCCGCTCAAGCCGCTGGACCGCTGGGACAATGGCCGTGACGTGGTGCTGGCGGGCGATGCCGCCGGTGTGGTGGCGCCCAGCTCGGGTGAGGGGATCTACTATGCCATGGCCTGCGGGCGCGCGGCGGCCACCGCGGTGCAGGCCTGCCTGGCGTCGGGCCGTGCCAAGGACCTGCAGATGGCGCGCAAGATGTTCCTCAAGGAGCACGGCGGCGTCTTCAAGATCCTCGGCGCGATGCAGAACGCCTATTACCGCTCGGACGAGCGGCGCGAACGCTTCGTCTCGCTGTGCCACGACATCGACGTGCAGAAGCTGACGTTCGAGGCCTACATGAACAAGAAGCTGGTGAACGCGCGGCCCTTTGCCCACATGAAGATCGGGGTGAAGAACCTGCTGCACCTGTCGGGCCTCGTGCGGCCCACCTACGCATGA",
    "translation": "MTYDVVVVGGGPCGATAAEDLARAGKRVALIDRAGRIKPCGGAIPPRLIADFDIPDEMIVAKINTARMISPTGRKVDIPIEGGFVGMVDREHFDEFLRVRAAKAGAERHTGTFVRIDRDESGARVIYRDKATKEERALPTRLVIGADGARSGVGRQEVPGGDTIPYVIAYHEIITPPEGGAQAAADYDPMRCDVIYDGAISPDFYGWVFPHGKSCSVGMGTGMDGVDLKACTAALRANSGLAGCETIRREGAPIPLKPLDRWDNGRDVVLAGDAAGVVAPSSGEGIYYAMACGRAAATAVQACLASGRAKDLQMARKMFLKEHGGVFKILGAMQNAYYRSDERRERFVSLCHDIDVQKLTFEAYMNKKLVNARPFAHMKIGVKNLLHLSGLVRPTYA",
    "product": "Menaquinone reductase"
   },
   {
    "start": 15296,
    "end": 15826,
    "strand": 1,
    "locus_tag": "KKHPANEM_02032",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02032</span></strong><br>\n \n  Isopentenyl-diphosphate Delta-isomerase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02032</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">idi</span><br>\n \n Location: 15,296 - 15,826,\n (total: 531 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02032 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00293.30 (NUDIX domain): [26:158](score: 77.6, e-value: 8.8e-22)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02032 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02150 (IPP_isom_1: isopentenyl-diphosphate delta-isomerase): [16:161](score: 120.8, e-value: 1.1e-35)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02032\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=5296&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/idi_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02032\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02032\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGAGATGATCCCGGCCTGGGTGAACGGCCGCCTGACCCCGGTGGAGAAGCTGGAGGCGCATCTGCAAGGGCTGCGCCACAAGGCGATCTCGGTCTTCGTCATGGACGGGGACCGGGTGCTGATCCAGCAGCGCGCGATGGGCAAGTACCACACGCCGGGGATGTGGGCGAACACCTGCTGCACCCATCCCCACTGGGACGAGGGGGCCGAGGCCTGCGCCACCCGCCGCCTGCGCGAGGAGCTGGGGATCGAGGGGCTGACCCTCGGCCACCGCGACCGCGTCGAATACCGCGCCGAGGTCGGCAACGGCCTGATCGAGCATGAGGTGGTGGACATCTTCACCGCCGCCGCCGGCCCGACGCTGCACATCGCCCCGAACCCCGACGAGGTGATGGCGGTGCGCTGGGTCCCGCTCGATACGCTGCGCGCCGAGGTCGCGCGGGAACCCGCGCGCTTCACCCCGTGGCTGCGCATCTATCTGGCAGAGCATGCCGCCGCGATCTTCGGAGCGATGGCGCGCGCGTGA",
    "translation": "MTEMIPAWVNGRLTPVEKLEAHLQGLRHKAISVFVMDGDRVLIQQRAMGKYHTPGMWANTCCTHPHWDEGAEACATRRLREELGIEGLTLGHRDRVEYRAEVGNGLIEHEVVDIFTAAAGPTLHIAPNPDEVMAVRWVPLDTLRAEVAREPARFTPWLRIYLAEHAAAIFGAMARA",
    "product": "Isopentenyl-diphosphate Delta-isomerase"
   },
   {
    "start": 15839,
    "end": 16312,
    "strand": -1,
    "locus_tag": "KKHPANEM_02033",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02033</span></strong><br>\n \n  Tryptophan-rich sensory protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02033</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">tspO_2</span><br>\n \n Location: 15,839 - 16,312,\n (total: 474 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02033 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03073.17 (TspO/MBR family): [9:145](score: 140.3, e-value: 3.9e-41)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02033 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03073.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02033\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=5839&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02033\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02033\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACTGGCTCTTGTTCTCCGTCTTTCTGTTCGCCTGCGCGGCCGCGGGCACCACTGGCGCGATGTTCGAGCCGGGAAAGTGGTATCGTGACCTCACCAAGCCGAGCTGGACGCCTCCGAACTGGCTGTTCCCGGTGGCGTGGTCGCTTCTGTACATCGCGATGTCACTGGCGGCGATGCGGGTGGCGCTGGCGGGTGACAGCGCCCTGGCGCTGGCGTTGTGGTCCACGCAGATCGCCTTCAACACGCTGTGGACACCGGTGTTCTTCGGTCTGAAACGGATGCGGGCGGCGATGGGCGTGATGGTCGCGCTGTGGGCATCGGTCGCGGCGACCATGGTGGCGTTCTGGCAGGTCGACCTGATCGCGGGGCTGTTGTTCGTGCCCTATCTTGCCTGGGTCACGGTGGCGGGTGCGCTGAACTTCAGCGTCTGGCGCCTCAACCCCGAGACAGGCACCCCGGCGGGGGCCTGA",
    "translation": "MDWLLFSVFLFACAAAGTTGAMFEPGKWYRDLTKPSWTPPNWLFPVAWSLLYIAMSLAAMRVALAGDSALALALWSTQIAFNTLWTPVFFGLKRMRAAMGVMVALWASVAATMVAFWQVDLIAGLLFVPYLAWVTVAGALNFSVWRLNPETGTPAGA",
    "product": "Tryptophan-rich sensory protein"
   },
   {
    "start": 16312,
    "end": 17421,
    "strand": -1,
    "locus_tag": "KKHPANEM_02034",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02034</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02034</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,312 - 17,421,\n (total: 1110 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02034 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.21 (Squalene/phytoene synthase): [32:279](score: 213.8, e-value: 3.2e-63)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02034 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02034\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=6312&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/KKHPANEM_02034_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02034\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02034\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCACCGTCGCCACCGACGCCCCCCGCGCGGCCCCGGCCGTGCGCCGCACGGCCCTGTTGGCCGAGGACCTGGACCATTGCGAGGCCGCGATCCGCACCGGGTCGCGGTCCTTCTTCACCGCCTCCAAGCTGTTGCCGGGGCGGGTGCGGCGTCCGGCGCTGGCGCTTTATGCCTTCTGCCGGCTGTCGGACGATGCGGTCGACCTGACGCGCGAGAAGCCCGCCGCGATCCTGGCGCTGCGTGACCGGCTGGACCTGGTGTATCGCGGCACGCCGCGCAATGCCCCTGCCGACCGGGCCTTCGCCGCCATCGTGGAGGAGTTCGAGATGCCGCGCGCCCTGCCGGAGGCCCTGCTGGAGGGGCTGGCGTGGGACGCGCAGGGGCGGCGCTACCGCACCATCGACGATCTGCACAGCTACTCCGCGCGGGTGGCGGCGGCGGTGGGGGCGATGATGTGCGTGCTGATGCGGGTGCGCGATGCCGATGCGCTGGCGCGGGCCTGCGATCTGGGGCTGGCGATGCAGCTGACCAACATCGCCCGCGACGTCGGCGAGGATGCGCGCGAGGGGCGGCTGTTCCTGCCCACCGACTGGATGGAGGGGGCGGGCATCGACACGCAGGCGTTCCTGGCCGATCCGCAGCCCACCGCCCCGGTATGCCGGGTGGTTCGGCGCCTTCTGGCCGAGGCCGACCGGCTGTATTTCCGCTCCGAGGCCGGGATCGCGGCGCTGCCGCTGTCGGTGCGCCCGGGAATTGCGGCGGCGCGTCACATCTATGCCGCCATCGGCACGCGGATCGCCTGTGCGGGCCACGACAGCATCACCCAGCGCGCCTATACCGGGCCGGGGGCCAAGCTGTGGGGGCTGGCCACGGCGGGGGTGCATGTCGCCGTCACCCTGGCGCTGCCGCGCCCGGTGGAGCTGCACGCCCTGCCCGAGCCGTCGGTGGCGTTTCTGGTGAATGCCGCGGCCCACGCACCGCCGGCGCGCGAAACCTGGGCACAGGGACGTTCGGCTGCGCTTTTGTCGGTGCTCTCGGACCTGGAATCGCGCGATCGCGCACGGCGGGGCTTGATGGGACGGGCGACAGAGCCTAACTGCGAGTGA",
    "translation": "MSTVATDAPRAAPAVRRTALLAEDLDHCEAAIRTGSRSFFTASKLLPGRVRRPALALYAFCRLSDDAVDLTREKPAAILALRDRLDLVYRGTPRNAPADRAFAAIVEEFEMPRALPEALLEGLAWDAQGRRYRTIDDLHSYSARVAAAVGAMMCVLMRVRDADALARACDLGLAMQLTNIARDVGEDAREGRLFLPTDWMEGAGIDTQAFLADPQPTAPVCRVVRRLLAEADRLYFRSEAGIAALPLSVRPGIAAARHIYAAIGTRIACAGHDSITQRAYTGPGAKLWGLATAGVHVAVTLALPRPVELHALPEPSVAFLVNAAAHAPPARETWAQGRSAALLSVLSDLESRDRARRGLMGRATEPNCE",
    "product": "hypothetical protein"
   },
   {
    "start": 17418,
    "end": 18971,
    "strand": -1,
    "locus_tag": "KKHPANEM_02035",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02035</span></strong><br>\n \n  Phytoene desaturase (neurosporene-forming)<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02035</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtI_2</span><br>\n \n Location: 17,418 - 18,971,\n (total: 1554 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 410.1; E-value: 2.6e-124)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02035 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.26 (Flavin containing amine oxidoreductase): [27:501](score: 110.8, e-value: 1e-31)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02035 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02734 (crtI_fam: phytoene desaturase): [20:511](score: 640.4, e-value: 4.8e-193)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02035 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02035\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=7418&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/crtI_2_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02035\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02035\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTCAACCGCATGCAGGACGACGTGGCCGTGGCCGCGGATGGGGCGCGACGGCCGCGGGCGCTGGTGATCGGCGCGGGTCTGGGTGGGCTGGCGGCGGCGATGCGGCTGGGGGCCAAGGGCTACCGGGTGACGGTGATCGACCGGCTGGACCGGGCGGGCGGGCGCGGGTCGTCGATCACGCAGGACGGGCACCGCTTCGATCTGGGCCCGACCATCGTCACCGTGCCGCAGTTGTTTCGCGAATTGTGGGCGGCGTGCGGGCGCGATTTCGATGCGGACGTGGATTTGCGCGCGCTCGATCCGTTCTATCAGATCCGCTGGCCCGACGGCTCGCACTTCACCGTGCGCCAGTCGACCGAGGCGATGCGGGCCGAGGTGGCGCGGCTGTCGCCCGATGACCTGCCCGGCTACGACAAGTTCCTCAAGGACGCCGAGGCGCGGTATTCCTTCGGCTTCGAGGATCTGGGCCGCCGGTCGATGCACAAGTTCATCGACCTGGTGAAGGTGCTGCCGAAGTTCGCCATGCTGCGCGCCGACCGGTCGGTGGCGGCGCACGCAGCAGCCCGGGTGCGCGACCCGCGCCTGCGCATGGCGCTGTCGTTCCACCCGCTGTTCATCGGCGGCGACCCGTTCCACGTCACCTCCATGTACATCCTCGTCAGCCACCTGGAGAAGGAATACGGCGTGCATTACGCGGTGGGCGGCGTGCAGGCCATCGCCGACGCCATGGTCCGCGTGATCGAGGACCAAGGCGGCACCCTTCGGCTGGACGAGGAGGTCGACGAGGTGCTGGTGAAATCGGGCCGGGTCGCCGGTCTGCGCACCACCCAGGGCGAGGTGATGACCGCCGACATCGTGGTGTCCAACGCGGACGCCGGCCACACCTATACCCGGCTTCTGCGCAACCACCGCCGCCGGCGCTGGACGGATGCCAAGCTGAAGCGGCGCACATGGTCGTCGGGGCTGTTCGTTTGGTACTTCGGGACCAAGGGGACGAAGGACATGTGGCCGGATCTGGGCCACCACACCATCCTCAACGGTCCCCGGTACGAAGGGTTGCTGCGCGACATCTTCCTCAACGGCAAGCTGTCGGAGGACATGAGCCTCTATATCCACCGCCCCTCGGTCACCGATCCGGGCGTGGCGCCTGCGGGCGACGACACCTTCTATGTGCTGTCGGTGGTGCCGCATCTGGGCTTCGACAACCCGGTGGACTGGAAGGCGGAGGGGGAGCGGTACCGCGCCGCCATGACCAGGGTGCTGGAGGAGCAGGTGATGCCGGGCTTTGCCGAGCGTGTGGGCCCGTCGCTGGTGTTCACGCCCGAGGATTTCCGCGACCGCTACCTGTCGCCCCACGGCGCGGGGTTCTCGATCGAGCCGCGGATCCTGCAATCGGCCTATTTCCGGCCGCACAACGTGTCCGAGGAGCTGCCGGGGCTGTATCTGGTGGGCGCGGGCACGCATCCCGGCGCGGGCCTGCCGGGGGTGGTGTCCTCGGCCGAGGTGCTGGGCAAGCTCGTTCCCGACGCGCAGCCGCAGGGGGTCGCATGA",
    "translation": "MLNRMQDDVAVAADGARRPRALVIGAGLGGLAAAMRLGAKGYRVTVIDRLDRAGGRGSSITQDGHRFDLGPTIVTVPQLFRELWAACGRDFDADVDLRALDPFYQIRWPDGSHFTVRQSTEAMRAEVARLSPDDLPGYDKFLKDAEARYSFGFEDLGRRSMHKFIDLVKVLPKFAMLRADRSVAAHAAARVRDPRLRMALSFHPLFIGGDPFHVTSMYILVSHLEKEYGVHYAVGGVQAIADAMVRVIEDQGGTLRLDEEVDEVLVKSGRVAGLRTTQGEVMTADIVVSNADAGHTYTRLLRNHRRRRWTDAKLKRRTWSSGLFVWYFGTKGTKDMWPDLGHHTILNGPRYEGLLRDIFLNGKLSEDMSLYIHRPSVTDPGVAPAGDDTFYVLSVVPHLGFDNPVDWKAEGERYRAAMTRVLEEQVMPGFAERVGPSLVFTPEDFRDRYLSPHGAGFSIEPRILQSAYFRPHNVSEELPGLYLVGAGTHPGAGLPGVVSSAEVLGKLVPDAQPQGVA",
    "product": "Phytoene desaturase (neurosporene-forming)"
   },
   {
    "start": 19098,
    "end": 19808,
    "strand": 1,
    "locus_tag": "KKHPANEM_02036",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02036</span></strong><br>\n \n  Spheroidene monooxygenase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02036</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">crtA</span><br>\n \n Location: 19,098 - 19,808,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02036\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=9098&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02036\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02036\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGACCGTCACCCTCTCGCTGTTTCGCTTTCCCACCCTGTCCGCGCGGCTCTGGGCGTTCGGCCAGATGGCGCTGGCGCGCTGGGACCTCAAGCGCACCCCCGATCTGTTGCAGTGGAAGCTGTGCGGCTCGGGCACGGGCGAGGGGTTCACCCCGGTGCCCAACACCGCCGTCTATGCGATCCTCGCGACCTGGCCCTCCGAGGAGATCGCCCGGGAGCGCATCGCCAAATCGAAGGTCTGGGCCCGCTGGCGTGCGCATGCCGCCGAGGACTGGACGATCTTCCTCGCGGCGACATCGGTGCGGGGCAAATGGGCCGGGGTGGAGCCGTTCCACGCCGTGGCCGAGCCGACCGACGGCCCGCTGGCGGCGCTGACGCGTGCGACGGTGAAGCCCAAGGTCGCGCTGAAGTTCTGGGGTTCGGTCCCCGACATCTCCCGGATGATCGGCATGGACGAACATGTCGCCTTCAAGATCGGCATCGGCGAGGTGCCGCTGCTGCACCAGGTGACCTTCTCGATCTGGCCCGACACCAGGACGATGGCCGAGTTCGCCCGCCACGACGGCCCCCACGCCCGCGCCATCAAGGCCGTGCGCGACGGGCAATGGTTCAACGAAGAGTGCTATGCCCGCTTCCGCATCCTGGGCGAGTGTGGCAGTTGGGACGGAACAAGCCCGCTGAAACCGCTCGAGAGGTCCGCCGCATGA",
    "translation": "METVTLSLFRFPTLSARLWAFGQMALARWDLKRTPDLLQWKLCGSGTGEGFTPVPNTAVYAILATWPSEEIARERIAKSKVWARWRAHAAEDWTIFLAATSVRGKWAGVEPFHAVAEPTDGPLAALTRATVKPKVALKFWGSVPDISRMIGMDEHVAFKIGIGEVPLLHQVTFSIWPDTRTMAEFARHDGPHARAIKAVRDGQWFNEECYARFRILGECGSWDGTSPLKPLERSAA",
    "product": "Spheroidene monooxygenase"
   },
   {
    "start": 19805,
    "end": 20809,
    "strand": 1,
    "locus_tag": "KKHPANEM_02037",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02037</span></strong><br>\n \n  Magnesium-chelatase 38 kDa subunit<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02037</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">bchI</span><br>\n \n Location: 19,805 - 20,809,\n (total: 1005 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02037 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01078.23 (Magnesium chelatase, subunit ChlI): [6:180](score: 52.9, e-value: 3.2e-14)<br>\n \n  PF17863.3 (AAA lid domain): [260:320](score: 66.4, e-value: 1.6e-18)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02037 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR02030 (BchI-ChlI: magnesium chelatase ATPase subunit I): [4:333](score: 548.5, e-value: 1.2e-165)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02037 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01078.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02037\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000273.1&amp;from=9805&amp;to=21589\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02037\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02037\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGCTCCGTTCCCGTTCTCCGCGATCGTCGGCCAGGAGGAGATGAAGCTCGCCATGGTCCTGACCGCCATCGACCCCGGCATCGGGGGCGTTCTGGTGTTCGGGGACCGCGGAACGGGGAAATCGACGGCGGTGCGGGCGCTTGCGGCACTGCTGCCGCCCATCCGGCAGGTCGAGAGCTGCCCCGTGAACTCCGCCCGGCTGGAGGACTGCCCCGAGTGGGCGCGGCTGACCTCACGGGAGATCGTCACCCGCCCCACGCCGGTGGTCGACCTGCCGCTGGGCGCGACCGAGGACCGGGTGGTCGGCGCGCTCGACATCGAACGCGCGCTCAGCCAGGGCGAAAAGGCGTTCGAGCCGGGCCTGCTGGCGCGCGCCAACCGCGGGTATCTCTACATCGACGAGGTCAACCTGCTGGAGGACCACATCGTCGACCTGCTGCTGGACGTCGCCCAATCCGGCCAGAACGTGGTGGAGCGCGAGGGCCTCTCGATCCGCCACCCCGCGCGCTTCGTCCTCGTCGGCTCCGGCAACCCCGAGGAAGGCGAGCTGCGTCCGCAGCTTCTCGATCGCTTCGGGCTGTCGGTGGAGGTTGGCTCTCCCAAGGACATCCCCACCCGGATCGAGGTCATCCGCCGCCGCGACGCCTATGAAAACGACCACGCCGCCTTCATGGCCAAATGGCAGGAGGAGGACACCACCCTGCGCGAGCGGATCCTGGCCGCGCGCACCCGGCTGTCGGCCATCGCCACCCCCGAGGCCGCGTTGCACGACTGCGCGGAGCTGTGCGTGGCGCTCGGCTCGGACGGGCTGCGCGGAGAGCTGACGCTGCTGCGCACCGGGCGCGCCTTCGCGGCCTATCACGGCGCCGACACGCTGACCCGCGACCACCTGCGCGAGGTCGCGCCGATGTCGCTGCGCCACCGCCTGCGCCGCGATCCGCTGGACGAGGCCGGGTCGGGCGCCCGCGTCGGCCGCGTGATCGAAGAGGTCTTCGGGTGA",
    "translation": "MKAPFPFSAIVGQEEMKLAMVLTAIDPGIGGVLVFGDRGTGKSTAVRALAALLPPIRQVESCPVNSARLEDCPEWARLTSREIVTRPTPVVDLPLGATEDRVVGALDIERALSQGEKAFEPGLLARANRGYLYIDEVNLLEDHIVDLLLDVAQSGQNVVEREGLSIRHPARFVLVGSGNPEEGELRPQLLDRFGLSVEVGSPKDIPTRIEVIRRRDAYENDHAAFMAKWQEEDTTLRERILAARTRLSAIATPEAALHDCAELCVALGSDGLRGELTLLRTGRAFAAYHGADTLTRDHLREVAPMSLRHRLRRDPLDEAGSGARVGRVIEEVFG",
    "product": "Magnesium-chelatase 38 kDa subunit"
   }
  ],
  "clusters": [
   {
    "start": 16311,
    "end": 17421,
    "tool": "rule-based-clusters",
    "neighbouring_start": 6311,
    "neighbouring_end": 21589,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 11896,
     "end": 11898,
     "strand": 1,
     "containedBy": [
      "KKHPANEM_02029"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r273c1"
 },
 "r292c1": {
  "start": 11262,
  "end": 36052,
  "idx": 1,
  "orfs": [
   {
    "start": 14088,
    "end": 15638,
    "strand": 1,
    "locus_tag": "KKHPANEM_02420",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02420</span></strong><br>\n \n  Dihydrolipoyllysine-residue succinyltransferase component of 2-oxoglutarate dehydrogenase complex<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02420</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">sucB</span><br>\n \n Location: 14,088 - 15,638,\n (total: 1551 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02420 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00364.24 (Biotin-requiring enzyme): [3:76](score: 78.9, e-value: 2e-22)<br>\n \n  PF00364.24 (Biotin-requiring enzyme): [104:177](score: 74.6, e-value: 4.4e-21)<br>\n \n  PF02817.19 (e3 binding domain): [216:247](score: 37.3, e-value: 2.7e-09)<br>\n \n  PF00198.25 (2-oxoacid dehydrogenases acyltransferase (catalytic domain)): [285:514](score: 270.0, e-value: 1.6e-80)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02420 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01347 (sucB: dihydrolipoyllysine-residue succinyltransferase, E2 component of oxoglutarate dehydrogenase (succiny): [103:515](score: 558.3, e-value: 2.7e-168)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02420 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00198.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity<br>\n  \n   PF02817.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02420\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=4088&amp;to=25638\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/sucB_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02420\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02420\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCATCGAAGTCCGCGTGCCCACGTTGGGCGAATCCGTCACCGAGGCCACGGTGGCGACGTGGTTCAAGAAGCCCGGCGAGACGGTCGCCGCCGACGAAATGCTGTGCGAGCTGGAGACCGACAAGGTCACGGTGGAGGTGCCCAGCCCCGCCGCCGGCACGCTGGGCGAGATCGTCGCGGCCGAGGGCGACACGGTGGGGGTGGATGCGCTGCTGGCAACCCTGACCGAGAGCGACGGCAAACCCGCACCGGCCCGCGGCGGCGCGCCCAAGGCCGCCGCACCCGCGGCTCCGGCGGGTGACACCGTGGACGTCATGGTCCCCGCGCTGGGCGAAAGCGTCAGCGAGGCGACAGTCGCCACCTGGTTCAAGGCGGTGGGCGACAGCGTCGCCGCCGACGAGATCCTGTGCGAACTGGAGACCGACAAGGTCAGCGTCGAGGTCCCGAGCCCCACCGCCGGCACGCTGTCGCAGATCGTCGCCGAGGCCGGGACCACGGTGGCCGCGGGTGGCAAGCTTGCGGTCCTGGCGGCCGGTGAGGGCGGCGCCGCGGCCACGGGGACCGGCGCGGCCGCAGCCCCTGCCCCGCCCACCGCCGCTGCGGCCGAGCGCAGCGGCGCGGGCCGCGCGGATGTGGAAGACGCCCCTTCGGCGAAGAAGATGATGGCCGAGAAGGGGCTGACGCGCGATCAGGTCGAAGGCACCGGCCGTGACGGGCGGATCATGAAGGAGGACGTGGCGCGCGCCGCGGCGGACGCGGCCCCGGCGGCGCAGGCTGCGCCTGCCCCGACCATGCCCGCCCCCGCAGCCCAACAGGCACCGCGCGCCGCCGTCCCGGCCGACGATGCCGCCCGCGAAGAGCGGGTGAAGATGAGCCGCCTGCGCCAGACCATCGCGCGCAGGCTCAAGGATGCGCAGAACACCGCGGCCATGCTGACCACCTATAACGAGGTGGACATGGGCCCGATCATGGATCTGCGCAACGAATACAAGGGGTTGTTCGAAAAGAAGCACGGCGTGAAGCTTGGCTTCATGTCCTTCTTCGTCAAGGCCTGCTGCCACGCCCTGCACGAGGTGCCCGAGGTCAACGCCGAGATCGACGGCACCGATGTGGTCTACAAGAACTATGTCCACATGGGCGTGGCGGTGGGCACGCCGTCAGGGCTGGTGGTGCCGGTGCTGCGCGATGCGCAGGCCATGGGCTTTGCCGAGATCGAAAAGACCATCGCGTCCCTGGGCGCACGCGCGCGCGACGGCAAGCTGTCGATGGCCGACATGCAGGGCGGATCGTTCACCATCTCCAACGGCGGGGTGTATGGCTCGCTGATGTCGTCGCCGATCCTGAACCCGCCGCAGTCGGGGATCCTGGGGATGCACAAGATCCAGGATCGTCCGATGGTGGTGAAGGGTCAGATCGTGGCGCGCCCCATGATGTACCTCGCGCTGAGCTATGACCACCGGATCGTGGACGGCAAGGGCGCGGTGACGTTCCTTGTCCGCGTCAAGGAGGCGCTGGAGGACCCGCGGCGCCTGTTGATGGACCTCTGA",
    "translation": "MSIEVRVPTLGESVTEATVATWFKKPGETVAADEMLCELETDKVTVEVPSPAAGTLGEIVAAEGDTVGVDALLATLTESDGKPAPARGGAPKAAAPAAPAGDTVDVMVPALGESVSEATVATWFKAVGDSVAADEILCELETDKVSVEVPSPTAGTLSQIVAEAGTTVAAGGKLAVLAAGEGGAAATGTGAAAAPAPPTAAAAERSGAGRADVEDAPSAKKMMAEKGLTRDQVEGTGRDGRIMKEDVARAAADAAPAAQAAPAPTMPAPAAQQAPRAAVPADDAAREERVKMSRLRQTIARRLKDAQNTAAMLTTYNEVDMGPIMDLRNEYKGLFEKKHGVKLGFMSFFVKACCHALHEVPEVNAEIDGTDVVYKNYVHMGVAVGTPSGLVVPVLRDAQAMGFAEIEKTIASLGARARDGKLSMADMQGGSFTISNGGVYGSLMSSPILNPPQSGILGMHKIQDRPMVVKGQIVARPMMYLALSYDHRIVDGKGAVTFLVRVKEALEDPRRLLMDL",
    "product": "Dihydrolipoyllysine-residue succinyltransferase component of 2-oxoglutarate dehydrogenase complex"
   },
   {
    "start": 15638,
    "end": 15925,
    "strand": 1,
    "locus_tag": "KKHPANEM_02421",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02421</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02421</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,638 - 15,925,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02421\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=5638&amp;to=25925\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02421\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02421\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTGGGGATCCTGTTTCTGGTCGCGGTGGCGCTGGTGGCGCTGGTGGTGGTGCAAAGCGTGCGCCAGGGCCGGCGCTTCATCCGCGCCGCGCTGTTCCTGCACGAGCTGGAGGGCGGGCGCCCGAAGGACTCCGCCAACGCCGCAGCCAACCTGTTGTTCAGCCCGGAAAGCTCGGCCTCGGCCGATGCGCATGCCGCCCAGATCGCGGACGCGCGGCGCAAGCGCACCTCCGAGACGCAGGCGCAGGTGATCGGCGCCGCGCGCGACCGCGGGTTCGAGGGGTGA",
    "translation": "MLGILFLVAVALVALVVVQSVRQGRRFIRAALFLHELEGGRPKDSANAAANLLFSPESSASADAHAAQIADARRKRTSETQAQVIGAARDRGFEG",
    "product": "hypothetical protein"
   },
   {
    "start": 15930,
    "end": 16337,
    "strand": 1,
    "locus_tag": "KKHPANEM_02422",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02422</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02422</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,930 - 16,337,\n (total: 408 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02422 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01124.20 (MAPEG family): [10:134](score: 81.2, e-value: 6.1e-23)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02422 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01124.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02422\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=5930&amp;to=26337\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02422\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02422\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAGGGATCATGACGACGGAGCTGACGGTTCTGGTGCTGGCCGCCCTTCTGGCGGTGGTTCAGCTGGGCTGGAACGCGGTGCGCGCCAACCTGGAGATGGGGCCGGACTGGTTCCTCACGCCACGCGACAGCGCCCCGCCGCAGCCGCTGCCGGTTGCGCTGGGTCGGCTCAAGCGCGCCTATGAGAACCACATGGAGACGCTGCCGCTGTTTGCCATCGCGGCCATCGTGGTGACGCTGGCGGGCGCCTCGTCCGGCCTGACGGCGGCCTGCGCGTGGATCTACCTGGCCGCTCGGGTGCTGTTCGTGCCGGCCTACCGCTTCGGCTGGATGCCGTGGCGCTCGTTCATCTGGGCGGCGGGCTTCGTCGCCACCGTTCTGATGCTGCTGGCCGCGCTGATCTGA",
    "translation": "MTGIMTTELTVLVLAALLAVVQLGWNAVRANLEMGPDWFLTPRDSAPPQPLPVALGRLKRAYENHMETLPLFAIAAIVVTLAGASSGLTAACAWIYLAARVLFVPAYRFGWMPWRSFIWAAGFVATVLMLLAALI",
    "product": "hypothetical protein"
   },
   {
    "start": 16366,
    "end": 17754,
    "strand": 1,
    "locus_tag": "KKHPANEM_02423",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02423</span></strong><br>\n \n  Dihydrolipoyl dehydrogenase 3<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02423</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">lpd3</span><br>\n \n Location: 16,366 - 17,754,\n (total: 1389 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1175:pyridine nucleotide-disulfide oxidoreductase (Score: 476.3; E-value: 1.3e-144)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02423 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07992.16 (Pyridine nucleotide-disulphide oxidoreductase): [3:324](score: 216.4, e-value: 5.4e-64)<br>\n \n  PF02852.24 (Pyridine nucleotide-disulphide oxidoreductase, dimerisation domain): [342:452](score: 136.2, e-value: 5.4e-40)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02423 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01350 (lipoamide_DH: dihydrolipoyl dehydrogenase): [2:461](score: 553.7, e-value: 6.9e-167)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02423 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07992.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02423\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=6366&amp;to=27754\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/lpd3_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02423\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02423\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAAGCTATGACGTGATCTTCATCGGCTCCGGCCCCGGCGGCTATGTCGGCGCCATCCGCGCAGCCCAGCTGGGCCTGCGCACCGCCTGCGTGGAGGGGCGCGAGACGCTGGGCGGCACCTGCCTGAACGTGGGCTGCATCCCCTCCAAGGCGCTGCTGCACGCCACCCACATGCTGCACGAGGCCGAGCACAACTTCGCCGAGATGGGCCTTGGCGGCGGCAAGCCCAAGGTCGACTGGGGCAAGATGCAGTCCTACAAGGACGACGTCATCGCCCAGAACACCAAGGGGATCGAGTTCCTGTTCAAGAAGAACAAGGTGGACTGGATCAAGGGCTGGGCCTCCATCCCCGCGCCGGGCAAGGTGAAGGTCGGCGACGACGTGCACGAGGCCCGGGCCATCGTGATCGCCTCGGGCTCCGAATCCGCCTCCCTTCCGGGGGTGGAGGTCGACGAGAAGGTCGTGGTCACCTCCACCGGCGCGCTGGAGCTGGGCCGCATCCCCAAGCGGCTGGCGGTGATCGGCGGCGGCGTGATCGGGCTGGAGATGGGCTCGGTCTATGCCCGCCTGGGGGCGCAGGTGACGGTGCTGGAGTACCTCGACCGGCTGATCCCCGGCAACGACATGGAGGTCGCGCGGACCTTCCAGCGCATCCTGAAGAAGCAGGGGATGGAGTTCATCCTCGGCGCCGCCGTGCAGGGGGTGGAGGCCACCAGGACCAAGGCCAAGGTCAGCTACACCCTGAAGAAGGACGACAGCGCCCAGACGCTGGAGGCCGATGTGGTGCTGCTCGCCACCGGGCGTCGTCCCTTCACCGACGGGCTGGGGCTGGACACACTGGGCGTGACCCTGTCCAAGCGCAGACAGGTGGAGGTCGATGGCCGCTACGAGACCTCGGTCAAGGGCGTCTACGCCATCGGCGACGCCATCACCGGCCCGATGCTCGCGCACAAGGCCGAGGATGAGGGCTACGCCGTGGCCGAGATCCTCGCGGGCCAGGCGGGCCATGTGAACTACGCCACCATCCCCGGCGTGATCTACACCCACCCCGAGGTCGCGAGCGTGGGCGAGACCGAGGAGACGCTGAAGGAGGCCGGGCGCGCCTACAAGGTCGGCAAGTTCAGTTTCATGGGCAATGGCCGGGCCAAGGCCAACTTCGCCGCCGACGGCTTCGTCAAGATCCTGGCTGACAAGGACACCGACCGCATCCTGGGCGCCCACATCATCGGCCCGATGGCGGGCGACCTGATCCACGAGATCTGCGTCGCGATGGAGTTCGGCGCCGCGGCCGAGGATCTTGCCCGCACCTGCCATGCCCACCCCACCTACTCCGAAGCGGTGCGCGAGGCGGCGCTGGCCTGCGGCGACGGGGCGCTGCACGCCTGA",
    "translation": "MASYDVIFIGSGPGGYVGAIRAAQLGLRTACVEGRETLGGTCLNVGCIPSKALLHATHMLHEAEHNFAEMGLGGGKPKVDWGKMQSYKDDVIAQNTKGIEFLFKKNKVDWIKGWASIPAPGKVKVGDDVHEARAIVIASGSESASLPGVEVDEKVVVTSTGALELGRIPKRLAVIGGGVIGLEMGSVYARLGAQVTVLEYLDRLIPGNDMEVARTFQRILKKQGMEFILGAAVQGVEATRTKAKVSYTLKKDDSAQTLEADVVLLATGRRPFTDGLGLDTLGVTLSKRRQVEVDGRYETSVKGVYAIGDAITGPMLAHKAEDEGYAVAEILAGQAGHVNYATIPGVIYTHPEVASVGETEETLKEAGRAYKVGKFSFMGNGRAKANFAADGFVKILADKDTDRILGAHIIGPMAGDLIHEICVAMEFGAAAEDLARTCHAHPTYSEAVREAALACGDGALHA",
    "product": "Dihydrolipoyl dehydrogenase 3"
   },
   {
    "start": 17981,
    "end": 19657,
    "strand": -1,
    "locus_tag": "KKHPANEM_02424",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02424</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02424</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,981 - 19,657,\n (total: 1677 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02424 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02646.18 (RmuC family): [230:526](score: 323.0, e-value: 1.5e-96)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02424\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=7981&amp;to=29657\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02424\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02424\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGACGCCCCCTGGCAGGCTCCCACCCCCGAGGAACTGCGCGCCCTGGCCGATGCCACCCTGGCCGAGGCGGTCGCGCTGGCGGAGGGGCTGCGCGCGCTGGGGCCAGCGGTGCAGGTCGCGGCGGGGCTGCTGGCCGCGCTGGTGCTGGCCGTGGTCTGGGCGGTGCTGCGCGCGCGGACCCGGCGCGAGGCGCTGCTGCGCGCCGACCTGATGGCGCGGCTGGCCGATCTGGAGGCCACCACCCGCCGGGCCGAGGCCGCCGAGGCCAACGCCGCCGCGCGCGCCGATGACCTTGCGGCGCTCACGGCCCGGGCGGAGGGGCTGGAGGGCAGCTTGCGGGCTGCCACCGTGACCGAGCGGGACCTGACCGCGCGCGCCGCCGCCCTCGATGCCCGGCTCGAGAGTGCCGAGCGCCGCCTGGCCGAGCGGCGCACCGAGGCCGAGGCGCGCGAGTCCGCCATCGCCGGGCTGCGCGGTCGGCTGGAGGCCGAGCAGGCCGCGCAGCGCGCGTTGCAGGCCCGCATCGCCGGGCTGACCCAGGAGCTGGAGAGCGAACAGGCCCGTGGCGCCGAAAAGGTGGCGCTGCTGTCGTCGGTGCGCGAGGACATGCAGGCGCGTTTCCGCGACCTCGCCGATGCCGCGCTGAAGACCCAGGCGGAGGTGTTCTCCAACACCAGCTTTGCCCGGCTGGAGGCGACGCTGACGCCGCTGAAGGAACATGTCGGCCATTTCGAGAAGGAACTGCGCGCCGTCCACACCGAGACCGCGCGGGACCGCGAGCGCCTGAAGGCCGAGATCGCCGCGCTGTCGAAACGCTCCGAGGAGGTCTCGCACGAGGCGATGGCGCTGACGCGCGCGCTCAAGGGCGACCGGCAGCGGCAGGGCGCCTGGGGGGAGATGATCCTCGAGAGCATCCTCGAACGCTGCGGCCTGCGCGAGGGCGAGGAGTACGAGACCCAGGCCCACCGCACCGACGACGAGGGCGCCCGCCTGCGCCCCGACGTGGTGGTGCGCATCCCCGGCGACCGCACGCTGGTGATCGATTCCAAGGTCTCGCTGAACGACTATGCCGCCGCCGTGAACGCCGAGGACGCGGCCGAGGCCGCCGGCCACCGCAAGCGCCATGTTGCGGCCCTGCGCGCCCACATCACCGGACTGTCGGCCAAGGGCTATCAGCGCGCCGAGGACGCCTCGGTCGACTATGTCATCATGTTCGTGCCCATCGAGGGCGCGCTGTCGGAGGCGCTGCGCGAGGACGGCGGGCTGACCGGCTTTGCGCTGGAGCGCCACATCACCATCGCCACGCCCACCACGCTGATGATGGCGCTGCGCACGGTGGCCCATGTCTGGGCCGTGGAGCGGCGCAACCGCAACGCCGAGGCGATCGCGGACCGGGCCGGCAAGCTCTATGACAAGCTGGTGGGATTTCTGGAAAACATGGAGACGGTGGGCAAGCGCCTCGACCAGGCGCAGGCGGCCTATGGCGACGCGCTGGGGCAGCTGTCGCGCGGGCGCGGCAACCTGCTGTCGCAGGTGGAGACCCTCAAGACGCTGGGCGCCAAGGCCACCAAGACCATCGCCACCGAGTTCGAGGACACCGCCCCCCCGGGCACCCTCGCCGCGGACCCCGAAACCGATCCCCCGAAGTTCGACAGGAAAGCCGACAGGTGA",
    "translation": "MTDAPWQAPTPEELRALADATLAEAVALAEGLRALGPAVQVAAGLLAALVLAVVWAVLRARTRREALLRADLMARLADLEATTRRAEAAEANAAARADDLAALTARAEGLEGSLRAATVTERDLTARAAALDARLESAERRLAERRTEAEARESAIAGLRGRLEAEQAAQRALQARIAGLTQELESEQARGAEKVALLSSVREDMQARFRDLADAALKTQAEVFSNTSFARLEATLTPLKEHVGHFEKELRAVHTETARDRERLKAEIAALSKRSEEVSHEAMALTRALKGDRQRQGAWGEMILESILERCGLREGEEYETQAHRTDDEGARLRPDVVVRIPGDRTLVIDSKVSLNDYAAAVNAEDAAEAAGHRKRHVAALRAHITGLSAKGYQRAEDASVDYVIMFVPIEGALSEALREDGGLTGFALERHITIATPTTLMMALRTVAHVWAVERRNRNAEAIADRAGKLYDKLVGFLENMETVGKRLDQAQAAYGDALGQLSRGRGNLLSQVETLKTLGAKATKTIATEFEDTAPPGTLAADPETDPPKFDRKADR",
    "product": "hypothetical protein"
   },
   {
    "start": 19848,
    "end": 20525,
    "strand": -1,
    "locus_tag": "KKHPANEM_02425",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02425</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02425</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,848 - 20,525,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02425\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=9848&amp;to=30525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02425\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02425\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGATTGCGCATGGCCACTACGCGACCCTCGTCTTCGATTGCGACGGCGTCGTCCTCGACTCCAATCGGCTGAAGACGGAGGCATTCCGGCGCGCGGCGCTGCCGTGGGGGGAAGCGGCGGCTGATGCGCTGGTGGCGTATCATATCGCGCACGGAGGGGTGTCGCGGTATGTCAAGTTCCGGCATTTCCTCGATGCGCTGGTGCCAGAGCATGCGCCCGGCGGCTGCGGGCCGGGGCTGGAGGGGTTGCTTGACGCATATGCCGGGGCGGTGCGCGACGGGTTGATGACCTGCGGTGTGGCGCCGGGGCTGGCAGAGCTGCGGGCGGCGACGCCGGGGGTGCGTTGGCTGATCGTGTCGGGCGGCGACCAGGCGGAGCTGCGCGAGGTGTTTGCGGCGCGGGGTCTGGACCGGCACTTCGACGGCGGGATCTTCGGCAGCCCGGACACCAAGGCGGCGATCCTCGCCCGTGAGCTTGCGGCGGGCAACATCCGCCGCCCGGCGCTGTTTCTTGGCGACAGTCGGCTGGACTTTGAGGCGGCGGCCGGTGCCGGGCTGGATTTTACCTTCGTCTCGGGCTGGTCCGAGGTGGCGGACTGGCGCGGCTTTGTTGCCGAACACCGGCTGGCCTGCGTGGCGGGGCTGTCGGATCTGTTGGGCGGGGCAGGTCCGGCCTGA",
    "translation": "MIAHGHYATLVFDCDGVVLDSNRLKTEAFRRAALPWGEAAADALVAYHIAHGGVSRYVKFRHFLDALVPEHAPGGCGPGLEGLLDAYAGAVRDGLMTCGVAPGLAELRAATPGVRWLIVSGGDQAELREVFAARGLDRHFDGGIFGSPDTKAAILARELAAGNIRRPALFLGDSRLDFEAAAGAGLDFTFVSGWSEVADWRGFVAEHRLACVAGLSDLLGGAGPA",
    "product": "hypothetical protein"
   },
   {
    "start": 20522,
    "end": 21175,
    "strand": -1,
    "locus_tag": "KKHPANEM_02426",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02426</span></strong><br>\n \n  3-deoxy-manno-octulosonate cytidylyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02426</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">kpsU</span><br>\n \n Location: 20,522 - 21,175,\n (total: 654 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02426 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02348.21 (Cytidylyltransferase): [0:185](score: 69.8, e-value: 3.3e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02426\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=10522&amp;to=31175\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02426\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02426\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCCTGTGGGTTGCCGAACTCTCGGCAAGAGCTGTCGGGCAGGATCATGTCTATGTTGCCACGGAGGATGAGCGGATCGCTGAGGTGGTGCGCGCATCCGGATTCGCTGCGCTGATGACAAGTGCATCCGCCCTGACCGGCACGGACCGTGTTGCCGAAGCCGCACAGAAGATCGATTATGACATCTATGTCAATGTGCAGGGCGACGAGCCGATTGTGGATCCTGCGGACATCCGACGCTGTATTGCGATAAAGTCGAACAACCTTGAGAAGGTTGTGAACGGATACTGCTGGGTTGGCTCTGATGAAGACCCGGCGTCCGTGAATATTCCGAAAGTCATCACCAACGAGTCGGACGATCTGGTTTACATGTCGCGCGTGGCTTTGCCGGGGTTCAAGGATGCGACGAATGCGCCGGACAGGTTCAAGAAGCAGGTGTGCATCTATGGTTTCACCCGGCAGGAGCTCATGGAATATGCGGCGTTCGGCCGAAAGAGTTATTTGGAAAAGTGCGAAGACATCGAGATCCTTCGTTTTTTGGAGATCGAACGAAAGGTTTTGATGTTCCAATGCAAGCCGGGTAGCCTTGCAGTTGATGTTCCCGCGGACGTATCCCCAGTCGAGGCATTGTTGCGGGAACGCCTCAGTTGA",
    "translation": "MILWVAELSARAVGQDHVYVATEDERIAEVVRASGFAALMTSASALTGTDRVAEAAQKIDYDIYVNVQGDEPIVDPADIRRCIAIKSNNLEKVVNGYCWVGSDEDPASVNIPKVITNESDDLVYMSRVALPGFKDATNAPDRFKKQVCIYGFTRQELMEYAAFGRKSYLEKCEDIEILRFLEIERKVLMFQCKPGSLAVDVPADVSPVEALLRERLS",
    "product": "3-deoxy-manno-octulosonate cytidylyltransferase"
   },
   {
    "start": 21262,
    "end": 22884,
    "strand": -1,
    "locus_tag": "KKHPANEM_02427",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02427</span></strong><br>\n \n  4-hydroxy-2-oxovalerate aldolase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02427</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">mhpE</span><br>\n \n Location: 21,262 - 22,884,\n (total: 1623 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n  biosynthetic-additional (smcogs) SMCOG1271:2-isopropylmalate synthase (Score: 104.2; E-value: 1.4e-31)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02427 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00682.21 (HMGL-like): [136:254](score: 73.9, e-value: 1.6e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02427 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00682.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02427\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=11262&amp;to=32884\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02427\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02427\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAATCAATATGACTGGCGGCACGCTTCTTGACTGCACATTCCGGGACGGCGGATACTACAACGCCTGGGATTTCTCGCCCGCGCTGATCACACAGTACCTCGGGGCCATGCGGGCCGCGCAGGTGGATGTGGTGGAGCTGGGGTTCCGTTTTCTGCGCAACGAGGGGTTCAAGGGGCCCTGCGCCTTCACCACCGATGACTTCCTGCGCAGCCTGCCGATCCCACCGGGGCTGACGGTGGGGGTGATGCTCAACGGGGCGGATCTGTGCACCGACTTGGGCCGGGGCGCCGCGCTGCAGAGGCTGTTTCCCGAACCGGCCGCATCCACGCCGGTCGATCTGGTCCGCTTTGCCTGCCATTTCCATGAGCTGGAGACGGTTCTGCCCGCCGTCGGCTGGCTGCACGAGCGCGGCTACCGGGTCGGGCTGAACCTGATGCAGATCGCCGACCGCTCGCGAACGCAGGTCGCCGAGCTTGCGAAAATGTCCCGCGACTGGCCGGTGGAGGTGCTGTATTTTGCCGACTCCATGGGCTCCATGACGCCCGACGACACCGCCCGCATCGTCGGCTGGCTGCGCGACGGGTGGGAGGGGCCGCTGGGCATCCACACCCACGACAACATGGGGCTTGCGCTGTCCAACACGCTGCGTGCCGCGGCCGAGGGCGTCACCTGGCTCGATGCCACCGTCACCGGGATGGGGCGCGGCCCGGGCAACGCCCGCACCGAGGAACTGGCGATCGAGGCGGAGGGCCTGCGCAACCGGCGCGCCAATCTCGTGCCGCTGATGGGCCTGATCCGCAAGCACTTCGGCCCGATGAAGGCGCAGTACGGCTGGGGCACCAACCCGTATTACTTCCTTGCCGGAAAGTACGGCATCCATCCCACCTATATCCAGGAAATGCTGGGCGACGCGCGCTATGACGAGGAGGACATCCTTGCCGTGATCGACCATCTGCGCGCCGAGGGCGGCAAGAAGTTCAGCTTCAACACCCTCGACGGCGCGCGGCAGTTCTACAGCGGCGCGCCGCGTGGCAGCTGGGCCCCGTCCGAGGTCATGGCCGGCCGCGACGTGCTGATCTTGGGCACCGGGCCGGGCGTGGCCGCGCATCGCCCTGCGCTGGAGGCCTATATCCGCCGCGCCCGGCCGCTGGTGCTGGCGCTCAACACCCAGTCGGCCATCGATCCCGCGCTGATCGACCTGCGCATTGCCTGCCACCCGGTCCGTCTTCTCGCCGACGCCGAGGCCCACGCGGCGCTTCCGCAACCGCTGATCACCCCGGCCTCCATGCTGCCCGAAACCCTCCGGGCCGAGTTCGGCGACAAGGAGCTTCTGGATTTCGGGATCGGTATCGAGCCTGGCCGGTTCGAGTTCCACGCGACGCACTGCGTTGCGCCCAACTCTCTGGTTCTGTCCTACGCGCTGTCTGTCGCGGCCAGCGGTCAAGCTTCGCGTATCCTGATGGCAGGCTTCGACGGCTATCCCGCCAGCGACCGCCGCAATGATGAGGTCGATGACATGCTGCTCAAGTTCGTGAATTCCGAATTCACGGGTCCGGTGTTTTCGATAACGCCAAGCGCTTACGGAAATCTTCCCGCGCTCAGCCTGTACGGTATGTGA",
    "translation": "MTINMTGGTLLDCTFRDGGYYNAWDFSPALITQYLGAMRAAQVDVVELGFRFLRNEGFKGPCAFTTDDFLRSLPIPPGLTVGVMLNGADLCTDLGRGAALQRLFPEPAASTPVDLVRFACHFHELETVLPAVGWLHERGYRVGLNLMQIADRSRTQVAELAKMSRDWPVEVLYFADSMGSMTPDDTARIVGWLRDGWEGPLGIHTHDNMGLALSNTLRAAAEGVTWLDATVTGMGRGPGNARTEELAIEAEGLRNRRANLVPLMGLIRKHFGPMKAQYGWGTNPYYFLAGKYGIHPTYIQEMLGDARYDEEDILAVIDHLRAEGGKKFSFNTLDGARQFYSGAPRGSWAPSEVMAGRDVLILGTGPGVAAHRPALEAYIRRARPLVLALNTQSAIDPALIDLRIACHPVRLLADAEAHAALPQPLITPASMLPETLRAEFGDKELLDFGIGIEPGRFEFHATHCVAPNSLVLSYALSVAASGQASRILMAGFDGYPASDRRNDEVDDMLLKFVNSEFTGPVFSITPSAYGNLPALSLYGM",
    "product": "4-hydroxy-2-oxovalerate aldolase"
   },
   {
    "start": 22941,
    "end": 24263,
    "strand": -1,
    "locus_tag": "KKHPANEM_02428",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02428</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02428</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,941 - 24,263,\n (total: 1323 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02428\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=12941&amp;to=34263\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02428\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02428\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTGGCCTGGTTGCAATGGAGGCTCAAGGGTCTGGCTATGGACCTGGCCTATCGGCTGCCGCTGGCGCTTGTGGCCCGATTGGCGCCATCGCCGATGCGGATGATTTCCTTCTATCTGGCAAAAGCCGATTCACCTCGGGCGTTGCAATACCTTGACCACTTGGTTCGAATCTCGCCCGAGGTTGGCTGCCTCATGCGGCTTGACGAGCGGTTGCGGAGGGGAAGCATAAGTGGCGTCGATCTGGTGGATTCAATCCCGAGCTCGATCTTGCGGAAGCTCAATTCCTACAAGGATGTACATCTGAACGATGCCGCAAGGGCCTTCAACCGCTTGGGTTGCCTTCGGTTGGGAGGAGCCCTGCGAGGCCTTCTGCTGATCAAGCTCGTGCAGCAGAGATTTCGGAGCCCGGCGAAGCAAGGCTGGGAGCTTGACGCTTTGCTCCTTGAGGTTTCTGCCAATGACTACAGCCGCCGCCTTTTTTCGCGTCCCGAGCTTTGGGAGGATGGCCTTGACAGGCAAGTTCAGGACCGCATCGAATTGCTTCGATGCTCTGACATGTTGGTCAAGCTGCGCGTTTTTGTTGATTCGGAAAGACTGCCATGCGGGGAACACGAGGCCTCTCTGAGCGGCTTGTCGGTGCTGCTACAGGGGCCGTCGAGGAGGGAGTCCAATCTGGCTGGTACACCTTGTGACGTGGTTGGCACCATCGGTTACTCTGGAGCCGGCTCCCTCGCCAGGCTCGTTGAAGGCAGGCACGTATCCTTCTACCGGCCATACAAAATTCGCGCAATGATTGCTGAAGGGTTAACCGAAAGATTTAACGATGTTGACCTGGCGGTTGTCACCAAGCGAGGCCTCGGTGTTTTGGAGGCACAGTTCACGCCAGAGTGCAGGGTTGCCTGCTCCAAGGTGCGAGAGAGGTTTGGACTTGGTTTCCTGAACGGAGGAACGGAGTTTCTGATCTGGCTCTTGGCATGCGATCTGAACCGGCTCTTCGTCACAAATGTCGATCTTTTTCTCAACCCAGCGTACCCGGTCGGTTATCTGCCGAGCAACTACCAGAAATCTCACCTTTCAAAGGATGCTGCGCAATGGCAGACACAGTCGTGGGCGACGCTAATGGTTTTTGGAGATCATGAACCGAGTCAGCAGTACTCTATCTACAAGGCCTTTCATGGTTACGATTCCGTTGTATACGACTCGATGCTTGATGCAATTGTATCTGCGCCGTTCAGCGCATACGCGGAGGCGCTTGAAGATGCCTATCGGGTTTGGCCCCAAGGTCCCGTCGTCGATTGCTGCGGTGGTGGCTCGGCTTGA",
    "translation": "MLAWLQWRLKGLAMDLAYRLPLALVARLAPSPMRMISFYLAKADSPRALQYLDHLVRISPEVGCLMRLDERLRRGSISGVDLVDSIPSSILRKLNSYKDVHLNDAARAFNRLGCLRLGGALRGLLLIKLVQQRFRSPAKQGWELDALLLEVSANDYSRRLFSRPELWEDGLDRQVQDRIELLRCSDMLVKLRVFVDSERLPCGEHEASLSGLSVLLQGPSRRESNLAGTPCDVVGTIGYSGAGSLARLVEGRHVSFYRPYKIRAMIAEGLTERFNDVDLAVVTKRGLGVLEAQFTPECRVACSKVRERFGLGFLNGGTEFLIWLLACDLNRLFVTNVDLFLNPAYPVGYLPSNYQKSHLSKDAAQWQTQSWATLMVFGDHEPSQQYSIYKAFHGYDSVVYDSMLDAIVSAPFSAYAEALEDAYRVWPQGPVVDCCGGGSA",
    "product": "hypothetical protein"
   },
   {
    "start": 24278,
    "end": 25579,
    "strand": -1,
    "locus_tag": "KKHPANEM_02429",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02429</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02429</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,278 - 25,579,\n (total: 1302 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02429\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=14278&amp;to=35579\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02429\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02429\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGTTCGCCTGAAGCGCCTCGGCATGGGAGTCGCGATGTCGGTCGTGCCTCGGCTTCCTGCATCGCTGGCGATGCGGATTACTCCGTCGCCCGTCTGGCTGGTGTCGCTTCTCCTGACGCGGGACGATCCGGCCGCGGCGGTGCGGTGCCTCAAGCGGCTCGCCGCGACCAGTCCCGAGATAGCTGCCCTTCTGCGCATCGACGAACAGCTGCAGTCCGGGGCCATCCCTGCCGATGCAATCGCCGACGCGATGCCAATCCCGGTGTTGCAGGCTTTCGTCACCACCGGGATTGCGCCTCTCCGGCATGCTGCCAAGGCGTTCAACGCGCTCGGGTGCCTGCGGCTGGGGGGGGCACTGAGGGCGCTCGTGCTTTTGCGGGTTGCCGCTGCGAACATTGCCTCCGGCGAGGACCGCGGATGGCAGCACGAGGCAGTACTTCTGGAGATCGCGGCCAACGATCACTGCGCGCGGTTCATGGCCCGCCCGGAGGTGATGCCAGAGGCCTGCCGCACGGCGCTTCAGGAAGAACTGCAAGCGGTCGCCGGCTGGAGCCTGGCGCGCAAGGTCTCGGTTCTCGTGGGCCAGGACAGCCCCGCCATGCCGGCGTTGCGCGCGCGCATGGCCGGCCGCAGCCTTCGGTTCCAGGGTCCGTCGAGCCGTTCCTCCGATCTGGACGATACGCCGGCCGATCTGACATGCGTCGTCGGCTACTCCGGACCTGGCTCGCTGGCCCGCCCGGTCGACAGCATTGGTGTGTCGCTATACAAGAAGCACAAGATCGCGGCGATGCGCGGGGACGGACTGCTGCATCACATGGCGGACGTGCAGGTTCCGGTGCTCAACCCGGAGGACCTGCGCCAAGAACGTGCGTTTTATGCGGACCTGATCGAGAAATATGGAGCCAGTTTGACGAATGTGCGCTGGGCGTCCCTGAACTCCCAGATGAATGCGGGCACGGAACTGTTTGTCTGGATGTTGAACTGCGGCGCTTCCTCGGTTTCTGTCAGTCACCTTGACCTGTTCTTGAACCGAACCTATCCCCCCGGTTACCTGGCCGGCGGCAAGGCGCAAGCCTCCCGTGACGGGCCAGGCTGGCAGATGGAGGAGTGGTCGCAGTTGAAGAGCTTCGGCTACCATGAGCCCAGCCAGCAGTTCGCGATCTACAGGGCGTTTCATCCGCATCGCGAGGTGGCGTACGATGGCATACTCGATGCGATCGTGGAGAAACCATTCAGCGCCTACGCGAGCGCGCTTGAGGACGGCTATCGAGTTTGGCGCGGTCGGGCCGAGGCGTGA",
    "translation": "MTVRLKRLGMGVAMSVVPRLPASLAMRITPSPVWLVSLLLTRDDPAAAVRCLKRLAATSPEIAALLRIDEQLQSGAIPADAIADAMPIPVLQAFVTTGIAPLRHAAKAFNALGCLRLGGALRALVLLRVAAANIASGEDRGWQHEAVLLEIAANDHCARFMARPEVMPEACRTALQEELQAVAGWSLARKVSVLVGQDSPAMPALRARMAGRSLRFQGPSSRSSDLDDTPADLTCVVGYSGPGSLARPVDSIGVSLYKKHKIAAMRGDGLLHHMADVQVPVLNPEDLRQERAFYADLIEKYGASLTNVRWASLNSQMNAGTELFVWMLNCGASSVSVSHLDLFLNRTYPPGYLAGGKAQASRDGPGWQMEEWSQLKSFGYHEPSQQFAIYRAFHPHREVAYDGILDAIVEKPFSAYASALEDGYRVWRGRAEA",
    "product": "hypothetical protein"
   },
   {
    "start": 25856,
    "end": 26299,
    "strand": -1,
    "locus_tag": "KKHPANEM_02430",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02430</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02430</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,856 - 26,299,\n (total: 444 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02430 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05099.15 (Tellurite resistance protein TerB): [22:140](score: 89.5, e-value: 2e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02430\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=15856&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02430\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02430\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTCGAGACATTCCTGCGCCGGCTGATCCGGCCCGATCCCATGCCCCTGCCGCAAGCCGATGCCCGGCTGGCGCTGGCGGCCCTGCTGGTGCGGGCGGCGCGCGTCAACGGCGATTATGACCCCGCACAGGTGGTTGCCATCGATGCCGCCCTCGCGCGTCGCTACGGCTTCGGGGCGGATGACGCCGCCGCCCTGCGCGCCCGCGCCGAAGGTCTGGAGAGCGAGGCGCCCGACACCGTGCGCTTCACCCGCGCCGTCAAGCAGGCAACCGCACTGGAAGATCGCGCGGCCGAGCTGGAGATGCTGTGGGAGGTGATCCTGTCCGACGGCGCGCGCGACCACGAGGAGGACGGGTTCATGCGCCTTGTGGCGGACCTGCTGGGGTTCTCCGATCGCGACAGCGCGCTGGCCCGCCAGCGCGTGGCCGAGCGGATGGCGTAA",
    "translation": "MFETFLRRLIRPDPMPLPQADARLALAALLVRAARVNGDYDPAQVVAIDAALARRYGFGADDAAALRARAEGLESEAPDTVRFTRAVKQATALEDRAAELEMLWEVILSDGARDHEEDGFMRLVADLLGFSDRDSALARQRVAERMA",
    "product": "hypothetical protein"
   },
   {
    "start": 26389,
    "end": 28062,
    "strand": -1,
    "locus_tag": "KKHPANEM_02431",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02431</span></strong><br>\n \n  Glucose-6-phosphate isomerase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02431</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">pgi</span><br>\n \n Location: 26,389 - 28,062,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02431 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00342.21 (Phosphoglucose isomerase): [59:545](score: 619.9, e-value: 3e-186)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02431 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00342.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004347' target='_blank'>GO:0004347</a>: glucose-6-phosphate isomerase activity<br>\n  \n   PF00342.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006094' target='_blank'>GO:0006094</a>: gluconeogenesis<br>\n  \n   PF00342.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006096' target='_blank'>GO:0006096</a>: glycolytic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02431\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=16389&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/pgi_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02431\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02431\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGCGGAGCGGACAACGGGGCGGGCACCGGGCGGGCACGATGCGGATCTGGCGCCGCTGTGGCGGGCACTGGAGCAATACCGCGACCGGGTGGCCGCGCGCCCCATCGCGGCGCTGTTCGACGCCGATCCGGCGCGCGCCGAGGCGTTCTCGGTCAGCGCGGCCGGGCTGATGCTCGATTACTCCAAGACCGGGGTGTGTGCGCAGGGGATGGCGCATCTTCTGGCGCTGGCCGATGGCGCCGGGGTGGAGGCGCGCCGGGACGCGATGTTCCGGGGCGCCGCGATCAACGAGACCGAGGGCCGGGCGGTGCTGCACACCGCGTTGCGTGATCCCGACGGGCCGCCGCTGGTGGTCGACGGGGTGGATGTGCGCCCGGGCATCGCCGGGACGCTGGCGCGGATGGAGGCGATGGCCGCCGATGTGCGCGCGGGCCGGGTCCGCGGGGCGGGCGGGGCGATCACGGATGTGGTCAATATCGGGATCGGCGGATCGGACCTCGGGCCTGCGATGGCGGTGCAGGCGCTGGCGCCGTACCACGACGGGCCGCGGTGTCATTTCGTCTCGAACGTGGACGGGGCGCATGTGCATGACGTGCTGGCGGGGCTGGACCCGGCGCGGACACTGGTGATCGTGGCCTCCAAGACCTTCACCACGCTGGAGACGATGACCAACGCCGCCACCGCACGCGACTGGATGGCCCGCGCCGTGGCCGATCCGGGGGCGCAGTTCGTGGCGCTGTCGTCGGCCGGGGACCGCGCGGCGGCGTTCGGCATCCCGCCCGATCGGGTGTTCGGCTTCGAGGACTGGGTCGGCGGGCGCTACTCGGTCTGGGGGCCGATCGGGTTGTCGCTGATGCTGGCCATCGGGCCGGAGCGGTTCCGCGACTTCCTTGCGGGGGCGGCGGCGATGGACGCGCATTTCCGCAGCGCCCCGCTGGCGTCCAGCATGCCGGTGCTGCTGGCGCTGGTGGGGGTGTGGCATGCGCAGGTCTGCGGGCATGCGACCCGCGCGGTCATCCCCTATGATCAACGGCTGGCGCGGCTTCCGGCGTATCTGCAGCAGCTGGAGATGGAGTCGAACGGCAAGCGCGTGGGGATGGACGGGCGCGACCTCGATCGTCCCTCGGGGCCGATCGTGTGGGGGGAGCCGGGAACCAATGGCCAGCACGCCTTCATGCAGTTGATCCATCAGGGCACGCGCGTCGTGCCGGTGGAGTTCCTGCTGGCCGCGCGCGGTCACGAGGCGGATCTGGCGCATCACCACCGCCTGCTGGTCGCCAACTGCCTGGCGCAGGCCGAGGCGCTGATGCGGGGGCGCACGCTGGAGGCGGCGCGCGCCGGGCTGTCGGCCGCAGCCCTGGGCGGTGCCGAGCTGGAGCGCCAGGCCCGCCACCGGGTGTTTCCCGGCAACCGGCCCTCGACGGTGCTGCTGTATTCCCGGCTGACGCCGCGGATGCTGGGGGCCGTCCTGGCCCTTTATGAGCATCGGGTGTTCGTGGAGGGCGTGATCCTCGGCATCAACCCGTTCGATCAATGGGGCGTGGAGCTGGGCAAGGAGCTGGCCGTCAGCCTGACGCCGCTGCTGGAGGGGACGGCCGAGGGCGGCGCGCACGACGCCTCCACCCTGCGGCTGGTGGCGATGGTGCGCGCGGATGGTGTCGCCCCGGGATGA",
    "translation": "MAERTTGRAPGGHDADLAPLWRALEQYRDRVAARPIAALFDADPARAEAFSVSAAGLMLDYSKTGVCAQGMAHLLALADGAGVEARRDAMFRGAAINETEGRAVLHTALRDPDGPPLVVDGVDVRPGIAGTLARMEAMAADVRAGRVRGAGGAITDVVNIGIGGSDLGPAMAVQALAPYHDGPRCHFVSNVDGAHVHDVLAGLDPARTLVIVASKTFTTLETMTNAATARDWMARAVADPGAQFVALSSAGDRAAAFGIPPDRVFGFEDWVGGRYSVWGPIGLSLMLAIGPERFRDFLAGAAAMDAHFRSAPLASSMPVLLALVGVWHAQVCGHATRAVIPYDQRLARLPAYLQQLEMESNGKRVGMDGRDLDRPSGPIVWGEPGTNGQHAFMQLIHQGTRVVPVEFLLAARGHEADLAHHHRLLVANCLAQAEALMRGRTLEAARAGLSAAALGGAELERQARHRVFPGNRPSTVLLYSRLTPRMLGAVLALYEHRVFVEGVILGINPFDQWGVELGKELAVSLTPLLEGTAEGGAHDASTLRLVAMVRADGVAPG",
    "product": "Glucose-6-phosphate isomerase"
   },
   {
    "start": 28927,
    "end": 29736,
    "strand": -1,
    "locus_tag": "KKHPANEM_02432",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02432</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02432</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,927 - 29,736,\n (total: 810 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02432 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03370 (VPLPA-CTERM: VPLPA-CTERM protein sorting domain): [242:266](score: 27.3, e-value: 6.3e-07)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02432\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=18927&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02432\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02432\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATCACAAGGCACGGACCGCTTTGGCAGCCCCGCTCGTGGCGGCGCTGGTGCTTTCGGCCGCGGCGGCCAATGGCGCGACCTTGCGGACGCTGTCCGGGGGGGATGGCGCCTTCAATGCGCTGTGCGCGGCGGGCAACGCGGTCGGAACCGGCAATCAGGCCTGCGAGTTTGCCGTCGGTGAAATGCGGACCGGGGCTGTCGGTGGCGCCCAGACATGGGAGGTCGGCGTGCAGAACCCGCCCGGATCGCCCGTCAGCACGCGCAATTATGCCTGGGGCAACGGCGCGGCGCAGGCGTTCGTGTTTTCCTTCAGCGGCGGCACCCTGACCCTTGCGGTCGGTGCGGCGGGGGCGACGCAGGTGGTCTCGACGGCGACGGGGGTCGACCTGGGCGGCATGTCGTCGATGTTCCTCCGCACCCGCACCGCACAGGAGGGGTTCGAGGGCGTGAAGCTGTTCGACATGACAGTGACGGGGGCCGCGCCGGGCGGGGGTGCGGTTGGTGTGCACGACCTGCCCGACCTGACCTCGTCCGCGCCGGGGTCGACCGGGGCGGGCTATGTTCAGGTGTCGGACGTGGACTGGAGCGCGGACTGGACGCTGGCGGGCTCGATCCGCTTCAGCTGGGACCCCGATCTGGCCTGCCCCTGCGGATCCAACCTGAATGTCAATTTCAAGCTGACCGATCTGGAGACGCTGTCGGGGGGGCCGCCGAGCAGTGTCATCCCGCTGCCGGCCGCCGGATGGCTGCTGCTGAGCGGGGTTGCGGGGCTGGGCTGGCTCGGGCGGCGGCGCGCGGTGGTCTGA",
    "translation": "MDHKARTALAAPLVAALVLSAAAANGATLRTLSGGDGAFNALCAAGNAVGTGNQACEFAVGEMRTGAVGGAQTWEVGVQNPPGSPVSTRNYAWGNGAAQAFVFSFSGGTLTLAVGAAGATQVVSTATGVDLGGMSSMFLRTRTAQEGFEGVKLFDMTVTGAAPGGGAVGVHDLPDLTSSAPGSTGAGYVQVSDVDWSADWTLAGSIRFSWDPDLACPCGSNLNVNFKLTDLETLSGGPPSSVIPLPAAGWLLLSGVAGLGWLGRRRAVV",
    "product": "hypothetical protein"
   },
   {
    "start": 30101,
    "end": 30238,
    "strand": -1,
    "locus_tag": "KKHPANEM_02433",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02433</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02433</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,101 - 30,238,\n (total: 138 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02433\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=20101&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02433\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02433\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCAAAGGCAACAACAAGCGCGGAAACAAGGAAGTGAAGAAGCCGAAGCAGGAGAAGCCCAAGGTGCTGGCGACGGCCAACTCCGGCGTGGCGAAACCGATGACCCTGGGCGAGAAGAAAGACCGCAGCCGGTAG",
    "translation": "MGKGNNKRGNKEVKKPKQEKPKVLATANSGVAKPMTLGEKKDRSR",
    "product": "hypothetical protein"
   },
   {
    "start": 30442,
    "end": 31245,
    "strand": -1,
    "locus_tag": "KKHPANEM_02434",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02434</span></strong><br>\n \n  D-beta-hydroxybutyrate dehydrogenase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02434</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">bdhA</span><br>\n \n Location: 30,442 - 31,245,\n (total: 804 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 200.7; E-value: 4.6e-61)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02434 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13561.8 (Enoyl-(Acyl carrier protein) reductase): [12:265](score: 169.4, e-value: 9.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02434\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=20442&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/bdhA_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02434\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02434\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGATCTGACGGGCAAGACGGCGCTGGTGACAGGCTCCACCTCGGGGATCGGGCTGGCCATCGCCGAGGCGCTGGGGGCTGCGGGCGCGCGCATCGCGCTGCACGGGCTGGCCGGCGACATGGAGATCCACGACGCGACCGAGCGGGTGCGCGCCGCCGGCAGCCCCGAGGTGGCGTTCTTCGGTGGCGACATGCGCAACCCCGAGCGCATTCACGAGCTGATGGCGGCGGTCGATGCCTGGGGCGGCGTGGACATCCTCGTCAACAACGCCGGCATCCAGCACACCGCCCCCACCACCGAGATGCCCGACGACAAGTGGGAGGCGATCATCGCCATCAACCTGTCGGCGTGTTTCCACACCATGAAGGCGGCGCTGCCTGGGATGGCCGCGCGGGGCTATGGGCGGGTTGTCAACATCGCCTCGACCCACGGGCTGGTGGCGTCGAAGGAAAAGGCGCCCTATGTCGCGGCCAAGCACGGGCTTGTGGGCATGACCAAGGTGGTGGCGCTGGAGCATGCGGCGCTGGGGGATGCGGCCTCGGGCGGGGTGACGGCGAACTGCATCTGTCCGGGCTGGACCGAAACCGCCCTGATCGAGCCGCAGATCGAGGCCCGCGCCAAGGCCCGCGGCGGCGACCGCACCGCCGCGATCGCGGATCTGCTGTCGGAGAAGCAACCCTCGCAGCGCATGACCAGCCCCGCCGATCTGGGGGCGCTGGCGGTGTGGTTGTGCAGCCCCGCCGCGCACAACATCACCGGGGTGGCGATCCCCGTGGACGGCGGCTGGACCGCGCAGTAA",
    "translation": "MTDLTGKTALVTGSTSGIGLAIAEALGAAGARIALHGLAGDMEIHDATERVRAAGSPEVAFFGGDMRNPERIHELMAAVDAWGGVDILVNNAGIQHTAPTTEMPDDKWEAIIAINLSACFHTMKAALPGMAARGYGRVVNIASTHGLVASKEKAPYVAAKHGLVGMTKVVALEHAALGDAASGGVTANCICPGWTETALIEPQIEARAKARGGDRTAAIADLLSEKQPSQRMTSPADLGALAVWLCSPAAHNITGVAIPVDGGWTAQ",
    "product": "D-beta-hydroxybutyrate dehydrogenase"
   },
   {
    "start": 31242,
    "end": 32768,
    "strand": -1,
    "locus_tag": "KKHPANEM_02435",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02435</span></strong><br>\n \n  Long-chain-fatty-acid--CoA ligase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02435</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">lcfB_3</span><br>\n \n Location: 31,242 - 32,768,\n (total: 1527 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 364.2; E-value: 1.5e-110)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02435 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.30 (AMP-binding enzyme): [8:406](score: 287.6, e-value: 1.4e-85)<br>\n \n  PF13193.8 (AMP-binding enzyme C-terminal domain): [414:488](score: 67.6, e-value: 1.5e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02435\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=21242&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/lcfB_3_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02435\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02435\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAACATCGCGAACTGGCTGGTGCGCAGCGCGCAGACGCGCGGGACGGCGCCCGCGCTGATGGCGGGCGCGCGGGAGGTGGCGGATTACGCGGGCTTTGCGCGGTCCGCTGGGGCGCTGGCGGGGGCGCTGGCGGCGCGCGGGATCGCGCCCGGCGACCGGGTCGCGCTGTTGGCGGGCAACCGGCCGGAGTATCTGGTGGCGGTGTTCGGGATCTGGACCGCCGGGGCGGTGGCGGTGCCGGTCAACGCCCGCCTGCATCCGCGCGAGGCGGCGTGGATCCTGTCCGACAGCGGCGCGGCGCTGGCGCTGGTGGCCCCCGACGCAGCACCCGATCTGGCGGGCGTGACCGAGGTGCCGCTGATGGCGCTGCCGGGTCCCGACTGGGCGGCGGCGGTGGCCGGGCCGCCCGCGCCGGTGGTGCCGCGGGGGCAGGGCGATCTGGCGTGGCTGTTCTACACCTCGGGCACCACGGGGCGGCCCAAGGGGGTGTGCATCACGCATGGCATGCTGGCGGCGATGTCGCTGTGCTATCCCGTCGACGTGGACCCGGTGGGGCCGCAGGACGCCGCGCTGTATGCGGCCCCCATGAGCCATGGGGCGGGCCTCTATGCGCCGATCCATGTGCGCATGGGGGCGCGGCATCTGGTGCCGCCCTCGGGCGGGTTCGACGCGGCCGAGGTGCTGGATCTGGCCGCATCCCACGGCCCGGTGTCGATGTTCCTGGCGCCCACCATGGTGCGCCGGCTGCTGGAGGCCGCGCGCGCCTCGGGGCGGCGGGGCGAGGGGCTGCGCACCGTCGTCTATGGCGGCGGGCCGATGTATCTGGCCGACATCACCGCCGCCGTCGACTGGTTCGGCCCGCGTTTCGTGCAGATCTATGGTCAGGGCGAATGCCCGATGGCCATCACCGCGCTGAGCCGGGCCGAGGTCGCGGACCGCACCCATCCCGACTGGCGCGCGCGCCTCGGCTCGGTCGGGCGGGCGCAGAGCCTGGCGGAGGTCGCGGTGATCGATGACGCGGGCGCGCCGCTGCCGGTGGGCGAGGCGGGCGAGATCGTGGTGCGCGGCGCCCCGGTGATGCCCGGCTACTGGCGCAATCCCGAGGCCAGCGCGAAAACCCTGTGCGACGGTTGGCTGCGGACCGGCGACGTGGGCCAGCTGGACGGCGACGGATACCTGACGCTGGTCGACCGTTCTCGGGACGTGATCATCTCGGGCGGGACCAACATCTATCCCCGCGAGGTCGAGGAGGCCCTGCTGGAACACCCCGACGTGGCCGAGGCCGCCGTCATCGGCCGCCCCAGCCCCGAGTGGGGCGAGGAGGTGGTGGCGTTCCTCGTGCCCCGCGCGGCGCTGCGCCGCGCGGCGCTGGAGGCGCATTGTCTGGAGCGGATGGCCCGGTTCAAGCGGCCCAGGGCATGGTATGCAGTGGCATCCCTTCCAAAGAACAATTACGGCAAGGTGCTGAAGACCGAGTTGCGCGCCCGGCTGGCCGCCGGGACCGAACAGGAGGACATCGCATGA",
    "translation": "MNIANWLVRSAQTRGTAPALMAGAREVADYAGFARSAGALAGALAARGIAPGDRVALLAGNRPEYLVAVFGIWTAGAVAVPVNARLHPREAAWILSDSGAALALVAPDAAPDLAGVTEVPLMALPGPDWAAAVAGPPAPVVPRGQGDLAWLFYTSGTTGRPKGVCITHGMLAAMSLCYPVDVDPVGPQDAALYAAPMSHGAGLYAPIHVRMGARHLVPPSGGFDAAEVLDLAASHGPVSMFLAPTMVRRLLEAARASGRRGEGLRTVVYGGGPMYLADITAAVDWFGPRFVQIYGQGECPMAITALSRAEVADRTHPDWRARLGSVGRAQSLAEVAVIDDAGAPLPVGEAGEIVVRGAPVMPGYWRNPEASAKTLCDGWLRTGDVGQLDGDGYLTLVDRSRDVIISGGTNIYPREVEEALLEHPDVAEAAVIGRPSPEWGEEVVAFLVPRAALRRAALEAHCLERMARFKRPRAWYAVASLPKNNYGKVLKTELRARLAAGTEQEDIA",
    "product": "Long-chain-fatty-acid--CoA ligase"
   },
   {
    "start": 32823,
    "end": 36047,
    "strand": -1,
    "locus_tag": "KKHPANEM_02436",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KKHPANEM_02436</span></strong><br>\n \n  Sensor histidine kinase RcsC<br>\n \n <br>\n Locus tag: <span class=\"serif\">KKHPANEM_02436</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">rcsC_7</span><br>\n \n Location: 32,823 - 36,047,\n (total: 3225 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 66.2; E-value: 5.2e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02436 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08448.12 (PAS fold): [62:171](score: 51.6, e-value: 9.9e-14)<br>\n \n  PF12860.9 (PAS fold): [194:309](score: 61.2, e-value: 9.9e-17)<br>\n \n  PF08447.14 (PAS fold): [333:422](score: 71.7, e-value: 5e-20)<br>\n \n  PF08447.14 (PAS fold): [456:546](score: 69.4, e-value: 2.6e-19)<br>\n \n  PF00989.27 (PAS fold): [565:681](score: 38.4, e-value: 1.1e-09)<br>\n \n  PF00512.27 (His Kinase A (phospho-acceptor) domain): [703:769](score: 68.7, e-value: 3.4e-19)<br>\n \n  PF02518.28 (Histidine kinase-, DNA gyrase B-, and HSP90-like ATPase): [815:926](score: 98.4, e-value: 3.6e-28)<br>\n \n  PF00072.26 (Response regulator receiver domain): [948:1060](score: 63.3, e-value: 2.2e-17)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-KKHPANEM_02436 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00229 (sensory_box: PAS domain S-box protein): [53:176](score: 42.7, e-value: 1.3e-11)<br>\n \n  TIGR00229 (sensory_box: PAS domain S-box protein): [304:435](score: 49.3, e-value: 1.2e-13)<br>\n \n  TIGR00229 (sensory_box: PAS domain S-box protein): [429:559](score: 63.5, e-value: 4.7e-18)<br>\n \n  TIGR00229 (sensory_box: PAS domain S-box protein): [566:691](score: 37.2, e-value: 6.6e-10)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-KKHPANEM_02436 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00072.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00512.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000155' target='_blank'>GO:0000155</a>: phosphorelay sensor kinase activity<br>\n  \n   PF00512.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007165' target='_blank'>GO:0007165</a>: signal transduction<br>\n  \n   PF00989.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n   PF08447.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"KKHPANEM_02436\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_NHSD01000292.1&amp;from=22823&amp;to=36052\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/rcsC_7_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02436\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"KKHPANEM_02436\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCCGGGGCGGGCACCGCCGCAGCGCCACCGGCTGGGCGCCCCCGGCGCCGAGCGGTGGGTCGAGGTGACAGCCGCCCCGCGCGGCCCCGGTGCCGCGCCGGGCCATGTGGTGGCGCTGCGCGATGTCACCGCCGCCGCGCGCGCCACCCACGAGGTCGAACAGCTGAGCCAGATCGCCCGGCGCACCGGCGATCTGGTGGTCATCACCGATACCGACCACCGCATCGACTGGGTCAACCCGGCCTTTGAGGCGCGCACCGGCTGGCGGCTGGAGGATGTCCGCGGCCACCTCCCCGAGAGCATCCTGCAAAGCCCCGAGGCCGACGCGGCCGAGGTCGCGCGCATCCGCGGCGCGCTGCTGGAGGGGGCGTCGGCCAGCGGGCTCTTGCTGTGCCGCACCCGGACGGACGATGCCTTCTGGGCCGAGATCGACGCCTATCCGCTGCGGGACTCGGACGGGCGGACGACGGGCCATGTCACGCTGGCCACCGACGTCACCGCGCGCCGCGCGCAGGAGGCCAAGCTGGAGCGCCTTGCGCAGGAGGCCACGCGGGCGCGCGAGCGGCTGGAGATGGCGGTGGAGGCGCTGCCGGACGCGTTTGCGTTTTTCGACGCCGAGGACCGGCTGGTGCTGTGCAACGAGCGCTATCGCACCTTTCATCCGCGGTCGGGGTACATGATCTCGCCGGGGGTGCAGTTCGCGGACTTTGCCCGGGCGGTGGCCCACAGCGGCGATGTCGCCGACGCCGTGGGCCGCGAGGAGGCGTGGCTGGCCGAGCGCCTGGCCTCGCACCGCGAGGGGCGCCCGGGCGGCGAGCACCGCATGGCCGACGGCAGCTGGCTGCGGGTGATCGAGCGCGTCACCGCCGACGGCGGCCGCGTCGGCATGCGCGTCGACATCACCGAGCTGAAGGAGGCCGAGCGGCGGCTGGCCGACATCATCCACGGCGCGCAGGTCGGCACCTGGGAGTGGCACCTGGCCAGCGGCGAGAACCGCATCAACGCGCGCTGGGCCGAGATCGTGGGCTATTGCCCCGACGAGATCGACCGCTCGGGCATCGATCTGTGGCGGGCGCTGGTGCACCCCGACGACCTGGCCCGCGCCGAGGCGCGGCTGGCGCGGGTGTTCGCCCGCGAGATCGACCAGTTCGAGTATGAATTGCGCATGCGCCACCGTGACGGCCACTGGGTCTGGGTGCTGTCGCGCGGGCGGGTGGCGCGTTGGTCGCCCGACGGCAAGCCCGAGGTGATGGCCGGGGTGCACATGGACATCACCGCCCTCAAGCGCGCCGAGGAACGGCTGGAGGCGATCCTGCACGCCGCCGAAGCCGGCACCTGGGAGACCGATCCCGCGCGCGGCGGCATGCGCATCAACGACCGCTGGGCGGAGATGCTGGGCTACACCGTGGACGAGCTTGCGCCCCTGCCGGAACACGGTTTTCGCACCCTGATGCACCCCGACGACCGCGCCCGGCTGGAGGCGGAGTTCGGCATGGACCTGGAGGGCCGCCCCGATCGCTTCAGCGTGGAGGTGCGGGTGCGCCACAAGGCCGGTGCCTGGGTCTGGCTGCTGGCGCGCGGCCGGGTGCTGGCGCGCGACGCCAACGGCCGGCCGGTGCGCACCGCGGGCATCCACCTCGACATCACCGAGCGCAAGCGGCTGGAGCAGCAGCTGGTGGCCGAGCGCGATTACATGTCGCGGCTGATGGAGACGAATGTCTCGGGCATCACCGCGCTGGATGGCGACGGGCGCATCATCTATGCCAACCGCGAGGCCGAGGCGATCCTGGGCTTGTCGGCGGCGGCGGTGGACCGGCGCAGCTATGCCGATCCGCGCTGGCAGATCACCGCCCCCGACGGCGGGCCGCTGGCCGATGCCGAGCTGCCCTTTACCCGCGCCATGACCGAGGGGCGGGTGGTGCGCGACGTGCGCTTCGCCATCGCCTGGCCCGACGGCACCCGGCGGCAGCTGTCGGTCAACGCGGCGCCGCTGCTGGCCGAGGGGCTGCAGGCGCGGGTGGTCTGCGCGATCACCGACATCACCGAACAGGTCGCCACCGAAGCCGCCCTGCGCAGCGCCGCCGAGCGGGCCGAGGCCGCCAGCGAGGCCAAGTCGCGGTTCCTGGCCAACATGAGCCACGAGATTCGCACCCCCCTGAACGGGGTCCTCGGGATGGCGCAGGTGCTGGAGGAGGAGCTGTCCGAGCCGCGCCACCGCCGCATGCTGGAGGTGATCCGCGAATCCGGCGAGATGCTGCTGGGCGTGCTCAACGATGTCCTCGACATGTCCAAGATCGAGGCCGGCAAGGTTACGCTGGAGCAGGTCGCCTTCGTGCCCGCCGATCTGGCACGGCGGATCGAGGCGATGCACGCCCTGCGCGCCGCCGAGAAGCATCTGTCGCTGGAGGTCGTGGCCGCCCCCGGCGCCGAGCGCGCGCGGCTGGGCGATCCGGGCCGGGTGGAGCAGATGCTGCACAACCTGGTCGGCAACGCCGTCAAGTTCACCGAGGCGGGCGGCGTGCGGGTGACGCTGGAGGGGGGGTGTGGCCCGCTGCGGGTGGTCGTCCATGACACCGGGATCGGCATGACGGACGATCAGTTGGCGCGCATCTTCGAGGATTTCGAACAGGCCGACGGCACGGTGACCCGCCGGTTCGGGGGCACCGGGCTGGGCATGTCCATCGTGCGCCGCCTGGTGGCGCTGATGGGCGGCCAGATCACGGTCGACAGCATCCCTGGCGCGGGCACCCAGGTGCGCGTCGCGCTGCCGCTGCCGCTGGCCGAGGGTGGCCCGCGCGATGCCGTCCCCGTGCCCGCCCAGCCGCTGGAGGGGCTGCGCGCGCTGGCGGCCGACGACAACGCCACCAACCGGCTGATCCTCCAGGCGATGCTGTCGGCGCTGGGCGGGGCCGTGACGATGGTGCCCGACGGGCAGGCCGCGGTGGAGGCGTGGGCGCCGGGGCGGTTCGATCTGATCCTGCTGGACATCTCGATGCCGGGGCTGGACGGTCTGGGCGCGCTGGCCGCGATCCGCCTGCGCGAGGCCGAGGCGGGTGTGCCACCCGCGCCCGCGGTGGCGATCACCGCCAACGCCATGGCCCATCAGGTGGCGCAGTACATGGGCGCGGGCTTTGCCGCCCATGTCGGCAAGCCGTTCCGCCGCGAGGACCTGGCGCGGACGCTGTTGCGCGTGCTGGACCGCGCCCCGCCCGCGCAGCGGTGA",
    "translation": "MPGRAPPQRHRLGAPGAERWVEVTAAPRGPGAAPGHVVALRDVTAAARATHEVEQLSQIARRTGDLVVITDTDHRIDWVNPAFEARTGWRLEDVRGHLPESILQSPEADAAEVARIRGALLEGASASGLLLCRTRTDDAFWAEIDAYPLRDSDGRTTGHVTLATDVTARRAQEAKLERLAQEATRARERLEMAVEALPDAFAFFDAEDRLVLCNERYRTFHPRSGYMISPGVQFADFARAVAHSGDVADAVGREEAWLAERLASHREGRPGGEHRMADGSWLRVIERVTADGGRVGMRVDITELKEAERRLADIIHGAQVGTWEWHLASGENRINARWAEIVGYCPDEIDRSGIDLWRALVHPDDLARAEARLARVFAREIDQFEYELRMRHRDGHWVWVLSRGRVARWSPDGKPEVMAGVHMDITALKRAEERLEAILHAAEAGTWETDPARGGMRINDRWAEMLGYTVDELAPLPEHGFRTLMHPDDRARLEAEFGMDLEGRPDRFSVEVRVRHKAGAWVWLLARGRVLARDANGRPVRTAGIHLDITERKRLEQQLVAERDYMSRLMETNVSGITALDGDGRIIYANREAEAILGLSAAAVDRRSYADPRWQITAPDGGPLADAELPFTRAMTEGRVVRDVRFAIAWPDGTRRQLSVNAAPLLAEGLQARVVCAITDITEQVATEAALRSAAERAEAASEAKSRFLANMSHEIRTPLNGVLGMAQVLEEELSEPRHRRMLEVIRESGEMLLGVLNDVLDMSKIEAGKVTLEQVAFVPADLARRIEAMHALRAAEKHLSLEVVAAPGAERARLGDPGRVEQMLHNLVGNAVKFTEAGGVRVTLEGGCGPLRVVVHDTGIGMTDDQLARIFEDFEQADGTVTRRFGGTGLGMSIVRRLVALMGGQITVDSIPGAGTQVRVALPLPLAEGGPRDAVPVPAQPLEGLRALAADDNATNRLILQAMLSALGGAVTMVPDGQAAVEAWAPGRFDLILLDISMPGLDGLGALAAIRLREAEAGVPPAPAVAITANAMAHQVAQYMGAGFAAHVGKPFRREDLARTLLRVLDRAPPAQR",
    "product": "Sensor histidine kinase RcsC"
   }
  ],
  "clusters": [
   {
    "start": 21261,
    "end": 32768,
    "tool": "rule-based-clusters",
    "neighbouring_start": 11261,
    "neighbouring_end": 36052,
    "product": "betalactone",
    "category": "other",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 23454,
     "end": 23456,
     "strand": -1,
     "containedBy": [
      "KKHPANEM_02428"
     ]
    }
   ],
   "bindingSites": [
    {
     "loc": 12753,
     "len": 10
    },
    {
     "loc": 28313,
     "len": 12
    }
   ]
  },
  "type": "betalactone",
  "products": [
   "betalactone"
  ],
  "product_categories": [
   "other"
  ],
  "cssClass": "other betalactone",
  "anchor": "r292c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {
 "r218c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000860: 710-5134": {
       "start": 710,
       "end": 5134,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 3539
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 2687
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 4436
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 1713
        },
        {
         "query": "KKHPANEM_01442",
         "subject": "ectR",
         "query_loc": 6799,
         "subject_loc": 987
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ask",
         "start": 3739,
         "end": 5134,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 1440,
         "end": 1986,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 2041,
         "end": 3334,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 3341,
         "end": 3737,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        },
        {
         "locus_tag": "ectR",
         "start": 710,
         "end": 1265,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "KKHPANEM_01442"
         }
        }
       ]
      },
      "BGC0000856: 517-4347": {
       "start": 517,
       "end": 4347,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 2698
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1756
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 3690
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 772
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ask",
         "start": 3033,
         "end": 4347,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 517,
         "end": 1027,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 1087,
         "end": 2425,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 2496,
         "end": 2901,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000859: 258-3305": {
       "start": 258,
       "end": 3305,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 2404
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1485
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 2985
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 517
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ask",
         "start": 2666,
         "end": 3305,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 258,
         "end": 777,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 819,
         "end": 2151,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 2202,
         "end": 2607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000857: 300-4871": {
       "start": 300,
       "end": 4871,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 2372
        },
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 3284
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 4214
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 1394
        },
        {
         "query": "KKHPANEM_01442",
         "subject": "ABY40743.1",
         "query_loc": 6799,
         "subject_loc": 583
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABY40743.1",
         "start": 300,
         "end": 867,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "KKHPANEM_01442"
         }
        },
        {
         "locus_tag": "ask",
         "start": 3557,
         "end": 4871,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 1135,
         "end": 1654,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 1708,
         "end": 3037,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 3082,
         "end": 3487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000855: 245-3455": {
       "start": 245,
       "end": 3455,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 2470
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1442
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 492
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABB30173.1",
         "start": 2999,
         "end": 3455,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ectA",
         "start": 245,
         "end": 740,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 787,
         "end": 2098,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 2268,
         "end": 2673,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000852: 415-2854": {
       "start": 415,
       "end": 2854,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1649
        },
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 2651
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ectA",
         "start": 415,
         "end": 958,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ectB",
         "start": 1009,
         "end": 2290,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 2449,
         "end": 2854,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000854: 838-6879": {
       "start": 838,
       "end": 6879,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 3853
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 2935
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 4837
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 1967
        },
        {
         "query": "KKHPANEM_01442",
         "subject": "ectR",
         "query_loc": 6799,
         "subject_loc": 1109
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ask",
         "start": 4116,
         "end": 5559,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 1708,
         "end": 2227,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 2269,
         "end": 3601,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 3651,
         "end": 4056,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        },
        {
         "locus_tag": "ectR",
         "start": 838,
         "end": 1381,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "KKHPANEM_01442"
         }
        },
        {
         "locus_tag": "phy",
         "start": 5919,
         "end": 6879,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000858: 213-3827": {
       "start": 213,
       "end": 3827,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1328
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 453
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ectA",
         "start": 213,
         "end": 693,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 689,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 1963,
         "end": 2371,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ssf",
         "start": 2453,
         "end": 3827,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000853: 8-3345": {
       "start": 8,
       "end": 3345,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "thpB",
         "query_loc": 5039,
         "subject_loc": 1328
        },
        {
         "query": "KKHPANEM_01439",
         "subject": "thpC",
         "query_loc": 4195,
         "subject_loc": 2245
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "thpA",
         "query_loc": 6005,
         "subject_loc": 273
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "thpA",
         "start": 8,
         "end": 539,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "thpB",
         "start": 697,
         "end": 1960,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "thpC",
         "start": 2046,
         "end": 2445,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        },
        {
         "locus_tag": "thpD",
         "start": 2451,
         "end": 3345,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002052: 188-3620": {
       "start": 188,
       "end": 3620,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "NAI38-5750",
         "query_loc": 5039,
         "subject_loc": 2280
        },
        {
         "query": "KKHPANEM_01439",
         "subject": "NAI38-5749",
         "query_loc": 4195,
         "subject_loc": 1391
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "NAI38-5751",
         "query_loc": 6005,
         "subject_loc": 3335
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "NAI38-5748",
         "start": 188,
         "end": 1088,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NAI38-5749",
         "start": 1183,
         "end": 1600,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        },
        {
         "locus_tag": "NAI38-5750",
         "start": 1646,
         "end": 2915,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "NAI38-5751",
         "start": 3050,
         "end": 3620,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000860: 710-5134": {
       "start": 710,
       "end": 5134,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 3539
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 2687
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 4436
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 1713
        },
        {
         "query": "KKHPANEM_01442",
         "subject": "ectR",
         "query_loc": 6799,
         "subject_loc": 987
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ask",
         "start": 3739,
         "end": 5134,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 1440,
         "end": 1986,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 2041,
         "end": 3334,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 3341,
         "end": 3737,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        },
        {
         "locus_tag": "ectR",
         "start": 710,
         "end": 1265,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "KKHPANEM_01442"
         }
        }
       ]
      },
      "BGC0000856: 517-4347": {
       "start": 517,
       "end": 4347,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 2698
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1756
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 3690
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 772
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ask",
         "start": 3033,
         "end": 4347,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 517,
         "end": 1027,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 1087,
         "end": 2425,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 2496,
         "end": 2901,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000859: 258-3305": {
       "start": 258,
       "end": 3305,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 2404
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1485
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 2985
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 517
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ask",
         "start": 2666,
         "end": 3305,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 258,
         "end": 777,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 819,
         "end": 2151,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 2202,
         "end": 2607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000857: 300-4871": {
       "start": 300,
       "end": 4871,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 2372
        },
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 3284
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 4214
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 1394
        },
        {
         "query": "KKHPANEM_01442",
         "subject": "ABY40743.1",
         "query_loc": 6799,
         "subject_loc": 583
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABY40743.1",
         "start": 300,
         "end": 867,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "KKHPANEM_01442"
         }
        },
        {
         "locus_tag": "ask",
         "start": 3557,
         "end": 4871,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 1135,
         "end": 1654,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 1708,
         "end": 3037,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 3082,
         "end": 3487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000855: 245-3455": {
       "start": 245,
       "end": 3455,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 2470
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1442
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 492
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABB30173.1",
         "start": 2999,
         "end": 3455,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ectA",
         "start": 245,
         "end": 740,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 787,
         "end": 2098,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 2268,
         "end": 2673,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000852: 415-2854": {
       "start": 415,
       "end": 2854,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1649
        },
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 2651
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ectA",
         "start": 415,
         "end": 958,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ectB",
         "start": 1009,
         "end": 2290,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 2449,
         "end": 2854,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        }
       ]
      },
      "BGC0000854: 838-6879": {
       "start": 838,
       "end": 6879,
       "links": [
        {
         "query": "KKHPANEM_01439",
         "subject": "ectC",
         "query_loc": 4195,
         "subject_loc": 3853
        },
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 2935
        },
        {
         "query": "KKHPANEM_01438",
         "subject": "ask",
         "query_loc": 3184,
         "subject_loc": 4837
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 1967
        },
        {
         "query": "KKHPANEM_01442",
         "subject": "ectR",
         "query_loc": 6799,
         "subject_loc": 1109
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ask",
         "start": 4116,
         "end": 5559,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01438"
         }
        },
        {
         "locus_tag": "ectA",
         "start": 1708,
         "end": 2227,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 2269,
         "end": 3601,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 3651,
         "end": 4056,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        },
        {
         "locus_tag": "ectR",
         "start": 838,
         "end": 1381,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "KKHPANEM_01442"
         }
        },
        {
         "locus_tag": "phy",
         "start": 5919,
         "end": 6879,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000858: 213-3827": {
       "start": 213,
       "end": 3827,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "ectB",
         "query_loc": 5039,
         "subject_loc": 1328
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "ectA",
         "query_loc": 6005,
         "subject_loc": 453
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ectA",
         "start": 213,
         "end": 693,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "ectB",
         "start": 689,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "ectC",
         "start": 1963,
         "end": 2371,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ssf",
         "start": 2453,
         "end": 3827,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000853: 8-3345": {
       "start": 8,
       "end": 3345,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "thpB",
         "query_loc": 5039,
         "subject_loc": 1328
        },
        {
         "query": "KKHPANEM_01439",
         "subject": "thpC",
         "query_loc": 4195,
         "subject_loc": 2245
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "thpA",
         "query_loc": 6005,
         "subject_loc": 273
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "thpA",
         "start": 8,
         "end": 539,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        },
        {
         "locus_tag": "thpB",
         "start": 697,
         "end": 1960,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "thpC",
         "start": 2046,
         "end": 2445,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        },
        {
         "locus_tag": "thpD",
         "start": 2451,
         "end": 3345,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002052: 188-3620": {
       "start": 188,
       "end": 3620,
       "links": [
        {
         "query": "KKHPANEM_01440",
         "subject": "NAI38-5750",
         "query_loc": 5039,
         "subject_loc": 2280
        },
        {
         "query": "KKHPANEM_01439",
         "subject": "NAI38-5749",
         "query_loc": 4195,
         "subject_loc": 1391
        },
        {
         "query": "KKHPANEM_01441",
         "subject": "NAI38-5751",
         "query_loc": 6005,
         "subject_loc": 3335
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "NAI38-5748",
         "start": 188,
         "end": 1088,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NAI38-5749",
         "start": 1183,
         "end": 1600,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01439"
         }
        },
        {
         "locus_tag": "NAI38-5750",
         "start": 1646,
         "end": 2915,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01440"
         }
        },
        {
         "locus_tag": "NAI38-5751",
         "start": 3050,
         "end": 3620,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_01441"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.modules.tfbs_finder": [],
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "KKHPANEM_01436": {
     "functions": []
    },
    "KKHPANEM_01437": {
     "functions": []
    },
    "KKHPANEM_01438": {
     "functions": []
    },
    "KKHPANEM_01439": {
     "functions": [
      {
       "description": "ectoine_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "KKHPANEM_01440": {
     "functions": [
      {
       "description": "Aminotran_3",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1013:aminotransferase class-III ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_01441": {
     "functions": []
    },
    "KKHPANEM_01442": {
     "functions": [
      {
       "description": "SMCOG1135:MarR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_01443": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "KKHPANEM_01436",
      "seqLength": 206,
      "domains": [
       {
        "start": 8,
        "end": 45,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004127' target='_blank'>GO:0004127</a>: cytidylate kinase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006139' target='_blank'>GO:0006139</a>: nucleobase-containing compound metabolic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Cytidylate_kin",
        "accession": "PF02224",
        "description": "Cytidylate kinase",
        "evalue": "1.9e-10",
        "score": "41.0"
       },
       {
        "start": 64,
        "end": 201,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004127' target='_blank'>GO:0004127</a>: cytidylate kinase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006139' target='_blank'>GO:0006139</a>: nucleobase-containing compound metabolic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Cytidylate_kin",
        "accession": "PF02224",
        "description": "Cytidylate kinase",
        "evalue": "5e-37",
        "score": "127.8"
       }
      ]
     },
     {
      "id": "KKHPANEM_01437",
      "seqLength": 449,
      "domains": [
       {
        "start": 13,
        "end": 436,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "EPSP_synthase",
        "accession": "PF00275",
        "description": "EPSP synthase (3-phosphoshikimate 1-carboxyvinyltransferase)",
        "evalue": "9.4e-98",
        "score": "327.7"
       }
      ]
     },
     {
      "id": "KKHPANEM_01438",
      "seqLength": 463,
      "domains": [
       {
        "start": 20,
        "end": 283,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AA_kinase",
        "accession": "PF00696",
        "description": "Amino acid kinase family",
        "evalue": "2.2e-20",
        "score": "73.4"
       }
      ]
     },
     {
      "id": "KKHPANEM_01439",
      "seqLength": 127,
      "domains": [
       {
        "start": 0,
        "end": 126,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0033990' target='_blank'>GO:0033990</a>: ectoine synthase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0019491' target='_blank'>GO:0019491</a>: ectoine biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Ectoine_synth",
        "accession": "PF06339",
        "description": "Ectoine synthase",
        "evalue": "1.1e-58",
        "score": "197.0"
       }
      ]
     },
     {
      "id": "KKHPANEM_01440",
      "seqLength": 432,
      "domains": [
       {
        "start": 28,
        "end": 419,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008483' target='_blank'>GO:0008483</a>: transaminase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Aminotran_3",
        "accession": "PF00202",
        "description": "Aminotransferase class-III",
        "evalue": "5.9e-77",
        "score": "259.1"
       }
      ]
     },
     {
      "id": "KKHPANEM_01441",
      "seqLength": 180,
      "domains": [
       {
        "start": 49,
        "end": 135,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Acetyltransf_1",
        "accession": "PF00583",
        "description": "Acetyltransferase (GNAT) family",
        "evalue": "5.5e-11",
        "score": "42.8"
       }
      ]
     },
     {
      "id": "KKHPANEM_01442",
      "seqLength": 162,
      "domains": [
       {
        "start": 31,
        "end": 90,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "MarR",
        "accession": "PF01047",
        "description": "MarR family",
        "evalue": "1.5e-15",
        "score": "56.9"
       }
      ]
     },
     {
      "id": "KKHPANEM_01443",
      "seqLength": 557,
      "domains": [
       {
        "start": 28,
        "end": 494,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004129' target='_blank'>GO:0004129</a>: cytochrome-c oxidase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009060' target='_blank'>GO:0009060</a>: aerobic respiration",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "COX1",
        "accession": "PF00115",
        "description": "Cytochrome C and Quinol oxidase polypeptide I",
        "evalue": "1.8e-150",
        "score": "501.7"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "KKHPANEM_01437",
      "seqLength": 449,
      "domains": [
       {
        "start": 21,
        "end": 443,
        "name": "TIGR01356",
        "description": "aroA: 3-phosphoshikimate 1-carboxyvinyltransferase",
        "accession": "TIGR01356",
        "evalue": "5.1e-115",
        "score": "382.5",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_01440",
      "seqLength": 432,
      "domains": [
       {
        "start": 13,
        "end": 420,
        "name": "TIGR02407",
        "description": "ectoine_ectB: diaminobutyrate--2-oxoglutarate aminotransferase",
        "accession": "TIGR02407",
        "evalue": "8.7e-173",
        "score": "572.6",
        "html_class": "generic-type-other"
       },
       {
        "start": 13,
        "end": 421,
        "name": "TIGR00709",
        "description": "dat: 2,4-diaminobutyrate 4-transaminase",
        "accession": "TIGR00709",
        "evalue": "5.3e-126",
        "score": "418.7",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_01441",
      "seqLength": 180,
      "domains": [
       {
        "start": 17,
        "end": 169,
        "name": "TIGR02406",
        "description": "ectoine_EctA: diaminobutyrate acetyltransferase",
        "accession": "TIGR02406",
        "evalue": "6e-52",
        "score": "173.8",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_01443",
      "seqLength": 557,
      "domains": [
       {
        "start": 20,
        "end": 547,
        "name": "TIGR02891",
        "description": "CtaD_CoxA: cytochrome c oxidase, subunit I",
        "accession": "TIGR02891",
        "evalue": "3.8e-205",
        "score": "680.3",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r237c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000647: 251-2872": {
       "start": 251,
       "end": 2872,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 1029
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 2338
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 1804,
         "end": 2872,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 251,
         "end": 1808,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        }
       ]
      },
      "BGC0000650: 28-7720": {
       "start": 28,
       "end": 7720,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 1284
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABB88947.1",
         "start": 28,
         "end": 541,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABB88953.1",
         "start": 5263,
         "end": 7720,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 2170,
         "end": 3013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 545,
         "end": 2024,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 4532,
         "end": 5303,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYcd",
         "start": 3015,
         "end": 3726,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ispH",
         "start": 3729,
         "end": 4575,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000656: 169-3770": {
       "start": 169,
       "end": 3770,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 2080
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 3302
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 2834,
         "end": 3770,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 1323,
         "end": 2838,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 169,
         "end": 1327,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000648: 1057-11443": {
       "start": 1057,
       "end": 11443,
       "links": [
        {
         "query": "KKHPANEM_01605",
         "subject": "ORF3",
         "query_loc": 1528,
         "subject_loc": 4205
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ORF1",
         "start": 1057,
         "end": 2143,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF2",
         "start": 2150,
         "end": 3704,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF3",
         "start": 3700,
         "end": 4711,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "ORF4",
         "start": 4771,
         "end": 6229,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF5",
         "start": 6225,
         "end": 7152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF6",
         "start": 7148,
         "end": 8261,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF7",
         "start": 8257,
         "end": 8644,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF8",
         "start": 8640,
         "end": 8991,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF9",
         "start": 8987,
         "end": 9665,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carA",
         "start": 9661,
         "end": 10528,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carH",
         "start": 10543,
         "end": 11443,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000640: 2399-8466": {
       "start": 2399,
       "end": 8466,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 6328
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 7530
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 7067,
         "end": 7994,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2399,
         "end": 3305,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 5589,
         "end": 7068,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 4423,
         "end": 5593,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 7908,
         "end": 8466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 3342,
         "end": 4392,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000630: 389-6051": {
       "start": 389,
       "end": 6051,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 3509
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 4715
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 4258,
         "end": 5173,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 5169,
         "end": 6051,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 2756,
         "end": 4262,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 389,
         "end": 1118,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 1599,
         "end": 2760,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 1114,
         "end": 1603,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000646: 60-6380": {
       "start": 60,
       "end": 6380,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "ACI04498.1",
         "query_loc": 510,
         "subject_loc": 3040
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "ACI04499.1",
         "query_loc": 1528,
         "subject_loc": 4262
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACI04496.1",
         "start": 60,
         "end": 1236,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ACI04497.1",
         "start": 1232,
         "end": 2288,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACI04498.1",
         "start": 2280,
         "end": 3801,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "ACI04499.1",
         "start": 3797,
         "end": 4727,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "ACI04500.1",
         "start": 4710,
         "end": 5298,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACI04501.1",
         "start": 5294,
         "end": 6380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000634: 1312-11784": {
       "start": 1312,
       "end": 11784,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 4485
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 5688
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAD99405.1",
         "start": 1312,
         "end": 1648,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAD99410.1",
         "start": 6161,
         "end": 7226,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAD99411.1",
         "start": 7225,
         "end": 8173,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "BAD99416.1",
         "start": 11415,
         "end": 11784,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 5222,
         "end": 6155,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 8132,
         "end": 9029,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtG",
         "start": 10747,
         "end": 11521,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 3744,
         "end": 5226,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 1752,
         "end": 2487,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 2566,
         "end": 3745,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 10187,
         "end": 10673,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 9168,
         "end": 10221,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000643: 363-10046": {
       "start": 363,
       "end": 10046,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 7334
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 6129
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABC50111.1",
         "start": 3744,
         "end": 4596,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC50112.1",
         "start": 4595,
         "end": 5660,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 5663,
         "end": 6596,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2792,
         "end": 3689,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtG",
         "start": 363,
         "end": 1113,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 6592,
         "end": 8077,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 9320,
         "end": 10046,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 8073,
         "end": 9240,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 1187,
         "end": 1673,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 1639,
         "end": 2683,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000664: 0-8391": {
       "start": 0,
       "end": 8391,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "SGR_6829",
         "query_loc": 510,
         "subject_loc": 6355
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "SGR_6828",
         "query_loc": 1528,
         "subject_loc": 5082
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SGR_6824",
         "start": 0,
         "end": 1242,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6825",
         "start": 1238,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6826",
         "start": 1963,
         "end": 3520,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6827",
         "start": 3555,
         "end": 4572,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6828",
         "start": 4568,
         "end": 5597,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "SGR_6829",
         "start": 5593,
         "end": 7117,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "SGR_6830",
         "start": 7113,
         "end": 8391,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000647: 251-2872": {
       "start": 251,
       "end": 2872,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 1029
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 2338
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 1804,
         "end": 2872,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 251,
         "end": 1808,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        }
       ]
      },
      "BGC0000650: 28-7720": {
       "start": 28,
       "end": 7720,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 1284
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABB88947.1",
         "start": 28,
         "end": 541,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABB88953.1",
         "start": 5263,
         "end": 7720,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 2170,
         "end": 3013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 545,
         "end": 2024,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 4532,
         "end": 5303,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYcd",
         "start": 3015,
         "end": 3726,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ispH",
         "start": 3729,
         "end": 4575,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000656: 169-3770": {
       "start": 169,
       "end": 3770,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 2080
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 3302
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 2834,
         "end": 3770,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 1323,
         "end": 2838,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 169,
         "end": 1327,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000648: 1057-11443": {
       "start": 1057,
       "end": 11443,
       "links": [
        {
         "query": "KKHPANEM_01605",
         "subject": "ORF3",
         "query_loc": 1528,
         "subject_loc": 4205
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ORF1",
         "start": 1057,
         "end": 2143,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF2",
         "start": 2150,
         "end": 3704,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF3",
         "start": 3700,
         "end": 4711,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "ORF4",
         "start": 4771,
         "end": 6229,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF5",
         "start": 6225,
         "end": 7152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF6",
         "start": 7148,
         "end": 8261,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF7",
         "start": 8257,
         "end": 8644,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF8",
         "start": 8640,
         "end": 8991,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF9",
         "start": 8987,
         "end": 9665,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carA",
         "start": 9661,
         "end": 10528,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carH",
         "start": 10543,
         "end": 11443,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000640: 2399-8466": {
       "start": 2399,
       "end": 8466,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 6328
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 7530
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 7067,
         "end": 7994,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2399,
         "end": 3305,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 5589,
         "end": 7068,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 4423,
         "end": 5593,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 7908,
         "end": 8466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 3342,
         "end": 4392,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000630: 389-6051": {
       "start": 389,
       "end": 6051,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 3509
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 4715
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 4258,
         "end": 5173,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 5169,
         "end": 6051,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 2756,
         "end": 4262,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 389,
         "end": 1118,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 1599,
         "end": 2760,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 1114,
         "end": 1603,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000646: 60-6380": {
       "start": 60,
       "end": 6380,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "ACI04498.1",
         "query_loc": 510,
         "subject_loc": 3040
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "ACI04499.1",
         "query_loc": 1528,
         "subject_loc": 4262
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACI04496.1",
         "start": 60,
         "end": 1236,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ACI04497.1",
         "start": 1232,
         "end": 2288,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACI04498.1",
         "start": 2280,
         "end": 3801,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "ACI04499.1",
         "start": 3797,
         "end": 4727,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "ACI04500.1",
         "start": 4710,
         "end": 5298,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACI04501.1",
         "start": 5294,
         "end": 6380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000634: 1312-11784": {
       "start": 1312,
       "end": 11784,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 4485
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 5688
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAD99405.1",
         "start": 1312,
         "end": 1648,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAD99410.1",
         "start": 6161,
         "end": 7226,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAD99411.1",
         "start": 7225,
         "end": 8173,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "BAD99416.1",
         "start": 11415,
         "end": 11784,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 5222,
         "end": 6155,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 8132,
         "end": 9029,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtG",
         "start": 10747,
         "end": 11521,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 3744,
         "end": 5226,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 1752,
         "end": 2487,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 2566,
         "end": 3745,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 10187,
         "end": 10673,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 9168,
         "end": 10221,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000643: 363-10046": {
       "start": 363,
       "end": 10046,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "crtI",
         "query_loc": 510,
         "subject_loc": 7334
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "crtB",
         "query_loc": 1528,
         "subject_loc": 6129
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABC50111.1",
         "start": 3744,
         "end": 4596,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC50112.1",
         "start": 4595,
         "end": 5660,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 5663,
         "end": 6596,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2792,
         "end": 3689,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtG",
         "start": 363,
         "end": 1113,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 6592,
         "end": 8077,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 9320,
         "end": 10046,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 8073,
         "end": 9240,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 1187,
         "end": 1673,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 1639,
         "end": 2683,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000664: 0-8391": {
       "start": 0,
       "end": 8391,
       "links": [
        {
         "query": "KKHPANEM_01604",
         "subject": "SGR_6829",
         "query_loc": 510,
         "subject_loc": 6355
        },
        {
         "query": "KKHPANEM_01605",
         "subject": "SGR_6828",
         "query_loc": 1528,
         "subject_loc": 5082
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SGR_6824",
         "start": 0,
         "end": 1242,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6825",
         "start": 1238,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6826",
         "start": 1963,
         "end": 3520,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6827",
         "start": 3555,
         "end": 4572,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6828",
         "start": 4568,
         "end": 5597,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_01605"
         }
        },
        {
         "locus_tag": "SGR_6829",
         "start": 5593,
         "end": 7117,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_01604"
         }
        },
        {
         "locus_tag": "SGR_6830",
         "start": 7113,
         "end": 8391,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.modules.tfbs_finder": [],
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "KKHPANEM_01604": {
     "functions": [
      {
       "description": "SMCOG1222:dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_01605": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "KKHPANEM_01606": {
     "functions": []
    },
    "KKHPANEM_01607": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "KKHPANEM_01604",
      "seqLength": 336,
      "domains": [
       {
        "start": 3,
        "end": 323,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Amino_oxidase",
        "accession": "PF01593",
        "description": "Flavin containing amine oxidoreductase",
        "evalue": "2.6e-12",
        "score": "46.9"
       }
      ]
     },
     {
      "id": "KKHPANEM_01605",
      "seqLength": 354,
      "domains": [
       {
        "start": 23,
        "end": 274,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "2.5e-66",
        "score": "224.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "KKHPANEM_01604",
      "seqLength": 336,
      "domains": [
       {
        "start": 1,
        "end": 332,
        "name": "TIGR02734",
        "description": "crtI_fam: phytoene desaturase",
        "accession": "TIGR02734",
        "evalue": "3.2e-129",
        "score": "429.8",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r273c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000647: 251-2872": {
       "start": 251,
       "end": 2872,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 1029
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 2338
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 1804,
         "end": 2872,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 251,
         "end": 1808,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        }
       ]
      },
      "BGC0000637: 540-9054": {
       "start": 540,
       "end": 9054,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 5649
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAK64297.1",
         "start": 1724,
         "end": 3917,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAK64303.1",
         "start": 8190,
         "end": 9054,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 3913,
         "end": 4828,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 540,
         "end": 1689,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtEb",
         "start": 7318,
         "end": 8182,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 4824,
         "end": 6474,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtYe",
         "start": 6477,
         "end": 6927,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYf",
         "start": 6923,
         "end": 7316,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000656: 169-3770": {
       "start": 169,
       "end": 3770,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 2080
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 3302
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 2834,
         "end": 3770,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 1323,
         "end": 2838,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 169,
         "end": 1327,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000648: 1057-11443": {
       "start": 1057,
       "end": 11443,
       "links": [
        {
         "query": "KKHPANEM_02034",
         "subject": "ORF3",
         "query_loc": 16866,
         "subject_loc": 4205
        },
        {
         "query": "KKHPANEM_02035",
         "subject": "ORF2",
         "query_loc": 18194,
         "subject_loc": 2927
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ORF1",
         "start": 1057,
         "end": 2143,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF2",
         "start": 2150,
         "end": 3704,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "ORF3",
         "start": 3700,
         "end": 4711,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "ORF4",
         "start": 4771,
         "end": 6229,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF5",
         "start": 6225,
         "end": 7152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF6",
         "start": 7148,
         "end": 8261,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF7",
         "start": 8257,
         "end": 8644,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF8",
         "start": 8640,
         "end": 8991,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF9",
         "start": 8987,
         "end": 9665,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carA",
         "start": 9661,
         "end": 10528,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carH",
         "start": 10543,
         "end": 11443,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000646: 60-6380": {
       "start": 60,
       "end": 6380,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "ACI04498.1",
         "query_loc": 18194,
         "subject_loc": 3040
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "ACI04499.1",
         "query_loc": 16866,
         "subject_loc": 4262
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ACI04496.1",
         "start": 60,
         "end": 1236,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ACI04497.1",
         "start": 1232,
         "end": 2288,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACI04498.1",
         "start": 2280,
         "end": 3801,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "ACI04499.1",
         "start": 3797,
         "end": 4727,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "ACI04500.1",
         "start": 4710,
         "end": 5298,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACI04501.1",
         "start": 5294,
         "end": 6380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000630: 389-6051": {
       "start": 389,
       "end": 6051,
       "links": [
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 4715
        },
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 3509
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 4258,
         "end": 5173,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 5169,
         "end": 6051,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 2756,
         "end": 4262,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 389,
         "end": 1118,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 1599,
         "end": 2760,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 1114,
         "end": 1603,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000640: 2399-8466": {
       "start": 2399,
       "end": 8466,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 6328
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 7530
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 7067,
         "end": 7994,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2399,
         "end": 3305,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 5589,
         "end": 7068,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 4423,
         "end": 5593,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 7908,
         "end": 8466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 3342,
         "end": 4392,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000664: 0-8391": {
       "start": 0,
       "end": 8391,
       "links": [
        {
         "query": "KKHPANEM_02034",
         "subject": "SGR_6828",
         "query_loc": 16866,
         "subject_loc": 5082
        },
        {
         "query": "KKHPANEM_02035",
         "subject": "SGR_6829",
         "query_loc": 18194,
         "subject_loc": 6355
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SGR_6824",
         "start": 0,
         "end": 1242,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6825",
         "start": 1238,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6826",
         "start": 1963,
         "end": 3520,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6827",
         "start": 3555,
         "end": 4572,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6828",
         "start": 4568,
         "end": 5597,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "SGR_6829",
         "start": 5593,
         "end": 7117,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "SGR_6830",
         "start": 7113,
         "end": 8391,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000641: 1208-7454": {
       "start": 1208,
       "end": 7454,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 5312
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 6514
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAZ73144.1",
         "start": 6917,
         "end": 7454,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 6049,
         "end": 6979,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 1208,
         "end": 2114,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 4571,
         "end": 6053,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtX",
         "start": 2128,
         "end": 3406,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 3405,
         "end": 4572,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000639: 324-6564": {
       "start": 324,
       "end": 6564,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 4425
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 5627
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 5162,
         "end": 6092,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 324,
         "end": 1230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 3684,
         "end": 5166,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtX",
         "start": 1244,
         "end": 2522,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 2521,
         "end": 3688,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 6030,
         "end": 6564,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000647: 251-2872": {
       "start": 251,
       "end": 2872,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 1029
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 2338
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 1804,
         "end": 2872,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 251,
         "end": 1808,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        }
       ]
      },
      "BGC0000637: 540-9054": {
       "start": 540,
       "end": 9054,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 5649
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAK64297.1",
         "start": 1724,
         "end": 3917,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAK64303.1",
         "start": 8190,
         "end": 9054,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 3913,
         "end": 4828,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 540,
         "end": 1689,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtEb",
         "start": 7318,
         "end": 8182,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 4824,
         "end": 6474,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtYe",
         "start": 6477,
         "end": 6927,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYf",
         "start": 6923,
         "end": 7316,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000656: 169-3770": {
       "start": 169,
       "end": 3770,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 2080
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 3302
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 2834,
         "end": 3770,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 1323,
         "end": 2838,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 169,
         "end": 1327,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000648: 1057-11443": {
       "start": 1057,
       "end": 11443,
       "links": [
        {
         "query": "KKHPANEM_02034",
         "subject": "ORF3",
         "query_loc": 16866,
         "subject_loc": 4205
        },
        {
         "query": "KKHPANEM_02035",
         "subject": "ORF2",
         "query_loc": 18194,
         "subject_loc": 2927
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ORF1",
         "start": 1057,
         "end": 2143,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF2",
         "start": 2150,
         "end": 3704,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "ORF3",
         "start": 3700,
         "end": 4711,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "ORF4",
         "start": 4771,
         "end": 6229,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF5",
         "start": 6225,
         "end": 7152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF6",
         "start": 7148,
         "end": 8261,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF7",
         "start": 8257,
         "end": 8644,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF8",
         "start": 8640,
         "end": 8991,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF9",
         "start": 8987,
         "end": 9665,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carA",
         "start": 9661,
         "end": 10528,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carH",
         "start": 10543,
         "end": 11443,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000646: 60-6380": {
       "start": 60,
       "end": 6380,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "ACI04498.1",
         "query_loc": 18194,
         "subject_loc": 3040
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "ACI04499.1",
         "query_loc": 16866,
         "subject_loc": 4262
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ACI04496.1",
         "start": 60,
         "end": 1236,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ACI04497.1",
         "start": 1232,
         "end": 2288,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACI04498.1",
         "start": 2280,
         "end": 3801,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "ACI04499.1",
         "start": 3797,
         "end": 4727,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "ACI04500.1",
         "start": 4710,
         "end": 5298,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACI04501.1",
         "start": 5294,
         "end": 6380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000630: 389-6051": {
       "start": 389,
       "end": 6051,
       "links": [
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 4715
        },
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 3509
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 4258,
         "end": 5173,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 5169,
         "end": 6051,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 2756,
         "end": 4262,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 389,
         "end": 1118,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 1599,
         "end": 2760,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 1114,
         "end": 1603,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000640: 2399-8466": {
       "start": 2399,
       "end": 8466,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 6328
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 7530
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 7067,
         "end": 7994,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2399,
         "end": 3305,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 5589,
         "end": 7068,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 4423,
         "end": 5593,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 7908,
         "end": 8466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 3342,
         "end": 4392,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000664: 0-8391": {
       "start": 0,
       "end": 8391,
       "links": [
        {
         "query": "KKHPANEM_02034",
         "subject": "SGR_6828",
         "query_loc": 16866,
         "subject_loc": 5082
        },
        {
         "query": "KKHPANEM_02035",
         "subject": "SGR_6829",
         "query_loc": 18194,
         "subject_loc": 6355
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SGR_6824",
         "start": 0,
         "end": 1242,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6825",
         "start": 1238,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6826",
         "start": 1963,
         "end": 3520,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6827",
         "start": 3555,
         "end": 4572,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6828",
         "start": 4568,
         "end": 5597,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "SGR_6829",
         "start": 5593,
         "end": 7117,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "SGR_6830",
         "start": 7113,
         "end": 8391,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000641: 1208-7454": {
       "start": 1208,
       "end": 7454,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 5312
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 6514
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAZ73144.1",
         "start": 6917,
         "end": 7454,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 6049,
         "end": 6979,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 1208,
         "end": 2114,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 4571,
         "end": 6053,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtX",
         "start": 2128,
         "end": 3406,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 3405,
         "end": 4572,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000639: 324-6564": {
       "start": 324,
       "end": 6564,
       "links": [
        {
         "query": "KKHPANEM_02035",
         "subject": "crtI",
         "query_loc": 18194,
         "subject_loc": 4425
        },
        {
         "query": "KKHPANEM_02034",
         "subject": "crtB",
         "query_loc": 16866,
         "subject_loc": 5627
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 5162,
         "end": 6092,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "KKHPANEM_02034"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 324,
         "end": 1230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 3684,
         "end": 5166,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02035"
         }
        },
        {
         "locus_tag": "crtX",
         "start": 1244,
         "end": 2522,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 2521,
         "end": 3688,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtZ",
         "start": 6030,
         "end": 6564,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.modules.tfbs_finder": [
   {
    "name": "NrtR",
    "start": 11858,
    "end": 11879,
    "confidence": "weak",
    "score": 18.831539098702418,
    "presequence": "ATG",
    "sequence": "TCGTGGTCATGTTGACGGCAT",
    "postsequence": "GAG",
    "target": "TAATCGTCANNNYGACNANAA",
    "strand": -1,
    "matches": [
     true,
     false,
     false,
     true,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     true,
     true,
     false
    ],
    "left": {
     "name": "KKHPANEM_02028",
     "location": 11779,
     "strand": 1
    },
    "contained_by_left": false,
    "right": {
     "name": "KKHPANEM_02029",
     "location": 11877,
     "strand": 1
    }
   }
  ],
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "KKHPANEM_02026": {
     "functions": []
    },
    "KKHPANEM_02027": {
     "functions": []
    },
    "KKHPANEM_02028": {
     "functions": []
    },
    "KKHPANEM_02029": {
     "functions": [
      {
       "description": "ubiA",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "KKHPANEM_02030": {
     "functions": []
    },
    "KKHPANEM_02031": {
     "functions": [
      {
       "description": "SMCOG1161:oxidoreductase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_02032": {
     "functions": []
    },
    "KKHPANEM_02033": {
     "functions": []
    },
    "KKHPANEM_02034": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "KKHPANEM_02035": {
     "functions": [
      {
       "description": "SMCOG1222:dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_02036": {
     "functions": []
    },
    "KKHPANEM_02037": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "KKHPANEM_02026",
      "seqLength": 233,
      "domains": [
       {
        "start": 18,
        "end": 169,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF3108",
        "accession": "PF11306",
        "description": "Protein of unknown function (DUF3108)",
        "evalue": "1.5e-11",
        "score": "44.8"
       }
      ]
     },
     {
      "id": "KKHPANEM_02027",
      "seqLength": 853,
      "domains": [
       {
        "start": 105,
        "end": 181,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Peptidase_M1_N",
        "accession": "PF17900",
        "description": "Peptidase M1 N-terminal domain",
        "evalue": "1.1e-08",
        "score": "35.6"
       },
       {
        "start": 219,
        "end": 433,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008237' target='_blank'>GO:0008237</a>: metallopeptidase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding"
        ],
        "html_class": "generic-type-other",
        "name": "Peptidase_M1",
        "accession": "PF01433",
        "description": "Peptidase family M1 domain",
        "evalue": "8.3e-51",
        "score": "172.7"
       },
       {
        "start": 438,
        "end": 532,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF3458",
        "accession": "PF11940",
        "description": "Domain of unknown function (DUF3458) Ig-like fold",
        "evalue": "6.5e-29",
        "score": "100.3"
       },
       {
        "start": 536,
        "end": 852,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF3458_C",
        "accession": "PF17432",
        "description": "Domain of unknown function (DUF3458_C) ARM repeats",
        "evalue": "3.7e-105",
        "score": "351.9"
       }
      ]
     },
     {
      "id": "KKHPANEM_02028",
      "seqLength": 507,
      "domains": [
       {
        "start": 3,
        "end": 129,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DNA_photolyase",
        "accession": "PF00875",
        "description": "DNA photolyase",
        "evalue": "3.4e-27",
        "score": "95.5"
       },
       {
        "start": 262,
        "end": 455,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "FAD_binding_7",
        "accession": "PF03441",
        "description": "FAD binding domain of DNA photolyase",
        "evalue": "1.2e-53",
        "score": "181.8"
       }
      ]
     },
     {
      "id": "KKHPANEM_02029",
      "seqLength": 298,
      "domains": [
       {
        "start": 38,
        "end": 275,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "UbiA",
        "accession": "PF01040",
        "description": "UbiA prenyltransferase family",
        "evalue": "5.2e-39",
        "score": "134.1"
       }
      ]
     },
     {
      "id": "KKHPANEM_02030",
      "seqLength": 434,
      "domains": [
       {
        "start": 30,
        "end": 420,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PUCC",
        "accession": "PF03209",
        "description": "PUCC protein",
        "evalue": "1.6e-113",
        "score": "379.8"
       }
      ]
     },
     {
      "id": "KKHPANEM_02031",
      "seqLength": 397,
      "domains": [
       {
        "start": 2,
        "end": 152,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Pyr_redox_2",
        "accession": "PF07992",
        "description": "Pyridine nucleotide-disulphide oxidoreductase",
        "evalue": "4.8e-09",
        "score": "36.0"
       }
      ]
     },
     {
      "id": "KKHPANEM_02032",
      "seqLength": 176,
      "domains": [
       {
        "start": 26,
        "end": 158,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "NUDIX",
        "accession": "PF00293",
        "description": "NUDIX domain",
        "evalue": "8.8e-22",
        "score": "77.6"
       }
      ]
     },
     {
      "id": "KKHPANEM_02033",
      "seqLength": 157,
      "domains": [
       {
        "start": 9,
        "end": 145,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "TspO_MBR",
        "accession": "PF03073",
        "description": "TspO/MBR family",
        "evalue": "3.9e-41",
        "score": "140.3"
       }
      ]
     },
     {
      "id": "KKHPANEM_02034",
      "seqLength": 369,
      "domains": [
       {
        "start": 32,
        "end": 279,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "3.2e-63",
        "score": "213.8"
       }
      ]
     },
     {
      "id": "KKHPANEM_02035",
      "seqLength": 517,
      "domains": [
       {
        "start": 27,
        "end": 501,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Amino_oxidase",
        "accession": "PF01593",
        "description": "Flavin containing amine oxidoreductase",
        "evalue": "1e-31",
        "score": "110.8"
       }
      ]
     },
     {
      "id": "KKHPANEM_02037",
      "seqLength": 334,
      "domains": [
       {
        "start": 6,
        "end": 180,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Mg_chelatase",
        "accession": "PF01078",
        "description": "Magnesium chelatase, subunit ChlI",
        "evalue": "3.2e-14",
        "score": "52.9"
       },
       {
        "start": 260,
        "end": 320,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AAA_lid_2",
        "accession": "PF17863",
        "description": "AAA lid domain",
        "evalue": "1.6e-18",
        "score": "66.4"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "KKHPANEM_02027",
      "seqLength": 853,
      "domains": [
       {
        "start": 12,
        "end": 851,
        "name": "TIGR02414",
        "description": "pepN_proteo: aminopeptidase N",
        "accession": "TIGR02414",
        "evalue": "0",
        "score": "1092.9",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_02029",
      "seqLength": 298,
      "domains": [
       {
        "start": 16,
        "end": 296,
        "name": "TIGR01476",
        "description": "chlor_syn_BchG: bacteriochlorophyll/chlorophyll synthetase",
        "accession": "TIGR01476",
        "evalue": "8.9e-114",
        "score": "377.6",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_02031",
      "seqLength": 397,
      "domains": [
       {
        "start": 2,
        "end": 388,
        "name": "TIGR02023",
        "description": "BchP-ChlP: geranylgeranyl reductase",
        "accession": "TIGR02023",
        "evalue": "5.1e-161",
        "score": "533.9",
        "html_class": "generic-type-other"
       },
       {
        "start": 2,
        "end": 300,
        "name": "TIGR02032",
        "description": "GG-red-SF: geranylgeranyl reductase family",
        "accession": "TIGR02032",
        "evalue": "5e-76",
        "score": "254.2",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_02032",
      "seqLength": 176,
      "domains": [
       {
        "start": 16,
        "end": 161,
        "name": "TIGR02150",
        "description": "IPP_isom_1: isopentenyl-diphosphate delta-isomerase",
        "accession": "TIGR02150",
        "evalue": "1.1e-35",
        "score": "120.8",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_02035",
      "seqLength": 517,
      "domains": [
       {
        "start": 20,
        "end": 511,
        "name": "TIGR02734",
        "description": "crtI_fam: phytoene desaturase",
        "accession": "TIGR02734",
        "evalue": "4.8e-193",
        "score": "640.4",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_02037",
      "seqLength": 334,
      "domains": [
       {
        "start": 4,
        "end": 333,
        "name": "TIGR02030",
        "description": "BchI-ChlI: magnesium chelatase ATPase subunit I",
        "accession": "TIGR02030",
        "evalue": "1.2e-165",
        "score": "548.5",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r292c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002405: 17312-42861": {
       "start": 17312,
       "end": 42861,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "LOC101250819",
         "query_loc": 32004,
         "subject_loc": 18247
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "LOC101246842",
         "start": 24022,
         "end": 25318,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "LOC101250233",
         "start": 34000,
         "end": 36165,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "LOC101250819",
         "start": 17312,
         "end": 19183,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        },
        {
         "locus_tag": "LOC109120718",
         "start": 42069,
         "end": 42861,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001137: 0-18476": {
       "start": 0,
       "end": 18476,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "AGL76720.1",
         "query_loc": 32004,
         "subject_loc": 12636
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AGL76713.1",
         "start": 0,
         "end": 3744,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76714.1",
         "start": 3890,
         "end": 5612,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76715.1",
         "start": 5847,
         "end": 6327,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76716.1",
         "start": 6323,
         "end": 7064,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76717.1",
         "start": 7244,
         "end": 8774,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76718.1",
         "start": 8826,
         "end": 10764,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76719.1",
         "start": 10841,
         "end": 11543,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "AGL76720.1",
         "start": 11892,
         "end": 13380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        },
        {
         "locus_tag": "AGL76721.1",
         "start": 13463,
         "end": 14408,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76722.1",
         "start": 14461,
         "end": 16114,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76723.1",
         "start": 16360,
         "end": 17242,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76724.1",
         "start": 17238,
         "end": 17892,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76725.1",
         "start": 17927,
         "end": 18476,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      },
      "BGC0000867: 21-5822": {
       "start": 21,
       "end": 5822,
       "links": [
        {
         "query": "KKHPANEM_02434",
         "subject": "phaB",
         "query_loc": 30843,
         "subject_loc": 334
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAG30257.1",
         "start": 1370,
         "end": 1715,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAG30261.1",
         "start": 2152,
         "end": 3136,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "phaA",
         "start": 2017,
         "end": 3202,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "phaB",
         "start": 21,
         "end": 648,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02434"
         }
        },
        {
         "locus_tag": "phaC",
         "start": 4754,
         "end": 5822,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "phaE",
         "start": 3623,
         "end": 4739,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "phaP",
         "start": 843,
         "end": 1215,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000866: 467-5165": {
       "start": 467,
       "end": 5165,
       "links": [
        {
         "query": "KKHPANEM_02434",
         "subject": "AAF23366.1",
         "query_loc": 30843,
         "subject_loc": 4107
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAF23364.1",
         "start": 467,
         "end": 2345,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAF23365.1",
         "start": 2443,
         "end": 3625,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAF23366.1",
         "start": 3737,
         "end": 4478,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02434"
         }
        },
        {
         "locus_tag": "AAF23367.1",
         "start": 4598,
         "end": 5165,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000933: 0-5189": {
       "start": 0,
       "end": 5189,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "AGY49247.1",
         "query_loc": 32004,
         "subject_loc": 781
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AGY49245.1",
         "start": 2794,
         "end": 3385,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGY49246.1",
         "start": 3393,
         "end": 4815,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGY49247.1",
         "start": 0,
         "end": 1563,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        },
        {
         "locus_tag": "AGY49248.1",
         "start": 1787,
         "end": 2729,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGY49249.1",
         "start": 4814,
         "end": 5189,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000231: 189-5010": {
       "start": 189,
       "end": 5010,
       "links": [
        {
         "query": "KKHPANEM_02434",
         "subject": "CAA54861.1",
         "query_loc": 30843,
         "subject_loc": 3593
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "CAA54858.1",
         "start": 189,
         "end": 1458,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "CAA54859.1",
         "start": 1454,
         "end": 2693,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "CAA54860.1",
         "start": 2808,
         "end": 3078,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "CAA54861.1",
         "start": 3200,
         "end": 3986,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02434"
         }
        },
        {
         "locus_tag": "CAA54862.1",
         "start": 4050,
         "end": 5010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001534: 799-5264": {
       "start": 799,
       "end": 5264,
       "links": [
        {
         "query": "KKHPANEM_02420",
         "subject": "bkdC2",
         "query_loc": 14862,
         "subject_loc": 1526
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "bkdA2",
         "start": 3263,
         "end": 4424,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "bkdB2",
         "start": 2235,
         "end": 3252,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "bkdC2",
         "start": 799,
         "end": 2254,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_02420"
         }
        },
        {
         "locus_tag": "bkdR",
         "start": 4685,
         "end": 5264,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      },
      "BGC0000888: 0-4342": {
       "start": 0,
       "end": 4342,
       "links": [
        {
         "query": "KKHPANEM_02434",
         "subject": "bacC",
         "query_loc": 30843,
         "subject_loc": 1578
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "bacA",
         "start": 0,
         "end": 501,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "bacB",
         "start": 490,
         "end": 1201,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "bacC",
         "start": 1197,
         "end": 1959,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02434"
         }
        },
        {
         "locus_tag": "bacD",
         "start": 1976,
         "end": 3395,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "bacE",
         "start": 3391,
         "end": 4342,
         "strand": 1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0000649: 148-10747": {
       "start": 148,
       "end": 10747,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "fadD",
         "query_loc": 32004,
         "subject_loc": 959
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 5136,
         "end": 6165,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 2342,
         "end": 3620,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 3616,
         "end": 5140,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtT",
         "start": 8780,
         "end": 9509,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 7227,
         "end": 8781,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 6161,
         "end": 7178,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 9505,
         "end": 10747,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "fadD",
         "start": 148,
         "end": 1771,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        }
       ]
      },
      "BGC0000595: 0-21771": {
       "start": 0,
       "end": 21771,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "SCO2444",
         "query_loc": 32004,
         "subject_loc": 6979
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SCO2438",
         "start": 0,
         "end": 1407,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCO2439",
         "start": 1464,
         "end": 2325,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2440",
         "start": 2321,
         "end": 3095,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "SCO2441",
         "start": 3221,
         "end": 3824,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2442",
         "start": 3848,
         "end": 4556,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "SCO2443",
         "start": 4765,
         "end": 6163,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2444",
         "start": 6250,
         "end": 7708,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        },
        {
         "locus_tag": "SCO2445",
         "start": 7700,
         "end": 9077,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCO2446",
         "start": 9345,
         "end": 13008,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCO2447",
         "start": 13186,
         "end": 13648,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2448",
         "start": 13644,
         "end": 15309,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2449",
         "start": 15447,
         "end": 16470,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2450",
         "start": 16469,
         "end": 20519,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "SCO2451",
         "start": 20688,
         "end": 21771,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002405: 17312-42861": {
       "start": 17312,
       "end": 42861,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "LOC101250819",
         "query_loc": 32004,
         "subject_loc": 18247
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "LOC101246842",
         "start": 24022,
         "end": 25318,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "LOC101250233",
         "start": 34000,
         "end": 36165,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "LOC101250819",
         "start": 17312,
         "end": 19183,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        },
        {
         "locus_tag": "LOC109120718",
         "start": 42069,
         "end": 42861,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001137: 0-18476": {
       "start": 0,
       "end": 18476,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "AGL76720.1",
         "query_loc": 32004,
         "subject_loc": 12636
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AGL76713.1",
         "start": 0,
         "end": 3744,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76714.1",
         "start": 3890,
         "end": 5612,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76715.1",
         "start": 5847,
         "end": 6327,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76716.1",
         "start": 6323,
         "end": 7064,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76717.1",
         "start": 7244,
         "end": 8774,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76718.1",
         "start": 8826,
         "end": 10764,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76719.1",
         "start": 10841,
         "end": 11543,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "AGL76720.1",
         "start": 11892,
         "end": 13380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        },
        {
         "locus_tag": "AGL76721.1",
         "start": 13463,
         "end": 14408,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76722.1",
         "start": 14461,
         "end": 16114,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76723.1",
         "start": 16360,
         "end": 17242,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76724.1",
         "start": 17238,
         "end": 17892,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76725.1",
         "start": 17927,
         "end": 18476,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      },
      "BGC0000867: 21-5822": {
       "start": 21,
       "end": 5822,
       "links": [
        {
         "query": "KKHPANEM_02434",
         "subject": "phaB",
         "query_loc": 30843,
         "subject_loc": 334
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAG30257.1",
         "start": 1370,
         "end": 1715,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAG30261.1",
         "start": 2152,
         "end": 3136,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "phaA",
         "start": 2017,
         "end": 3202,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "phaB",
         "start": 21,
         "end": 648,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02434"
         }
        },
        {
         "locus_tag": "phaC",
         "start": 4754,
         "end": 5822,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "phaE",
         "start": 3623,
         "end": 4739,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "phaP",
         "start": 843,
         "end": 1215,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000866: 467-5165": {
       "start": 467,
       "end": 5165,
       "links": [
        {
         "query": "KKHPANEM_02434",
         "subject": "AAF23366.1",
         "query_loc": 30843,
         "subject_loc": 4107
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAF23364.1",
         "start": 467,
         "end": 2345,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAF23365.1",
         "start": 2443,
         "end": 3625,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAF23366.1",
         "start": 3737,
         "end": 4478,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02434"
         }
        },
        {
         "locus_tag": "AAF23367.1",
         "start": 4598,
         "end": 5165,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000933: 0-5189": {
       "start": 0,
       "end": 5189,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "AGY49247.1",
         "query_loc": 32004,
         "subject_loc": 781
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AGY49245.1",
         "start": 2794,
         "end": 3385,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGY49246.1",
         "start": 3393,
         "end": 4815,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGY49247.1",
         "start": 0,
         "end": 1563,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        },
        {
         "locus_tag": "AGY49248.1",
         "start": 1787,
         "end": 2729,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGY49249.1",
         "start": 4814,
         "end": 5189,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000231: 189-5010": {
       "start": 189,
       "end": 5010,
       "links": [
        {
         "query": "KKHPANEM_02434",
         "subject": "CAA54861.1",
         "query_loc": 30843,
         "subject_loc": 3593
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "CAA54858.1",
         "start": 189,
         "end": 1458,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "CAA54859.1",
         "start": 1454,
         "end": 2693,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "CAA54860.1",
         "start": 2808,
         "end": 3078,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "CAA54861.1",
         "start": 3200,
         "end": 3986,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02434"
         }
        },
        {
         "locus_tag": "CAA54862.1",
         "start": 4050,
         "end": 5010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001534: 799-5264": {
       "start": 799,
       "end": 5264,
       "links": [
        {
         "query": "KKHPANEM_02420",
         "subject": "bkdC2",
         "query_loc": 14862,
         "subject_loc": 1526
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "bkdA2",
         "start": 3263,
         "end": 4424,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "bkdB2",
         "start": 2235,
         "end": 3252,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "bkdC2",
         "start": 799,
         "end": 2254,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "KKHPANEM_02420"
         }
        },
        {
         "locus_tag": "bkdR",
         "start": 4685,
         "end": 5264,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      },
      "BGC0000888: 0-4342": {
       "start": 0,
       "end": 4342,
       "links": [
        {
         "query": "KKHPANEM_02434",
         "subject": "bacC",
         "query_loc": 30843,
         "subject_loc": 1578
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "bacA",
         "start": 0,
         "end": 501,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "bacB",
         "start": 490,
         "end": 1201,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "bacC",
         "start": 1197,
         "end": 1959,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02434"
         }
        },
        {
         "locus_tag": "bacD",
         "start": 1976,
         "end": 3395,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "bacE",
         "start": 3391,
         "end": 4342,
         "strand": 1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0000649: 148-10747": {
       "start": 148,
       "end": 10747,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "fadD",
         "query_loc": 32004,
         "subject_loc": 959
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 5136,
         "end": 6165,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 2342,
         "end": 3620,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 3616,
         "end": 5140,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtT",
         "start": 8780,
         "end": 9509,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 7227,
         "end": 8781,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 6161,
         "end": 7178,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 9505,
         "end": 10747,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "fadD",
         "start": 148,
         "end": 1771,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        }
       ]
      },
      "BGC0000595: 0-21771": {
       "start": 0,
       "end": 21771,
       "links": [
        {
         "query": "KKHPANEM_02435",
         "subject": "SCO2444",
         "query_loc": 32004,
         "subject_loc": 6979
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SCO2438",
         "start": 0,
         "end": 1407,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCO2439",
         "start": 1464,
         "end": 2325,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2440",
         "start": 2321,
         "end": 3095,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "SCO2441",
         "start": 3221,
         "end": 3824,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2442",
         "start": 3848,
         "end": 4556,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "SCO2443",
         "start": 4765,
         "end": 6163,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2444",
         "start": 6250,
         "end": 7708,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "KKHPANEM_02435"
         }
        },
        {
         "locus_tag": "SCO2445",
         "start": 7700,
         "end": 9077,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCO2446",
         "start": 9345,
         "end": 13008,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCO2447",
         "start": 13186,
         "end": 13648,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2448",
         "start": 13644,
         "end": 15309,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2449",
         "start": 15447,
         "end": 16470,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCO2450",
         "start": 16469,
         "end": 20519,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "SCO2451",
         "start": 20688,
         "end": 21771,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.modules.tfbs_finder": [
   {
    "name": "AbrC3",
    "start": 12753,
    "end": 12763,
    "confidence": "strong",
    "score": 18.15655576909236,
    "presequence": "GAA",
    "sequence": "GGCCGCCTTC",
    "postsequence": "CAG",
    "target": "SGYCGCSTTC",
    "strand": -1,
    "matches": [
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true
    ],
    "left": null,
    "contained_by_left": false,
    "right": {
     "name": "KKHPANEM_02420",
     "location": 14087,
     "strand": 1
    }
   },
   {
    "name": "ZuR",
    "start": 22874,
    "end": 22889,
    "confidence": "weak",
    "score": 19.283835060230434,
    "presequence": "TAT",
    "sequence": "TGATTGTCATTTCCC",
    "postsequence": "TCA",
    "target": "TGAANNTCATTTTCA",
    "strand": 1,
    "matches": [
     true,
     true,
     true,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     true,
     false
    ],
    "left": {
     "name": "KKHPANEM_02427",
     "location": 22884,
     "strand": -1
    },
    "contained_by_left": false,
    "right": {
     "name": "KKHPANEM_02428",
     "location": 22940,
     "strand": -1
    }
   },
   {
    "name": "AfsR",
    "start": 28313,
    "end": 28325,
    "confidence": "strong",
    "score": 21.398984176481,
    "presequence": "GGG",
    "sequence": "GCGTTCATGTCC",
    "postsequence": "CGC",
    "target": "GCGTTCATTTAC",
    "strand": -1,
    "matches": [
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     true,
     false,
     true
    ],
    "left": {
     "name": "KKHPANEM_02431",
     "location": 28062,
     "strand": -1
    },
    "contained_by_left": false,
    "right": {
     "name": "KKHPANEM_02432",
     "location": 28926,
     "strand": -1
    }
   }
  ],
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "KKHPANEM_02420": {
     "functions": []
    },
    "KKHPANEM_02421": {
     "functions": []
    },
    "KKHPANEM_02422": {
     "functions": []
    },
    "KKHPANEM_02423": {
     "functions": [
      {
       "description": "SMCOG1175:pyridine nucleotide-disulfide oxidoreductase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_02424": {
     "functions": []
    },
    "KKHPANEM_02425": {
     "functions": []
    },
    "KKHPANEM_02426": {
     "functions": []
    },
    "KKHPANEM_02427": {
     "functions": [
      {
       "description": "HMGL-like",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1271:2-isopropylmalate synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_02428": {
     "functions": []
    },
    "KKHPANEM_02429": {
     "functions": []
    },
    "KKHPANEM_02430": {
     "functions": []
    },
    "KKHPANEM_02431": {
     "functions": []
    },
    "KKHPANEM_02432": {
     "functions": []
    },
    "KKHPANEM_02433": {
     "functions": []
    },
    "KKHPANEM_02434": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_02435": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "KKHPANEM_02436": {
     "functions": [
      {
       "description": "SMCOG1008:response regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "KKHPANEM_02420",
      "seqLength": 516,
      "domains": [
       {
        "start": 3,
        "end": 76,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Biotin_lipoyl",
        "accession": "PF00364",
        "description": "Biotin-requiring enzyme",
        "evalue": "2e-22",
        "score": "78.9"
       },
       {
        "start": 104,
        "end": 177,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Biotin_lipoyl",
        "accession": "PF00364",
        "description": "Biotin-requiring enzyme",
        "evalue": "4.4e-21",
        "score": "74.6"
       },
       {
        "start": 216,
        "end": 247,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity"
        ],
        "html_class": "generic-type-other",
        "name": "E3_binding",
        "accession": "PF02817",
        "description": "e3 binding domain",
        "evalue": "2.7e-09",
        "score": "37.3"
       },
       {
        "start": 285,
        "end": 514,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "2-oxoacid_dh",
        "accession": "PF00198",
        "description": "2-oxoacid dehydrogenases acyltransferase (catalytic domain)",
        "evalue": "1.6e-80",
        "score": "270.0"
       }
      ]
     },
     {
      "id": "KKHPANEM_02422",
      "seqLength": 135,
      "domains": [
       {
        "start": 10,
        "end": 134,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "MAPEG",
        "accession": "PF01124",
        "description": "MAPEG family",
        "evalue": "6.1e-23",
        "score": "81.2"
       }
      ]
     },
     {
      "id": "KKHPANEM_02423",
      "seqLength": 462,
      "domains": [
       {
        "start": 3,
        "end": 324,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Pyr_redox_2",
        "accession": "PF07992",
        "description": "Pyridine nucleotide-disulphide oxidoreductase",
        "evalue": "5.4e-64",
        "score": "216.4"
       },
       {
        "start": 342,
        "end": 452,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Pyr_redox_dim",
        "accession": "PF02852",
        "description": "Pyridine nucleotide-disulphide oxidoreductase, dimerisation domain",
        "evalue": "5.4e-40",
        "score": "136.2"
       }
      ]
     },
     {
      "id": "KKHPANEM_02424",
      "seqLength": 558,
      "domains": [
       {
        "start": 230,
        "end": 526,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "RmuC",
        "accession": "PF02646",
        "description": "RmuC family",
        "evalue": "1.5e-96",
        "score": "323.0"
       }
      ]
     },
     {
      "id": "KKHPANEM_02426",
      "seqLength": 217,
      "domains": [
       {
        "start": 0,
        "end": 185,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "CTP_transf_3",
        "accession": "PF02348",
        "description": "Cytidylyltransferase",
        "evalue": "3.3e-19",
        "score": "69.8"
       }
      ]
     },
     {
      "id": "KKHPANEM_02427",
      "seqLength": 540,
      "domains": [
       {
        "start": 136,
        "end": 254,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "HMGL-like",
        "accession": "PF00682",
        "description": "HMGL-like",
        "evalue": "1.6e-20",
        "score": "73.9"
       }
      ]
     },
     {
      "id": "KKHPANEM_02430",
      "seqLength": 147,
      "domains": [
       {
        "start": 22,
        "end": 140,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TerB",
        "accession": "PF05099",
        "description": "Tellurite resistance protein TerB",
        "evalue": "2e-25",
        "score": "89.5"
       }
      ]
     },
     {
      "id": "KKHPANEM_02431",
      "seqLength": 557,
      "domains": [
       {
        "start": 59,
        "end": 545,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004347' target='_blank'>GO:0004347</a>: glucose-6-phosphate isomerase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006094' target='_blank'>GO:0006094</a>: gluconeogenesis",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006096' target='_blank'>GO:0006096</a>: glycolytic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "PGI",
        "accession": "PF00342",
        "description": "Phosphoglucose isomerase",
        "evalue": "3e-186",
        "score": "619.9"
       }
      ]
     },
     {
      "id": "KKHPANEM_02434",
      "seqLength": 267,
      "domains": [
       {
        "start": 12,
        "end": 265,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short_C2",
        "accession": "PF13561",
        "description": "Enoyl-(Acyl carrier protein) reductase",
        "evalue": "9.8e-50",
        "score": "169.4"
       }
      ]
     },
     {
      "id": "KKHPANEM_02435",
      "seqLength": 508,
      "domains": [
       {
        "start": 8,
        "end": 406,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "1.4e-85",
        "score": "287.6"
       },
       {
        "start": 414,
        "end": 488,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AMP-binding_C",
        "accession": "PF13193",
        "description": "AMP-binding enzyme C-terminal domain",
        "evalue": "1.5e-18",
        "score": "67.6"
       }
      ]
     },
     {
      "id": "KKHPANEM_02436",
      "seqLength": 1074,
      "domains": [
       {
        "start": 62,
        "end": 171,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PAS_4",
        "accession": "PF08448",
        "description": "PAS fold",
        "evalue": "9.9e-14",
        "score": "51.6"
       },
       {
        "start": 194,
        "end": 309,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PAS_7",
        "accession": "PF12860",
        "description": "PAS fold",
        "evalue": "9.9e-17",
        "score": "61.2"
       },
       {
        "start": 333,
        "end": 422,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "PAS_3",
        "accession": "PF08447",
        "description": "PAS fold",
        "evalue": "5e-20",
        "score": "71.7"
       },
       {
        "start": 456,
        "end": 546,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "PAS_3",
        "accession": "PF08447",
        "description": "PAS fold",
        "evalue": "2.6e-19",
        "score": "69.4"
       },
       {
        "start": 565,
        "end": 681,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-other",
        "name": "PAS",
        "accession": "PF00989",
        "description": "PAS fold",
        "evalue": "1.1e-09",
        "score": "38.4"
       },
       {
        "start": 703,
        "end": 769,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000155' target='_blank'>GO:0000155</a>: phosphorelay sensor kinase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007165' target='_blank'>GO:0007165</a>: signal transduction"
        ],
        "html_class": "generic-type-regulatory",
        "name": "HisKA",
        "accession": "PF00512",
        "description": "His Kinase A (phospho-acceptor) domain",
        "evalue": "3.4e-19",
        "score": "68.7"
       },
       {
        "start": 815,
        "end": 926,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "HATPase_c",
        "accession": "PF02518",
        "description": "Histidine kinase-, DNA gyrase B-, and HSP90-like ATPase",
        "evalue": "3.6e-28",
        "score": "98.4"
       },
       {
        "start": 948,
        "end": 1060,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system"
        ],
        "html_class": "generic-type-regulatory",
        "name": "Response_reg",
        "accession": "PF00072",
        "description": "Response regulator receiver domain",
        "evalue": "2.2e-17",
        "score": "63.3"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "KKHPANEM_02420",
      "seqLength": 516,
      "domains": [
       {
        "start": 103,
        "end": 515,
        "name": "TIGR01347",
        "description": "sucB: dihydrolipoyllysine-residue succinyltransferase, E2 component of oxoglutarate dehydrogenase (succiny",
        "accession": "TIGR01347",
        "evalue": "2.7e-168",
        "score": "558.3",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_02423",
      "seqLength": 462,
      "domains": [
       {
        "start": 2,
        "end": 461,
        "name": "TIGR01350",
        "description": "lipoamide_DH: dihydrolipoyl dehydrogenase",
        "accession": "TIGR01350",
        "evalue": "6.9e-167",
        "score": "553.7",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_02432",
      "seqLength": 269,
      "domains": [
       {
        "start": 242,
        "end": 266,
        "name": "TIGR03370",
        "description": "VPLPA-CTERM: VPLPA-CTERM protein sorting domain",
        "accession": "TIGR03370",
        "evalue": "6.3e-07",
        "score": "27.3",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "KKHPANEM_02436",
      "seqLength": 1074,
      "domains": [
       {
        "start": 53,
        "end": 176,
        "name": "TIGR00229",
        "description": "sensory_box: PAS domain S-box protein",
        "accession": "TIGR00229",
        "evalue": "1.3e-11",
        "score": "42.7",
        "html_class": "generic-type-other"
       },
       {
        "start": 304,
        "end": 435,
        "name": "TIGR00229",
        "description": "sensory_box: PAS domain S-box protein",
        "accession": "TIGR00229",
        "evalue": "1.2e-13",
        "score": "49.3",
        "html_class": "generic-type-other"
       },
       {
        "start": 429,
        "end": 559,
        "name": "TIGR00229",
        "description": "sensory_box: PAS domain S-box protein",
        "accession": "TIGR00229",
        "evalue": "4.7e-18",
        "score": "63.5",
        "html_class": "generic-type-other"
       },
       {
        "start": 566,
        "end": 691,
        "name": "TIGR00229",
        "description": "sensory_box: PAS domain S-box protein",
        "accession": "TIGR00229",
        "evalue": "6.6e-10",
        "score": "37.2",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 }
};
